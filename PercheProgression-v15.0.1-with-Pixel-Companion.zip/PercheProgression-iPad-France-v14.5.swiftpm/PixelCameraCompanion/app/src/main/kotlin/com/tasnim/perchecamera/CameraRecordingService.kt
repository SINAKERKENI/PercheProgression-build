package com.tasnim.perchecamera

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.CameraInfo
import androidx.camera.core.DynamicRange
import androidx.camera.core.CameraSelector
import androidx.camera.core.SessionConfig
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.HighSpeedVideoSessionConfig
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.RecordingManifest
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.time.Instant
import java.util.Properties
import java.util.UUID
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraRecordingService : LifecycleService() {
    data class InternalConfig(val public: CameraConfiguration, val cameraId: String, val quality: Quality, val highSpeed: Boolean)

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var activeRecording: Recording? = null
    private var activeFile: File? = null
    private var activeConfig: InternalConfig? = null
    private var recordingStartNanos: Long = 0
    private var stopFuture: CompletableFuture<RecordingManifest>? = null
    private val configs = ConcurrentHashMap<String, InternalConfig>()
    private val manifests = ConcurrentHashMap<String, RecordingManifest>()
    @Volatile private var latestFinalizedManifest: RecordingManifest? = null
    private lateinit var localServer: LocalCameraServer

    override fun onCreate() {
        super.onCreate()
        CompanionRuntime.service = this
        loadPersistedManifests()
        startForegroundNotification()
        LocalCameraServer(this).also { localServer = it; it.start() }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                rebuildConfigurations()
                if (CompanionRuntime.stateMachine.state.name == "ERROR") CompanionRuntime.stateMachine.recoverReady()
            } catch (_: Throwable) {
                CompanionRuntime.stateMachine.recordingFailed()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        localServer.stop()
        provider?.unbindAll()
        cameraExecutor.shutdown()
        CompanionRuntime.service = null
        super.onDestroy()
    }

    fun configurations(): List<CameraConfiguration> = configs.values.map { it.public }.sortedWith(compareBy({ it.lensLabel }, { it.width }, { it.fps }))

    fun startRemoteRecording(requested: CameraConfiguration?): CompletableFuture<Long> {
        val result = CompletableFuture<Long>()
        ContextCompat.getMainExecutor(this).execute {
            try {
                if (activeRecording != null) throw IllegalStateException("Un enregistrement est déjà en cours.")
                val config = requested?.id?.let(configs::get) ?: configs.values.firstOrNull()
                    ?: throw IllegalStateException("Aucune configuration caméra exploitable.")
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    throw SecurityException("Autorisation caméra refusée.")
                }
                bindAndRecord(config, result)
            } catch (t: Throwable) {
                CompanionRuntime.stateMachine.recordingFailed()
                result.completeExceptionally(t)
            }
        }
        return result
    }

    fun stopRemoteRecording(): CompletableFuture<RecordingManifest> {
        val recording = activeRecording ?: return CompletableFuture.failedFuture(IllegalStateException("Aucun enregistrement en cours."))
        val future = CompletableFuture<RecordingManifest>()
        stopFuture = future
        try {
            CompanionRuntime.stateMachine.stopRequested()
            recording.stop()
        } catch (t: Throwable) {
            stopFuture = null
            future.completeExceptionally(t)
        }
        return future
    }

    private fun bindAndRecord(config: InternalConfig, startFuture: CompletableFuture<Long>) {
        val provider = requireNotNull(provider) { "CameraX n’est pas prêt." }
        provider.unbindAll()
        val selector = CameraSelector.Builder().addCameraFilter { infos ->
            infos.filter { Camera2CameraInfo.from(it).cameraId == config.cameraId }
        }.build()
        val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(config.quality)).build()
        val videoCapture = VideoCapture.withOutput(recorder)
        val fpsRange = Range(config.public.fps, config.public.fps)
        if (config.highSpeed) {
            val session = HighSpeedVideoSessionConfig.Builder(videoCapture)
                .setFrameRateRange(fpsRange)
                .setSlowMotionEnabled(false)
                .build()
            provider.bindToLifecycle(this, selector, session)
        } else {
            val session = SessionConfig.Builder(videoCapture).setFrameRateRange(fpsRange).build()
            val info = provider.getCameraInfo(selector)
            require(info.getSupportedFrameRateRanges(session).any { it.contains(config.public.fps) }) { "Cadence non prise en charge avec cette configuration." }
            provider.bindToLifecycle(this, selector, session)
        }

        val recordings = File(filesDir, "recordings").apply { mkdirs() }
        val id = UUID.randomUUID().toString()
        val file = File(recordings, "$id.mp4")
        var pending: PendingRecording = recorder.prepareRecording(this, FileOutputOptions.Builder(file).build())
        if (config.public.audioEnabled && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }
        activeFile = file
        activeConfig = config
        val recording = pending.start(cameraExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    recordingStartNanos = System.nanoTime()
                    CompanionRuntime.stateMachine.recordingStarted()
                    startFuture.complete(recordingStartNanos)
                }
                is VideoRecordEvent.Finalize -> finalizeRecording(event, id, file, config, startFuture)
            }
        }
        activeRecording = recording
    }

    private fun finalizeRecording(event: VideoRecordEvent.Finalize, id: String, file: File, config: InternalConfig, startFuture: CompletableFuture<Long>) {
        activeRecording = null
        activeFile = null
        activeConfig = null
        if (event.hasError() || !file.isFile || file.length() <= 0) {
            CompanionRuntime.stateMachine.recordingFailed()
            val error = IllegalStateException("CameraX Finalize a signalé l’erreur ${event.error}.")
            if (!startFuture.isDone) startFuture.completeExceptionally(error)
            stopFuture?.completeExceptionally(error)
            stopFuture = null
            return
        }
        try {
            val metadata = readMetadata(file)
            val manifest = RecordingManifest(
                recordingID = id,
                filename = file.name,
                sizeBytes = file.length(),
                sha256 = sha256(file),
                createdAtISO8601 = Instant.ofEpochMilli(file.lastModified()).toString(),
                durationSeconds = metadata.first,
                width = metadata.second.first,
                height = metadata.second.second,
                nominalFPS = config.public.fps.toDouble(),
                lensLabel = config.public.lensLabel,
                orientation = if (metadata.second.first >= metadata.second.second) "landscape" else "portrait",
                transferPath = "/recordings/$id",
            )
            CompanionRuntime.stateMachine.recordingFinalized(manifest)
            manifests[manifest.recordingID] = manifest
            latestFinalizedManifest = manifest
            persistManifest(manifest)
            stopFuture?.complete(manifest)
        } catch (t: Throwable) {
            CompanionRuntime.stateMachine.recordingFailed()
            stopFuture?.completeExceptionally(t)
        } finally {
            stopFuture = null
        }
    }

    private fun rebuildConfigurations() {
        val provider = provider ?: return
        val next = mutableMapOf<String, InternalConfig>()
        for (info in provider.availableCameraInfos) {
            val camera2 = Camera2CameraInfo.from(info)
            val id = camera2.cameraId
            val facing = info.lensFacing
            val label = when (facing) {
                CameraSelector.LENS_FACING_BACK -> "Arrière · $id"
                CameraSelector.LENS_FACING_FRONT -> "Avant · $id"
                else -> "Caméra $id"
            }
            val stabilizationModes = camera2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
            val stabilization = stabilizationModes.any { it != CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_OFF }
            val capabilities = Recorder.getVideoCapabilities(info)
            for (quality in capabilities.getSupportedQualities(DynamicRange.SDR)) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                val probe = SessionConfig.Builder(capture).build()
                val supportedRanges = info.getSupportedFrameRateRanges(probe)
                for (fps in listOf(30, 60)) if (supportedRanges.any { it.contains(fps) }) {
                    val public = CameraConfiguration("$id|${qualityName(quality)}|$fps", label, w, h, fps, stabilization)
                    next[public.id] = InternalConfig(public, id, quality, false)
                }
            }

            val highCaps = Recorder.getHighSpeedVideoCapabilities(info)
            for (quality in highCaps?.getSupportedQualities(DynamicRange.SDR).orEmpty()) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                for (fps in listOf(120, 240)) {
                    try {
                        val probe = HighSpeedVideoSessionConfig.Builder(capture)
                            .setFrameRateRange(Range(fps, fps)).setSlowMotionEnabled(false).build()
                        if (info.getSupportedFrameRateRanges(probe).any { it.contains(fps) }) {
                            val public = CameraConfiguration("$id|${qualityName(quality)}|$fps", label, w, h, fps, stabilization)
                            next[public.id] = InternalConfig(public, id, quality, true)
                        }
                    } catch (_: IllegalArgumentException) { /* unsupported combination: do not expose */ }
                }
            }
        }
        configs.clear(); configs.putAll(next)
    }

    private fun qualityName(q: Quality) = when (q) { Quality.UHD -> "UHD"; Quality.FHD -> "FHD"; Quality.HD -> "HD"; Quality.SD -> "SD"; else -> q.toString() }
    private fun qualityResolution(q: Quality): Pair<Int, Int>? = when (q) {
        Quality.UHD -> 3840 to 2160; Quality.FHD -> 1920 to 1080; Quality.HD -> 1280 to 720; Quality.SD -> 720 to 480; else -> null
    }

    private fun readMetadata(file: File): Pair<Double, Pair<Int, Int>> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val duration = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
            val width = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            duration to (width to height)
        } finally { r.release() }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun latestManifest(): RecordingManifest? = latestFinalizedManifest ?: CompanionRuntime.stateMachine.finalizedManifest

    fun manifest(recordingID: String): RecordingManifest? = manifests[recordingID]

    fun finalizedFile(recordingID: String): File? {
        val manifest = manifests[recordingID] ?: return null
        val file = File(filesDir, "recordings/${manifest.filename}")
        return file.takeIf(File::isFile)
    }

    private fun persistManifest(manifest: RecordingManifest) {
        val dir = File(filesDir, "recordings").apply { mkdirs() }
        val props = Properties().apply {
            setProperty("recordingID", manifest.recordingID)
            setProperty("filename", manifest.filename)
            setProperty("sizeBytes", manifest.sizeBytes.toString())
            setProperty("sha256", manifest.sha256)
            setProperty("createdAtISO8601", manifest.createdAtISO8601)
            setProperty("durationSeconds", manifest.durationSeconds.toString())
            setProperty("width", manifest.width.toString())
            setProperty("height", manifest.height.toString())
            setProperty("nominalFPS", manifest.nominalFPS.toString())
            setProperty("lensLabel", manifest.lensLabel)
            setProperty("orientation", manifest.orientation)
            setProperty("transferPath", manifest.transferPath)
        }
        File(dir, "${manifest.recordingID}.manifest").outputStream().use { props.store(it, "Perche Camera Companion recording") }
    }

    private fun loadPersistedManifests() {
        val dir = File(filesDir, "recordings")
        if (!dir.isDirectory) return
        val loaded = dir.listFiles { file -> file.extension == "manifest" }.orEmpty().mapNotNull { file ->
            try {
                val p = Properties().also { props -> file.inputStream().use(props::load) }
                RecordingManifest(
                    p.getProperty("recordingID"), p.getProperty("filename"), p.getProperty("sizeBytes").toLong(),
                    p.getProperty("sha256"), p.getProperty("createdAtISO8601"), p.getProperty("durationSeconds").toDouble(),
                    p.getProperty("width").toInt(), p.getProperty("height").toInt(), p.getProperty("nominalFPS").toDouble(),
                    p.getProperty("lensLabel"), p.getProperty("orientation"), p.getProperty("transferPath")
                ).takeIf { File(dir, it.filename).isFile }
            } catch (_: Throwable) { null }
        }.sortedBy { it.createdAtISO8601 }
        loaded.forEach { manifests[it.recordingID] = it }
        latestFinalizedManifest = loaded.lastOrNull()
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val channelId = "remote_camera"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "Caméra distante", NotificationManager.IMPORTANCE_LOW))
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Perche Camera Companion")
            .setContentText("Caméra distante disponible sur le réseau local")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
        startForeground(1500, notification)
    }
}
