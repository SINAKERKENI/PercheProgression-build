# Changement v14.3 — catégories de la Training Library

## Taxonomie affichée

La bibliothèque utilise désormais exactement les dix catégories visibles dans l’application de référence, dans le même ordre :

1. Warm-up
2. PV Drills
3. Med Ball
4. Strength
5. Gym
6. Core
7. Plyo
8. Flexibility
9. Rehab
10. Running

Le filtre global porte le libellé « All ». Les nombres affichés dans chaque pastille ne sont pas les valeurs fictives de la capture : ils sont calculés en temps réel à partir des vidéos réellement enregistrées.

## Migration des données v14.2

La migration est automatique et non destructive :

| Ancienne catégorie | Nouvelle catégorie |
| --- | --- |
| Présentation, Impulsion, Renversement, Extension, Demi-tour, Franchissement | PV Drills |
| Abdos & gainage | Core |
| Gymnastique | Gym |
| Sprint & course d’élan | Running |
| Force & mobilité | Strength |

Les URL, titres, descriptions, vignettes et dates sont conservés. Les cinq autres catégories démarrent vides et peuvent recevoir de nouvelles vidéos depuis le formulaire d’ajout.

## Compatibilité

- Bundle identifier inchangé : `com.tasnim.vaultroadmap.ipad`.
- Schéma SwiftData inchangé ; seules les valeurs de catégorie sont migrées.
- Export JSON passé au schéma v6 afin d’identifier la nouvelle taxonomie.
