# Perche Progression v13.3 — calibration fine, vitesses visibles et bibliothèque vidéo réelle

## 1. Grille et repères de calibration

- Traits de grille fortement affinés : les lignes principales, intermédiaires et l’origine ne masquent plus le revêtement de piste.
- Poignées visuelles réduites de 60 px à 32 px tout en conservant une grande zone tactile invisible pour le doigt.
- Croix centrale et cercle de sélection affinés ; le réglage au pixel de la v13.2 est conservé.
- Le repère d’échelle réelle et la trajectoire de suivi ont également été affinés pour éviter de masquer les détails vidéo.

## 2. Retour des valeurs de vitesse

- La vitesse moyenne/représentative s’affiche désormais directement sur la vidéo dès qu’un résultat de tracking existe.
- En mode **Mesurer**, une carte de résultat dédiée affiche en permanence : moyenne de zone, pic P95 et vitesse longitudinale au curseur.
- Le repère mobile affiche explicitement la **vitesse longitudinale** plutôt qu’une résultante 2D pouvant être trompeuse.
- Le panneau Biomécanique détaillé est conservé pour les mesures au curseur et les accélérations.

## 3. Bibliothèque d’exercices

- Les anciens clips locaux sont maintenant explicitement présentés comme des **repères vidéo schématiques**, et non comme des démonstrations réalistes de référence.
- Ajout d’une section **Vidéos réelles · sources officielles** avec accès aux catalogues de Tibo InShape Entrainement (abdos/gainage), Team-Hoot Pole Vault, Pole Vault Swing-Up Rack et Get Gymnast Fit.
- Les contenus tiers ne sont pas copiés dans le bundle : l’application ouvre la source officielle, ce qui évite les copies non autorisées et garde les catalogues à jour.
- Chaque fiche locale propose maintenant un accès contextuel vers une démonstration réelle pertinente (Team-Hoot ou Swing-Up Rack selon la phase).

---

# Perche Progression v13.2 — calibration relative, plein écran analytique et réglage pixel

## 1. Butoir hors champ en caméra fixe

- Le mode caméra fixe possède maintenant deux origines métriques : **Butoir visible** et **Butoir hors champ**.
- Si le butoir est hors cadre, l’utilisateur peut calibrer un quadrilatère réel quelconque de longueur et largeur connues sur le plan de la piste.
- La vitesse longitudinale reste métrique car une translation d’origine ne modifie pas `ΔX/Δt`.
- La distance absolue d’impulsion depuis le butoir est explicitement désactivée dans ce cas : l’application ne fabrique pas une origine 0 m.
- La grille fixe et le type d’origine sont maintenant sauvegardés dans `MotionAnalysisResult`, ce qui permet de restaurer correctement une analyse fixe après réouverture.

## 2. Grille de précision v2

- Les libellés des coins ne supposent plus une zone de 5 m : ils utilisent la longueur réellement saisie.
- La ligne proche affiche soit `FOND DU BUTOIR`, soit `LIGNE DE RÉFÉRENCE` selon le protocole.
- Après sélection d’un coin, un panneau de **micro-ajustement au pixel** apparaît.
- Les quatre flèches déplacent le coin par pas de 1 px ou 5 px, avec guides croisés persistants.
- Ce réglage évite que le doigt masque le point exact lors de la dernière phase de calibration.

## 3. Plein écran réellement analytique

- Le plein écran conserve maintenant les couches d’analyse : grille, échelle réelle, repères fixes, suivi, impulsion, bassin, posture, vecteurs et dessin PencilKit.
- Une calibration commencée dans la vue principale peut donc être affinée directement en plein écran.
- Les contrôles plein écran se masquent automatiquement pour libérer l’image et réapparaissent au toucher.
- Le mode d’outil actif est affiché dans la barre supérieure afin d’éviter les erreurs de manipulation.

## 4. Validation

- `swiftc -parse` : tous les fichiers Swift passent.
- Type-check du noyau Foundation : Domain + homographie + configuration + service caméra fixe passent.
- Test exécutable synthétique : une trajectoire à 5,000 m/s donne 5,000 m/s avec origine butoir **et** avec origine relative.
- Test de persistance : la grille fixe et l’origine relative survivent à l’encodage de `MotionAnalysisResult`.

---

# Correctif v13.1.1 — compilation Swift Playgrounds

- Correction de `DynamicCalibrationOverlayView` : suppression de l’appel ambigu à `.formatted(.number...)` sur des valeurs `CGFloat`.
- Les coordonnées de réglage fin utilisent maintenant un `String(format:)` avec conversion explicite en `Double`.
- Validation `swiftc -parse` relancée sur tous les fichiers Swift : OK.

---

# Perche Progression v13.1 — précision de grille, workflow sans butoir et ergonomie vidéo

## Nouveautés v13.1

- **Grille de calibration plus précise** : maille longitudinale densifiée (jusqu’à 0,25 m), lignes latérales intermédiaires et lecture plus fine des distances.
- **Réglage fin des coins** : pendant le glisser d’une poignée, des guides horizontaux/verticaux apparaissent pour aider l’alignement précis des quatre coins au sol.
- **Plein écran plus accessible** : le bouton n’est plus perdu dans la barre d’outils ; un petit bouton flottant s’affiche en bas à droite uniquement quand l’utilisateur touche la vidéo.
- **Butoir hors champ mieux géré** : ajout d’un encart explicite dans le workflow caméra mobile pour basculer sans ambiguïté vers le protocole “sans butoir”, au lieu d’inciter à forcer une fausse grille.
- **Consignes de calibration clarifiées** : les aides utilisateur expliquent maintenant le réglage fin, la logique des guides et le fait qu’une grille ne doit jamais être improvisée si le butoir est masqué.

---

# Perche Progression v13.0 — intégrité des données, mesure fixe et recommandation de perches


## 1. Données et diagrammes

- Toutes les tentatives, métriques, progressions de perches et dimensions radar sont désormais filtrées sur **l’athlète actif** avant calcul.
- Les records entraînement / compétition utilisent maintenant le vrai `VaultSessionRecord.kind` au lieu de déduire le type de séance depuis `attemptNumber`.
- Suppression du faux polygone « saison précédente » qui était généré en soustrayant des constantes aux valeurs actuelles.
- Les courbes quantitatives utilisent une interpolation **linéaire** afin de ne pas créer d’overshoot visuel entre deux mesures réelles.
- Le suivi par homographie dynamique n’utilise plus le « top 20 % » comme valeur principale : la vitesse affichée est désormais `|ΔX métrique| / Δt PTS`, et le pic est le 95e percentile des vitesses horizontales.

## 2. Caméra fixe face ou en biais

- Le mode fixe est présenté comme « caméra fixe – face ou biais » : la même homographie plane couvre les vues quasi perpendiculaires et obliques lorsque les quatre points sont réellement coplanaires au sol.
- En mode **point au sol**, la validation n’impose plus la détection préalable du bassin.
- Le bouton de reproposition Vision est masqué pour le point au sol : Vision peut proposer un bassin 2D, pas sa projection métrique exacte sur la piste.
- Les messages et contrôles indiquent désormais le véritable point mesuré (point au sol ou bassin).
- Le score qualité fixe n’est plus une constante 0,94/0,95. Il dérive du conditionnement géométrique de la grille et de la cohérence cinématique, et reste explicitement un score de qualité non probabiliste.
- Version du pipeline fixe : `Homographie fixe ... v2`; paramètres reproductibles : `video-analysis-params-v13.0`.
- Les exports vidéo distinguent maintenant explicitement une référence au plan du sol, une verticale estimée et une mesure estimée/vérifiée ; le suivi bassin/torse avec homographie dynamique reste signalé comme estimation à cause de la parallaxe hors plan.
- Le recalcul manuel du bassin ne fabrique plus de confiances fixes 0,94/0,98 : sa qualité reprend celle de la calibration/stabilisation réellement disponible.
- Dans ce recalcul manuel, la vitesse principale est désormais une moyenne longitudinale métrique sur l’intervalle PTS et l’accélération principale reste strictement longitudinale ; la verticale estimée n’est plus recombinée dans une pseudo-accélération 2D.

## 3. Recommandation de perches v13

- Nouveau moteur `pole-readiness-v13.0`.
- Indice de préparation 0–100 fondé sur les sauts récents pondérés, le taux de réussite, la maîtrise, les diagnostics répétés, la stabilité de l’impulsion, la quantité de données et la régularité de vitesse.
- Les vitesses ne sont comparées que lorsqu’elles appartiennent au **même protocole** (`5 m`, radar, etc.).
- Deux signaux récents « perche trop dure » ou refus de planter bloquent la montée de perche au lieu d’être dilués dans un score moyen.
- Les changements simultanés de longueur, gamme/fabricant et flex diminuent la confiance et génèrent des avertissements explicites.
- L’UI affiche l’indice de préparation, le nombre de sauts utilisés et la version du modèle.
- La hauteur de prise et les limites constructeur n’étant pas encore modélisées, la recommandation reste une aide à la décision et non une garantie de sécurité.

## 4. Validation ajoutée

- Tests unitaires du moteur de perches : série stable, blocage sur signaux « trop dure », séparation des protocoles de vitesse.
- Validation syntaxique `swiftc -parse` sur l’ensemble des fichiers Swift.
- Type-check du noyau pur Foundation (`Domain`, homographie, configuration et moteur de perches) dans l’environnement disponible.
