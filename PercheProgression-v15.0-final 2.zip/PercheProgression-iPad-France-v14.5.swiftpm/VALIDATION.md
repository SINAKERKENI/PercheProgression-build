# Validation v15.0.0

| Zone | Test | Résultat | Notes |
|---|---|---|---|
| Swift source | `swiftc -frontend -parse` AppModule + Tests | **80/80 parsés** | Swift 6.2.1 Linux ; validation syntaxique, pas un build iOS |
| Swift Concurrency caméra distante | modèle de transport/delegate reproduit sous `-swift-version 6 -strict-concurrency=complete -warnings-as-errors` | **Réussi** | vérifie l’architecture actor/Task/continuation sans SDK Apple |
| Caméra distante Swift | tests de concurrence `RemoteCameraConcurrencyTests` | **5/5 réussis** | succès/timeout, déconnexion/réponse, annulation/réponse, doublons, découverte rapide |
| Décision de perche | `PoleRecommendationEngineTests` | **16/16 réussis** | `pole-decision-v15.0` |
| Perspective | `PerspectiveAwareSpeedEngineTests` | **7/7 réussis** | inclut rejet calibration mauvaise/dégénérée |
| Perspective | erreur de reconstruction des scénarios valides précédemment exécutés | **≈ 1,6–1,7 %** | objectif < 5 % |
| FFA | fixtures backend parser/import/déduplication | **4/4 réussies** | sans réseau FFA live |
| Pixel Kotlin | protocole/machine d’état indépendante d’Android | **Réussi** | `ProtocolSelfTest: PASS` |
| Apple/Xcode | build utilisateur antérieur | **Diagnostics reçus puis corrigés dans cette révision** | exclusivité `config`, isolation Bonjour, variable `resumed`, warnings VideoLab ; Xcode/SDK Apple absents ici, rerun requis pour confirmer le build Apple |
| Android CameraX | build APK complet | **Non exécutable ici** | SDK Android absent |
| Pixel + iPad | enregistrement/transfert réel | **Matériel requis** | checklist dédiée |
| Migration SwiftData | store binaire v14.5 réel | **Runtime Apple requis** | aucune validation binaire simulée comme réussite |

## Correctifs issus du build Apple

- L’accès exclusif à `config` a été corrigé en copiant la configuration sélectionnée dans `updatedConfig`, puis en appliquant les changements avant l’affectation finale.
- `BonjourCameraDiscovery` est désormais uniquement l’état observable `@MainActor`; les conformances Foundation sont portées par `BonjourCameraDiscoveryWorker`, qui ne transfère vers l’UI que des valeurs `Sendable`.
- Le booléen capturé `resumed` a été supprimé. La continuation de connexion appartient à `PixelControlTransport` (acteur) et un `RemoteConnectionAttemptGate` autorise un seul événement terminal.
- Les continuations de requêtes sont également possédées par l’acteur et retirées avant `resume`; annulation, réponse, erreur réseau et timeout sont donc idempotents.
- `scaleIsValid` et `anchorsAreValid` ont été supprimés du panneau unifié : ils validaient l’ancien protocole échelle/repères et ne participaient plus au pipeline perspective actif. Les anciens flux qui les utilisent encore possèdent leurs propres `guard`.
