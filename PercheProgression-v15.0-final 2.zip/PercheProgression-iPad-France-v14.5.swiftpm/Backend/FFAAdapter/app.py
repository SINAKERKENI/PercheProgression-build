"""Perche Progression FFA adapter.

This service intentionally DOES NOT scrape public athle.fr HTML. Current public result pages
state that displayed data may not be copied. Deploy only with an authorized/documented structured
FFA feed or webservice configured through environment variables.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx
from fastapi import FastAPI, HTTPException, Query, Response

APP = FastAPI(title="Perche Progression FFA Adapter", version="15.0.0")
UPSTREAM = os.getenv("FFA_UPSTREAM_BASE_URL", "").rstrip("/")
TOKEN = os.getenv("FFA_UPSTREAM_BEARER_TOKEN", "")
SEARCH_PATH = os.getenv("FFA_SEARCH_PATH", "/athletes/search")
PERF_PATH = os.getenv("FFA_PERFORMANCES_PATH", "/athletes/{athlete_id}/performances")
CACHE_DB = Path(os.getenv("FFA_CACHE_DB", "/tmp/perche-ffa-cache.sqlite3"))
CACHE_TTL = int(os.getenv("FFA_CACHE_TTL_SECONDS", "21600"))  # 6 h
MIN_UPSTREAM_INTERVAL = float(os.getenv("FFA_MIN_UPSTREAM_INTERVAL_SECONDS", "2"))

_lock = threading.Lock()
_last_request_by_key: dict[str, float] = {}


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(CACHE_DB)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, etag TEXT, body BLOB NOT NULL, fetched REAL NOT NULL)"
    )
    return conn


def _cached(key: str) -> tuple[str | None, bytes, float] | None:
    with _db() as conn:
        row = conn.execute("SELECT etag, body, fetched FROM cache WHERE key=?", (key,)).fetchone()
    return (row[0], bytes(row[1]), float(row[2])) if row else None


def _store(key: str, etag: str | None, body: bytes) -> None:
    with _db() as conn:
        conn.execute(
            "INSERT INTO cache(key, etag, body, fetched) VALUES(?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET etag=excluded.etag, body=excluded.body, fetched=excluded.fetched",
            (key, etag, body, time.time()),
        )


def _require_upstream() -> None:
    if not UPSTREAM:
        raise HTTPException(
            503,
            "Aucun webservice FFA autorisé n’est configuré. Définissez FFA_UPSTREAM_BASE_URL côté serveur.",
        )


def _throttle(key: str) -> None:
    with _lock:
        now = time.monotonic()
        last = _last_request_by_key.get(key, 0.0)
        delay = MIN_UPSTREAM_INTERVAL - (now - last)
    if delay > 0:
        time.sleep(delay)
    with _lock:
        _last_request_by_key[key] = time.monotonic()


def _request(path: str, params: dict[str, str], *, force: bool = False) -> Any:
    _require_upstream()
    cache_key = hashlib.sha256((path + "?" + json.dumps(params, sort_keys=True)).encode()).hexdigest()
    cached = _cached(cache_key)
    if cached and not force and time.time() - cached[2] < CACHE_TTL:
        return json.loads(cached[1])

    headers = {"Accept": "application/json", "User-Agent": "PercheProgression-FFAAdapter/15.0"}
    if TOKEN:
        headers["Authorization"] = f"Bearer {TOKEN}"
    if cached and cached[0]:
        headers["If-None-Match"] = cached[0]

    _throttle(cache_key)
    try:
        with httpx.Client(timeout=12.0, follow_redirects=False) as client:
            r = client.get(f"{UPSTREAM}{path}", params=params, headers=headers)
    except httpx.HTTPError as exc:
        if cached:
            return json.loads(cached[1])  # stale-if-error, never deletes local history
        raise HTTPException(503, f"Webservice FFA indisponible: {type(exc).__name__}") from exc

    if r.status_code == 304 and cached:
        _store(cache_key, cached[0], cached[1])
        return json.loads(cached[1])
    if r.status_code in (401, 403, 429):
        # Never bypass access controls or anti-bot responses.
        if cached:
            return json.loads(cached[1])
        raise HTTPException(r.status_code, "Accès FFA non autorisé ou temporairement limité.")
    if not 200 <= r.status_code < 300:
        if cached:
            return json.loads(cached[1])
        raise HTTPException(502, f"Le webservice FFA a répondu {r.status_code}.")
    if "json" not in r.headers.get("content-type", "").lower():
        raise HTTPException(502, "Le webservice configuré n’a pas renvoyé de JSON structuré.")
    body = r.content
    _store(cache_key, r.headers.get("etag"), body)
    return r.json()


def _pick(item: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in item and item[key] not in (None, ""):
            return item[key]
    return default


def normalize_athlete(item: dict[str, Any]) -> dict[str, Any]:
    athlete_id = str(_pick(item, "id", "athleteId", "athlete_id", "ffaAthleteID", default="")).strip()
    if not athlete_id:
        raise ValueError("athlete id missing")
    year = _pick(item, "birthYear", "birth_year")
    return {
        "id": athlete_id,
        "firstName": str(_pick(item, "firstName", "first_name", "prenom", default="")).strip(),
        "lastName": str(_pick(item, "lastName", "last_name", "nom", default="")).strip(),
        "birthYear": int(year) if str(year).isdigit() else None,
        "club": _pick(item, "club", "clubName", "club_name"),
        "licenseOrPPS": _pick(item, "licenseOrPPS", "licence", "license", "pps"),
    }


def _iso_date(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError("date missing")
    # Preserve an upstream ISO timestamp/date; Swift's ISO8601 decoder expects a timestamp.
    if len(text) == 10 and text[4] == "-" and text[7] == "-":
        return text + "T00:00:00Z"
    if text.endswith("Z") or "+" in text[10:]:
        return text
    try:
        return datetime.fromisoformat(text).replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")
    except ValueError as exc:
        raise ValueError("invalid date") from exc


def normalize_performance(item: dict[str, Any], athlete_id: str) -> dict[str, Any]:
    source_id = str(_pick(item, "id", "resultId", "result_id", "sourceResultID", default="")).strip()
    return {
        "id": source_id,
        "athleteID": athlete_id,
        "event": str(_pick(item, "event", "eventName", "epreuve", default="")).strip(),
        "performance": str(_pick(item, "performance", "result", "perf", default="")).strip(),
        "date": _iso_date(_pick(item, "date", "competitionDate", "eventDate")),
        "indoor": _pick(item, "indoor", "isIndoor"),
        "venue": _pick(item, "venue", "lieu"),
        "competition": _pick(item, "competition", "competitionName"),
        "place": str(_pick(item, "place", "rank", "ranking", default="")) or None,
        "level": _pick(item, "level", "niveau"),
        "sourceURL": _pick(item, "sourceURL", "sourceUrl", "url"),
    }


def _items(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "results", "athletes", "performances", "data"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    raise ValueError("unsupported structured payload")


@APP.get("/health")
def health() -> dict[str, Any]:
    return {"ok": True, "authorizedUpstreamConfigured": bool(UPSTREAM)}


@APP.get("/ffa/athletes/search")
def search_athletes(
    firstName: str = "", lastName: str = "", licenseOrPPS: str = "",
    birthYear: int | None = None, club: str = "",
) -> list[dict[str, Any]]:
    if not any([firstName.strip(), lastName.strip(), licenseOrPPS.strip()]):
        raise HTTPException(400, "Nom, prénom ou licence/PPS requis.")
    params = {"firstName": firstName, "lastName": lastName, "licenseOrPPS": licenseOrPPS, "club": club}
    if birthYear is not None:
        params["birthYear"] = str(birthYear)
    try:
        return [normalize_athlete(x) for x in _items(_request(SEARCH_PATH, params))]
    except ValueError as exc:
        raise HTTPException(502, f"Réponse athlète FFA non reconnue: {exc}") from exc


@APP.get("/ffa/athletes/{athlete_id}/performances")
def performances(athlete_id: str, force: bool = Query(False)) -> list[dict[str, Any]]:
    if not athlete_id or len(athlete_id) > 128:
        raise HTTPException(400, "Identifiant athlète invalide.")
    path = PERF_PATH.format(athlete_id=quote(athlete_id, safe=""))
    try:
        return [normalize_performance(x, athlete_id) for x in _items(_request(path, {}, force=force))]
    except ValueError as exc:
        raise HTTPException(502, f"Réponse performance FFA non reconnue: {exc}") from exc
