import importlib.util, json, pathlib, sys, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("ffa_adapter", ROOT / "app.py")
mod = importlib.util.module_from_spec(spec); sys.modules["ffa_adapter"] = mod; spec.loader.exec_module(mod)

class AdapterTests(unittest.TestCase):
    def load(self, name): return json.loads((ROOT / "tests/fixtures" / name).read_text())
    def test_athlete_candidates_remain_distinct(self):
        items = [mod.normalize_athlete(x) for x in mod._items(self.load("athletes.json"))]
        self.assertEqual([x["id"] for x in items], ["A123", "B456"])
        self.assertNotEqual(items[0]["birthYear"], items[1]["birthYear"])
    def test_performance_normalization_preserves_event_and_source_id(self):
        items = [mod.normalize_performance(x, "A123") for x in mod._items(self.load("performances.json"))]
        self.assertEqual(items[0]["id"], "R1")
        self.assertEqual(items[0]["event"], "Perche - Salle")
        self.assertEqual(items[0]["performance"], "4m20")
        self.assertEqual(items[0]["date"], "2024-02-03T00:00:00Z")
    def test_structured_payload_required(self):
        with self.assertRaises(ValueError): mod._items("html is not parsed")
    def test_missing_upstream_fails_closed(self):
        old = mod.UPSTREAM; mod.UPSTREAM = ""
        try:
            with self.assertRaises(Exception): mod._require_upstream()
        finally: mod.UPSTREAM = old

if __name__ == "__main__": unittest.main()
