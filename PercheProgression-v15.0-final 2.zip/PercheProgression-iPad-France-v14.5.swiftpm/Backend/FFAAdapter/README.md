# FFA Adapter

This adapter is the only network component used by the iPad FFA provider. It deliberately does **not** scrape public `athle.fr` result HTML: current FFA result pages state that displayed data may not be copied. Deploy it only after obtaining an authorized/documented structured FFA data source.

## Configuration

Set `FFA_UPSTREAM_BASE_URL` to the approved structured service. If required, set `FFA_UPSTREAM_BEARER_TOKEN` on the server only. Optional `FFA_SEARCH_PATH` and `FFA_PERFORMANCES_PATH` adapt endpoint paths. Never place the upstream credential in the iPad application.

The adapter exposes `/ffa/athletes/search` and `/ffa/athletes/{id}/performances`, uses a persistent SQLite response cache, forwards ETags with `If-None-Match`, applies per-query throttling, serves stale cache on transient upstream failures, and never retries/bypasses 401/403/429 controls.

Run with `uvicorn app:APP --host 0.0.0.0 --port 8080` behind TLS/reverse proxy in production.
