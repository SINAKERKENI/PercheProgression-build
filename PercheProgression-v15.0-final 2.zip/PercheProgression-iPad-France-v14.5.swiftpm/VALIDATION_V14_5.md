# Validation v14.5

## Catalogue intégré

| Catégorie | Fiches |
| --- | ---: |
| Warm-up | 16 |
| PV Drills | 31 |
| Med Ball | 39 |
| Strength | 36 |
| Gym | 82 |
| Core | 16 |
| Plyo | 8 |
| Flexibility | 6 |
| Rehab | 11 |
| Running | 2 |
| **Total** | **247** |

- 247 identifiants distincts.
- 247 couples catégorie–URL distincts.
- 246 valeurs d’URL distinctes : une URL est volontairement conservée dans deux catégories.
- 247 URL HTTPS valides.

## Contrôles source

- Un seul modificateur `.fileImporter` dans `VideoLabView`.
- Aucun ancien état `showingRelinkImporter`.
- Ressource JSON incluse par `Package.swift` via `.process("Resources")`.
- Bundle identifier inchangé.
- Version 14.5, build 33.

La compilation et l’essai matériel final doivent être effectués dans Swift Playgrounds ou Xcode sur iPad/macOS.
