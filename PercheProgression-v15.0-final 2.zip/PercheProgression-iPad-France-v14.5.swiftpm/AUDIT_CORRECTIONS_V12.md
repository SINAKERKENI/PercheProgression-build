# Perche Progression v12 — traçabilité de l’audit v11.1

Cette branche corrige en priorité la sécurité des données, la définition des métriques, le temps vidéo, la comparaison, la calibration et la lisibilité scientifique. Elle ne prétend pas transformer une estimation monoculaire en mesure de laboratoire : les éléments nécessitant un corpus terrain ou un iPad physique restent explicitement marqués comme tels.

**Statuts** : ✅ corrigé dans le code · 🟡 renforcé/partiel · 🧪 validation matérielle ou scientifique encore requise.

## 1. Critiques

| # | Statut | Correction v12 |
|---|---|---|
| 1 | ✅ | Suppression du reset destructif piloté par UserDefaults. Bootstrap non destructif. |
| 2 | ✅ | Marqueur d’impulsion indépendant pour chaque vidéo ; offset calculé entre les deux marqueurs. |
| 3 | ✅ | Taxonomie de vitesse séparée : 5 m, 10 m, pic, vidéo estimée, radar, impulsion. |
| 4 | ✅ | Accélération principale = accélération longitudinale uniquement ; plus de `hypot` métrique/image. |
| 5 | ✅ | Index navigation et principaux pipelines séquentiels basés sur les PTS réels via AVAssetReader. Fallback FPS explicitement signalé. |
| 6 | ✅ | Cible XCTest ajoutée : homographie, outlier, couverture calibration, taxonomie métrique. |

## 2. Persistance / SwiftData

| # | Statut | Correction v12 |
|---|---|---|
| 7 | ✅ | `PhysicalMetricRecord` est canonique ; `currentApproachSpeed` n’est plus qu’un cache de compatibilité synchronisé lors des écritures. |
| 8 | ✅ | `AttemptRecord.approachSpeedMPS` est documenté comme snapshot de tentative et reçoit `approachSpeedKindRaw` + source. |
| 9 | 🟡 | Pas de `SchemaMigrationPlan` rétroactif artificiel : l’historique v11 n’était pas versionné. Ajouter un faux snapshot historique risquerait précisément de rendre le store illisible. La v12 reste sur migration légère automatique et établit une base à versionner lors du prochain snapshot vérifié. |
| 10 | ✅ | Suppression des `try? modelContext.save()` silencieux ; centre d’erreurs global et sauvegardes explicites. |
| 11 | ✅ | L’écran de panne peut réellement réessayer l’ouverture du store et afficher le diagnostic. |
| 12 | 🟡 | Les repositories critiques utilisent des prédicats ; les vues principales filtrent maintenant par athlète. Certaines `@Query` chargent encore un ensemble plus large que nécessaire. |
| 13 | ✅ | Sélection explicite de l’athlète actif dans la sidebar si plusieurs profils existent, persistée dans UserDefaults. |
| 14 | 🟡 | Payloads versionnés/provenance renforcée, mais compression/external storage des gros JSON non activée afin de ne pas risquer une migration destructive non testée. |

## 3. Vidéo / comparaison / timeline

| # | Statut | Correction v12 |
|---|---|---|
| 15 | ✅ | Mode, offset, marqueur référence, transformation et opacité de comparaison persistés dans `VideoClipRecord`. |
| 16 | ✅ | « Transparence » utilise partout la même convention `1 - opacity`. |
| 17 | ✅ | Une seule source de vérité : `OverlayVideoTransform.opacity`. |
| 18 | ✅ | La vidéo de référence est vérifiée par SHA-256 comme la principale. |
| 19 | 🟡 | Corrections de dérive moins agressives et tolérances non nulles ; un timebase partagé AVPlayer complet reste un axe futur. |
| 20 | ✅ | Viewport principal + overlay + couches d’analyse partagent une transformation commune. |
| 21 | ✅ | Timeline sur PTS réels ; fallback dégradé annoncé si l’index média échoue. |
| 22 | 🧪 | Gestes restructurés, mais conflit doigt/Pencil/pinch à valider sur iPad physique. |
| 23 | ✅ | `accessibilityAdjustableAction` permet VoiceOver image précédente/suivante. |
| 24 | ✅ | Quatre espaces : Lecture, Comparer, Mesurer, Biomécanique. |
| 25 | ✅ | Lecture 2,0× ajoutée. |

## 4. Acquisition / précision temporelle

| # | Statut | Correction v12 |
|---|---|---|
| 26 | ✅ | Index de frame obtenu par recherche dans la table PTS. |
| 27 | ✅ | Timecode et navigation ne dépendent plus d’un FPS entier lorsque les PTS sont disponibles. |
| 28 | ✅ | Dernière frame = dernière entrée réelle de l’index PTS. |
| 29 | ✅ | Seek frame utilise le PTS de l’échantillon ciblé. |
| 30 | ✅ | Cadence PTS, vitesse de lecture, FPS d’analyse effectif et nombre d’échantillons sont affichés. |
| 31 | 🟡 | AVAssetReader est utilisé pour indexer les samples ; le décodage Vision garde encore AVAssetImageGenerator afin de préserver la transformation/orientation dans cette révision. |
| 32 | ✅ | UI distingue cadence média PTS, lecture × et cadence d’analyse. |

## 5. Vision / pose

| # | Statut | Correction v12 |
|---|---|---|
| 33 | ✅ | Seuil articulation relevé et centralisé (`0.35`). |
| 34 | ✅ | Minimum de joints + racine/épaules/hanches + chaîne jambe requis. |
| 35 | 🟡 | Détection du pied d’impulsion utilise une courte séquence ; filtre temporel complet du squelette encore à ajouter. |
| 36 | 🟡 | Association temporelle locale bbox/squelette pour le pied ; ré-identification multi-personnes continue/embedding non implémentée. |
| 37 | ✅ | Pied proposé sur plusieurs frames avec score contact/mouvement et validation manuelle obligatoire. |
| 38 | ✅ | La bbox suivie peut être réancrée sur une redétection humaine globale, ce qui réadapte aussi sa taille lorsque le sujet grossit dans l’image. |
| 39 | ✅ | Redétection humaine globale périodique (~0,5 s) + redensification des repères de décor pour limiter la dérive locale. |
| 40 | 🧪 | Pas de modèle d’occlusion spécialisé perche/montants/tapis. |
| 41 | 🧪 | Pas de correction optique générique sans métadonnées caméra fiables ; protocole UX avertit de l’ultra-grand-angle. |
| 42 | 🧪 | Rolling shutter non corrigé ; protocole d’acquisition demande de limiter les panoramiques rapides. |

## 6. Calibration géométrique

| # | Statut | Correction v12 |
|---|---|---|
| 43 | 🟡 | Multi-ancrages + RANSAC conservés et seuils de tracking renforcés ; passage complet à optical-flow/KLT reste futur. |
| 44 | ✅ | Les valeurs sont présentées comme « score qualité non probabiliste », plus comme probabilité de confiance. |
| 45 | ✅ | Corrections manuelles : plus de 0,96 / 2,5 cm inventés ; incertitude inconnue = nil/0 interne et affichage explicite. |
| 46 | ✅ | L’erreur auto n’est plus remplacée par une constante arbitraire lorsqu’aucun résidu indépendant n’existe. |
| 47 | ✅ | `validatedSample` impose un delta temporel maximal dérivé de l’échantillonnage réel. |
| 48 | ✅ | `isUsable` exige une couverture fiable >= 80 %, pas seulement un échantillon valide. |
| 49 | ✅ | `manualRequired` / `unavailable` sont exclus des métriques. |
| 50 | ✅ | Les trous `manualRequired` ne sont plus réparés temporellement par interpolation de coins ; ils restent invalides jusqu’à correction/retracking. |

## 7. Homographie

| # | Statut | Correction v12 |
|---|---|---|
| 51 | ✅ | Suppression des équations normales AᵀA ; DLT normalisée résolue par QR. |
| 52 | ✅ | Normalisation source + destination avant résolution puis dénormalisation. |
| 53 | ✅ | Avec 4 points exacts, l’erreur renvoyée est `NaN` : elle n’est plus présentée comme une incertitude nulle. |
| 54 | 🟡 | Paramètres majeurs centralisés/versionnés ; le seuil RANSAC métrique est adapté à la largeur de piste, quelques seuils secondaires restent fixes. |
| 55 | 🟡 | Contrôles orientation/surface/cohérence existants ; validation biomécanique complète par point de fuite reste à faire. |

## 8. Vitesse

| # | Statut | Correction v12 |
|---|---|---|
| 56 | ✅ | Les estimateurs vidéo ne sont plus enregistrés comme une moyenne 5 m/10 m : type `videoEstimatedSpeed`. |
| 57 | ✅ | Échelle anthropométrique clairement marquée comme estimation avec provenance. |
| 58 | 🟡 | Pelvis Vision utilisé lorsqu’il existe ; fallback bbox reste disponible pour éviter l’échec complet. |
| 59 | ✅ | Le top 20 % ne peut plus être mélangé à une série radar/5 m grâce à la taxonomie. |
| 60 | ✅ | Taxonomie protocolaire ajoutée. |
| 61 | ✅ | Version algorithme, FPS, intervalle, samples, statut qualité, vérification utilisateur et paramètres exportés. |

## 9. Biomécanique

| # | Statut | Correction v12 |
|---|---|---|
| 62 | ✅ | UI avertit de ne pas comparer des angles issus de géométries caméra différentes. |
| 63 | 🟡 | Tronc maintenant mesuré vs verticale de l’image, avec avertissement roulis non corrigé ; verticale monde calibrée reste future. |
| 64 | ✅ | Le score Vision n’est plus présenté comme incertitude angulaire ; incertitude = « non calibrée » tant qu’elle n’est pas propagée. |
| 65 | ✅ | Angle de perche explicitement « vs horizontale image » et perspective non corrigée. |
| 66 | ✅ | Catégories Automatique / Vérifié manuellement / Faible qualité / À revoir ; suppression des faux 0,95/0,98 pour les angles. |
| 67 | ✅ | Verticale/résultante sorties des statistiques principales vers « estimations 2D secondaires », avec avertissement centre de masse. |
| 68 | ✅ | Distance d’impulsion signée ; `abs(xMeters)` supprimé. |
| 69 | 🟡 | Convention toe/centre/avant conservée et nommée ; enrichissement graphique du repère de chaussure encore possible. |
| 70 | 🧪 | Validation bassin 10 Hz conservée pour moyenne de zone ; non revendiquée comme accélération instantanée de laboratoire. |
| 71 | 🟡 | Stabilisation de similarité conservée dans ce workflow ; homographie dynamique utilisée quand la piste est calibrée. |
| 72 | ✅ | Modèle physique maintenu comme guide pédagogique, sans revendication prédictive. |

## 10. Architecture / concurrence

| # | Statut | Correction v12 |
|---|---|---|
| 73 | 🟡 | Timeline, transport, configuration, persistance d’erreurs et service PTS sont séparés ; View/ViewModel restent encore volumineux. |
| 74 | 🟡 | Sous-domaines supplémentaires introduits sous forme de services dédiés, mais extraction complète en six coordinators non terminée pour éviter une régression massive sans tests iPad. |
| 75 | 🟡 | Tous les services longs testent l’annulation ; résultat obsolète bloqué par session ID. Les Tasks UI ne sont pas encore toutes détenues/cancelées explicitement. |
| 76 | ✅ | `analysisSessionID + loadedURL` vérifiés avant toute écriture de résultat majeur. |
| 77 | ✅ | Sélectionner Pose ne lance plus automatiquement le calcul. |
| 78 | 🟡 | PTS via AVAssetReader réduit l’approximation ; décodage frame Vision reste à migrer entièrement vers CVPixelBuffer. |
| 79 | 🟡 | `VideoAnalysisConfiguration` versionne les paramètres critiques ; quelques constantes UX/heuristiques secondaires subsistent. |
| 80 | ✅ | `parameterSetVersion` et paramètres effectifs sont enregistrés avec la mesure. |

## 11. UX/UI iPad

| # | Statut | Correction v12 |
|---|---|---|
| 81 | ✅ | Parcours recentré sur tâche. |
| 82 | ✅ | Lecture / Comparer / Mesurer / Biomécanique. |
| 83 | ✅ | Score qualité, état vérifié/estimé et incertitude non calibrée affichés près des résultats. |
| 84 | ✅ | États faibles/à revoir différenciés et avertissements orange/rouge. |
| 85 | 🧪 | Plusieurs zones utilisent `ViewThatFits`; validation Dynamic Type XL sur iPad physique reste requise. |
| 86 | ✅ | Matériaux/scrims utilisés sur les contrôles vidéo afin de stabiliser le contraste. |
| 87 | ✅ | `.preferredColorScheme(.light)` supprimé. |
| 88 | ✅ | « Nerd Stats » remplacé par « Mesures avancées ». |
| 89 | ✅ | « Développement » remplacé par « Bibliothèque et profil ». |

## 12. Fonctionnalités incomplètes / export

| # | Statut | Correction v12 |
|---|---|---|
| 90 | ✅ | Aucune fausse file cloud n’est créée tant que la sync distante est désactivée. |
| 91 | ✅ | UI FFA indique explicitement qu’un backend autorisé doit être configuré. |
| 92 | ✅ | « Données locales prêtes » remplacé par « Stockage local actif » et erreurs de sauvegarde remontées. |
| 93 | 🟡 | Export propose trois périmètres et avertit sur les données personnelles ; les vidéos originales ne sont pas exportées. La protection finale d’un fichier placé dans Fichiers/iCloud dépend du provider de destination et doit être validée sur iOS. |

## Contrôles effectués dans cet environnement

- `swiftc -parse` réussi sur **tous les fichiers Swift AppModule + Tests**.
- Recherche automatisée : aucun `resetAllLocalData`, aucun `try? modelContext.save()`, aucun mode clair forcé, aucun « Nerd Stats » restant.
- Les tests XCTest sont fournis mais ne peuvent pas être exécutés ici : l’environnement Linux ne possède ni le SDK iOS, ni `AppleProductTypes`, AVFoundation/Vision/SwiftData iOS.

## Ce qui doit obligatoirement être validé avant de revendiquer une précision scientifique

Voir `VALIDATION_PROTOCOL_V12.md`. Aucune valeur ±cm, ±m/s ou ±° n’est revendiquée avant comparaison à une vérité terrain.
