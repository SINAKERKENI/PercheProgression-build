# Architecture — vitesse vidéo perspective

La source quantitative v15 est `PerspectiveAwareSpeedEngine` (`perspective-speed-v15.0`). Le flux métrique est :

**image → calibration → homographie (fixe/dynamique) → position au sol → PTS → trajectoire métrique robuste → intervalle métrique → vitesse → diagnostics de qualité.**

## Caméra fixe

Une calibration du plan de piste fournit une transformation image→coordonnées métriques. `FixedObliqueRunwayMotionAnalysisService` valide cette géométrie et transmet au moteur des observations métriques horodatées. Une géométrie non exploitable bloque la mesure.

## Caméra mobile/panoramique

`VideoMotionAnalysisService` consomme les échantillons de `DynamicCalibrationService`. Plusieurs ancrages statiques servent à estimer la transformation image→piste au cours du temps ; les échantillons sans homographie fiable sont exclus. Les composantes de stabilité des ancrages, nombre d’ancrages et continuité de l’homographie sont conservées dans le rapport de qualité.

## Position de l’athlète

Une homographie du sol ne transforme correctement que les points appartenant au sol. Le pipeline privilégie donc un point d’appui issu des chevilles/support (`supportAnkle`, puis `ankleMidpoint`/estimation de contact selon disponibilité). Le suivi de personne sert à préserver l’identité et la continuité. Un bassin projeté, lorsqu’il est explicitement utilisé dans un ancien mode, est marqué comme estimation et n’est pas silencieusement assimilé à un point au sol calibré.

## Temps et trajectoire

Chaque observation transporte son temps PTS réel. Le moteur rejette les temps dupliqués/non monotones, élimine les ruptures métriques aberrantes, applique un lissage robuste court puis estime les dérivées localement. La vitesse moyenne principale est une distance longitudinale métrique divisée par le temps PTS correspondant ; le pic est secondaire.

## Qualité inspectable

Le rapport conserve séparément : calibration, stabilité des ancrages, nombre d’ancrages utilisables, continuité d’homographie, continuité du suivi athlète, confiance du point au sol, couverture de trajectoire métrique, contrôle des outliers et couverture PTS. L’indice global n’est qu’un résumé de qualité, jamais une probabilité.

Les diagnostics utilisateur peuvent notamment signaler : calibration exploitable/fragile, ancrages instables, ancrages insuffisants, perspective dynamique discontinue, position au sol incertaine ou couverture PTS incomplète.

## Politique d’échec

Si la calibration, la continuité géométrique ou la couverture temporelle sont trop faibles, le moteur lève une erreur et aucune vitesse métrique « crédible » n’est produite. Les modes historiques anthropométriques/bassin peuvent rester consultables, mais l’UI v15 refuse leur sauvegarde dans le champ de vitesse métrique calibrée.
