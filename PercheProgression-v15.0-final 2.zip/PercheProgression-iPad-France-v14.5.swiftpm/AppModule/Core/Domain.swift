import Foundation

// MARK: - Domaine sportif

enum ApproachLength: Int, CaseIterable, Codable, Identifiable, Hashable, Sendable {
  case six = 6
  case eight = 8
  case ten = 10
  case twelve = 12
  case fourteen = 14
  case sixteen = 16
  case eighteen = 18

  var id: Int { rawValue }
  var title: String { "\(rawValue) foulées" }
  var shortTitle: String { "\(rawValue)" }

  static func from(_ value: Int) -> ApproachLength {
    ApproachLength(rawValue: value) ?? .fourteen
  }
}

enum PoleManufacturer: String, CaseIterable, Identifiable, Codable, Sendable {
  case altius = "Altius"
  case bigStick = "BIG STICK"
  case essx = "ESSX"
  case fiberSport = "FiberSport"
  case nordic = "Nordic"
  case pacer = "Pacer"
  case skypole = "Skypole"
  case ucsSpirit = "UCS Spirit"

  var id: String { rawValue }
}

enum SessionKind: String, CaseIterable, Codable, Identifiable, Sendable {
  case training
  case competition

  var id: String { rawValue }
  var title: String { self == .training ? "Entraînement" : "Compétition" }
  var symbol: String { self == .training ? "figure.run" : "medal" }
}

enum VaultEnvironment: String, CaseIterable, Codable, Identifiable, Sendable {
  case outdoor
  case indoor

  var id: String { rawValue }
  var title: String { self == .outdoor ? "Extérieur" : "Salle" }
  var symbol: String { self == .outdoor ? "sun.max.fill" : "building.2.fill" }
}

enum WeatherCondition: String, CaseIterable, Codable, Identifiable, Sendable {
  case unknown
  case clear
  case cloudy
  case rain
  case hot
  case cold

  var id: String { rawValue }
  var title: String {
    switch self {
    case .unknown: "Non renseignée"
    case .clear: "Dégagé"
    case .cloudy: "Couvert"
    case .rain: "Pluie"
    case .hot: "Chaud"
    case .cold: "Froid"
    }
  }

  var symbol: String {
    switch self {
    case .unknown: "questionmark.circle"
    case .clear: "sun.max.fill"
    case .cloudy: "cloud.fill"
    case .rain: "cloud.rain.fill"
    case .hot: "thermometer.high"
    case .cold: "thermometer.low"
    }
  }
}

enum WindDirection: String, CaseIterable, Codable, Identifiable, Sendable {
  case none
  case tail
  case head
  case cross

  var id: String { rawValue }
  var title: String {
    switch self {
    case .none: "Calme / inconnu"
    case .tail: "Vent arrière"
    case .head: "Vent de face"
    case .cross: "Vent latéral"
    }
  }
}

enum JumpRating: Int, CaseIterable, Codable, Identifiable, Sendable {
  case unrated = 0
  case incomplete = 1
  case ok = 2
  case good = 3
  case great = 4

  var id: Int { rawValue }
  var title: String {
    switch self {
    case .unrated: "Non évalué"
    case .incomplete: "Incomplet"
    case .ok: "Correct"
    case .good: "Bon"
    case .great: "Excellent"
    }
  }

  var symbol: String {
    switch self {
    case .unrated: "circle"
    case .incomplete: "circle.lefthalf.filled"
    case .ok: "checkmark.circle"
    case .good: "hand.thumbsup.fill"
    case .great: "star.fill"
    }
  }
}

enum AttemptResult: String, CaseIterable, Codable, Identifiable, Sendable {
  case clear
  case miss
  case abort
  case runThrough = "run-through"
  case pass

  var id: String { rawValue }
  var title: String {
    switch self {
    case .clear: "Réussi"
    case .miss: "Échec"
    case .abort: "Abandon"
    case .runThrough: "Course interrompue"
    case .pass: "Impasse"
    }
  }

  var competitionMark: String {
    switch self {
    case .clear: "O"
    case .miss: "X"
    case .pass: "–"
    case .abort, .runThrough: "·"
    }
  }

  var isValidAttempt: Bool { self == .clear || self == .miss }
}

enum AttemptDiagnostic: String, CaseIterable, Codable, Identifiable, Sendable {
  case plantRefusal = "plant refusal"
  case takeoffUnder = "takeoff under"
  case takeoffOut = "takeoff out"
  case barContact = "bar contact"
  case standardsIssue = "standards issue"
  case poleTooSoft = "pole too soft"
  case poleTooStiff = "pole too stiff"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .plantRefusal: "Refus de planter"
    case .takeoffUnder: "Impulsion sous la perche"
    case .takeoffOut: "Impulsion trop loin"
    case .barContact: "Contact avec la barre"
    case .standardsIssue: "Réglage des poteaux"
    case .poleTooSoft: "Perche trop souple"
    case .poleTooStiff: "Perche trop dure"
    }
  }
  var symbol: String {
    switch self {
    case .plantRefusal: "hand.raised"
    case .takeoffUnder: "arrow.down.forward"
    case .takeoffOut: "arrow.up.forward"
    case .barContact: "line.diagonal"
    case .standardsIssue: "ruler"
    case .poleTooSoft: "arrow.down.right.and.arrow.up.left"
    case .poleTooStiff: "arrow.up.left.and.arrow.down.right"
    }
  }
}

enum PoleProgressState: String, CaseIterable, Codable, Identifiable, Comparable, Sendable {
  case locked
  case unlocked
  case successful
  case mastered

  var id: String { rawValue }
  var title: String {
    switch self {
    case .locked: "Verrouillée"
    case .unlocked: "Débloquée"
    case .successful: "Utilisée avec réussite"
    case .mastered: "Maîtrisée"
    }
  }
  var symbol: String {
    switch self {
    case .locked: "lock"
    case .unlocked: "lock.open"
    case .successful: "checkmark.circle"
    case .mastered: "crown"
    }
  }

  var rank: Int {
    switch self {
    case .locked: 0
    case .unlocked: 1
    case .successful: 2
    case .mastered: 3
    }
  }

  static func < (lhs: PoleProgressState, rhs: PoleProgressState) -> Bool {
    lhs.rank < rhs.rank
  }
}

enum VaultPhase: String, CaseIterable, Codable, Identifiable, Sendable {
  case plant
  case takeoff
  case rockBack = "rock-back"
  case extensionPhase = "extension"
  case turn
  case flyAway = "fly-away"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .plant: "Présentation"
    case .takeoff: "Impulsion"
    case .rockBack: "Renversement"
    case .extensionPhase: "Extension"
    case .turn: "Demi-tour"
    case .flyAway: "Franchissement"
    }
  }
}

enum ExerciseVideoCategory: String, CaseIterable, Codable, Identifiable, Sendable {
  case warmUp = "warm-up"
  case pvDrills = "pv-drills"
  case medBall = "med-ball"
  case strength
  case gym
  case core
  case plyo
  case flexibility
  case rehab
  case running

  var id: String { rawValue }

  static func migrated(from rawValue: String) -> ExerciseVideoCategory {
    if let currentCategory = ExerciseVideoCategory(rawValue: rawValue) {
      return currentCategory
    }

    switch rawValue {
    case "plant", "takeoff", "rock-back", "extension", "turn", "fly-away":
      return .pvDrills
    case "gymnastics":
      return .gym
    case "sprint":
      return .running
    case "strength-mobility":
      return .strength
    default:
      return .pvDrills
    }
  }

  var title: String {
    switch self {
    case .warmUp: "Warm-up"
    case .pvDrills: "PV Drills"
    case .medBall: "Med Ball"
    case .strength: "Strength"
    case .gym: "Gym"
    case .core: "Core"
    case .plyo: "Plyo"
    case .flexibility: "Flexibility"
    case .rehab: "Rehab"
    case .running: "Running"
    }
  }
}

enum GoalActionKind: String, CaseIterable, Codable, Identifiable, Sendable {
  case habit
  case metric
  case sessionTask = "session-task"
  case milestone

  var id: String { rawValue }
  var title: String {
    switch self {
    case .habit: "Habitude"
    case .metric: "Mesure"
    case .sessionTask: "Tâche de séance"
    case .milestone: "Étape clé"
    }
  }
}

enum VectorKind: String, CaseIterable, Codable, Identifiable, Sendable {
  case manual
  case velocity
  case bodyAxis = "body-axis"
  case poleAxis = "pole-axis"
  case trajectory
  case calibration

  var id: String { rawValue }
  var title: String {
    switch self {
    case .manual: "Manuel"
    case .velocity: "Vitesse"
    case .bodyAxis: "Axe du corps"
    case .poleAxis: "Axe de la perche"
    case .trajectory: "Trajectoire"
    case .calibration: "Étalonnage"
    }
  }
}

enum PhysicalMetricKind: String, CaseIterable, Codable, Identifiable, Sendable {
  case bodyWeight = "body-weight"
  case height
  case sprint100m = "100m-time"

  // Legacy aggregate retained for decoding old stores only. New writes must use a protocol-specific case.
  case approachSpeed = "approach-speed"
  case approachSpeed5mMean = "approach-speed-5m-mean"
  case approachSpeed10mMean = "approach-speed-10m-mean"
  case approachPeakSpeed = "approach-peak-speed"
  case videoEstimatedSpeed = "video-estimated-speed"
  case radarSpeed = "radar-speed"
  case takeoffSpeed = "takeoff-speed"

  case theoreticalMaximum = "theoretical-maximum"
  case startMark = "start-mark"
  case takeoffMark = "takeoff-mark"
  case strength
  case mobility

  var id: String { rawValue }

  static var userSelectableCases: [PhysicalMetricKind] {
    allCases.filter { $0 != .approachSpeed }
  }

  var isApproachSpeedFamily: Bool {
    switch self {
    case .approachSpeed, .approachSpeed5mMean, .approachSpeed10mMean, .approachPeakSpeed, .videoEstimatedSpeed, .radarSpeed:
      true
    default:
      false
    }
  }

  var title: String {
    switch self {
    case .bodyWeight: "Poids"
    case .height: "Taille"
    case .sprint100m: "Temps sur 100 m"
    case .approachSpeed: "Vitesse d’élan · ancien format"
    case .approachSpeed5mMean: "Vitesse moyenne · 5 m"
    case .approachSpeed10mMean: "Vitesse moyenne · 10 m"
    case .approachPeakSpeed: "Vitesse de pointe d’élan"
    case .videoEstimatedSpeed: "Vitesse vidéo estimée"
    case .radarSpeed: "Vitesse radar / cellule"
    case .takeoffSpeed: "Vitesse à l’impulsion"
    case .theoreticalMaximum: "Potentiel théorique"
    case .startMark: "Marque de départ"
    case .takeoffMark: "Marque d’impulsion"
    case .strength: "Force"
    case .mobility: "Mobilité"
    }
  }

  var defaultUnit: String {
    switch self {
    case .bodyWeight: "kg"
    case .height, .theoreticalMaximum, .startMark, .takeoffMark: "m"
    case .sprint100m: "s"
    case .approachSpeed, .approachSpeed5mMean, .approachSpeed10mMean, .approachPeakSpeed, .videoEstimatedSpeed, .radarSpeed, .takeoffSpeed: "m/s"
    case .strength, .mobility: "%"
    }
  }
}

enum ProgressMetric: String, CaseIterable, Identifiable, Sendable {
  case officialPR = "official-pr"
  case trainingPR = "training-pr"
  case approachSpeed = "approach-speed"
  case takeoffSpeed = "takeoff-speed"
  case clearRate = "clear-rate"
  case startMark = "start-mark"
  case takeoffMark = "takeoff-mark"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .officialPR: "Record officiel"
    case .trainingPR: "Record à l’entraînement"
    case .approachSpeed: "Vitesse d’élan"
    case .takeoffSpeed: "Vitesse à l’impulsion"
    case .clearRate: "Taux de réussite"
    case .startMark: "Marque de départ"
    case .takeoffMark: "Marque d’impulsion"
    }
  }

  var unit: String {
    switch self {
    case .officialPR, .trainingPR, .startMark, .takeoffMark: "m"
    case .approachSpeed, .takeoffSpeed: "m/s"
    case .clearRate: "%"
    }
  }
}

// MARK: - Objets de valeur

struct PoleSnapshot: Identifiable, Equatable, Sendable {
  let id: UUID
  let manufacturer: String
  let model: String
  let lengthCM: Int
  let weightKG: Double
  let flexCM: Double
  let progressionOrder: Int

  var displayName: String {
    String(format: "%.2f m · %.0f kg · %.1f cm flex", Double(lengthCM) / 100.0, weightKG, flexCM)
  }
}

struct PoleProgressSnapshot: Equatable, Sendable {
  let poleID: UUID
  let approachSteps: Int
  let state: PoleProgressState
  let validAttempts: Int
  let clears: Int

  var clearRate: Double {
    guard validAttempts > 0 else { return 0 }
    return Double(clears) / Double(validAttempts)
  }
}

struct AttemptSnapshot: Equatable, Sendable {
  let id: UUID
  let sessionID: UUID
  let poleID: UUID
  let approachSteps: Int
  let result: AttemptResult
  let diagnostics: Set<AttemptDiagnostic>
  let barHeightCM: Int
  let gripHeightM: Double?
  let approachSpeedMPS: Double?
  let approachSpeedKind: PhysicalMetricKind?
  let approachSpeedSource: String
  let takeoffSpeedMPS: Double?
  let actualTakeoffMarkM: Double?
  let runUpDistanceM: Double?
  let midMarkM: Double?
  let standardsOffsetCM: Int?
  let technicalRating: JumpRating
  let createdAt: Date

  init(
    id: UUID = UUID(),
    sessionID: UUID = UUID(),
    poleID: UUID,
    approachSteps: Int,
    result: AttemptResult,
    diagnostics: Set<AttemptDiagnostic>,
    barHeightCM: Int,
    gripHeightM: Double? = nil,
    approachSpeedMPS: Double? = nil,
    approachSpeedKind: PhysicalMetricKind? = nil,
    approachSpeedSource: String = "",
    takeoffSpeedMPS: Double? = nil,
    actualTakeoffMarkM: Double? = nil,
    runUpDistanceM: Double? = nil,
    midMarkM: Double? = nil,
    standardsOffsetCM: Int? = nil,
    technicalRating: JumpRating = .unrated,
    createdAt: Date
  ) {
    self.id = id
    self.sessionID = sessionID
    self.poleID = poleID
    self.approachSteps = approachSteps
    self.result = result
    self.diagnostics = diagnostics
    self.barHeightCM = barHeightCM
    self.gripHeightM = gripHeightM
    self.approachSpeedMPS = approachSpeedMPS
    self.approachSpeedKind = approachSpeedKind
    self.approachSpeedSource = approachSpeedSource
    self.takeoffSpeedMPS = takeoffSpeedMPS
    self.actualTakeoffMarkM = actualTakeoffMarkM
    self.runUpDistanceM = runUpDistanceM
    self.midMarkM = midMarkM
    self.standardsOffsetCM = standardsOffsetCM
    self.technicalRating = technicalRating
    self.createdAt = createdAt
  }
}

struct PoleAthleteContext: Equatable, Sendable {
  var bodyWeightKG: Double
  var heightCM: Double
  var officialPRCM: Int
  var trainingPRCM: Int
  var targetHeightCM: Int

  static let empty = PoleAthleteContext(bodyWeightKG: 0, heightCM: 0, officialPRCM: 0, trainingPRCM: 0, targetHeightCM: 0)
}

enum PoleRecommendationDirection: String, Codable, Sendable {
  case stay
  case up
  case down
  case lateral

  var title: String {
    switch self {
    case .stay: "Rester"
    case .up: "Monter"
    case .down: "Descendre"
    case .lateral: "Changer latéralement"
    }
  }
}

struct PoleCandidateEvaluation: Equatable, Sendable, Identifiable {
  let pole: PoleSnapshot
  let direction: PoleRecommendationDirection
  let transitionDescription: String
  let evidenceScore: Double
  let contextualFitScore: Double
  let readinessScore: Double
  let evidenceQuality: Double
  let evidenceCount: Int
  let blockers: [String]
  let reasons: [String]
  let warnings: [String]

  var id: UUID { pole.id }
}

struct PoleRecommendation: Equatable, Sendable {
  enum Confidence: String, Codable, Sendable {
    case low
    case medium
    case high

    var title: String {
      switch self {
      case .low: "Faible"
      case .medium: "Moyenne"
      case .high: "Élevée"
      }
    }
  }

  let evaluation: PoleCandidateEvaluation
  let alternatives: [PoleCandidateEvaluation]
  let confidence: Confidence
  let modelVersion: String

  var pole: PoleSnapshot { evaluation.pole }
  var readinessScore: Double { evaluation.readinessScore }
  var evidenceCount: Int { evaluation.evidenceCount }
  var reasons: [String] { evaluation.reasons }
  var warnings: [String] { evaluation.warnings }
  var direction: PoleRecommendationDirection { evaluation.direction }
}

struct MetricPoint: Identifiable, Equatable, Sendable {
  let id: UUID
  let date: Date
  let value: Double
  let label: String

  init(id: UUID = UUID(), date: Date, value: Double, label: String = "") {
    self.id = id
    self.date = date
    self.value = value
    self.label = label
  }
}


struct NormalizedPoint: Codable, Equatable, Sendable {
  var x: Double
  var y: Double

  func clamped() -> NormalizedPoint {
    NormalizedPoint(x: min(max(x, 0), 1), y: min(max(y, 0), 1))
  }
}

struct NormalizedRect: Codable, Equatable, Sendable {
  var x: Double
  var y: Double
  var width: Double
  var height: Double

  var minX: Double { x }
  var minY: Double { y }
  var maxX: Double { x + width }
  var maxY: Double { y + height }
  var midX: Double { x + width * 0.5 }
  var midY: Double { y + height * 0.5 }
  var area: Double { max(width, 0) * max(height, 0) }
  var center: NormalizedPoint { .init(x: midX, y: midY) }

  func clamped() -> NormalizedRect {
    let nx = min(max(x, 0), 1)
    let ny = min(max(y, 0), 1)
    return NormalizedRect(
      x: nx,
      y: ny,
      width: min(max(width, 0), 1 - nx),
      height: min(max(height, 0), 1 - ny)
    )
  }

  func contains(_ point: NormalizedPoint, padding: Double = 0) -> Bool {
    point.x >= minX - padding && point.x <= maxX + padding
      && point.y >= minY - padding && point.y <= maxY + padding
  }
}

struct PoseCandidate: Identifiable, Equatable, Sendable {
  let id: UUID
  let joints: [PoseJoint]
  let boundingBox: NormalizedRect
  let confidence: Double

  init(
    id: UUID = UUID(),
    joints: [PoseJoint],
    boundingBox: NormalizedRect,
    confidence: Double
  ) {
    self.id = id
    self.joints = joints
    self.boundingBox = boundingBox.clamped()
    self.confidence = min(max(confidence, 0), 1)
  }

  var pelvisPoint: NormalizedPoint? {
    if let root = joints.first(where: { $0.id == "root" }) { return root.point }
    let hips = joints.filter { $0.id == "leftHip" || $0.id == "rightHip" }
    guard !hips.isEmpty else { return nil }
    return NormalizedPoint(
      x: hips.map(\.point.x).reduce(0, +) / Double(hips.count),
      y: hips.map(\.point.y).reduce(0, +) / Double(hips.count)
    )
  }
}

struct OverlayVector: Identifiable, Codable, Equatable, Sendable {
  var id: UUID
  var timeSeconds: Double
  var label: String
  var kind: VectorKind
  var start: NormalizedPoint
  var end: NormalizedPoint
  var source: String

  init(
    id: UUID = UUID(),
    timeSeconds: Double,
    label: String,
    kind: VectorKind,
    start: NormalizedPoint,
    end: NormalizedPoint,
    source: String = "athlete"
  ) {
    self.id = id
    self.timeSeconds = timeSeconds
    self.label = label
    self.kind = kind
    self.start = start
    self.end = end
    self.source = source
  }

  var angleDegrees: Double {
    let degrees = atan2(-(end.y - start.y), end.x - start.x) * 180 / .pi
    return degrees < 0 ? degrees + 360 : degrees
  }
}

struct PoseJoint: Identifiable, Equatable, Sendable {
  let id: String
  let point: NormalizedPoint
  let confidence: Double
}

struct PhaseMarker: Identifiable, Equatable, Sendable {
  let id: UUID
  let phase: VaultPhase
  let timeSeconds: Double

  init(id: UUID = UUID(), phase: VaultPhase, timeSeconds: Double) {
    self.id = id
    self.phase = phase
    self.timeSeconds = timeSeconds
  }
}

// MARK: - Analyse biomécanique vidéo

enum VideoComparisonMode: String, CaseIterable, Identifiable, Codable, Sendable {
  case sideBySide = "side-by-side"
  case overlay

  var id: String { rawValue }
  var title: String {
    switch self {
    case .sideBySide: "Côte à côte"
    case .overlay: "Superposition"
    }
  }

  var symbol: String {
    switch self {
    case .sideBySide: "rectangle.split.2x1"
    case .overlay: "square.stack.3d.up"
    }
  }
}

struct VideoCalibration: Codable, Equatable, Sendable {
  var start: NormalizedPoint
  var end: NormalizedPoint
  var distanceMeters: Double

  init(
    start: NormalizedPoint = NormalizedPoint(x: 0.18, y: 0.82),
    end: NormalizedPoint = NormalizedPoint(x: 0.62, y: 0.82),
    distanceMeters: Double = 0
  ) {
    self.start = start
    self.end = end
    self.distanceMeters = distanceMeters
  }

  func pixelLength(in videoSize: CGSize) -> Double {
    let dx = (end.x - start.x) * Double(videoSize.width)
    let dy = (end.y - start.y) * Double(videoSize.height)
    return hypot(dx, dy)
  }

  func metersPerPixel(in videoSize: CGSize) -> Double? {
    let pixels = pixelLength(in: videoSize)
    guard pixels > 2, distanceMeters > 0 else { return nil }
    return distanceMeters / pixels
  }
}



enum PelvisCheckpointState: String, Codable, Equatable, Sendable {
  case pending
  case confirmed
  case adjusted

  var title: String {
    switch self {
    case .pending: "À confirmer"
    case .confirmed: "Suggestion confirmée"
    case .adjusted: "Position corrigée"
    }
  }
}

/// Point de bassin contrôlé par l'utilisateur à cadence fixe (10 Hz par défaut).
/// Les coordonnées sont normalisées dans l'image affichée, indépendamment de sa résolution.
struct PelvisCheckpoint: Identifiable, Codable, Equatable, Sendable {
  var id: UUID
  var timeSeconds: Double
  var suggestedPoint: NormalizedPoint
  var confirmedPoint: NormalizedPoint?
  var suggestionConfidence: Double
  var state: PelvisCheckpointState

  init(
    id: UUID = UUID(),
    timeSeconds: Double,
    suggestedPoint: NormalizedPoint,
    confirmedPoint: NormalizedPoint? = nil,
    suggestionConfidence: Double = 0,
    state: PelvisCheckpointState = .pending
  ) {
    self.id = id
    self.timeSeconds = timeSeconds
    self.suggestedPoint = suggestedPoint.clamped()
    self.confirmedPoint = confirmedPoint?.clamped()
    self.suggestionConfidence = min(max(suggestionConfidence, 0), 1)
    self.state = state
  }

  var effectivePoint: NormalizedPoint {
    confirmedPoint ?? suggestedPoint
  }

  var isConfirmed: Bool {
    state != .pending && confirmedPoint != nil
  }
}

struct PelvisValidationSession: Codable, Equatable, Sendable {
  var checkpoints: [PelvisCheckpoint]
  var intervalSeconds: Double
  var startTime: Double
  var endTime: Double
  var athleteHeightMeters: Double
  var createdAt: Date
  var modelVersion: String

  init(
    checkpoints: [PelvisCheckpoint],
    intervalSeconds: Double = 0.1,
    startTime: Double,
    endTime: Double,
    athleteHeightMeters: Double,
    createdAt: Date = .now,
    modelVersion: String = "Validation manuelle bassin 10 Hz v1"
  ) {
    self.checkpoints = checkpoints.sorted { $0.timeSeconds < $1.timeSeconds }
    self.intervalSeconds = max(intervalSeconds, 0.04)
    self.startTime = startTime
    self.endTime = endTime
    self.athleteHeightMeters = athleteHeightMeters
    self.createdAt = createdAt
    self.modelVersion = modelVersion
  }

  var confirmedCount: Int {
    checkpoints.filter(\.isConfirmed).count
  }

  var isComplete: Bool {
    !checkpoints.isEmpty && confirmedCount == checkpoints.count
  }

  var progress: Double {
    guard !checkpoints.isEmpty else { return 0 }
    return Double(confirmedCount) / Double(checkpoints.count)
  }
}

struct MotionSample: Identifiable, Codable, Equatable, Sendable {
  var id: UUID
  var timeSeconds: Double
  var point: NormalizedPoint
  var confidence: Double
  var horizontalVelocity: Double
  var verticalVelocity: Double
  var acceleration: Double
  var runwayX: Double?
  var runwayY: Double?
  var calibrationConfidence: Double?
  var verticalIsEstimated: Bool?
  var horizontalAcceleration: Double?
  var verticalAcceleration: Double?

  init(
    id: UUID = UUID(),
    timeSeconds: Double,
    point: NormalizedPoint,
    confidence: Double,
    horizontalVelocity: Double = 0,
    verticalVelocity: Double = 0,
    acceleration: Double = 0,
    runwayX: Double? = nil,
    runwayY: Double? = nil,
    calibrationConfidence: Double? = nil,
    verticalIsEstimated: Bool? = nil,
    horizontalAcceleration: Double? = nil,
    verticalAcceleration: Double? = nil
  ) {
    self.id = id
    self.timeSeconds = timeSeconds
    self.point = point
    self.confidence = confidence
    self.horizontalVelocity = horizontalVelocity
    self.verticalVelocity = verticalVelocity
    self.acceleration = acceleration
    self.runwayX = runwayX
    self.runwayY = runwayY
    self.calibrationConfidence = calibrationConfidence
    self.verticalIsEstimated = verticalIsEstimated
    self.horizontalAcceleration = horizontalAcceleration
    self.verticalAcceleration = verticalAcceleration
  }

  var resultantVelocity: Double {
    hypot(horizontalVelocity, verticalVelocity)
  }
}

enum MotionMeasurementMode: String, Codable, Sendable {
  case dynamicRunway = "dynamic-runway"
  case athleteScale = "athlete-scale"
  case calibratedManual = "calibrated-manual"
  case fixedObliqueRunway = "fixed-oblique-runway"

  var title: String {
    switch self {
    case .dynamicRunway: "Grille dynamique de piste"
    case .athleteScale: "Stabilisation sans butoir"
    case .calibratedManual: "Mesure physique étalonnée"
    case .fixedObliqueRunway: "Caméra fixe · perspective corrigée"
    }
  }
}

enum PhysicalCameraMode: String, CaseIterable, Codable, Sendable, Identifiable {
  case fixedOblique = "fixed-oblique"
  case mobile = "mobile"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .fixedOblique: "Caméra fixe – face ou biais"
    case .mobile: "Caméra mobile"
    }
  }
}

enum FixedObliqueTrackingPoint: String, CaseIterable, Codable, Sendable, Identifiable {
  case groundProjection = "ground-projection"
  case pelvisEstimate = "pelvis-estimate"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .groundProjection: "Point au sol (recommandé)"
    case .pelvisEstimate: "Bassin (estimation)"
    }
  }
  var explanation: String {
    switch self {
    case .groundProjection:
      "À chaque validation, touchez le point du sol situé sous le bassin / l’appui. L’homographie du sol est alors utilisée dans son domaine valide."
    case .pelvisEstimate:
      "Le bassin est plus simple à suivre, mais il n’appartient pas au plan du sol : une erreur de parallaxe subsiste en vue oblique."
    }
  }
}

enum FixedRunwayMetricOrigin: String, Codable, CaseIterable, Identifiable, Sendable {
  case box
  case freeReference

  var id: String { rawValue }

  var title: String {
    switch self {
    case .box: "Butoir visible"
    case .freeReference: "Butoir hors champ"
    }
  }

  var explanation: String {
    switch self {
    case .box:
      "La ligne proche du quadrilatère correspond au fond du butoir : l’origine X = 0,00 m est absolue."
    case .freeReference:
      "La ligne proche est une référence métrique libre au sol. La vitesse reste métrique, mais la distance absolue depuis le butoir n’est pas calculable."
    }
  }
}

struct MotionAnalysisResult: Codable, Equatable, Sendable {
  var samples: [MotionSample]
  var startTime: Double
  var endTime: Double
  var calibration: VideoCalibration
  var trackingSeed: NormalizedPoint
  var representativeHorizontalSpeed: Double
  var peakHorizontalSpeed: Double
  var averageConfidence: Double
  var modelVersion: String
  var dynamicCalibration: DynamicCalibrationTrack?
  var takeoffMeasurement: TakeoffMeasurement?
  var measurementMode: MotionMeasurementMode?
  var referenceDescription: String?
  var pelvisValidation: PelvisValidationSession?
  var backgroundReferencePoints: [NormalizedPoint]?
  var calibrationReferenceTime: Double?
  var fixedRunwayGrid: RunwayGridCalibration?
  var fixedRunwayMetricOrigin: FixedRunwayMetricOrigin?
  var speedQualityReport: PerspectiveAwareSpeedEngine.QualityReport?
  var groundPointMethodRaw: String?
  var timeBasisRaw: String?

  init(
    samples: [MotionSample],
    startTime: Double,
    endTime: Double,
    calibration: VideoCalibration,
    trackingSeed: NormalizedPoint,
    representativeHorizontalSpeed: Double,
    peakHorizontalSpeed: Double,
    averageConfidence: Double,
    modelVersion: String = "Vision point tracking v1",
    dynamicCalibration: DynamicCalibrationTrack? = nil,
    takeoffMeasurement: TakeoffMeasurement? = nil,
    measurementMode: MotionMeasurementMode? = nil,
    referenceDescription: String? = nil,
    pelvisValidation: PelvisValidationSession? = nil,
    backgroundReferencePoints: [NormalizedPoint]? = nil,
    calibrationReferenceTime: Double? = nil,
    fixedRunwayGrid: RunwayGridCalibration? = nil,
    fixedRunwayMetricOrigin: FixedRunwayMetricOrigin? = nil,
    speedQualityReport: PerspectiveAwareSpeedEngine.QualityReport? = nil,
    groundPointMethodRaw: String? = nil,
    timeBasisRaw: String? = nil
  ) {
    self.samples = samples
    self.startTime = startTime
    self.endTime = endTime
    self.calibration = calibration
    self.trackingSeed = trackingSeed
    self.representativeHorizontalSpeed = representativeHorizontalSpeed
    self.peakHorizontalSpeed = peakHorizontalSpeed
    self.averageConfidence = averageConfidence
    self.modelVersion = modelVersion
    self.dynamicCalibration = dynamicCalibration
    self.takeoffMeasurement = takeoffMeasurement
    self.measurementMode = measurementMode
    self.referenceDescription = referenceDescription
    self.pelvisValidation = pelvisValidation
    self.backgroundReferencePoints = backgroundReferencePoints
    self.calibrationReferenceTime = calibrationReferenceTime
    self.fixedRunwayGrid = fixedRunwayGrid
    self.fixedRunwayMetricOrigin = fixedRunwayMetricOrigin
    self.speedQualityReport = speedQualityReport
    self.groundPointMethodRaw = groundPointMethodRaw
    self.timeBasisRaw = timeBasisRaw
  }

  func sample(nearest time: Double) -> MotionSample? {
    samples.min { abs($0.timeSeconds - time) < abs($1.timeSeconds - time) }
  }
}
