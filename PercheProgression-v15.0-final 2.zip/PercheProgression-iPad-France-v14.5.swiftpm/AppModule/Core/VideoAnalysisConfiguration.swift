import Foundation

/// Versioned parameters that materially affect reproducibility of video measurements.
/// A measurement export records the algorithm/model version; changes here require a model-version bump.
enum VideoAnalysisConfiguration {
  static let parameterSetVersion = "video-analysis-params-v13.0"

  enum Pose {
    static let minimumJointConfidence = 0.35
    static let minimumJointCount = 9
  }

  enum Tracking {
    static let subjectMinimumConfidence = 0.25
    static let backgroundMinimumConfidence = 0.18
    static let dynamicAnchorMinimumConfidence = 0.18
  }

  enum Sampling {
    static let maximumDynamicMotionFrames = 600
    static let maximumAthleteScaleFrames = 600
    static let maximumCalibrationFrames = 720
    static let maximumStabilizationFrames = 1_800
  }

  enum Calibration {
    static let requiredReliableCoverage = 0.80
    static let minimumUsableSamples = 5
    static let nearestSampleMultiplier = 1.75
    static let nearestSampleFloorSeconds = 0.05
    static let ransacThresholdRunwayWidthFraction = 0.08
    static let ransacThresholdMinimumMeters = 0.04
    static let ransacThresholdMaximumMeters = 0.12
  }
}
