import Foundation

/// Explainable athlete-specific pole decision support.
///
/// `progressionOrder` is deliberately excluded from the sports score. It is used only as the
/// final deterministic tie-break when two evaluations are otherwise indistinguishable.
struct PoleRecommendationEngine: Sendable {
  static let modelVersion = "pole-decision-v15.0"

  struct Input: Sendable {
    let currentPoleID: UUID
    let approach: ApproachLength
    let poles: [PoleSnapshot]
    let progress: [PoleProgressSnapshot]
    let recentAttempts: [AttemptSnapshot]
    var athlete: PoleAthleteContext = .empty
  }

  func recommend(_ input: Input) -> PoleRecommendation? {
    guard let current = input.poles.first(where: { $0.id == input.currentPoleID }) else { return nil }
    let activePoles = input.poles
    guard !activePoles.isEmpty else { return nil }

    let relevant = input.recentAttempts
      .filter { $0.approachSteps == input.approach.rawValue }
      .sorted { $0.createdAt > $1.createdAt }
    let currentAttempts = relevant.filter { $0.poleID == current.id }
    let validCurrent = currentAttempts.filter { $0.result.isValidAttempt }

    let evaluations = activePoles.map {
      evaluate(candidate: $0, current: current, attempts: relevant, currentAttempts: currentAttempts,
               validCurrent: validCurrent, progress: input.progress, athlete: input.athlete,
               approach: input.approach)
    }

    let sorted = evaluations.sorted { lhs, rhs in
      if abs(lhs.readinessScore - rhs.readinessScore) > 0.0001 {
        return lhs.readinessScore > rhs.readinessScore
      }
      if abs(lhs.evidenceQuality - rhs.evidenceQuality) > 0.0001 {
        return lhs.evidenceQuality > rhs.evidenceQuality
      }
      // Weak metadata only: rack order is never part of readiness.
      return lhs.pole.progressionOrder < rhs.pole.progressionOrder
    }
    guard var best = sorted.first else { return nil }

    // Sparse evidence must not manufacture a compelling equipment change.
    if validCurrent.count < 3, best.direction != .stay,
       let stay = evaluations.first(where: { $0.direction == .stay }) {
      best = stay
    }

    // Any hard blocker on the leading transition yields stay/down/lateral when available.
    if !best.blockers.isEmpty, best.direction == .up {
      if let safer = sorted.first(where: { $0.direction != .up && $0.blockers.isEmpty }) {
        best = safer
      }
    }

    let confidence = confidence(for: best)
    return PoleRecommendation(
      evaluation: best,
      alternatives: sorted.filter { $0.pole.id != best.pole.id && $0.blockers.isEmpty }.prefix(2).map { $0 },
      confidence: confidence,
      modelVersion: Self.modelVersion
    )
  }

  private func evaluate(
    candidate: PoleSnapshot,
    current: PoleSnapshot,
    attempts: [AttemptSnapshot],
    currentAttempts: [AttemptSnapshot],
    validCurrent: [AttemptSnapshot],
    progress: [PoleProgressSnapshot],
    athlete: PoleAthleteContext,
    approach: ApproachLength
  ) -> PoleCandidateEvaluation {
    let transition = transition(from: current, to: candidate)
    let candidateAttempts = attempts.filter { $0.poleID == candidate.id && $0.result.isValidAttempt }
    let candidateClears = candidateAttempts.filter { $0.result == .clear }
    let currentProgress = progress.first { $0.poleID == current.id && $0.approachSteps == approach.rawValue }
    let candidateProgress = progress.first { $0.poleID == candidate.id && $0.approachSteps == approach.rawValue }

    let clearRate = weightedRate(validCurrent) { $0.result == .clear }
    let tooSoft = weightedRate(currentAttempts) { $0.diagnostics.contains(.poleTooSoft) }
    let tooStiff = weightedRate(currentAttempts) { $0.diagnostics.contains(.poleTooStiff) }
    let refusal = weightedRate(currentAttempts) { $0.diagnostics.contains(.plantRefusal) }
    let under = weightedRate(currentAttempts) { $0.diagnostics.contains(.takeoffUnder) }
    let out = weightedRate(currentAttempts) { $0.diagnostics.contains(.takeoffOut) }
    let technical = technicalSignal(validCurrent)
    let speed = speedEvidence(validCurrent)
    let grip = gripEvidence(validCurrent)
    let candidateHistory = historicalCandidateSignal(candidateAttempts)

    var blockers: [String] = []
    let stiffCount = currentAttempts.prefix(6).filter { $0.diagnostics.contains(.poleTooStiff) }.count
    let refusalCount = currentAttempts.prefix(6).filter { $0.diagnostics.contains(.plantRefusal) }.count
    let unstableTakeoffCount = currentAttempts.prefix(8).filter {
      $0.diagnostics.contains(.takeoffUnder) || $0.diagnostics.contains(.takeoffOut)
    }.count

    if transition.direction == .up {
      if stiffCount >= 2 { blockers.append("Plusieurs observations « perche trop dure » sur la perche actuelle") }
      if refusalCount >= 2 { blockers.append("Refus de planté répétés") }
      if unstableTakeoffCount >= 4 { blockers.append("Impulsion trop instable pour augmenter la contrainte matériel") }
      if validCurrent.count < 3 { blockers.append("Pas assez de sauts valables pour justifier une montée") }
      if transition.changedAxes >= 3 && candidateAttempts.isEmpty {
        blockers.append("Transition matériel trop importante sans historique sur cette perche")
      }
    }

    var evidence = 0.35
    if !validCurrent.isEmpty {
      evidence = clearRate * 0.36 + technical * 0.18 + speed.consistency * 0.14
        + grip.stability * 0.10 + min(Double(validCurrent.count) / 8.0, 1) * 0.22
    }

    var contextualFit = 0.5
    switch transition.direction {
    case .stay:
      contextualFit = 0.58 + clearRate * 0.14 + (1 - min(tooStiff + refusal, 1)) * 0.08
      if tooSoft >= 0.35 && clearRate >= 0.55 { contextualFit -= 0.12 }
    case .up:
      contextualFit = 0.38 + clearRate * 0.20 + tooSoft * 0.24 + technical * 0.10 + speed.trend * 0.08
      contextualFit -= tooStiff * 0.22 + refusal * 0.24 + under * 0.12 + out * 0.07
    case .down:
      contextualFit = 0.32 + tooStiff * 0.28 + refusal * 0.22 + under * 0.10
      contextualFit += candidateHistory * 0.14
      if clearRate > 0.75 && tooStiff < 0.15 { contextualFit -= 0.16 }
    case .lateral:
      contextualFit = 0.40 + candidateHistory * 0.22 + clearRate * 0.10
      contextualFit -= transition.crossFamily ? 0.08 : 0
    }

    if candidate.id != current.id {
      contextualFit += candidateHistory * 0.16
      if candidateProgress?.state == .mastered { contextualFit += 0.08 }
      contextualFit -= transition.penalty
    }
    if currentProgress?.state == .mastered, transition.direction == .up { contextualFit += 0.05 }

    // Weight-rating sanity is contextual, not a manufacturer stiffness equation.
    if athlete.bodyWeightKG > 0, candidate.weightKG + 0.5 < athlete.bodyWeightKG {
      contextualFit -= 0.10
    }

    var readiness = evidence * 0.46 + contextualFit * 0.54
    if !blockers.isEmpty && transition.direction == .up { readiness = min(readiness, 0.34) }
    if validCurrent.count < 3 && transition.direction != .stay { readiness = min(readiness, 0.44) }
    readiness = finiteUnit(readiness)

    var quality = min(Double(validCurrent.count) / 10.0, 1) * 0.52
    if speed.available { quality += 0.14 }
    if grip.available { quality += 0.10 }
    if !candidateAttempts.isEmpty { quality += min(Double(candidateAttempts.count) / 6.0, 1) * 0.16 }
    if transition.crossFamily { quality -= 0.12 }
    if transition.changedAxes >= 2 { quality -= 0.06 }
    quality = finiteUnit(quality)

    var reasons: [String] = []
    if transition.direction == .stay {
      reasons.append("Rester sur la perche actuelle est inclus comme une vraie option de décision.")
    }
    if !validCurrent.isEmpty {
      reasons.append("Réussite récente pondérée : \(Int((clearRate * 100).rounded())) % sur \(validCurrent.count) saut(s) valable(s).")
    }
    if tooSoft >= 0.25 { reasons.append("Le diagnostic « perche trop souple » est répété.") }
    if tooStiff >= 0.25 { reasons.append("Le diagnostic « perche trop dure » est répété.") }
    if candidateClears.count >= 2 { reasons.append("Cette perche a déjà été utilisée avec réussite par cet athlète sur le même élan.") }
    if speed.available { reasons.append(speed.reason) }
    if grip.available { reasons.append(grip.reason) }
    if technical > 0.65 { reasons.append("Les évaluations techniques récentes sont cohérentes.") }

    var warnings = transition.warnings
    if speed.mixedProtocols { warnings.append("Les vitesses issues de protocoles différents n’ont pas été mélangées.") }
    if grip.changed { warnings.append("La hauteur de prise a récemment changé : comparaison interprétée avec prudence.") }
    if validCurrent.count < 3 { warnings.append("Données rares : privilégier des mesures supplémentaires avant un changement de perche.") }
    if !blockers.isEmpty { warnings.append(contentsOf: blockers) }

    return PoleCandidateEvaluation(
      pole: candidate,
      direction: transition.direction,
      transitionDescription: transition.description,
      evidenceScore: finiteUnit(evidence),
      contextualFitScore: finiteUnit(contextualFit),
      readinessScore: readiness,
      evidenceQuality: quality,
      evidenceCount: validCurrent.count,
      blockers: blockers,
      reasons: Array(reasons.prefix(6)),
      warnings: Array(warnings.prefix(7))
    )
  }

  private struct Transition {
    var direction: PoleRecommendationDirection
    var description: String
    var penalty: Double
    var changedAxes: Int
    var crossFamily: Bool
    var warnings: [String]
  }

  private func transition(from current: PoleSnapshot, to candidate: PoleSnapshot) -> Transition {
    if current.id == candidate.id {
      return Transition(direction: .stay, description: "Même perche", penalty: 0, changedAxes: 0,
                        crossFamily: false, warnings: [])
    }
    let sameFamily = normalized(current.manufacturer) == normalized(candidate.manufacturer)
      && normalized(current.model) == normalized(candidate.model)
    let lengthDelta = candidate.lengthCM - current.lengthCM
    let weightDelta = candidate.weightKG - current.weightKG
    let flexDelta = candidate.flexCM - current.flexCM

    var upVotes = 0
    var downVotes = 0
    if lengthDelta >= 10 { upVotes += 1 }
    if lengthDelta <= -10 { downVotes += 1 }
    if weightDelta >= 2 { upVotes += 1 }
    if weightDelta <= -2 { downVotes += 1 }
    // Flex direction is meaningful only within the same manufacturer/model family and comparable length.
    if sameFamily && abs(lengthDelta) < 15 {
      if flexDelta <= -0.5 { upVotes += 1 }
      if flexDelta >= 0.5 { downVotes += 1 }
    }

    let direction: PoleRecommendationDirection
    if upVotes > downVotes { direction = .up }
    else if downVotes > upVotes { direction = .down }
    else { direction = .lateral }

    var changedAxes = 0
    if abs(lengthDelta) >= 5 { changedAxes += 1 }
    if abs(weightDelta) >= 1 { changedAxes += 1 }
    if sameFamily && abs(flexDelta) >= 0.4 { changedAxes += 1 }
    if !sameFamily { changedAxes += 1 }

    // Transition cost is an equipment-change magnitude, not a success probability.
    // Raw flex contributes only inside the same manufacturer/model family.
    var penalty = 0.0
    penalty += min(abs(weightDelta) / 10.0 * 0.08, 0.12)
    penalty += min(Double(abs(lengthDelta)) / 30.0 * 0.08, 0.12)
    if sameFamily { penalty += min(abs(flexDelta) / 3.0 * 0.06, 0.08) }
    if changedAxes >= 2 { penalty += 0.03 }
    if changedAxes >= 3 { penalty += 0.04 }
    if !sameFamily { penalty += 0.08 }

    var warnings: [String] = []
    if !sameFamily {
      warnings.append("Changement de famille/fabricant : les valeurs de flex ne sont pas comparées directement.")
    }
    if changedAxes >= 2 { warnings.append("Plusieurs caractéristiques de la perche changent simultanément.") }
    let description = "\(String(format: "%.2f", Double(current.lengthCM)/100)) m / \(Int(current.weightKG)) kg → \(String(format: "%.2f", Double(candidate.lengthCM)/100)) m / \(Int(candidate.weightKG)) kg"
    return Transition(direction: direction, description: description, penalty: penalty,
                      changedAxes: changedAxes, crossFamily: !sameFamily, warnings: warnings)
  }

  private func normalized(_ value: String) -> String {
    value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
  }

  private func weightedRate(_ attempts: [AttemptSnapshot], predicate: (AttemptSnapshot) -> Bool) -> Double {
    guard !attempts.isEmpty else { return 0 }
    var numerator = 0.0, denominator = 0.0
    for (index, attempt) in attempts.enumerated() {
      let weight = exp(-0.18 * Double(index))
      denominator += weight
      if predicate(attempt) { numerator += weight }
    }
    return denominator > 0 ? finiteUnit(numerator / denominator) : 0
  }

  private func historicalCandidateSignal(_ attempts: [AttemptSnapshot]) -> Double {
    guard !attempts.isEmpty else { return 0 }
    let clears = Double(attempts.filter { $0.result == .clear }.count)
    let rate = clears / Double(attempts.count)
    return finiteUnit(rate * min(Double(attempts.count) / 5.0, 1))
  }

  private func technicalSignal(_ attempts: [AttemptSnapshot]) -> Double {
    let values = attempts.map(\.technicalRating.rawValue).filter { $0 > 0 }
    guard !values.isEmpty else { return 0.5 }
    // JumpRating is a bounded athlete-entered ordinal observation, not converted to a probability.
    let maxRating = max(JumpRating.allCases.map(\.rawValue).max() ?? 1, 1)
    return finiteUnit(Double(values.reduce(0,+)) / Double(values.count * maxRating))
  }

  private struct SpeedEvidence {
    var available: Bool; var consistency: Double; var trend: Double; var mixedProtocols: Bool; var reason: String
  }

  private func speedEvidence(_ attempts: [AttemptSnapshot]) -> SpeedEvidence {
    let valid = attempts.compactMap { attempt -> (String, Date, Double)? in
      guard let value = attempt.approachSpeedMPS, value.isFinite, value > 0,
            let kind = attempt.approachSpeedKind else { return nil }
      let protocolKey = "\(kind.rawValue)|\(attempt.approachSpeedSource.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())"
      return (protocolKey, attempt.createdAt, value)
    }
    let groups = Dictionary(grouping: valid, by: { $0.0 })
    guard let group = groups.values.max(by: { $0.count < $1.count }), group.count >= 3 else {
      return SpeedEvidence(available: false, consistency: 0.45, trend: 0.5, mixedProtocols: groups.count > 1,
                           reason: "")
    }
    let ordered = group.sorted { $0.1 < $1.1 }
    let values = ordered.map(\.2)
    let mean = values.reduce(0,+) / Double(values.count)
    guard mean > 0 else { return SpeedEvidence(available: false, consistency: 0.45, trend: 0.5, mixedProtocols: groups.count > 1, reason: "") }
    let variance = values.map { pow($0-mean,2) }.reduce(0,+) / Double(values.count)
    let cv = sqrt(variance)/mean
    let consistency = finiteUnit(1 - max(0, cv - 0.02)/0.08)
    let split = max(values.count/2,1)
    let early = Array(values.prefix(split)); let late = Array(values.suffix(split))
    let earlyMean = early.reduce(0,+)/Double(early.count); let lateMean = late.reduce(0,+)/Double(late.count)
    let relative = (lateMean-earlyMean)/max(earlyMean,0.1)
    let trend = finiteUnit(0.5 + relative*4)
    return SpeedEvidence(available: true, consistency: consistency, trend: trend, mixedProtocols: groups.count > 1,
      reason: String(format: "Vitesse cohérente sur le même protocole (dispersion %.1f %%).", cv*100))
  }

  private struct GripEvidence { var available: Bool; var stability: Double; var changed: Bool; var reason: String }
  private func gripEvidence(_ attempts: [AttemptSnapshot]) -> GripEvidence {
    let values = attempts.compactMap(\.gripHeightM).filter { $0.isFinite && $0 > 0 }
    guard values.count >= 3 else { return GripEvidence(available: false, stability: 0.5, changed: false, reason: "") }
    let mean = values.reduce(0,+)/Double(values.count)
    let range = (values.max() ?? mean) - (values.min() ?? mean)
    let changed = range >= 0.08
    let stability = finiteUnit(1 - range/0.20)
    return GripEvidence(available: true, stability: stability, changed: changed,
      reason: changed ? "La hauteur de prise est renseignée mais varie récemment." : "La hauteur de prise récente est stable et renseignée.")
  }

  private func confidence(for evaluation: PoleCandidateEvaluation) -> PoleRecommendation.Confidence {
    let q = evaluation.evidenceQuality
    if q >= 0.72 && evaluation.evidenceCount >= 7 { return .high }
    if q >= 0.45 && evaluation.evidenceCount >= 4 { return .medium }
    return .low
  }

  private func finiteUnit(_ value: Double) -> Double {
    guard value.isFinite else { return 0 }
    return min(max(value, 0), 1)
  }
}
