import Foundation

enum AchievementCategory: String, CaseIterable, Identifiable, Sendable {
  case gettingStarted = "Premiers pas"
  case performance = "Performance"
  case consistency = "Régularité"
  case technique = "Technique"
  case equipment = "Matériel"

  var id: String { rawValue }
}

struct AchievementSnapshot: Sendable {
  let sessionCount: Int
  let attemptCount: Int
  let clearCount: Int
  let currentPRCM: Int
  let targetHeightCM: Int
  let videoCount: Int
  let analyzedVideoCount: Int
  let masteredPoleCount: Int
  let completedDrillCount: Int
  let speedMeasurementCount: Int
  let consecutiveWeeks: Int
  let bestSessionClearRate: Double
  let hasVoiceLog: Bool

  static let empty = AchievementSnapshot(
    sessionCount: 0,
    attemptCount: 0,
    clearCount: 0,
    currentPRCM: 0,
    targetHeightCM: 0,
    videoCount: 0,
    analyzedVideoCount: 0,
    masteredPoleCount: 0,
    completedDrillCount: 0,
    speedMeasurementCount: 0,
    consecutiveWeeks: 0,
    bestSessionClearRate: 0,
    hasVoiceLog: false
  )
}

struct VaultAchievement: Identifiable, Sendable {
  let id: String
  let category: AchievementCategory
  let title: String
  let detail: String
  let symbol: String
  let current: Double
  let target: Double

  var progress: Double {
    guard target > 0 else { return 0 }
    return min(max(current / target, 0), 1)
  }

  var isUnlocked: Bool { current >= target }
}

enum AchievementEngine {
  static func snapshot(
    athlete: AthleteProfile?,
    sessions: [VaultSessionRecord],
    attempts: [AttemptRecord],
    videos: [VideoClipRecord],
    poleProgress: [PoleApproachProgressRecord],
    drillCompletions: [DrillCompletionRecord],
    metrics: [PhysicalMetricRecord]
  ) -> AchievementSnapshot {
    guard let athlete else { return .empty }
    let athleteID = athlete.id
    let scopedSessions = sessions.filter { $0.athleteID == athleteID }
    let scopedAttempts = attempts.filter { $0.athleteID == athleteID && $0.deletedAt == nil }
    let scopedVideos = videos.filter { $0.athleteID == athleteID }
    let scopedMetrics = metrics.filter { $0.athleteID == athleteID }
    let grouped = Dictionary(grouping: scopedAttempts.filter { $0.result.isValidAttempt }) {
      $0.sessionID
    }
    let bestRate = grouped.values.compactMap { group -> Double? in
      guard group.count >= 5 else { return nil }
      return Double(group.filter { $0.result == .clear }.count) / Double(group.count)
    }.max() ?? 0

    return AchievementSnapshot(
      sessionCount: scopedSessions.count,
      attemptCount: scopedAttempts.count,
      clearCount: scopedAttempts.filter { $0.result == .clear }.count,
      currentPRCM: max(athlete.currentPRCM, athlete.trainingPRCM),
      targetHeightCM: athlete.targetHeightCM,
      videoCount: scopedVideos.count,
      analyzedVideoCount: scopedVideos.filter { $0.motionAnalysisData != nil }.count,
      masteredPoleCount: poleProgress.filter {
        $0.athleteID == athleteID && $0.state == .mastered
      }.count,
      completedDrillCount: drillCompletions.filter { $0.athleteID == athleteID }.count,
      speedMeasurementCount: scopedMetrics.filter { $0.kind.isApproachSpeedFamily }.count,
      consecutiveWeeks: consecutiveWeekCount(
        dates: scopedSessions.map(\.startedAt), calendar: .current),
      bestSessionClearRate: bestRate,
      hasVoiceLog: scopedAttempts.contains { !$0.voiceTranscript.isEmpty }
    )
  }

  static func achievements(for snapshot: AchievementSnapshot) -> [VaultAchievement] {
    let targetReached = snapshot.targetHeightCM > 0 && snapshot.currentPRCM >= snapshot.targetHeightCM
    return [
      item("first-session", .gettingStarted, "Première séance", "Enregistrer une séance complète.", "figure.run", snapshot.sessionCount, 1),
      item("first-jump", .gettingStarted, "Premier saut", "Ajouter un saut au journal.", "figure.track.and.field", snapshot.attemptCount, 1),
      item("voice-log", .gettingStarted, "Journal mains libres", "Valider un saut dicté à la voix.", "waveform.and.mic", snapshot.hasVoiceLog ? 1 : 0, 1),
      item("first-clear", .performance, "Première barre", "Enregistrer un saut réussi.", "checkmark.circle.fill", snapshot.clearCount, 1),
      item("personal-best", .performance, "Record renseigné", "Établir un record supérieur à 0 m.", "trophy.fill", snapshot.currentPRCM > 0 ? 1 : 0, 1),
      item("target-reached", .performance, "Objectif atteint", "Atteindre l’objectif principal du profil.", "flag.checkered", targetReached ? 1 : 0, 1),
      item("quality-session", .performance, "Séance maîtrisée", "Atteindre 80 % de réussite sur au moins cinq essais.", "scope", snapshot.bestSessionClearRate, 0.8),
      item("five-sessions", .consistency, "Rythme installé", "Enregistrer cinq séances.", "calendar.badge.checkmark", snapshot.sessionCount, 5),
      item("twenty-sessions", .consistency, "Habitude durable", "Enregistrer vingt séances.", "calendar", snapshot.sessionCount, 20),
      item("four-week-streak", .consistency, "Quatre semaines", "S’entraîner quatre semaines consécutives.", "flame.fill", snapshot.consecutiveWeeks, 4),
      item("twenty-five-jumps", .consistency, "Compteur 25", "Journaliser vingt-cinq sauts.", "number", snapshot.attemptCount, 25),
      item("hundred-jumps", .consistency, "Compteur 100", "Journaliser cent sauts.", "100.circle.fill", snapshot.attemptCount, 100),
      item("first-video", .technique, "Œil technique", "Importer une première vidéo.", "video.fill", snapshot.videoCount, 1),
      item("five-analyses", .technique, "Analyste", "Finaliser cinq analyses vidéo.", "viewfinder", snapshot.analyzedVideoCount, 5),
      item("speed-measured", .technique, "Vitesse mesurée", "Enregistrer une mesure de vitesse d’élan.", "speedometer", snapshot.speedMeasurementCount, 1),
      item("ten-drills", .technique, "Travail ciblé", "Valider dix exercices techniques.", "checklist", snapshot.completedDrillCount, 10),
      item("first-mastered-pole", .equipment, "Perche maîtrisée", "Maîtriser une perche sur une course d’élan.", "line.diagonal", snapshot.masteredPoleCount, 1),
      item("three-mastered-poles", .equipment, "Râtelier solide", "Maîtriser trois perches.", "crown.fill", snapshot.masteredPoleCount, 3),
    ]
  }

  private static func item(
    _ id: String,
    _ category: AchievementCategory,
    _ title: String,
    _ detail: String,
    _ symbol: String,
    _ current: Int,
    _ target: Int
  ) -> VaultAchievement {
    item(id, category, title, detail, symbol, Double(current), Double(target))
  }

  private static func item(
    _ id: String,
    _ category: AchievementCategory,
    _ title: String,
    _ detail: String,
    _ symbol: String,
    _ current: Double,
    _ target: Double
  ) -> VaultAchievement {
    VaultAchievement(
      id: id,
      category: category,
      title: title,
      detail: detail,
      symbol: symbol,
      current: current,
      target: target
    )
  }

  private static func consecutiveWeekCount(dates: [Date], calendar: Calendar) -> Int {
    let weeks = Set(dates.compactMap { calendar.dateInterval(of: .weekOfYear, for: $0)?.start })
      .sorted(by: >)
    guard let latest = weeks.first else { return 0 }

    let currentWeek = calendar.dateInterval(of: .weekOfYear, for: .now)?.start
    let previousWeek = currentWeek.flatMap {
      calendar.date(byAdding: .weekOfYear, value: -1, to: $0)
    }
    let isCurrentWeek = currentWeek.map { calendar.isDate(latest, inSameDayAs: $0) } ?? false
    let isPreviousWeek = previousWeek.map { calendar.isDate(latest, inSameDayAs: $0) } ?? false
    guard isCurrentWeek || isPreviousWeek else { return 0 }

    var count = 1
    var cursor = latest
    for week in weeks.dropFirst() {
      guard let expected = calendar.date(byAdding: .weekOfYear, value: -1, to: cursor) else {
        break
      }
      if calendar.isDate(week, inSameDayAs: expected) {
        count += 1
        cursor = week
      } else {
        break
      }
    }
    return count
  }
}
