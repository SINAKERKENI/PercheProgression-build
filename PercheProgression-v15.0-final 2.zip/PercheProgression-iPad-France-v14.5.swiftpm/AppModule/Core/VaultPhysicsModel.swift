import Foundation

/// Modèle énergétique explicable, destiné à guider la lecture de la jauge et non à prédire un résultat.
/// L'énergie cinétique spécifique suit 1/2 v² : une hausse de vitesse coûte donc de façon quadratique.
struct VaultPhysicsModel: Sendable {
  struct Estimate: Equatable, Sendable {
    let targetSpeed: Double
    let currentSpecificKineticEnergy: Double
    let targetSpecificKineticEnergy: Double
    let energyProgress: Double
    let speedGap: Double
    let modelVersion: String
  }

  let gravity: Double = 9.80665
  /// Part de l'énergie horizontale disponible convertie en élévation utile dans ce modèle simplifié.
  let conversionEfficiency: Double = 0.78
  /// Contribution verticale/technique moyenne (impulsion, travail sous la perche et repoussée), en mètres équivalents.
  let activeTechnicalLiftMeters: Double = 0.95
  /// Approximation anthropométrique du centre de masse debout.
  let standingCOMRatio: Double = 0.55

  func estimate(
    targetHeightCM: Int,
    athleteHeightCM: Double,
    currentSpeed: Double
  ) -> Estimate {
    let targetHeight = max(Double(targetHeightCM) / 100.0, 0)
    let athleteHeight = max(athleteHeightCM / 100.0, 0)

    guard targetHeight > 0, athleteHeight > 0 else {
      return Estimate(
        targetSpeed: 0,
        currentSpecificKineticEnergy: 0.5 * max(currentSpeed, 0) * max(currentSpeed, 0),
        targetSpecificKineticEnergy: 0,
        energyProgress: 0,
        speedGap: 0,
        modelVersion: "Énergie v1"
      )
    }

    let takeoffCOMHeight = standingCOMRatio * athleteHeight
    let verticalDemand = max(targetHeight - takeoffCOMHeight - activeTechnicalLiftMeters, 0)
    let targetSpeed = sqrt((2 * gravity * verticalDemand) / conversionEfficiency)
    let currentEnergy = 0.5 * pow(max(currentSpeed, 0), 2)
    let targetEnergy = 0.5 * pow(max(targetSpeed, 0), 2)
    let progress = targetEnergy > 0 ? min(max(currentEnergy / targetEnergy, 0), 1) : 0

    return Estimate(
      targetSpeed: targetSpeed,
      currentSpecificKineticEnergy: currentEnergy,
      targetSpecificKineticEnergy: targetEnergy,
      energyProgress: progress,
      speedGap: max(targetSpeed - currentSpeed, 0),
      modelVersion: "Énergie v1 · η 78 % · apport technique 0,95 m"
    )
  }
}
