import Foundation

// MARK: - Étalonnage dynamique du plan de la piste

/// Convention métrique utilisée par l'application :
/// - X = distance longitudinale sur le plan de piste.
/// - en mode absolu, X = 0 correspond au fond du butoir ;
/// - en mode fixe sans butoir, X = 0 correspond à une ligne de référence réelle choisie par l'utilisateur.
/// - Y = position transversale sur la piste.
/// - Z = 0 pour le plan de la piste.
struct RunwayGridCalibration: Codable, Equatable, Sendable {
  var boxLeft: NormalizedPoint
  var boxRight: NormalizedPoint
  var farLeft: NormalizedPoint
  var farRight: NormalizedPoint
  var zoneLengthMeters: Double
  var runwayWidthMeters: Double

  init(
    boxLeft: NormalizedPoint = .init(x: 0.64, y: 0.80),
    boxRight: NormalizedPoint = .init(x: 0.84, y: 0.80),
    farLeft: NormalizedPoint = .init(x: 0.18, y: 0.62),
    farRight: NormalizedPoint = .init(x: 0.46, y: 0.62),
    zoneLengthMeters: Double = 5,
    runwayWidthMeters: Double = 1.22
  ) {
    self.boxLeft = boxLeft.clamped()
    self.boxRight = boxRight.clamped()
    self.farLeft = farLeft.clamped()
    self.farRight = farRight.clamped()
    self.zoneLengthMeters = max(zoneLengthMeters, 0.5)
    self.runwayWidthMeters = max(runwayWidthMeters, 0.4)
  }

  var imagePoints: [NormalizedPoint] {
    [boxLeft, boxRight, farLeft, farRight]
  }

  static func manualTemplate(
    zoneLengthMeters: Double = 5,
    runwayWidthMeters: Double = 1.22,
    mirrored: Bool = false
  ) -> RunwayGridCalibration {
    let grid = RunwayGridCalibration(
      boxLeft: .init(x: 0.64, y: 0.80),
      boxRight: .init(x: 0.84, y: 0.80),
      farLeft: .init(x: 0.18, y: 0.62),
      farRight: .init(x: 0.46, y: 0.62),
      zoneLengthMeters: zoneLengthMeters,
      runwayWidthMeters: runwayWidthMeters
    )
    return mirrored ? grid.mirroredHorizontally() : grid
  }

  func mirroredHorizontally() -> RunwayGridCalibration {
    func mirror(_ point: NormalizedPoint) -> NormalizedPoint {
      .init(x: 1 - point.x, y: point.y)
    }
    return RunwayGridCalibration(
      boxLeft: mirror(boxRight),
      boxRight: mirror(boxLeft),
      farLeft: mirror(farRight),
      farRight: mirror(farLeft),
      zoneLengthMeters: zoneLengthMeters,
      runwayWidthMeters: runwayWidthMeters
    )
  }

  var isGeometricallyUsable: Bool {
    zoneLengthMeters > 0.5
      && runwayWidthMeters > 0.4
      && polygonArea > 0.004
      && edgeLength(boxLeft, boxRight) > 0.035
      && edgeLength(farLeft, farRight) > 0.020
      && edgeLength(boxLeft, farLeft) > 0.055
      && edgeLength(boxRight, farRight) > 0.055
      && isConvexAndOrdered
      && imagePoints.allSatisfy { (0...1).contains($0.x) && (0...1).contains($0.y) }
  }

  private var isConvexAndOrdered: Bool {
    let points = [boxLeft, boxRight, farRight, farLeft]
    var signs: [Double] = []
    for index in points.indices {
      let a = points[index]
      let b = points[(index + 1) % points.count]
      let c = points[(index + 2) % points.count]
      let cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
      if abs(cross) > 1e-6 { signs.append(cross) }
    }
    guard signs.count >= 3 else { return false }
    return signs.allSatisfy { $0 > 0 } || signs.allSatisfy { $0 < 0 }
  }

  private func edgeLength(_ first: NormalizedPoint, _ second: NormalizedPoint) -> Double {
    hypot(second.x - first.x, second.y - first.y)
  }

  var polygonArea: Double {
    let points = [boxLeft, boxRight, farRight, farLeft]
    var area = 0.0
    for index in points.indices {
      let next = points[(index + 1) % points.count]
      area += points[index].x * next.y - next.x * points[index].y
    }
    return abs(area) * 0.5
  }

  var center: NormalizedPoint {
    let points = imagePoints
    return NormalizedPoint(
      x: points.map(\.x).reduce(0, +) / Double(points.count),
      y: points.map(\.y).reduce(0, +) / Double(points.count)
    )
  }

  func replacingPoint(at index: Int, with point: NormalizedPoint) -> RunwayGridCalibration {
    var copy = self
    switch index {
    case 0: copy.boxLeft = point.clamped()
    case 1: copy.boxRight = point.clamped()
    case 2: copy.farLeft = point.clamped()
    case 3: copy.farRight = point.clamped()
    default: break
    }
    return copy
  }

  func translated(dx: Double, dy: Double) -> RunwayGridCalibration {
    var copy = self
    copy.boxLeft = .init(x: boxLeft.x + dx, y: boxLeft.y + dy).clamped()
    copy.boxRight = .init(x: boxRight.x + dx, y: boxRight.y + dy).clamped()
    copy.farLeft = .init(x: farLeft.x + dx, y: farLeft.y + dy).clamped()
    copy.farRight = .init(x: farRight.x + dx, y: farRight.y + dy).clamped()
    return copy
  }

  func scaled(by factor: Double) -> RunwayGridCalibration {
    let c = center
    func scale(_ point: NormalizedPoint) -> NormalizedPoint {
      NormalizedPoint(
        x: c.x + (point.x - c.x) * factor,
        y: c.y + (point.y - c.y) * factor
      ).clamped()
    }
    var copy = self
    copy.boxLeft = scale(boxLeft)
    copy.boxRight = scale(boxRight)
    copy.farLeft = scale(farLeft)
    copy.farRight = scale(farRight)
    return copy
  }

  func rotated(by radians: Double) -> RunwayGridCalibration {
    let c = center
    let cosine = cos(radians)
    let sine = sin(radians)
    func rotate(_ point: NormalizedPoint) -> NormalizedPoint {
      let dx = point.x - c.x
      let dy = point.y - c.y
      return NormalizedPoint(
        x: c.x + dx * cosine - dy * sine,
        y: c.y + dx * sine + dy * cosine
      ).clamped()
    }
    var copy = self
    copy.boxLeft = rotate(boxLeft)
    copy.boxRight = rotate(boxRight)
    copy.farLeft = rotate(farLeft)
    copy.farRight = rotate(farRight)
    return copy
  }
}

enum CalibrationSource: String, Codable, Sendable {
  case automaticRectangle
  case detectorAnchor
  case featureTracking
  case userCorrection
  case interpolated

  var title: String {
    switch self {
    case .automaticRectangle: "Détection automatique"
    case .detectorAnchor: "Ré-ancrage IA"
    case .featureTracking: "Suivi dynamique"
    case .userCorrection: "Correction manuelle"
    case .interpolated: "Interpolation"
    }
  }
}

enum CalibrationStatus: String, Codable, Sendable {
  case reliable
  case review
  case manualRequired
  case unavailable

  var title: String {
    switch self {
    case .reliable: "Mesure fiable"
    case .review: "À contrôler"
    case .manualRequired: "Correction requise"
    case .unavailable: "Indisponible"
    }
  }
}

struct Matrix3x3: Codable, Equatable, Sendable {
  var m11: Double
  var m12: Double
  var m13: Double
  var m21: Double
  var m22: Double
  var m23: Double
  var m31: Double
  var m32: Double
  var m33: Double

  static let identity = Matrix3x3(
    m11: 1, m12: 0, m13: 0,
    m21: 0, m22: 1, m23: 0,
    m31: 0, m32: 0, m33: 1
  )

  func project(_ point: NormalizedPoint) -> NormalizedPoint? {
    let denominator = m31 * point.x + m32 * point.y + m33
    guard denominator.isFinite, abs(denominator) > 1e-10 else { return nil }
    let x = (m11 * point.x + m12 * point.y + m13) / denominator
    let y = (m21 * point.x + m22 * point.y + m23) / denominator
    guard x.isFinite, y.isFinite else { return nil }
    return NormalizedPoint(x: x, y: y)
  }

  func projectMetric(_ point: NormalizedPoint) -> MetricRunwayPoint? {
    guard let projected = project(point) else { return nil }
    return MetricRunwayPoint(xMeters: projected.x, yMeters: projected.y)
  }
}

struct MetricRunwayPoint: Codable, Equatable, Sendable {
  var xMeters: Double
  var yMeters: Double
}

struct CalibrationKeyframe: Identifiable, Codable, Equatable, Sendable {
  var id: UUID
  var timeSeconds: Double
  var source: CalibrationSource
  var grid: RunwayGridCalibration
  var imageToRunway: Matrix3x3
  var confidence: Double
  var reprojectionErrorPixels: Double
  var estimatedErrorMeters: Double

  init(
    id: UUID = UUID(),
    timeSeconds: Double,
    source: CalibrationSource,
    grid: RunwayGridCalibration,
    imageToRunway: Matrix3x3,
    confidence: Double,
    reprojectionErrorPixels: Double = 0,
    estimatedErrorMeters: Double = 0
  ) {
    self.id = id
    self.timeSeconds = timeSeconds
    self.source = source
    self.grid = grid
    self.imageToRunway = imageToRunway
    self.confidence = min(max(confidence, 0), 1)
    self.reprojectionErrorPixels = max(reprojectionErrorPixels, 0)
    self.estimatedErrorMeters = max(estimatedErrorMeters, 0)
  }
}

struct HomographySample: Identifiable, Codable, Equatable, Sendable {
  var id: UUID
  var timeSeconds: Double
  var grid: RunwayGridCalibration
  var imageToRunway: Matrix3x3
  var source: CalibrationSource
  var trackedPointCount: Int
  var inlierRatio: Double
  var confidence: Double
  var estimatedErrorMeters: Double
  var status: CalibrationStatus

  init(
    id: UUID = UUID(),
    timeSeconds: Double,
    grid: RunwayGridCalibration,
    imageToRunway: Matrix3x3,
    source: CalibrationSource,
    trackedPointCount: Int,
    inlierRatio: Double,
    confidence: Double,
    estimatedErrorMeters: Double,
    status: CalibrationStatus
  ) {
    self.id = id
    self.timeSeconds = timeSeconds
    self.grid = grid
    self.imageToRunway = imageToRunway
    self.source = source
    self.trackedPointCount = trackedPointCount
    self.inlierRatio = min(max(inlierRatio, 0), 1)
    self.confidence = min(max(confidence, 0), 1)
    self.estimatedErrorMeters = max(estimatedErrorMeters, 0)
    self.status = status
  }
}

struct DynamicCalibrationTrack: Codable, Equatable, Sendable {
  var coordinateSystemVersion: String
  var initialGrid: RunwayGridCalibration
  var keyframes: [CalibrationKeyframe]
  var samples: [HomographySample]
  var startTime: Double
  var endTime: Double
  var averageConfidence: Double
  var modelVersion: String
  var takeoffMeasurement: TakeoffMeasurement?

  init(
    coordinateSystemVersion: String = "box-origin-x-runway-v1",
    initialGrid: RunwayGridCalibration = RunwayGridCalibration(),
    keyframes: [CalibrationKeyframe] = [],
    samples: [HomographySample] = [],
    startTime: Double = 0,
    endTime: Double = 0,
    averageConfidence: Double = 0,
    modelVersion: String = "Vision multi-anchor dynamic homography v1",
    takeoffMeasurement: TakeoffMeasurement? = nil
  ) {
    self.coordinateSystemVersion = coordinateSystemVersion
    self.initialGrid = initialGrid
    self.keyframes = keyframes
    self.samples = samples.sorted { $0.timeSeconds < $1.timeSeconds }
    self.startTime = startTime
    self.endTime = endTime
    self.averageConfidence = min(max(averageConfidence, 0), 1)
    self.modelVersion = modelVersion
    self.takeoffMeasurement = takeoffMeasurement
  }

  var reliableCoverageRatio: Double {
    guard !samples.isEmpty else { return 0 }
    let valid = samples.filter { $0.status == .reliable || $0.status == .review }.count
    return Double(valid) / Double(samples.count)
  }

  var isUsable: Bool {
    samples.count >= VideoAnalysisConfiguration.Calibration.minimumUsableSamples && reliableCoverageRatio >= VideoAnalysisConfiguration.Calibration.requiredReliableCoverage
  }

  /// Nearest sample for display, including review/manual-required states.
  func sample(nearest time: Double) -> HomographySample? {
    samples.min { abs($0.timeSeconds - time) < abs($1.timeSeconds - time) }
  }

  /// Sample allowed to feed a metric. Manual-required/unavailable samples are never accepted.
  func validatedSample(nearest time: Double, maximumDelta: Double? = nil) -> HomographySample? {
    guard let candidate = sample(nearest: time),
      candidate.status == .reliable || candidate.status == .review
    else { return nil }

    let typicalDelta: Double = {
      guard samples.count > 1 else { return 1.0 / 30.0 }
      let deltas = zip(samples.dropFirst(), samples).map { $0.0.timeSeconds - $0.1.timeSeconds }
        .filter { $0 > 0 }.sorted()
      return deltas.isEmpty ? 1.0 / 30.0 : deltas[deltas.count / 2]
    }()
    let allowed = maximumDelta ?? max(typicalDelta * VideoAnalysisConfiguration.Calibration.nearestSampleMultiplier, VideoAnalysisConfiguration.Calibration.nearestSampleFloorSeconds)
    return abs(candidate.timeSeconds - time) <= allowed ? candidate : nil
  }

  func grid(nearest time: Double) -> RunwayGridCalibration {
    sample(nearest: time)?.grid ?? initialGrid
  }
}

enum TakeoffContactConvention: String, CaseIterable, Identifiable, Codable, Sendable {
  case toe = "toe"
  case footCenter = "foot-center"
  case shoeFront = "shoe-front"

  var id: String { rawValue }
  var title: String {
    switch self {
    case .toe: "Pointe du pied"
    case .footCenter: "Centre de l’appui"
    case .shoeFront: "Avant de la chaussure"
    }
  }
}

struct TakeoffMeasurement: Codable, Equatable, Sendable {
  var timeSeconds: Double
  var imagePoint: NormalizedPoint
  var distanceFromBoxMeters: Double
  var lateralPositionMeters: Double
  var confidence: Double
  var uncertaintyMeters: Double?
  var convention: TakeoffContactConvention
  var status: CalibrationStatus

  var formattedDistance: String {
    if let uncertaintyMeters, uncertaintyMeters > 0 {
      return String(format: "%.2f m ± %.2f m", distanceFromBoxMeters, uncertaintyMeters)
    }
    return String(format: "%.2f m · incertitude non calibrée", distanceFromBoxMeters)
  }
}

enum VideoProcessingPhase: String, Codable, Sendable {
  case earlyApproach
  case metricZone
  case plantTakeoff
  case aerial
  case complete

  var title: String {
    switch self {
    case .earlyApproach: "Approche · mode léger"
    case .metricZone: "Zone métrique · 5 derniers mètres"
    case .plantTakeoff: "Présentation et impulsion"
    case .aerial: "Phase aérienne · posture et angles"
    case .complete: "Analyse terminée"
    }
  }

  var symbol: String {
    switch self {
    case .earlyApproach: "figure.run"
    case .metricZone: "ruler"
    case .plantTakeoff: "shoeprints.fill"
    case .aerial: "figure.gymnastics"
    case .complete: "checkmark.circle"
    }
  }
}
