import Foundation

enum BiomechanicalMeasurementQuality: String, Codable, Sendable {
  case automatic = "Automatique"
  case verifiedManual = "Vérifié manuellement"
  case lowQuality = "Faible qualité"
  case review = "À revoir"
}

struct BiomechanicalAngle: Identifiable, Equatable, Sendable {
  var id: String
  var title: String
  var degrees: Double
  /// Vision detection score when available. It is NOT interpreted as an angular uncertainty.
  var detectionScore: Double?
  var quality: BiomechanicalMeasurementQuality
  var uncertaintyDegrees: Double?
  var referenceDescription: String
  var isProjected2D: Bool
}

enum BiomechanicsAngleEngine {
  static func calculate(joints: [PoseJoint], vectors: [OverlayVector]) -> [BiomechanicalAngle] {
    let map = Dictionary(uniqueKeysWithValues: joints.map { ($0.id, $0) })
    var values: [BiomechanicalAngle] = []

    appendJointAngle(
      id: "left-knee", title: "Genou gauche",
      a: map["leftHip"], b: map["leftKnee"], c: map["leftAnkle"], to: &values
    )
    appendJointAngle(
      id: "right-knee", title: "Genou droit",
      a: map["rightHip"], b: map["rightKnee"], c: map["rightAnkle"], to: &values
    )
    appendJointAngle(
      id: "left-hip", title: "Hanche gauche",
      a: map["leftShoulder"], b: map["leftHip"], c: map["leftKnee"], to: &values
    )
    appendJointAngle(
      id: "right-hip", title: "Hanche droite",
      a: map["rightShoulder"], b: map["rightHip"], c: map["rightKnee"], to: &values
    )
    appendJointAngle(
      id: "left-elbow", title: "Coude gauche",
      a: map["leftShoulder"], b: map["leftElbow"], c: map["leftWrist"], to: &values
    )
    appendJointAngle(
      id: "right-elbow", title: "Coude droit",
      a: map["rightShoulder"], b: map["rightElbow"], c: map["rightWrist"], to: &values
    )

    if let neck = map["neck"], let root = map["root"] {
      let dx = neck.point.x - root.point.x
      let dy = neck.point.y - root.point.y
      // Signed projected lean relative to image vertical. This deliberately does not claim
      // correction for camera roll unless a calibrated world vertical becomes available.
      let degrees = atan2(dx, -dy) * 180 / .pi
      let score = min(neck.confidence, root.confidence)
      values.append(
        BiomechanicalAngle(
          id: "trunk",
          title: "Tronc vs verticale image",
          degrees: degrees,
          detectionScore: score,
          quality: quality(forDetectionScore: score),
          uncertaintyDegrees: nil,
          referenceDescription: "Projection 2D · verticale de l’image · roulis caméra non corrigé",
          isProjected2D: true
        )
      )
    }

    if let pole = vectors.last(where: { $0.kind == .poleAxis }) {
      let isAutomatic = pole.source == "ai"
      values.append(
        BiomechanicalAngle(
          id: "pole-axis",
          title: "Axe perche vs horizontale image",
          degrees: normalizedHalfTurn(pole.angleDegrees),
          detectionScore: nil,
          quality: isAutomatic ? .automatic : .verifiedManual,
          uncertaintyDegrees: nil,
          referenceDescription: "Projection 2D · perspective caméra non corrigée",
          isProjected2D: true
        )
      )
    }

    return values.sorted { $0.title < $1.title }
  }

  private static func appendJointAngle(
    id: String,
    title: String,
    a: PoseJoint?,
    b: PoseJoint?,
    c: PoseJoint?,
    to values: inout [BiomechanicalAngle]
  ) {
    guard let a, let b, let c else { return }
    let bax = a.point.x - b.point.x
    let bay = a.point.y - b.point.y
    let bcx = c.point.x - b.point.x
    let bcy = c.point.y - b.point.y
    let denominator = hypot(bax, bay) * hypot(bcx, bcy)
    guard denominator > 1e-8 else { return }
    let cosine = min(max((bax * bcx + bay * bcy) / denominator, -1), 1)
    let score = min(a.confidence, b.confidence, c.confidence)
    values.append(
      BiomechanicalAngle(
        id: id,
        title: title,
        degrees: acos(cosine) * 180 / .pi,
        detectionScore: score,
        quality: quality(forDetectionScore: score),
        uncertaintyDegrees: nil,
        referenceDescription: "Projection 2D de trois articulations Vision",
        isProjected2D: true
      )
    )
  }

  private static func quality(forDetectionScore score: Double) -> BiomechanicalMeasurementQuality {
    if score >= 0.70 { return .automatic }
    if score >= 0.50 { return .review }
    return .lowQuality
  }

  private static func normalizedHalfTurn(_ degrees: Double) -> Double {
    var value = degrees.truncatingRemainder(dividingBy: 180)
    if value < 0 { value += 180 }
    return value
  }
}
