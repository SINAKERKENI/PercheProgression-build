import Foundation

struct AnalyticsEngine: Sendable {
  func cumulativePRPoints(
    attempts: [AttemptSnapshot],
    sessionKindByAttempt: [UUID: SessionKind] = [:],
    desiredKind: SessionKind? = nil
  ) -> [MetricPoint] {
    let filteredAttempts: [AttemptSnapshot]
    if let desiredKind {
      filteredAttempts = attempts.filter { sessionKindByAttempt[$0.id] == desiredKind }
    } else {
      filteredAttempts = attempts
    }
    let clears = filteredAttempts
      .filter { $0.result == .clear }
      .sorted { $0.createdAt < $1.createdAt }

    var best = 0
    var points: [MetricPoint] = []
    for attempt in clears where attempt.barHeightCM > best {
      best = attempt.barHeightCM
      points.append(
        MetricPoint(
          date: attempt.createdAt,
          value: Double(best) / 100.0,
          label: String(format: "%.2f m", Double(best) / 100.0)
        )
      )
    }
    return points
  }

  func clearRatePoints(attempts: [AttemptSnapshot], window: Int = 10) -> [MetricPoint] {
    let sorted =
      attempts
      .filter { $0.result.isValidAttempt }
      .sorted { $0.createdAt < $1.createdAt }

    guard !sorted.isEmpty else { return [] }
    return sorted.indices.map { index in
      let lower = max(0, index - window + 1)
      let slice = sorted[lower...index]
      let clears = slice.filter { $0.result == .clear }.count
      let rate = Double(clears) / Double(slice.count) * 100.0
      return MetricPoint(
        date: sorted[index].createdAt, value: rate, label: "\(Int(rate.rounded()))%")
    }
  }

  func speedGoalProgress(current: Double, target: Double) -> Double {
    guard target > 0 else { return 0 }
    // L’effort énergétique cinétique est proportionnel au carré de la vitesse.
    return min(max((current * current) / (target * target), 0), 1)
  }

}
