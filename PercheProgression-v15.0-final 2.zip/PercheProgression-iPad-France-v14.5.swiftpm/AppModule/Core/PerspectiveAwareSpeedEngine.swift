import Foundation

/// Single quantitative source of truth for calibrated metric video speed.
/// Inputs must already describe a ground-plane position in metres associated with an exact PTS.
struct PerspectiveAwareSpeedEngine: Sendable {
  static let algorithmVersion = "perspective-speed-v15.0"

  enum GroundPointMethod: String, Codable, Sendable {
    case supportAnkle = "support-ankle"
    case ankleMidpoint = "ankle-midpoint"
    case personGroundEstimate = "person-ground-estimate"
    case manualGroundPoint = "manual-ground-point"
    case pelvisProjectedEstimate = "pelvis-projected-estimate"
  }

  struct Observation: Equatable, Sendable {
    let timeSeconds: Double
    let imagePoint: NormalizedPoint
    let runwayPoint: MetricRunwayPoint
    let trackingConfidence: Double
    let groundPointConfidence: Double
    let calibrationQuality: Double
    let anchorCount: Int
    let anchorStability: Double
    let homographyContinuity: Double
    let groundPointMethod: GroundPointMethod
  }

  struct QualityComponents: Codable, Equatable, Sendable {
    var calibration: Double
    var anchorStability: Double
    var usableAnchorCount: Double
    var homographyContinuity: Double
    var athleteTrackingContinuity: Double
    var groundPointConfidence: Double
    var metricTrajectoryCoverage: Double
    var outlierControl: Double
    var ptsCoverage: Double

    var overall: Double {
      let values = [calibration, anchorStability, usableAnchorCount, homographyContinuity,
                    athleteTrackingContinuity, groundPointConfidence, metricTrajectoryCoverage,
                    outlierControl, ptsCoverage]
      let finite = values.filter(\.isFinite).map { min(max($0, 0), 1) }
      guard !finite.isEmpty else { return 0 }
      // Quality index only: an inspectable completeness/geometry summary, never a probability.
      return finite.reduce(0,+) / Double(finite.count)
    }
  }

  struct QualityReport: Codable, Equatable, Sendable {
    var components: QualityComponents
    var diagnostics: [String]
    var rejected: Bool
    var groundPointMethods: [String]
  }

  struct Result: Equatable, Sendable {
    var samples: [MotionSample]
    var meanLongitudinalSpeed: Double
    var peakLongitudinalSpeed: Double
    var quality: QualityReport
    var startTime: Double
    var endTime: Double
    var distanceMeters: Double
  }

  enum AnalysisError: LocalizedError, Equatable {
    case insufficientSamples
    case invalidTimebase
    case unreliableGeometry([String])
    case implausibleTrajectory

    var errorDescription: String? {
      switch self {
      case .insufficientSamples: "Pas assez de positions au sol fiables pour calculer une vitesse métrique."
      case .invalidTimebase: "Les horodatages vidéo ne sont pas exploitables. La vitesse n’est pas calculée."
      case .unreliableGeometry(let reasons): "Mesure refusée : \(reasons.joined(separator: " · "))."
      case .implausibleTrajectory: "La trajectoire métrique contient trop de ruptures ; vérifiez la calibration et le suivi des appuis."
      }
    }
  }

  func analyze(_ raw: [Observation], expectedStartTime: Double? = nil, expectedEndTime: Double? = nil) throws -> Result {
    let ordered = raw
      .filter { obs in
        obs.timeSeconds.isFinite && obs.runwayPoint.xMeters.isFinite && obs.runwayPoint.yMeters.isFinite
      }
      .sorted { $0.timeSeconds < $1.timeSeconds }
    guard ordered.count >= 5 else { throw AnalysisError.insufficientSamples }

    let unique = removeDuplicateTimes(ordered)
    guard unique.count >= 5 else { throw AnalysisError.invalidTimebase }
    let deltas = zip(unique.dropFirst(), unique).map { $0.0.timeSeconds - $0.1.timeSeconds }
    guard deltas.allSatisfy({ $0 > 0 && $0.isFinite }) else { throw AnalysisError.invalidTimebase }

    let direction = (unique.last!.runwayPoint.xMeters >= unique.first!.runwayPoint.xMeters) ? 1.0 : -1.0
    let rawX = unique.map { direction * $0.runwayPoint.xMeters }
    let medianStep = median(zip(rawX.dropFirst(), rawX).map { $0.0 - $0.1 })
    let residuals = zip(rawX.dropFirst(), rawX).map { abs(($0.0 - $0.1) - medianStep) }
    let mad = max(median(residuals), 0.005)
    let outlierStepIndices = Set(residuals.enumerated().compactMap { index, value in value > max(0.45, mad * 8) ? index + 1 : nil })

    let cleaned = unique.enumerated().filter { !outlierStepIndices.contains($0.offset) }.map(\.element)
    guard cleaned.count >= 5 else { throw AnalysisError.implausibleTrajectory }
    let outlierRatio = Double(unique.count - cleaned.count) / Double(unique.count)
    guard outlierRatio <= 0.22 else { throw AnalysisError.implausibleTrajectory }

    let smoothedX = robustSmooth(cleaned.map { direction * $0.runwayPoint.xMeters })
    let smoothedY = robustSmooth(cleaned.map { $0.runwayPoint.yMeters })
    var samples: [MotionSample] = []
    samples.reserveCapacity(cleaned.count)

    for index in cleaned.indices {
      let lower = max(index - 2, 0)
      let upper = min(index + 2, cleaned.count - 1)
      let fit = linearFit((lower...upper).map { (cleaned[$0].timeSeconds, smoothedX[$0]) })
      let velocity = fit?.slope ?? centralVelocity(times: cleaned.map(\.timeSeconds), positions: smoothedX, index: index)
      let acceleration: Double
      if index > 0 && index < cleaned.count - 1 {
        let prevV = centralVelocity(times: cleaned.map(\.timeSeconds), positions: smoothedX, index: index - 1)
        let nextV = centralVelocity(times: cleaned.map(\.timeSeconds), positions: smoothedX, index: index + 1)
        let dt = cleaned[min(index + 1, cleaned.count - 1)].timeSeconds - cleaned[max(index - 1, 0)].timeSeconds
        acceleration = dt > 0 ? (nextV - prevV) / dt : 0
      } else { acceleration = 0 }
      let localQuality = min(max((cleaned[index].trackingConfidence + cleaned[index].groundPointConfidence + cleaned[index].calibrationQuality) / 3, 0), 1)
      samples.append(MotionSample(timeSeconds: cleaned[index].timeSeconds, point: cleaned[index].imagePoint,
                                  confidence: localQuality, horizontalVelocity: velocity,
                                  verticalVelocity: 0, acceleration: abs(acceleration),
                                  runwayX: smoothedX[index], runwayY: smoothedY[index],
                                  calibrationConfidence: cleaned[index].calibrationQuality,
                                  verticalIsEstimated: false, horizontalAcceleration: acceleration,
                                  verticalAcceleration: nil))
    }

    let elapsed = cleaned.last!.timeSeconds - cleaned.first!.timeSeconds
    guard elapsed > 0 else { throw AnalysisError.invalidTimebase }
    let distance = abs(smoothedX.last! - smoothedX.first!)
    let meanSpeed = distance / elapsed
    guard meanSpeed.isFinite, (0...15).contains(meanSpeed) else { throw AnalysisError.implausibleTrajectory }
    let peak = percentile(samples.map { abs($0.horizontalVelocity) }.filter { $0.isFinite && $0 <= 16 }.sorted(), fraction: 0.95)

    let expectedDuration = max((expectedEndTime ?? cleaned.last!.timeSeconds) - (expectedStartTime ?? cleaned.first!.timeSeconds), elapsed)
    let ptsCoverage = min(max(elapsed / max(expectedDuration, 0.001), 0), 1)
    let trackingContinuity = min(max(Double(cleaned.count) / Double(max(raw.count, 1)), 0), 1)
    let quality = QualityComponents(
      calibration: average(cleaned.map(\.calibrationQuality)),
      anchorStability: average(cleaned.map(\.anchorStability)),
      usableAnchorCount: average(cleaned.map { min(Double($0.anchorCount) / 6.0, 1) }),
      homographyContinuity: average(cleaned.map(\.homographyContinuity)),
      athleteTrackingContinuity: trackingContinuity,
      groundPointConfidence: average(cleaned.map(\.groundPointConfidence)),
      metricTrajectoryCoverage: trackingContinuity,
      outlierControl: min(max(1 - outlierRatio / 0.22, 0), 1),
      ptsCoverage: ptsCoverage
    )
    var diagnostics: [String] = []
    if quality.calibration >= 0.65 { diagnostics.append("Calibration exploitable") }
    else { diagnostics.append("Calibration géométrique fragile") }
    if quality.anchorStability < 0.55 { diagnostics.append("Ancrages insuffisamment stables") }
    if quality.usableAnchorCount < 0.5 { diagnostics.append("Nombre d’ancrages utilisables insuffisant") }
    if quality.homographyContinuity < 0.55 { diagnostics.append("Perspective dynamique discontinue") }
    if quality.groundPointConfidence < 0.65 {
      diagnostics.append("Position au sol incertaine sur une partie de la séquence")
    }
    if ptsCoverage < 0.75 { diagnostics.append("Couverture temporelle PTS incomplète") }
    if outlierRatio > 0.08 { diagnostics.append("\(Int((outlierRatio * 100).rounded())) % de points aberrants rejetés") }

    let hardGeometryFailure = quality.calibration < 0.35 || quality.homographyContinuity < 0.35 || ptsCoverage < 0.45
    if hardGeometryFailure { throw AnalysisError.unreliableGeometry(diagnostics) }

    let methods = Array(Set(cleaned.map { $0.groundPointMethod.rawValue })).sorted()
    return Result(samples: samples, meanLongitudinalSpeed: meanSpeed, peakLongitudinalSpeed: peak,
                  quality: QualityReport(components: quality, diagnostics: diagnostics, rejected: false,
                                         groundPointMethods: methods),
                  startTime: cleaned.first!.timeSeconds, endTime: cleaned.last!.timeSeconds,
                  distanceMeters: distance)
  }

  private func removeDuplicateTimes(_ values: [Observation]) -> [Observation] {
    var result: [Observation] = []
    for value in values {
      if let last = result.last, abs(last.timeSeconds - value.timeSeconds) < 1e-7 {
        if value.groundPointConfidence > last.groundPointConfidence { result[result.count - 1] = value }
      } else { result.append(value) }
    }
    return result
  }

  private func robustSmooth(_ values: [Double]) -> [Double] {
    guard values.count >= 3 else { return values }
    return values.indices.map { i in
      let low = max(0, i - 1), high = min(values.count - 1, i + 1)
      return median(Array(values[low...high]))
    }
  }

  private func centralVelocity(times: [Double], positions: [Double], index: Int) -> Double {
    let a = max(0, index - 1), b = min(positions.count - 1, index + 1)
    let dt = times[b] - times[a]
    return dt > 0 ? (positions[b] - positions[a]) / dt : 0
  }

  private func linearFit(_ values: [(Double, Double)]) -> (slope: Double, intercept: Double)? {
    guard values.count >= 2 else { return nil }
    let meanT = values.map(\.0).reduce(0,+)/Double(values.count)
    let meanX = values.map(\.1).reduce(0,+)/Double(values.count)
    let denominator = values.map { pow($0.0-meanT,2) }.reduce(0,+)
    guard denominator > 1e-10 else { return nil }
    let slope = values.map { ($0.0-meanT)*($0.1-meanX) }.reduce(0,+)/denominator
    return (slope, meanX - slope*meanT)
  }

  private func average(_ values: [Double]) -> Double {
    let finite = values.filter(\.isFinite)
    guard !finite.isEmpty else { return 0 }
    return min(max(finite.reduce(0,+)/Double(finite.count),0),1)
  }
  private func median(_ values: [Double]) -> Double {
    let sorted = values.filter(\.isFinite).sorted(); guard !sorted.isEmpty else { return 0 }
    if sorted.count % 2 == 1 { return sorted[sorted.count/2] }
    return (sorted[sorted.count/2-1] + sorted[sorted.count/2]) / 2
  }
  private func percentile(_ values: [Double], fraction: Double) -> Double {
    guard !values.isEmpty else { return 0 }
    let i = Int((min(max(fraction,0),1)*Double(values.count-1)).rounded())
    return values[i]
  }
}
