import Foundation

enum HomographyMath {
  enum HomographyError: LocalizedError {
    case invalidGeometry
    case singularSystem
    case insufficientCorrespondences

    var errorDescription: String? {
      switch self {
      case .invalidGeometry:
        "La grille métrique est croisée, trop étroite ou ne décrit pas un quadrilatère valide. Ajustez les quatre coins."
      case .singularSystem:
        "La perspective ne peut pas être calculée avec ces points. Écartez davantage les poignées de la grille."
      case .insufficientCorrespondences:
        "Au moins quatre points fiables sont nécessaires pour calculer la perspective."
      }
    }
  }

  struct RobustResult: Sendable {
    var matrix: Matrix3x3
    var inlierIndices: [Int]
    var meanMetricError: Double
  }

  /// Résout une homographie exacte à partir des quatre coins de la grille.
  static func imageToRunway(for grid: RunwayGridCalibration) throws -> Matrix3x3 {
    guard grid.isGeometricallyUsable else { throw HomographyError.invalidGeometry }
    return try imageToRunway(
      source: [grid.boxLeft, grid.boxRight, grid.farLeft, grid.farRight],
      destination: [
        MetricRunwayPoint(xMeters: 0, yMeters: 0),
        MetricRunwayPoint(xMeters: 0, yMeters: grid.runwayWidthMeters),
        MetricRunwayPoint(xMeters: grid.zoneLengthMeters, yMeters: 0),
        MetricRunwayPoint(xMeters: grid.zoneLengthMeters, yMeters: grid.runwayWidthMeters),
      ]
    )
  }

  /// DLT normalisée résolue par QR pour N correspondances.
  /// Évite les équations normales AᵀA, qui amplifient le conditionnement numérique.
  static func imageToRunway(
    source: [NormalizedPoint],
    destination: [MetricRunwayPoint]
  ) throws -> Matrix3x3 {
    guard source.count == destination.count, source.count >= 4 else {
      throw HomographyError.insufficientCorrespondences
    }

    let sourceRaw = source.map { NormalizedPoint(x: $0.x, y: $0.y) }
    let destinationRaw = destination.map { NormalizedPoint(x: $0.xMeters, y: $0.yMeters) }
    let sourceNormalization = try normalization(for: sourceRaw)
    let destinationNormalization = try normalization(for: destinationRaw)

    let normalizedSource = sourceRaw.compactMap { sourceNormalization.transform.project($0) }
    let normalizedDestination = destinationRaw.compactMap { destinationNormalization.transform.project($0) }
    guard normalizedSource.count == source.count, normalizedDestination.count == destination.count else {
      throw HomographyError.singularSystem
    }

    let rowCount = source.count * 2
    var design = Array(repeating: Array(repeating: 0.0, count: 8), count: rowCount)
    var rhs = Array(repeating: 0.0, count: rowCount)

    for index in normalizedSource.indices {
      let x = normalizedSource[index].x
      let y = normalizedSource[index].y
      let u = normalizedDestination[index].x
      let v = normalizedDestination[index].y
      let row = index * 2

      design[row][0] = x
      design[row][1] = y
      design[row][2] = 1
      design[row][6] = -u * x
      design[row][7] = -u * y
      rhs[row] = u

      design[row + 1][3] = x
      design[row + 1][4] = y
      design[row + 1][5] = 1
      design[row + 1][6] = -v * x
      design[row + 1][7] = -v * y
      rhs[row + 1] = v
    }

    let solution = try leastSquaresQR(matrix: design, rhs: rhs)
    let normalizedHomography = Matrix3x3(
      m11: solution[0], m12: solution[1], m13: solution[2],
      m21: solution[3], m22: solution[4], m23: solution[5],
      m31: solution[6], m32: solution[7], m33: 1
    )

    guard let destinationInverse = destinationNormalization.transform.inverted() else {
      throw HomographyError.singularSystem
    }
    let denormalized = destinationInverse
      .multiplied(by: normalizedHomography)
      .multiplied(by: sourceNormalization.transform)
    guard denormalized.m33.isFinite, abs(denormalized.m33) > 1e-12 else {
      throw HomographyError.singularSystem
    }
    return denormalized.scaled(by: 1 / denormalized.m33)
  }

  /// RANSAC déterministe, puis raffinement sur les inliers.
  static func robustImageToRunway(
    source: [NormalizedPoint],
    destination: [MetricRunwayPoint],
    thresholdMeters: Double = 0.12,
    maximumTrials: Int = 48
  ) throws -> RobustResult {
    guard source.count == destination.count, source.count >= 4 else {
      throw HomographyError.insufficientCorrespondences
    }
    if source.count == 4 {
      let matrix = try imageToRunway(source: source, destination: destination)
      // Four points define the model exactly; the residual cannot estimate measurement error.
      return RobustResult(matrix: matrix, inlierIndices: Array(source.indices), meanMetricError: .nan)
    }

    let subsets = deterministicSubsets(count: source.count, maximumTrials: maximumTrials)
    var bestMatrix: Matrix3x3?
    var bestInliers: [Int] = []
    var bestError = Double.infinity

    for subset in subsets {
      let subsetSource = subset.map { source[$0] }
      let subsetDestination = subset.map { destination[$0] }
      guard let candidate = try? imageToRunway(
        source: subsetSource,
        destination: subsetDestination
      ) else { continue }

      var inliers: [Int] = []
      var errors: [Double] = []
      for index in source.indices {
        guard let projected = candidate.projectMetric(source[index]) else { continue }
        let error = hypot(
          projected.xMeters - destination[index].xMeters,
          projected.yMeters - destination[index].yMeters
        )
        if error <= thresholdMeters {
          inliers.append(index)
          errors.append(error)
        }
      }
      let mean = errors.isEmpty ? .infinity : errors.reduce(0, +) / Double(errors.count)
      if inliers.count > bestInliers.count || (inliers.count == bestInliers.count && mean < bestError) {
        bestMatrix = candidate
        bestInliers = inliers
        bestError = mean
      }
    }

    guard bestMatrix != nil, bestInliers.count >= 4 else {
      throw HomographyError.invalidGeometry
    }
    let refined = try imageToRunway(
      source: bestInliers.map { source[$0] },
      destination: bestInliers.map { destination[$0] }
    )
    let refinedErrors = bestInliers.compactMap { index -> Double? in
      guard let projected = refined.projectMetric(source[index]) else { return nil }
      return hypot(
        projected.xMeters - destination[index].xMeters,
        projected.yMeters - destination[index].yMeters
      )
    }
    let mean = refinedErrors.isEmpty ? bestError : refinedErrors.reduce(0, +) / Double(refinedErrors.count)
    return RobustResult(matrix: refined, inlierIndices: bestInliers, meanMetricError: mean)
  }

  static func grid(from imageToRunway: Matrix3x3, template: RunwayGridCalibration) -> RunwayGridCalibration? {
    guard let runwayToImage = imageToRunway.inverted() else { return nil }
    let metricCorners = [
      NormalizedPoint(x: 0, y: 0),
      NormalizedPoint(x: 0, y: template.runwayWidthMeters),
      NormalizedPoint(x: template.zoneLengthMeters, y: 0),
      NormalizedPoint(x: template.zoneLengthMeters, y: template.runwayWidthMeters),
    ]
    let imageCorners = metricCorners.compactMap { runwayToImage.project($0) }
    guard imageCorners.count == 4 else { return nil }
    let grid = RunwayGridCalibration(
      boxLeft: imageCorners[0],
      boxRight: imageCorners[1],
      farLeft: imageCorners[2],
      farRight: imageCorners[3],
      zoneLengthMeters: template.zoneLengthMeters,
      runwayWidthMeters: template.runwayWidthMeters
    )
    return grid.isGeometricallyUsable ? grid : nil
  }

  static func gridReprojectionError(
    _ grid: RunwayGridCalibration,
    homography: Matrix3x3
  ) -> Double {
    let expected = [
      MetricRunwayPoint(xMeters: 0, yMeters: 0),
      MetricRunwayPoint(xMeters: 0, yMeters: grid.runwayWidthMeters),
      MetricRunwayPoint(xMeters: grid.zoneLengthMeters, yMeters: 0),
      MetricRunwayPoint(xMeters: grid.zoneLengthMeters, yMeters: grid.runwayWidthMeters),
    ]
    let actual = grid.imagePoints.compactMap { homography.projectMetric($0) }
    guard actual.count == expected.count else { return .infinity }
    return zip(actual, expected).map {
      hypot($0.xMeters - $1.xMeters, $0.yMeters - $1.yMeters)
    }.reduce(0, +) / Double(expected.count)
  }

  static func interpolatedGrid(
    from first: RunwayGridCalibration,
    to second: RunwayGridCalibration,
    fraction: Double
  ) -> RunwayGridCalibration {
    let t = min(max(fraction, 0), 1)
    func lerp(_ a: NormalizedPoint, _ b: NormalizedPoint) -> NormalizedPoint {
      NormalizedPoint(x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t)
    }
    return RunwayGridCalibration(
      boxLeft: lerp(first.boxLeft, second.boxLeft),
      boxRight: lerp(first.boxRight, second.boxRight),
      farLeft: lerp(first.farLeft, second.farLeft),
      farRight: lerp(first.farRight, second.farRight),
      zoneLengthMeters: first.zoneLengthMeters + (second.zoneLengthMeters - first.zoneLengthMeters) * t,
      runwayWidthMeters: first.runwayWidthMeters + (second.runwayWidthMeters - first.runwayWidthMeters) * t
    )
  }

  private static func deterministicSubsets(count: Int, maximumTrials: Int) -> [[Int]] {
    guard count >= 4 else { return [] }
    if count <= 9 {
      var exhaustive: [[Int]] = []
      for a in 0..<(count - 3) {
        for b in (a + 1)..<(count - 2) {
          for c in (b + 1)..<(count - 1) {
            for d in (c + 1)..<count {
              exhaustive.append([a, b, c, d])
            }
          }
        }
      }
      return exhaustive
    }
    var result: [[Int]] = []
    let first = [0, max(count / 3, 1), max((2 * count) / 3, 2), count - 1]
    result.append(Array(Set(first)).sorted())

    var state = UInt64(count * 1_103_515_245 + 12_345)
    while result.count < maximumTrials {
      var set: Set<Int> = []
      while set.count < 4 {
        state = state &* 6_364_136_223_846_793_005 &+ 1_442_695_040_888_963_407
        set.insert(Int(state % UInt64(count)))
      }
      let subset = set.sorted()
      if !result.contains(subset) { result.append(subset) }
      if result.count >= combinationUpperBound(count: count) { break }
    }
    return result.filter { $0.count == 4 }
  }

  private static func combinationUpperBound(count: Int) -> Int {
    guard count >= 4 else { return 0 }
    return count * (count - 1) * (count - 2) * (count - 3) / 24
  }

  private struct Normalization {
    var transform: Matrix3x3
  }

  private static func normalization(for points: [NormalizedPoint]) throws -> Normalization {
    guard !points.isEmpty else { throw HomographyError.singularSystem }
    let cx = points.map(\.x).reduce(0, +) / Double(points.count)
    let cy = points.map(\.y).reduce(0, +) / Double(points.count)
    let meanDistance = points.map { hypot($0.x - cx, $0.y - cy) }.reduce(0, +) / Double(points.count)
    guard meanDistance.isFinite, meanDistance > 1e-10 else { throw HomographyError.singularSystem }
    let scale = sqrt(2) / meanDistance
    return Normalization(
      transform: Matrix3x3(
        m11: scale, m12: 0, m13: -scale * cx,
        m21: 0, m22: scale, m23: -scale * cy,
        m31: 0, m32: 0, m33: 1
      )
    )
  }

  /// Modified Gram-Schmidt QR. The homography system is tiny (8 columns),
  /// so this is stable enough here without forming AᵀA.
  private static func leastSquaresQR(matrix: [[Double]], rhs: [Double]) throws -> [Double] {
    let rows = matrix.count
    guard rows == rhs.count, rows >= 8, matrix.allSatisfy({ $0.count == 8 }) else {
      throw HomographyError.singularSystem
    }
    let columns = 8
    var q = Array(repeating: Array(repeating: 0.0, count: rows), count: columns)
    var r = Array(repeating: Array(repeating: 0.0, count: columns), count: columns)

    for j in 0..<columns {
      var v = matrix.map { $0[j] }
      for i in 0..<j {
        let projection = zip(q[i], v).reduce(0.0) { $0 + $1.0 * $1.1 }
        r[i][j] = projection
        for row in 0..<rows { v[row] -= projection * q[i][row] }
      }
      let norm = sqrt(v.reduce(0.0) { $0 + $1 * $1 })
      guard norm.isFinite, norm > 1e-12 else { throw HomographyError.singularSystem }
      r[j][j] = norm
      for row in 0..<rows { q[j][row] = v[row] / norm }
    }

    var y = Array(repeating: 0.0, count: columns)
    for j in 0..<columns {
      y[j] = zip(q[j], rhs).reduce(0.0) { $0 + $1.0 * $1.1 }
    }

    var x = Array(repeating: 0.0, count: columns)
    for i in stride(from: columns - 1, through: 0, by: -1) {
      var residual = y[i]
      if i + 1 < columns {
        for j in (i + 1)..<columns { residual -= r[i][j] * x[j] }
      }
      guard abs(r[i][i]) > 1e-12 else { throw HomographyError.singularSystem }
      x[i] = residual / r[i][i]
    }
    return x
  }

}

extension Matrix3x3 {

  func multiplied(by other: Matrix3x3) -> Matrix3x3 {
    Matrix3x3(
      m11: m11 * other.m11 + m12 * other.m21 + m13 * other.m31,
      m12: m11 * other.m12 + m12 * other.m22 + m13 * other.m32,
      m13: m11 * other.m13 + m12 * other.m23 + m13 * other.m33,
      m21: m21 * other.m11 + m22 * other.m21 + m23 * other.m31,
      m22: m21 * other.m12 + m22 * other.m22 + m23 * other.m32,
      m23: m21 * other.m13 + m22 * other.m23 + m23 * other.m33,
      m31: m31 * other.m11 + m32 * other.m21 + m33 * other.m31,
      m32: m31 * other.m12 + m32 * other.m22 + m33 * other.m32,
      m33: m31 * other.m13 + m32 * other.m23 + m33 * other.m33
    )
  }

  func scaled(by factor: Double) -> Matrix3x3 {
    Matrix3x3(
      m11: m11 * factor, m12: m12 * factor, m13: m13 * factor,
      m21: m21 * factor, m22: m22 * factor, m23: m23 * factor,
      m31: m31 * factor, m32: m32 * factor, m33: m33 * factor
    )
  }
  func inverted() -> Matrix3x3? {
    let determinant =
      m11 * (m22 * m33 - m23 * m32)
      - m12 * (m21 * m33 - m23 * m31)
      + m13 * (m21 * m32 - m22 * m31)
    guard determinant.isFinite, abs(determinant) > 1e-12 else { return nil }
    let inv = 1 / determinant
    return Matrix3x3(
      m11: (m22 * m33 - m23 * m32) * inv,
      m12: (m13 * m32 - m12 * m33) * inv,
      m13: (m12 * m23 - m13 * m22) * inv,
      m21: (m23 * m31 - m21 * m33) * inv,
      m22: (m11 * m33 - m13 * m31) * inv,
      m23: (m13 * m21 - m11 * m23) * inv,
      m31: (m21 * m32 - m22 * m31) * inv,
      m32: (m12 * m31 - m11 * m32) * inv,
      m33: (m11 * m22 - m12 * m21) * inv
    )
  }
}
