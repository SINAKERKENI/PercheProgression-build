import Foundation
import SwiftData

@MainActor
struct PerformanceRepository {
  let context: ModelContext

  @discardableResult
  func saveSpeedMeasurement(
    athleteID: UUID,
    kind: PhysicalMetricKind,
    value: Double,
    source: String,
    protocolName: String,
    note: String = "",
    measuredAt: Date = .now,
    algorithmVersion: String = "",
    captureFrameRate: Double? = nil,
    analysisFrameRate: Double? = nil,
    analysisStartTime: Double? = nil,
    analysisEndTime: Double? = nil,
    sampleCount: Int? = nil,
    qualityStatusRaw: String = "automatic",
    isEstimated: Bool = false,
    userVerified: Bool = false,
    parametersJSON: String = ""
  ) throws -> PhysicalMetricRecord {
    precondition(kind.isApproachSpeedFamily || kind == .takeoffSpeed, "Use a speed-specific metric kind")
    let record = PhysicalMetricRecord(
      athleteID: athleteID,
      kind: kind,
      value: value,
      source: source,
      protocolName: protocolName,
      measuredAt: measuredAt,
      note: note,
      algorithmVersion: algorithmVersion,
      captureFrameRate: captureFrameRate,
      analysisFrameRate: analysisFrameRate,
      analysisStartTime: analysisStartTime,
      analysisEndTime: analysisEndTime,
      sampleCount: sampleCount,
      qualityStatusRaw: qualityStatusRaw,
      isEstimated: isEstimated,
      userVerified: userVerified,
      parametersJSON: parametersJSON
    )
    context.insert(record)

    // AthleteProfile.currentApproachSpeed is retained only for store compatibility/export of old data.
    // PhysicalMetricRecord is the source of truth; keep this cache synchronized until a future schema removes it.
    if kind.isApproachSpeedFamily {
      let descriptor = FetchDescriptor<AthleteProfile>(predicate: #Predicate { $0.id == athleteID })
      if let profile = try context.fetch(descriptor).first {
        profile.currentApproachSpeed = value
        profile.updatedAt = .now
      }
    }

    try context.save()
    return record
  }

  /// Compatibility shim for older callers. New code should specify the protocol-specific kind.
  @discardableResult
  func saveApproachSpeed(
    athleteID: UUID,
    value: Double,
    source: String,
    protocolName: String,
    note: String = "",
    measuredAt: Date = .now
  ) throws -> PhysicalMetricRecord {
    try saveSpeedMeasurement(
      athleteID: athleteID,
      kind: .videoEstimatedSpeed,
      value: value,
      source: source,
      protocolName: protocolName,
      note: note,
      measuredAt: measuredAt,
      isEstimated: true
    )
  }

  func latestApproachSpeed(athleteID: UUID, metrics: [PhysicalMetricRecord]) -> Double {
    metrics
      .filter { $0.athleteID == athleteID && $0.kind.isApproachSpeedFamily }
      .max(by: { $0.measuredAt < $1.measuredAt })?
      .value ?? 0
  }
}

@MainActor
struct VideoProjectRepository {
  let context: ModelContext

  func save() throws {
    try context.save()
  }
}
