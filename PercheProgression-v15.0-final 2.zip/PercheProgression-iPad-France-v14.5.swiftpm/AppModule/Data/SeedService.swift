import Foundation
import SwiftData

@MainActor
enum SeedService {
  /// Seed version is metadata only. It must never authorize deletion of user data.
  private static let seedVersionKey = "PercheProgression.seed.version"
  private static let currentSeedVersion = 10

  /// Applied only when a profile is created. Existing roadmaps are never overwritten by an app update.
  private static let haradaPillarDefinitions: [(String, String, [String])] = [
    ("Vitesse & rythme d’élan", "bolt.fill", [
      "Mesurer la vitesse moyenne sur les 5 derniers mètres avec un protocole identifié",
      "Renseigner la longueur d’élan sur les prochains sauts mesurés",
      "Filmer une course d’élan complète et contrôler le rythme des six dernières foulées",
      "Réaliser deux séquences d’accélération planifiées cette semaine",
      "Comparer deux mesures de vitesse uniquement avec le même protocole"
    ]),
    ("Précision de course & impulsion", "scope", [
      "Noter la marque de départ avant la prochaine séance de saut",
      "Renseigner la marque intermédiaire sur une course d’élan complète",
      "Noter la marque réelle d’impulsion sur les prochains sauts",
      "Qualifier chaque impulsion dessous, dehors ou dans la zone attendue",
      "Modifier la marque de départ seulement après une dérive répétée et observée"
    ]),
    ("Présentation / planté", "arrow.up.right", [
      "Filmer de profil les trois dernières foulées et la présentation",
      "Noter chaque refus de planter pendant la séance",
      "Réaliser une série de présentations marchées avec fin de geste avant l’impulsion",
      "Réaliser une série de présentations en course avec main haute stable",
      "Comparer un planté réussi et un planté manqué image par image"
    ]),
    ("Balancé & renversement", "arrow.triangle.2.circlepath", [
      "Filmer au moins un saut exploitable centré sur le balancé",
      "Réaliser le travail de balancé à la barre fixe prévu dans la séance",
      "Repérer si le groupé commence avant la fin du balancé",
      "Comparer le renversement du meilleur saut avec un saut manqué",
      "Consigner une observation technique précise après la séance"
    ]),
    ("Extension, demi-tour & franchissement", "arrow.up.and.down.and.arrow.left.and.right", [
      "Marquer l’image de début d’extension sur une vidéo exploitable",
      "Comparer le timing du demi-tour sur deux sauts à même hauteur",
      "Noter les contacts avec la barre sur les tentatives de la séance",
      "Réaliser le travail gymnique d’extension prévu dans la semaine",
      "Analyser le franchissement du meilleur saut sans interpolation de performance"
    ]),
    ("Perches & hauteur de prise", "line.diagonal", [
      "Renseigner la hauteur de prise sur les huit prochains sauts",
      "Vérifier longueur, poids et flex des perches actives du râtelier",
      "Noter les retours « trop souple » ou « trop dure » au moment où ils surviennent",
      "Lire les raisons de la recommandation avant tout changement de perche",
      "Enregistrer si la recommandation de perche a été acceptée, refusée ou ignorée"
    ]),
    ("Préparation physique & prévention", "figure.strengthtraining.traditional", [
      "Renseigner le poids du corps avec la date de mesure",
      "Mesurer un sprint avec distance et protocole clairement identifiés",
      "Réaliser la routine de prévention planifiée avant la prochaine séance de saut",
      "Consigner la charge des exercices principaux de la semaine",
      "Adapter la séance si une gêne modifie la course ou l’impulsion"
    ]),
    ("Compétition, routine & mental", "flag.checkered", [
      "Écrire la routine des trois actions précédant chaque tentative",
      "Consigner les hauteurs tentées et réussies après la compétition",
      "Synchroniser l’historique FFA après une compétition lorsque le profil est lié",
      "Noter une observation factuelle sur la course d’élan en compétition",
      "Choisir au maximum trois actions prioritaires dans « En ce moment »"
    ])
  ]

  static func prepareFrenchEdition(context: ModelContext) throws {
    // Non-destructive bootstrap: existing stores are preserved regardless of UserDefaults.
    // Schema evolution is handled by SwiftData/store migration, never by a reset flag.
    let profileCount = try context.fetchCount(FetchDescriptor<AthleteProfile>())
    if profileCount == 0 {
      try seedFreshFrenchData(context: context)
    }
    let previousSeedVersion = UserDefaults.standard.integer(forKey: seedVersionKey)
    let removedBundledReferences = try removeBundledExampleVideoReferences(context: context)
    let migratedVideoCategories = try migrateExerciseVideoCategories(context: context)
    let installedExerciseVideos = previousSeedVersion < currentSeedVersion
      ? try installExerciseVideoLibrary(context: context)
      : false
    if removedBundledReferences || migratedVideoCategories || installedExerciseVideos {
      try context.save()
    }
    UserDefaults.standard.set(currentSeedVersion, forKey: seedVersionKey)
  }

  /// Installs the curated 247-video catalog once when upgrading to seed v9.
  /// Existing records and user edits are preserved. Matching category/URL pairs
  /// are skipped, so importing an earlier backup never creates duplicates.
  private static func installExerciseVideoLibrary(context: ModelContext) throws -> Bool {
    let catalog = try ExerciseVideoSeedCatalog.load()
    let existing = try context.fetch(FetchDescriptor<ExerciseVideoRecord>())
    var existingIDs = Set(existing.map(\.id))
    var existingCategoryURLs = Set(
      existing.map {
        let category = ExerciseVideoCategory.migrated(from: $0.categoryRaw)
        let url = $0.urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        return "\(category.rawValue)|\(url)"
      }
    )
    var changed = false

    for item in catalog {
      guard
        !existingIDs.contains(item.id),
        !existingCategoryURLs.contains(item.categoryURLSignature)
      else { continue }

      context.insert(
        ExerciseVideoRecord(
          id: item.id,
          category: item.category,
          urlString: item.urlString,
          title: item.title,
          videoDescription: item.videoDescription,
          thumbnailURLString: item.thumbnailURLString,
          createdAt: item.createdAt,
          updatedAt: item.updatedAt
        )
      )
      existingIDs.insert(item.id)
      existingCategoryURLs.insert(item.categoryURLSignature)
      changed = true
    }
    return changed
  }

  static func seedIfNeeded(context: ModelContext) throws {
    try prepareFrenchEdition(context: context)
  }

  @discardableResult
  static func createAthlete(
    displayName: String,
    category: String,
    heightCM: Double,
    bodyWeightKG: Double,
    context: ModelContext
  ) throws -> AthleteProfile {
    let athlete = AthleteProfile(
      displayName: displayName,
      category: category,
      heightCM: heightCM,
      bodyWeightKG: bodyWeightKG
    )
    context.insert(athlete)

    let goal = GoalRecord(
      athleteID: athlete.id,
      title: "Mon objectif",
      targetHeightCM: 0
    )
    context.insert(goal)

    let starterPillars = haradaPillarDefinitions

    for (pillarIndex, definition) in starterPillars.enumerated() {
      let pillar = GoalPillarRecord(
        goalID: goal.id,
        title: definition.0,
        iconSymbol: definition.1,
        sortIndex: pillarIndex,
        accentHex: "F15D18"
      )
      context.insert(pillar)
      for (actionIndex, title) in definition.2.enumerated() {
        context.insert(
          GoalActionRecord(
            pillarID: pillar.id,
            title: title,
            kind: actionIndex == 0 ? .metric : .habit,
            recurrence: "Hebdomadaire",
            sortIndex: actionIndex
          )
        )
      }
    }

    for approach in ApproachLength.allCases {
      context.insert(
        ApproachProfileRecord(
          athleteID: athlete.id,
          approach: approach,
          startMarkM: 0,
          notes: "Toutes les mesures partent du fond du butoir."
        )
      )
    }

    try context.save()
    return athlete
  }

  private static func seedFreshFrenchData(context: ModelContext) throws {
    let athlete = AthleteProfile(
      displayName: "Athlète",
      category: "Sénior",
      heightCM: 0,
      bodyWeightKG: 0,
      currentPRCM: 0,
      trainingPRCM: 0,
      targetHeightCM: 0,
      currentApproachSpeed: 0,
      targetApproachSpeed: 0,
      theoreticalMaximumCM: 0
    )
    context.insert(athlete)

    let goal = GoalRecord(
      athleteID: athlete.id,
      title: "Mon objectif",
      targetHeightCM: 0,
      targetDate: nil
    )
    context.insert(goal)

    let pillarDefinitions = haradaPillarDefinitions

    for (pillarIndex, definition) in pillarDefinitions.enumerated() {
      let pillar = GoalPillarRecord(
        goalID: goal.id,
        title: definition.0,
        iconSymbol: definition.1,
        sortIndex: pillarIndex,
        accentHex: "F15D18"
      )
      context.insert(pillar)

      for (actionIndex, title) in definition.2.enumerated() {
        let lower = title.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
        let kind: GoalActionKind = lower.contains("mesurer") || lower.contains("renseigner") || lower.contains("noter") || lower.contains("consigner")
          ? .metric
          : (lower.contains("synchroniser") ? .milestone : .habit)
        context.insert(
          GoalActionRecord(
            pillarID: pillar.id,
            title: title,
            kind: kind,
            targetValue: nil,
            recurrence: actionIndex == 6 ? "Saison" : "Hebdomadaire",
            currentValue: 0,
            isCompleted: false,
            sortIndex: actionIndex
          )
        )
      }
    }

    for approach in ApproachLength.allCases {
      context.insert(
        ApproachProfileRecord(
          athleteID: athlete.id,
          approach: approach,
          startMarkM: 0,
          intermediateMarkM: nil,
          finalCheckMarkM: nil,
          expectedTakeoffMarkM: nil,
          notes: "Toutes les mesures partent du fond du butoir."
        )
      )
    }

    seedDrills(context: context)
    try context.save()
  }

  private static func seedDrills(context: ModelContext) {
    let drills: [(
      String, VaultPhase, [AttemptDiagnostic], String, String, Int, Int, Int, String, String
    )] = [
      (
        "Présentation marchée", .plant, [.plantRefusal],
        "Monter les mains sans rupture et terminer grand.",
        "Arrêter la main haute ou présenter tardivement.", 3, 6, 45,
        "Perche et couloir d’élan",
        "Utiliser une zone dégagée et une perche adaptée à l’exercice."
      ),
      (
        "Impulsion sur 3 foulées", .takeoff, [.takeoffUnder, .takeoffOut],
        "Rester haut, traverser avec le buste et conserver la jambe libre longue.",
        "S’asseoir à l’impulsion ou s’effondrer sous la perche.", 4, 4, 60,
        "Petite perche et butoir",
        "Vérifier le tapis, le butoir et la zone de réception avant la série."
      ),
      (
        "Balancé–renversement à la barre fixe", .rockBack, [],
        "Conduire avec la jambe libre et fermer l’angle des hanches tardivement.",
        "Grouper trop tôt ou tirer avec les bras fléchis.", 4, 5, 75,
        "Barre fixe",
        "Utiliser une barre fixe stable avec une réception sécurisée."
      ),
      (
        "Extensions type Bubka", .extensionPhase, [],
        "Faire monter les hanches verticalement et terminer dans les mains.",
        "Tourner avant que les hanches soient montées.", 3, 6, 60,
        "Barre fixe",
        "Adapter l’amplitude au niveau gymnique de l’athlète."
      ),
      (
        "Demi-tour et repoussée", .turn, [.barContact],
        "Continuer à monter pendant le demi-tour et se repousser de la perche.",
        "Chercher la barre trop tôt.", 4, 4, 75,
        "Perche et élastique bas",
        "Réaliser l’exercice uniquement avec une zone de réception complète."
      ),
      (
        "Franchissements à élan réduit", .flyAway, [.barContact],
        "Créer de la distance avec la perche et finir la repoussée.",
        "Laisser les hanches retomber vers la barre.", 5, 3, 90,
        "Tapis, perche et élastique",
        "Commencer bas et augmenter seulement lorsque les réceptions sont maîtrisées."
      ),
    ]

    for (index, drill) in drills.enumerated() {
      context.insert(
        DrillRecord(
          title: drill.0,
          phase: drill.1,
          faults: drill.2,
          coachingCues: drill.3,
          commonErrors: drill.4,
          sets: drill.5,
          repetitions: drill.6,
          restSeconds: drill.7,
          difficulty: min(index / 2 + 1, 3),
          equipment: drill.8,
          safetyNote: drill.9,
          sortIndex: index
        )
      )
    }
  }

  /// Clears only the six legacy bundle-backed placeholders. User-provided web
  /// links and local references are left untouched.
  private static func removeBundledExampleVideoReferences(context: ModelContext) throws -> Bool {
    let records = try context.fetch(FetchDescriptor<DrillRecord>())
    var changed = false

    for record in records where record.videoURLString.hasPrefix("bundle://") {
      record.videoURLString = ""
      changed = true
    }

    return changed
  }

  /// Maps every legacy video category to the ten-category training taxonomy.
  /// Existing links, titles, descriptions and thumbnails are preserved.
  private static func migrateExerciseVideoCategories(context: ModelContext) throws -> Bool {
    let videos = try context.fetch(FetchDescriptor<ExerciseVideoRecord>())
    var changed = false

    for video in videos {
      let migratedCategory = ExerciseVideoCategory.migrated(from: video.categoryRaw)
      guard video.categoryRaw != migratedCategory.rawValue else { continue }
      video.categoryRaw = migratedCategory.rawValue
      video.updatedAt = .now
      changed = true
    }

    return changed
  }
}
