import Foundation
import SwiftData

@MainActor
enum ModelContainerFactory {
  static let schema = Schema([
    AthleteProfile.self,
    GoalRecord.self,
    GoalPillarRecord.self,
    GoalActionRecord.self,
    ActionCheckInRecord.self,
    PoleRecord.self,
    PoleApproachProgressRecord.self,
    ApproachProfileRecord.self,
    VaultSessionRecord.self,
    AttemptRecord.self,
    PhysicalMetricRecord.self,
    DrillRecord.self,
    ExerciseVideoRecord.self,
    DrillCompletionRecord.self,
    VideoClipRecord.self,
    VectorAnnotationRecord.self,
    PhaseMarkerRecord.self,
    OfficialPerformanceRecord.self,
    PoleRecommendationDecisionRecord.self,
    PerformanceDimensionRecord.self,
    SyncOperationRecord.self,
  ])

  static func make() throws -> ModelContainer {
    let configuration = ModelConfiguration(
      "PercheProgressionFranceV4",
      schema: schema,
      isStoredInMemoryOnly: false
    )
    return try ModelContainer(for: schema, configurations: [configuration])
  }

  static func diagnosticSummary(error: Error? = nil) -> String {
    var lines = [
      "Store: PercheProgressionFranceV4",
      "Mode mémoire: non",
      "Modèles: \(schema.entities.count)",
      "Protection: store persistant SwiftData"
    ]
    if let error { lines.append("Erreur: \(String(reflecting: error))") }
    return lines.joined(separator: "\n")
  }
}
