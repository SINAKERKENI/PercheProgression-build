import Foundation

struct ExerciseVideoSeedItem {
  let id: UUID
  let category: ExerciseVideoCategory
  let urlString: String
  let title: String
  let videoDescription: String
  let thumbnailURLString: String?
  let createdAt: Date
  let updatedAt: Date

  var categoryURLSignature: String {
    "\(category.rawValue)|\(urlString.trimmingCharacters(in: .whitespacesAndNewlines))"
  }
}

enum ExerciseVideoSeedCatalogError: LocalizedError {
  case missingResource
  case unsupportedSchema(Int)
  case invalidCount(Int)
  case invalidRecord(String)
  case invalidCategoryCounts

  var errorDescription: String? {
    switch self {
    case .missingResource:
      "La bibliothèque intégrée des vidéos d’exercice est introuvable."
    case .unsupportedSchema(let version):
      "La version \(version) de la bibliothèque d’exercices n’est pas prise en charge."
    case .invalidCount(let count):
      "La bibliothèque intégrée contient \(count) fiches au lieu des 247 attendues."
    case .invalidRecord(let identifier):
      "Une fiche vidéo intégrée est invalide (\(identifier))."
    case .invalidCategoryCounts:
      "La répartition des vidéos intégrées par catégorie est invalide."
    }
  }
}

enum ExerciseVideoSeedCatalog {
  static let expectedCount = 247
  static let expectedCategoryCounts: [ExerciseVideoCategory: Int] = [
    .warmUp: 16,
    .pvDrills: 31,
    .medBall: 39,
    .strength: 36,
    .gym: 82,
    .core: 16,
    .plyo: 8,
    .flexibility: 6,
    .rehab: 11,
    .running: 2,
  ]

  static func load() throws -> [ExerciseVideoSeedItem] {
    guard let resourceURL = Bundle.module.url(
      forResource: "ExerciseVideoSeed",
      withExtension: "json"
    ) else {
      throw ExerciseVideoSeedCatalogError.missingResource
    }

    let data = try Data(contentsOf: resourceURL)
    let payload = try JSONDecoder().decode(Payload.self, from: data)
    guard payload.schemaVersion == 1 else {
      throw ExerciseVideoSeedCatalogError.unsupportedSchema(payload.schemaVersion)
    }
    guard payload.videos.count == expectedCount else {
      throw ExerciseVideoSeedCatalogError.invalidCount(payload.videos.count)
    }

    var seenIDs = Set<UUID>()
    var seenCategoryURLs = Set<String>()
    let videos = try payload.videos.map { source -> ExerciseVideoSeedItem in
      guard
        let id = UUID(uuidString: source.id),
        seenIDs.insert(id).inserted,
        let category = ExerciseVideoCategory(rawValue: source.category),
        let url = URL(string: source.url),
        ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
        !source.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
        let createdAt = parseDate(source.createdAt),
        let updatedAt = parseDate(source.updatedAt)
      else {
        throw ExerciseVideoSeedCatalogError.invalidRecord(source.id)
      }

      let item = ExerciseVideoSeedItem(
        id: id,
        category: category,
        urlString: source.url,
        title: source.title,
        videoDescription: source.description,
        thumbnailURLString: source.thumbnailURL,
        createdAt: createdAt,
        updatedAt: updatedAt
      )
      guard seenCategoryURLs.insert(item.categoryURLSignature).inserted else {
        throw ExerciseVideoSeedCatalogError.invalidRecord(source.id)
      }
      return item
    }

    let actualCounts = Dictionary(grouping: videos, by: \ExerciseVideoSeedItem.category)
      .mapValues(\.count)
    guard actualCounts == expectedCategoryCounts else {
      throw ExerciseVideoSeedCatalogError.invalidCategoryCounts
    }
    return videos
  }

  private static func parseDate(_ value: String) -> Date? {
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = formatter.date(from: value) { return date }
    formatter.formatOptions = [.withInternetDateTime]
    return formatter.date(from: value)
  }

  private struct Payload: Decodable {
    let schemaVersion: Int
    let videos: [SourceVideo]
  }

  private struct SourceVideo: Decodable {
    let id: String
    let category: String
    let url: String
    let title: String
    let description: String
    let thumbnailURL: String?
    let createdAt: String
    let updatedAt: String
  }
}
