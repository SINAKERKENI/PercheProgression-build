import Foundation
import Observation
import SwiftData

/// Centralizes persistence failures so no save error is silently discarded.
@MainActor
@Observable
final class PersistenceIssueCenter {
  static let shared = PersistenceIssueCenter()
  var lastError: String?

  private init() {}

  func save(_ context: ModelContext, operation: String = "Enregistrement") {
    do {
      try context.save()
    } catch {
      lastError = "\(operation) impossible : \(error.localizedDescription)"
    }
  }

  func report(_ error: Error, operation: String) {
    lastError = "\(operation) impossible : \(error.localizedDescription)"
  }
}
