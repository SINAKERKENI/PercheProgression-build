import Foundation
import SwiftData

@Model
final class AthleteProfile {
  var id: UUID
  var displayName: String
  var category: String
  var dateOfBirth: Date?
  var heightCM: Double
  var bodyWeightKG: Double
  var currentPRCM: Int
  var trainingPRCM: Int
  var targetHeightCM: Int
  var currentApproachSpeed: Double
  var targetApproachSpeed: Double
  var theoreticalMaximumCM: Int
  var firstName: String = ""
  var lastName: String = ""
  var clubName: String = ""
  var licenseNumber: String = ""
  var ffaAthleteID: String = ""
  var ffaLinkedClub: String = ""
  var ffaLastSyncAt: Date? = nil
  var ffaSyncStatusRaw: String = "nonLie"
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    displayName: String,
    category: String = "Sénior",
    dateOfBirth: Date? = nil,
    heightCM: Double = 0,
    bodyWeightKG: Double = 0,
    currentPRCM: Int = 0,
    trainingPRCM: Int = 0,
    targetHeightCM: Int = 0,
    currentApproachSpeed: Double = 0,
    targetApproachSpeed: Double = 0,
    theoreticalMaximumCM: Int = 0,
    firstName: String = "",
    lastName: String = "",
    clubName: String = "",
    licenseNumber: String = "",
    ffaAthleteID: String = "",
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.displayName = displayName
    self.category = category
    self.dateOfBirth = dateOfBirth
    self.heightCM = heightCM
    self.bodyWeightKG = bodyWeightKG
    self.currentPRCM = currentPRCM
    self.trainingPRCM = trainingPRCM
    self.targetHeightCM = targetHeightCM
    self.currentApproachSpeed = currentApproachSpeed
    self.targetApproachSpeed = targetApproachSpeed
    self.theoreticalMaximumCM = theoreticalMaximumCM
    self.firstName = firstName
    self.lastName = lastName
    self.clubName = clubName
    self.licenseNumber = licenseNumber
    self.ffaAthleteID = ffaAthleteID
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }
}

@Model
final class GoalRecord {
  var id: UUID
  var athleteID: UUID
  var title: String
  var targetHeightCM: Int
  var targetDate: Date?
  var isActive: Bool
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    title: String,
    targetHeightCM: Int,
    targetDate: Date? = nil,
    isActive: Bool = true,
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.title = title
    self.targetHeightCM = targetHeightCM
    self.targetDate = targetDate
    self.isActive = isActive
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }
}

@Model
final class GoalPillarRecord {
  var id: UUID
  var goalID: UUID
  var title: String
  var iconSymbol: String
  var sortIndex: Int
  var accentHex: String
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    goalID: UUID,
    title: String,
    iconSymbol: String,
    sortIndex: Int,
    accentHex: String = "136BC9",
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.goalID = goalID
    self.title = title
    self.iconSymbol = iconSymbol
    self.sortIndex = sortIndex
    self.accentHex = accentHex
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }
}

@Model
final class GoalActionRecord {
  var id: UUID
  var pillarID: UUID
  var title: String
  var kindRaw: String
  var targetValue: Double?
  var unit: String
  var recurrence: String
  var currentValue: Double
  var isCompleted: Bool
  var isArchived: Bool = false
  var isFocused: Bool = false
  var sortIndex: Int
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    pillarID: UUID,
    title: String,
    kind: GoalActionKind,
    targetValue: Double? = nil,
    unit: String = "",
    recurrence: String = "Hebdomadaire",
    currentValue: Double = 0,
    isCompleted: Bool = false,
    sortIndex: Int,
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.pillarID = pillarID
    self.title = title
    self.kindRaw = kind.rawValue
    self.targetValue = targetValue
    self.unit = unit
    self.recurrence = recurrence
    self.currentValue = currentValue
    self.isCompleted = isCompleted
    self.sortIndex = sortIndex
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }

  var kind: GoalActionKind {
    get { GoalActionKind(rawValue: kindRaw) ?? .habit }
    set { kindRaw = newValue.rawValue }
  }
}

@Model
final class ActionCheckInRecord {
  var id: UUID
  var actionID: UUID
  var date: Date
  var completed: Bool
  var value: Double?
  var note: String

  init(
    id: UUID = UUID(),
    actionID: UUID,
    date: Date = .now,
    completed: Bool,
    value: Double? = nil,
    note: String = ""
  ) {
    self.id = id
    self.actionID = actionID
    self.date = date
    self.completed = completed
    self.value = value
    self.note = note
  }
}

@Model
final class PoleRecord {
  var id: UUID
  var athleteID: UUID
  var manufacturer: String
  var modelName: String
  var lengthCM: Int
  var weightKG: Double
  var flexCM: Double
  var nickname: String
  var progressionOrder: Int
  var isActive: Bool
  var notes: String
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    manufacturer: String,
    modelName: String = "",
    lengthCM: Int,
    weightKG: Double,
    flexCM: Double,
    nickname: String = "",
    progressionOrder: Int,
    isActive: Bool = true,
    notes: String = "",
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.manufacturer = manufacturer
    self.modelName = modelName
    self.lengthCM = lengthCM
    self.weightKG = weightKG
    self.flexCM = flexCM
    self.nickname = nickname
    self.progressionOrder = progressionOrder
    self.isActive = isActive
    self.notes = notes
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }

  var displayName: String {
    String(format: "%.2f m · %.0f kg · %.1f cm flex", Double(lengthCM) / 100.0, weightKG, flexCM)
  }

  var snapshot: PoleSnapshot {
    PoleSnapshot(
      id: id,
      manufacturer: manufacturer,
      model: modelName,
      lengthCM: lengthCM,
      weightKG: weightKG,
      flexCM: flexCM,
      progressionOrder: progressionOrder
    )
  }
}

@Model
final class PoleApproachProgressRecord {
  var id: UUID
  var athleteID: UUID
  var poleID: UUID
  var approachSteps: Int
  var stateRaw: String
  var validAttempts: Int
  var clears: Int
  var firstSuccessfulUse: Date?
  var masteredAt: Date?
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    poleID: UUID,
    approach: ApproachLength,
    state: PoleProgressState = .locked,
    validAttempts: Int = 0,
    clears: Int = 0,
    firstSuccessfulUse: Date? = nil,
    masteredAt: Date? = nil,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.poleID = poleID
    self.approachSteps = approach.rawValue
    self.stateRaw = state.rawValue
    self.validAttempts = validAttempts
    self.clears = clears
    self.firstSuccessfulUse = firstSuccessfulUse
    self.masteredAt = masteredAt
    self.updatedAt = updatedAt
  }

  var state: PoleProgressState {
    get { PoleProgressState(rawValue: stateRaw) ?? .locked }
    set { stateRaw = newValue.rawValue }
  }

  var clearRate: Double {
    guard validAttempts > 0 else { return 0 }
    return Double(clears) / Double(validAttempts)
  }

  var snapshot: PoleProgressSnapshot {
    PoleProgressSnapshot(
      poleID: poleID,
      approachSteps: approachSteps,
      state: state,
      validAttempts: validAttempts,
      clears: clears
    )
  }
}

@Model
final class ApproachProfileRecord {
  var id: UUID
  var athleteID: UUID
  var approachSteps: Int
  var startMarkM: Double
  var intermediateMarkM: Double?
  var finalCheckMarkM: Double?
  var expectedTakeoffMarkM: Double?
  var notes: String
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    approach: ApproachLength,
    startMarkM: Double,
    intermediateMarkM: Double? = nil,
    finalCheckMarkM: Double? = nil,
    expectedTakeoffMarkM: Double? = nil,
    notes: String = "",
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.approachSteps = approach.rawValue
    self.startMarkM = startMarkM
    self.intermediateMarkM = intermediateMarkM
    self.finalCheckMarkM = finalCheckMarkM
    self.expectedTakeoffMarkM = expectedTakeoffMarkM
    self.notes = notes
    self.updatedAt = updatedAt
  }
}

@Model
final class VaultSessionRecord {
  var id: UUID
  var athleteID: UUID
  var kindRaw: String
  var startedAt: Date
  var endedAt: Date?
  var title: String
  var notes: String
  var locationName: String = ""
  var environmentRaw: String = "outdoor"
  var weatherRaw: String = "unknown"
  var windDirectionRaw: String = "none"
  var windSpeedMPS: Double? = nil
  var temperatureC: Double? = nil
  var energyLevel: Int = 3
  var sessionGoal: String = ""
  var isActive: Bool
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    kind: SessionKind,
    startedAt: Date = .now,
    endedAt: Date? = nil,
    title: String = "",
    notes: String = "",
    locationName: String = "",
    environment: VaultEnvironment = .outdoor,
    weather: WeatherCondition = .unknown,
    windDirection: WindDirection = .none,
    windSpeedMPS: Double? = nil,
    temperatureC: Double? = nil,
    energyLevel: Int = 3,
    sessionGoal: String = "",
    isActive: Bool = true,
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.kindRaw = kind.rawValue
    self.startedAt = startedAt
    self.endedAt = endedAt
    self.title = title
    self.notes = notes
    self.locationName = locationName
    self.environmentRaw = environment.rawValue
    self.weatherRaw = weather.rawValue
    self.windDirectionRaw = windDirection.rawValue
    self.windSpeedMPS = windSpeedMPS
    self.temperatureC = temperatureC
    self.energyLevel = min(max(energyLevel, 1), 5)
    self.sessionGoal = sessionGoal
    self.isActive = isActive
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }

  var kind: SessionKind {
    get { SessionKind(rawValue: kindRaw) ?? .training }
    set { kindRaw = newValue.rawValue }
  }

  var environment: VaultEnvironment {
    get { VaultEnvironment(rawValue: environmentRaw) ?? .outdoor }
    set { environmentRaw = newValue.rawValue }
  }

  var weather: WeatherCondition {
    get { WeatherCondition(rawValue: weatherRaw) ?? .unknown }
    set { weatherRaw = newValue.rawValue }
  }

  var windDirection: WindDirection {
    get { WindDirection(rawValue: windDirectionRaw) ?? .none }
    set { windDirectionRaw = newValue.rawValue }
  }
}

@Model
final class AttemptRecord {
  var id: UUID
  var athleteID: UUID
  var sessionID: UUID
  var poleID: UUID
  var resultRaw: String
  var diagnosticsCSV: String
  var barHeightCM: Int
  var approachSteps: Int
  var attemptNumber: Int?
  var sequenceIndex: Int
  var note: String
  var technicalRatingRaw: Int = 0
  var gripHeightM: Double? = nil
  var runUpDistanceM: Double? = nil
  var midMarkM: Double? = nil
  var standardsOffsetCM: Int? = nil
  var voiceTranscript: String = ""
  var actualTakeoffMarkM: Double?
  /// Snapshot attached to this attempt only; longitudinal measurements live in PhysicalMetricRecord.
  var approachSpeedMPS: Double?
  var approachSpeedKindRaw: String? = nil
  var approachSpeedSource: String = ""
  var takeoffSpeedMPS: Double?
  var createdAt: Date
  var updatedAt: Date
  var deletedAt: Date?

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    sessionID: UUID,
    poleID: UUID,
    result: AttemptResult,
    diagnostics: Set<AttemptDiagnostic> = [],
    barHeightCM: Int,
    approach: ApproachLength,
    attemptNumber: Int? = nil,
    sequenceIndex: Int,
    note: String = "",
    technicalRating: JumpRating = .unrated,
    gripHeightM: Double? = nil,
    runUpDistanceM: Double? = nil,
    midMarkM: Double? = nil,
    standardsOffsetCM: Int? = nil,
    voiceTranscript: String = "",
    actualTakeoffMarkM: Double? = nil,
    approachSpeedMPS: Double? = nil,
    approachSpeedKind: PhysicalMetricKind? = nil,
    approachSpeedSource: String = "",
    takeoffSpeedMPS: Double? = nil,
    createdAt: Date = .now,
    updatedAt: Date = .now,
    deletedAt: Date? = nil
  ) {
    self.id = id
    self.athleteID = athleteID
    self.sessionID = sessionID
    self.poleID = poleID
    self.resultRaw = result.rawValue
    self.diagnosticsCSV = diagnostics.map(\.rawValue).sorted().joined(separator: "|")
    self.barHeightCM = barHeightCM
    self.approachSteps = approach.rawValue
    self.attemptNumber = attemptNumber
    self.sequenceIndex = sequenceIndex
    self.note = note
    self.technicalRatingRaw = technicalRating.rawValue
    self.gripHeightM = gripHeightM
    self.runUpDistanceM = runUpDistanceM
    self.midMarkM = midMarkM
    self.standardsOffsetCM = standardsOffsetCM
    self.voiceTranscript = voiceTranscript
    self.actualTakeoffMarkM = actualTakeoffMarkM
    self.approachSpeedMPS = approachSpeedMPS
    self.approachSpeedKindRaw = approachSpeedKind?.rawValue
    self.approachSpeedSource = approachSpeedSource
    self.takeoffSpeedMPS = takeoffSpeedMPS
    self.createdAt = createdAt
    self.updatedAt = updatedAt
    self.deletedAt = deletedAt
  }

  var approachSpeedKind: PhysicalMetricKind? {
    get { approachSpeedKindRaw.flatMap(PhysicalMetricKind.init(rawValue:)) }
    set { approachSpeedKindRaw = newValue?.rawValue }
  }

  var technicalRating: JumpRating {
    get { JumpRating(rawValue: technicalRatingRaw) ?? .unrated }
    set { technicalRatingRaw = newValue.rawValue }
  }

  var result: AttemptResult {
    get { AttemptResult(rawValue: resultRaw) ?? .miss }
    set { resultRaw = newValue.rawValue }
  }

  var diagnostics: Set<AttemptDiagnostic> {
    get {
      Set(
        diagnosticsCSV.split(separator: "|").compactMap { AttemptDiagnostic(rawValue: String($0)) })
    }
    set {
      diagnosticsCSV = newValue.map(\.rawValue).sorted().joined(separator: "|")
    }
  }

  var snapshot: AttemptSnapshot {
    AttemptSnapshot(
      id: id,
      sessionID: sessionID,
      poleID: poleID,
      approachSteps: approachSteps,
      result: result,
      diagnostics: diagnostics,
      barHeightCM: barHeightCM,
      gripHeightM: gripHeightM,
      approachSpeedMPS: approachSpeedMPS,
      approachSpeedKind: approachSpeedKind,
      approachSpeedSource: approachSpeedSource,
      takeoffSpeedMPS: takeoffSpeedMPS,
      actualTakeoffMarkM: actualTakeoffMarkM,
      runUpDistanceM: runUpDistanceM,
      midMarkM: midMarkM,
      standardsOffsetCM: standardsOffsetCM,
      technicalRating: technicalRating,
      createdAt: createdAt
    )
  }
}

@Model
final class PhysicalMetricRecord {
  var id: UUID
  var athleteID: UUID
  var kindRaw: String
  var value: Double
  var unit: String
  var source: String
  var protocolName: String
  var approachSteps: Int?
  var measuredAt: Date
  var note: String
  // Reproducibility metadata. Defaults preserve compatibility with existing records.
  var algorithmVersion: String = ""
  var captureFrameRate: Double? = nil
  var analysisFrameRate: Double? = nil
  var analysisStartTime: Double? = nil
  var analysisEndTime: Double? = nil
  var sampleCount: Int? = nil
  var qualityStatusRaw: String = "manual"
  var isEstimated: Bool = false
  var userVerified: Bool = false
  var parametersJSON: String = ""

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    kind: PhysicalMetricKind,
    value: Double,
    unit: String? = nil,
    source: String = "Manuel",
    protocolName: String = "",
    approach: ApproachLength? = nil,
    measuredAt: Date = .now,
    note: String = "",
    algorithmVersion: String = "",
    captureFrameRate: Double? = nil,
    analysisFrameRate: Double? = nil,
    analysisStartTime: Double? = nil,
    analysisEndTime: Double? = nil,
    sampleCount: Int? = nil,
    qualityStatusRaw: String = "manual",
    isEstimated: Bool = false,
    userVerified: Bool = false,
    parametersJSON: String = ""
  ) {
    self.id = id
    self.athleteID = athleteID
    self.kindRaw = kind.rawValue
    self.value = value
    self.unit = unit ?? kind.defaultUnit
    self.source = source
    self.protocolName = protocolName
    self.approachSteps = approach?.rawValue
    self.measuredAt = measuredAt
    self.note = note
    self.algorithmVersion = algorithmVersion
    self.captureFrameRate = captureFrameRate
    self.analysisFrameRate = analysisFrameRate
    self.analysisStartTime = analysisStartTime
    self.analysisEndTime = analysisEndTime
    self.sampleCount = sampleCount
    self.qualityStatusRaw = qualityStatusRaw
    self.isEstimated = isEstimated
    self.userVerified = userVerified
    self.parametersJSON = parametersJSON
  }

  var kind: PhysicalMetricKind {
    get { PhysicalMetricKind(rawValue: kindRaw) ?? .approachSpeed }
    set { kindRaw = newValue.rawValue }
  }
}

@Model
final class DrillRecord {
  var id: UUID
  var title: String
  var phaseRaw: String
  var faultsCSV: String
  var coachingCues: String
  var commonErrors: String
  var sets: Int
  var repetitions: Int
  var restSeconds: Int
  var difficulty: Int
  var equipment: String
  var videoURLString: String
  var safetyNote: String
  var isPublished: Bool
  var sortIndex: Int

  init(
    id: UUID = UUID(),
    title: String,
    phase: VaultPhase,
    faults: [AttemptDiagnostic] = [],
    coachingCues: String,
    commonErrors: String,
    sets: Int,
    repetitions: Int,
    restSeconds: Int,
    difficulty: Int,
    equipment: String,
    videoURLString: String = "",
    safetyNote: String = "",
    isPublished: Bool = true,
    sortIndex: Int
  ) {
    self.id = id
    self.title = title
    self.phaseRaw = phase.rawValue
    self.faultsCSV = faults.map(\.rawValue).joined(separator: "|")
    self.coachingCues = coachingCues
    self.commonErrors = commonErrors
    self.sets = sets
    self.repetitions = repetitions
    self.restSeconds = restSeconds
    self.difficulty = difficulty
    self.equipment = equipment
    self.videoURLString = videoURLString
    self.safetyNote = safetyNote
    self.isPublished = isPublished
    self.sortIndex = sortIndex
  }

  var phase: VaultPhase {
    get { VaultPhase(rawValue: phaseRaw) ?? .plant }
    set { phaseRaw = newValue.rawValue }
  }

  var faults: [AttemptDiagnostic] {
    faultsCSV.split(separator: "|").compactMap { AttemptDiagnostic(rawValue: String($0)) }
  }
}

/// A real, user-managed video resource attached to one exercise category.
///
/// `DrillRecord.videoURLString` is retained only for store compatibility with
/// earlier releases. The training library now uses these records exclusively,
/// allowing several external resources in every category.
@Model
final class ExerciseVideoRecord {
  var id: UUID
  var categoryRaw: String
  var urlString: String
  var title: String
  var videoDescription: String
  var thumbnailURLString: String? = nil
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    category: ExerciseVideoCategory,
    urlString: String,
    title: String,
    videoDescription: String = "",
    thumbnailURLString: String? = nil,
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.categoryRaw = category.rawValue
    self.urlString = urlString
    self.title = title
    self.videoDescription = videoDescription
    self.thumbnailURLString = thumbnailURLString
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }

  var category: ExerciseVideoCategory {
    get { ExerciseVideoCategory.migrated(from: categoryRaw) }
    set { categoryRaw = newValue.rawValue }
  }
}

@Model
final class DrillCompletionRecord {
  var id: UUID
  var athleteID: UUID
  var drillID: UUID
  var sessionID: UUID?
  var completedSets: Int
  var completedRepetitions: Int
  var rating: Int
  var note: String
  var completedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    drillID: UUID,
    sessionID: UUID? = nil,
    completedSets: Int,
    completedRepetitions: Int,
    rating: Int = 0,
    note: String = "",
    completedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.drillID = drillID
    self.sessionID = sessionID
    self.completedSets = completedSets
    self.completedRepetitions = completedRepetitions
    self.rating = rating
    self.note = note
    self.completedAt = completedAt
  }
}

@Model
final class VideoClipRecord {
  var id: UUID
  var athleteID: UUID
  var attemptID: UUID?
  /// Legacy v10 only. New writes use `mediaStorageKey`.
  var localURLString: String
  /// Relative path inside Application Support/PercheProgression/Media.
  var mediaStorageKey: String = ""
  var fileSHA256: String? = nil
  var originalFilename: String
  var durationSeconds: Double
  var frameRate: Double
  var phaseRaw: String?
  var pencilDrawingData: Data?
  var calibrationData: Data?
  var trackingSeedX: Double?
  var trackingSeedY: Double?
  var motionAnalysisData: Data?
  var analysisNotes: String
  // Persisted comparison workspace (v12).
  var comparisonClipID: UUID? = nil
  var comparisonOffsetSeconds: Double = 0
  var comparisonModeRaw: String = "side-by-side"
  var comparisonTakeoffTime: Double? = nil
  var overlayTransformData: Data? = nil
  // Remote-camera provenance (v15). Defaults keep legacy stores decodable.
  var sourceDeviceName: String = ""
  var sourceCameraDescription: String = ""
  var sourceResolution: String = ""
  var remoteRecordingID: String = ""
  var remoteCreationTime: Date? = nil
  var remoteOrientation: String = ""
  var createdAt: Date
  var updatedAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    attemptID: UUID? = nil,
    localURLString: String = "",
    mediaStorageKey: String = "",
    fileSHA256: String? = nil,
    originalFilename: String,
    durationSeconds: Double = 0,
    frameRate: Double = 60,
    phase: VaultPhase? = nil,
    pencilDrawingData: Data? = nil,
    calibrationData: Data? = nil,
    trackingSeedX: Double? = nil,
    trackingSeedY: Double? = nil,
    motionAnalysisData: Data? = nil,
    analysisNotes: String = "",
    comparisonClipID: UUID? = nil,
    comparisonOffsetSeconds: Double = 0,
    comparisonModeRaw: String = "side-by-side",
    comparisonTakeoffTime: Double? = nil,
    overlayTransformData: Data? = nil,
    createdAt: Date = .now,
    updatedAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.attemptID = attemptID
    self.localURLString = localURLString
    self.mediaStorageKey = mediaStorageKey
    self.fileSHA256 = fileSHA256
    self.originalFilename = originalFilename
    self.durationSeconds = durationSeconds
    self.frameRate = frameRate
    self.phaseRaw = phase?.rawValue
    self.pencilDrawingData = pencilDrawingData
    self.calibrationData = calibrationData
    self.trackingSeedX = trackingSeedX
    self.trackingSeedY = trackingSeedY
    self.motionAnalysisData = motionAnalysisData
    self.analysisNotes = analysisNotes
    self.comparisonClipID = comparisonClipID
    self.comparisonOffsetSeconds = comparisonOffsetSeconds
    self.comparisonModeRaw = comparisonModeRaw
    self.comparisonTakeoffTime = comparisonTakeoffTime
    self.overlayTransformData = overlayTransformData
    self.createdAt = createdAt
    self.updatedAt = updatedAt
  }
}

@Model
final class VectorAnnotationRecord {
  var id: UUID
  var athleteID: UUID
  var videoID: UUID
  var timeSeconds: Double
  var label: String
  var kindRaw: String
  var startX: Double
  var startY: Double
  var endX: Double
  var endY: Double
  var source: String
  var createdAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    videoID: UUID,
    vector: OverlayVector,
    createdAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.videoID = videoID
    self.timeSeconds = vector.timeSeconds
    self.label = vector.label
    self.kindRaw = vector.kind.rawValue
    self.startX = vector.start.x
    self.startY = vector.start.y
    self.endX = vector.end.x
    self.endY = vector.end.y
    self.source = vector.source
    self.createdAt = createdAt
  }

  var overlayVector: OverlayVector {
    OverlayVector(
      id: id,
      timeSeconds: timeSeconds,
      label: label,
      kind: VectorKind(rawValue: kindRaw) ?? .manual,
      start: NormalizedPoint(x: startX, y: startY),
      end: NormalizedPoint(x: endX, y: endY),
      source: source
    )
  }
}

@Model
final class PhaseMarkerRecord {
  var id: UUID
  var athleteID: UUID
  var videoID: UUID
  var phaseRaw: String
  var timeSeconds: Double
  var source: String
  var confidence: Double?
  var createdAt: Date

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    videoID: UUID,
    phase: VaultPhase,
    timeSeconds: Double,
    source: String = "athlete",
    confidence: Double? = nil,
    createdAt: Date = .now
  ) {
    self.id = id
    self.athleteID = athleteID
    self.videoID = videoID
    self.phaseRaw = phase.rawValue
    self.timeSeconds = timeSeconds
    self.source = source
    self.confidence = confidence
    self.createdAt = createdAt
  }
}


enum FFASyncStatus: String, Codable, CaseIterable {
  case unlinked = "nonLie"
  case linked = "lie"
  case syncing = "synchronisation"
  case success = "aJour"
  case failed = "erreur"
}

@Model
final class OfficialPerformanceRecord {
  var id: UUID
  var athleteID: UUID
  var ffaAthleteID: String
  var externalKey: String
  var sourceResultID: String
  var eventName: String
  var performanceCM: Int
  var date: Date
  var isIndoor: Bool
  var venue: String
  var competition: String
  var place: String
  var level: String
  var sourceURLString: String
  var importedAt: Date
  var lastRefreshedAt: Date

  init(
    id: UUID = UUID(), athleteID: UUID, ffaAthleteID: String, externalKey: String,
    sourceResultID: String = "", eventName: String, performanceCM: Int, date: Date,
    isIndoor: Bool, venue: String = "", competition: String = "", place: String = "",
    level: String = "", sourceURLString: String = "", importedAt: Date = .now,
    lastRefreshedAt: Date = .now
  ) {
    self.id = id; self.athleteID = athleteID; self.ffaAthleteID = ffaAthleteID
    self.externalKey = externalKey; self.sourceResultID = sourceResultID; self.eventName = eventName
    self.performanceCM = performanceCM; self.date = date; self.isIndoor = isIndoor
    self.venue = venue; self.competition = competition; self.place = place; self.level = level
    self.sourceURLString = sourceURLString; self.importedAt = importedAt; self.lastRefreshedAt = lastRefreshedAt
  }
}

@Model
final class PoleRecommendationDecisionRecord {
  var id: UUID
  var athleteID: UUID
  var currentPoleID: UUID
  var recommendedPoleID: UUID
  var approachSteps: Int
  var modelVersion: String
  var directionRaw: String
  var readinessScore: Double
  var confidenceRaw: String
  var decisionRaw: String
  var createdAt: Date

  init(
    id: UUID = UUID(), athleteID: UUID, currentPoleID: UUID, recommendedPoleID: UUID,
    approachSteps: Int, modelVersion: String, direction: PoleRecommendationDirection,
    readinessScore: Double, confidence: PoleRecommendation.Confidence, decision: String, createdAt: Date = .now
  ) {
    self.id = id; self.athleteID = athleteID; self.currentPoleID = currentPoleID
    self.recommendedPoleID = recommendedPoleID; self.approachSteps = approachSteps
    self.modelVersion = modelVersion; self.directionRaw = direction.rawValue
    self.readinessScore = readinessScore.isFinite ? min(max(readinessScore, 0), 1) : 0
    self.confidenceRaw = confidence.rawValue; self.decisionRaw = decision; self.createdAt = createdAt
  }
}

enum PerformanceDataSource: String, Codable, CaseIterable, Identifiable {
  case manual = "Manuel"
  case video = "Vidéo"
  case competition = "Compétition"
  case ffa = "FFA"
  case physicalTest = "Test physique"

  var id: String { rawValue }
}

enum PerformanceDimension: String, Codable, CaseIterable, Identifiable {
  case speed = "Vitesse"
  case takeoffQuality = "Qualité de l’impulsion"
  case poleUtilization = "Utilisation des perches"
  case poleProgression = "Progression de perches"
  case technicalConsistency = "Régularité technique"
  case strength = "Force"
  case mobility = "Mobilité"
  case competition = "Compétition"

  var id: String { rawValue }
}

@Model
final class PerformanceDimensionRecord {
  var id: UUID
  var athleteID: UUID
  var dimensionRaw: String
  var rawValue: Double
  var normalizedScore: Double
  var sourceRaw: String
  var measuredAt: Date
  var note: String

  init(
    id: UUID = UUID(),
    athleteID: UUID,
    dimension: PerformanceDimension,
    rawValue: Double,
    normalizedScore: Double,
    source: PerformanceDataSource,
    measuredAt: Date = .now,
    note: String = ""
  ) {
    self.id = id
    self.athleteID = athleteID
    self.dimensionRaw = dimension.rawValue
    self.rawValue = rawValue
    self.normalizedScore = min(max(normalizedScore, 0), 1)
    self.sourceRaw = source.rawValue
    self.measuredAt = measuredAt
    self.note = note
  }

  var dimension: PerformanceDimension {
    get { PerformanceDimension(rawValue: dimensionRaw) ?? .speed }
    set { dimensionRaw = newValue.rawValue }
  }

  var source: PerformanceDataSource {
    get { PerformanceDataSource(rawValue: sourceRaw) ?? .manual }
    set { sourceRaw = newValue.rawValue }
  }
}

@Model
final class SyncOperationRecord {
  var id: UUID
  var entityType: String
  var entityID: UUID
  var operation: String
  var payloadJSON: String
  var createdAt: Date
  var retryCount: Int
  var lastError: String

  init(
    id: UUID = UUID(),
    entityType: String,
    entityID: UUID,
    operation: String,
    payloadJSON: String,
    createdAt: Date = .now,
    retryCount: Int = 0,
    lastError: String = ""
  ) {
    self.id = id
    self.entityType = entityType
    self.entityID = entityID
    self.operation = operation
    self.payloadJSON = payloadJSON
    self.createdAt = createdAt
    self.retryCount = retryCount
    self.lastError = lastError
  }
}
