import SwiftUI

extension Color {
  static let vaultBackground = Color(red: 0.974, green: 0.969, blue: 0.949)
  static let vaultPanel = Color.white
  static let vaultPanelRaised = Color(red: 0.955, green: 0.947, blue: 0.920)
  static let vaultText = Color(red: 0.035, green: 0.145, blue: 0.245)
  static let vaultMuted = Color(red: 0.365, green: 0.415, blue: 0.460)
  static let vaultLine = Color(red: 0.900, green: 0.878, blue: 0.830)
  static let vaultAccent = Color(red: 0.945, green: 0.365, blue: 0.095)
  static let vaultSuccess = Color(red: 0.120, green: 0.515, blue: 0.345)
  static let vaultWarning = Color(red: 0.735, green: 0.365, blue: 0.120)
  static let vaultCyan = Color(red: 0.080, green: 0.480, blue: 0.690)
  static let vaultNavy = Color(red: 0.025, green: 0.145, blue: 0.260)
  static let vaultNavyLight = Color(red: 0.050, green: 0.255, blue: 0.425)
  static let vaultGold = Color(red: 0.965, green: 0.670, blue: 0.090)
  /// High-contrast blue reserved for the video-analysis workspace.
  static let vaultAnalysisAccent = Color(red: 0.000, green: 0.384, blue: 0.608)
  /// Purple status color used for points that still require review.
  static let vaultAnalysisReview = Color(red: 0.451, green: 0.208, blue: 0.569)
  /// Balanced blue for markers drawn over both light and dark video frames.
  static let vaultAnalysisMarker = Color(red: 0.000, green: 0.467, blue: 0.714)
}

enum VaultSpacing {
  static let xSmall: CGFloat = 8
  static let small: CGFloat = 12
  static let medium: CGFloat = 20
  static let large: CGFloat = 30
  static let xLarge: CGFloat = 42
}

enum VaultRadius {
  static let small: CGFloat = 14
  static let medium: CGFloat = 22
  static let large: CGFloat = 30
}

struct VaultCardModifier: ViewModifier {
  var padding: CGFloat = VaultSpacing.medium
  var background: Color = .vaultPanel

  func body(content: Content) -> some View {
    content
      .padding(padding)
      .background(
        background, in: RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
      )
      .overlay {
        RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
          .stroke(Color.vaultLine, lineWidth: 1)
      }
      .shadow(color: Color.vaultText.opacity(0.055), radius: 16, x: 0, y: 7)
  }
}

extension View {
  func vaultCard(padding: CGFloat = VaultSpacing.medium, background: Color = .vaultPanel)
    -> some View
  {
    modifier(VaultCardModifier(padding: padding, background: background))
  }

  func vaultPage() -> some View {
    background(Color.vaultBackground.ignoresSafeArea())
      .foregroundStyle(Color.vaultText)
  }
}

struct SectionEyebrow: View {
  let text: String

  var body: some View {
    Text(text.uppercased())
      .font(.caption.weight(.black))
      .tracking(1.25)
      .foregroundStyle(Color.vaultMuted)
      .accessibilityAddTraits(.isHeader)
  }
}

struct VaultScreenHeader: View {
  let title: String
  let subtitle: String
  var symbol: String? = nil
  var tint: Color = .vaultAccent

  var body: some View {
    HStack(alignment: .top, spacing: 18) {
      if let symbol {
        Image(systemName: symbol)
          .font(.title2.weight(.bold))
          .foregroundStyle(tint)
          .frame(width: 48, height: 48)
          .background(
            tint.opacity(0.10),
            in: RoundedRectangle(cornerRadius: 15, style: .continuous))
      }
      VStack(alignment: .leading, spacing: 7) {
        Text(title)
          .font(.system(.largeTitle, design: .rounded, weight: .black))
          .foregroundStyle(Color.vaultText)
        Text(subtitle)
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
          .lineSpacing(3)
      }
      Spacer()
    }
  }
}

struct MetricPill: View {
  let title: String
  let value: String
  var tint: Color = .vaultAccent

  var body: some View {
    VStack(alignment: .leading, spacing: 7) {
      Text(title.uppercased())
        .font(.caption2.weight(.black))
        .tracking(0.9)
        .foregroundStyle(Color.vaultMuted)
      Text(value)
        .font(.headline.monospacedDigit().weight(.black))
        .foregroundStyle(Color.vaultText)
    }
    .padding(.horizontal, 17)
    .padding(.vertical, 13)
    .background(tint.opacity(0.09), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
    .overlay {
      RoundedRectangle(cornerRadius: 15, style: .continuous)
        .stroke(tint.opacity(0.20), lineWidth: 1)
    }
  }
}

struct ApproachPicker: View {
  @Binding var selection: ApproachLength

  var body: some View {
    HStack(spacing: 9) {
      ForEach(ApproachLength.allCases) { approach in
        Button {
          selection = approach
          Haptics.selection()
        } label: {
          Text(approach.shortTitle)
            .font(.subheadline.monospacedDigit().weight(.bold))
            .frame(minWidth: 40)
            .padding(.vertical, 11)
            .padding(.horizontal, 7)
            .foregroundStyle(selection == approach ? Color.white : Color.vaultText)
            .background(
              selection == approach ? Color.vaultAccent : Color.vaultPanelRaised,
              in: Capsule()
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(approach.title)
      }
    }
  }
}

struct VaultCommentEditor: View {
  @Binding var text: String
  let placeholder: String
  var minHeight: CGFloat = 150

  var body: some View {
    ZStack(alignment: .topLeading) {
      if text.isEmpty {
        Text(placeholder)
          .font(.body)
          .foregroundStyle(Color.vaultMuted.opacity(0.78))
          .padding(.horizontal, 16)
          .padding(.vertical, 18)
          .allowsHitTesting(false)
      }

      TextEditor(text: $text)
        .font(.body)
        .scrollContentBackground(.hidden)
        .padding(10)
        .frame(minHeight: minHeight)
        .background(Color.clear)
    }
    .background(
      Color.vaultPanelRaised,
      in: RoundedRectangle(cornerRadius: VaultRadius.small, style: .continuous)
    )
    .overlay {
      RoundedRectangle(cornerRadius: VaultRadius.small, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }
}

struct EmptyStateView: View {
  let symbol: String
  let title: String
  let message: String

  var body: some View {
    VStack(spacing: 16) {
      Image(systemName: symbol)
        .font(.system(size: 44, weight: .semibold))
        .foregroundStyle(Color.vaultAccent.opacity(0.65))
      Text(title)
        .font(.title3.weight(.bold))
      Text(message)
        .font(.subheadline)
        .foregroundStyle(Color.vaultMuted)
        .multilineTextAlignment(.center)
        .lineSpacing(4)
    }
    .frame(maxWidth: .infinity, minHeight: 260)
    .vaultCard(padding: VaultSpacing.large)
  }
}
