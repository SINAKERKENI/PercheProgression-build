import CoreGraphics
import CoreML
import Foundation
import Vision

/// Adaptateur facultatif pour un modèle Core ML de type YOLO/RT-DETR.
/// L'application reste exécutable sans modèle : le détecteur géométrique Vision prend le relais.
final class PoleVaultSceneDetectorService: @unchecked Sendable {
  private let visionModel: VNCoreMLModel?

  init() {
    guard let modelURL = Bundle.main.url(
      forResource: "PoleVaultSceneDetector",
      withExtension: "mlmodelc"
    ), let model = try? MLModel(contentsOf: modelURL)
    else {
      visionModel = nil
      return
    }
    visionModel = try? VNCoreMLModel(for: model)
  }
  var isAvailable: Bool { visionModel != nil }

  struct Detection: Sendable {
    var label: String
    var confidence: Double
    var boundingBox: CGRect
  }

  func detect(in image: CGImage) -> [Detection] {
    guard let visionModel else { return [] }

    let request = VNCoreMLRequest(model: visionModel)
    request.imageCropAndScaleOption = .scaleFit
    let handler = VNImageRequestHandler(cgImage: image, orientation: .up)
    do {
      try handler.perform([request])
    } catch {
      return []
    }

    return (request.results as? [VNRecognizedObjectObservation] ?? []).compactMap { observation in
      guard let label = observation.labels.first, label.confidence >= 0.20 else { return nil }
      return Detection(
        label: label.identifier.lowercased(),
        confidence: Double(label.confidence),
        boundingBox: observation.boundingBox
      )
    }
  }

  func runwayGuess(
    in image: CGImage,
    zoneLengthMeters: Double,
    runwayWidthMeters: Double
  ) -> RunwaySceneDetectionService.Guess? {
    let detections = detect(in: image)
    guard !detections.isEmpty else { return nil }

    let runway = detections
      .filter { $0.label.contains("runway") || $0.label.contains("track") || $0.label.contains("piste") }
      .max { $0.confidence < $1.confidence }
    let box = detections
      .filter {
        $0.label.contains("plant_box") || $0.label.contains("vault_box")
          || $0.label.contains("butoir") || $0.label.contains("box")
      }
      .max { $0.confidence < $1.confidence }

    guard let runway else { return nil }
    let runwayRect = uiRect(runway.boundingBox)
    let nearY = min(max(box.map { uiRect($0.boundingBox).midY } ?? runwayRect.maxY, 0), 1)
    let farY = min(max(runwayRect.minY, 0), 1)
    let nearLeftX = runwayRect.minX
    let nearRightX = runwayRect.maxX
    let farHalfWidth = runwayRect.width * 0.28
    let farCenter = runwayRect.midX

    let grid = RunwayGridCalibration(
      boxLeft: .init(x: nearLeftX, y: nearY),
      boxRight: .init(x: nearRightX, y: nearY),
      farLeft: .init(x: farCenter - farHalfWidth, y: farY),
      farRight: .init(x: farCenter + farHalfWidth, y: farY),
      zoneLengthMeters: zoneLengthMeters,
      runwayWidthMeters: runwayWidthMeters
    )
    guard grid.isGeometricallyUsable else { return nil }
    let confidence = min(runway.confidence * 0.72 + (box?.confidence ?? 0.35) * 0.28, 0.95)
    return RunwaySceneDetectionService.Guess(
      grid: grid,
      confidence: confidence,
      sourceDescription: "Core ML · piste et butoir"
    )
  }

  private func uiRect(_ visionRect: CGRect) -> CGRect {
    CGRect(
      x: visionRect.minX,
      y: 1 - visionRect.maxY,
      width: visionRect.width,
      height: visionRect.height
    )
  }
}
