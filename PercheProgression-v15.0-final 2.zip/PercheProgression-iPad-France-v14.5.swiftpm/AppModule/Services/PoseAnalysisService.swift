import AVFoundation
import Foundation
import Vision

struct PoseAnalysisService: Sendable {
  enum PoseError: LocalizedError {
    case noFrame
    case noPerson

    var errorDescription: String? {
      switch self {
      case .noFrame: "L’application n’a pas pu extraire cette image de la vidéo."
      case .noPerson: "Aucune posture humaine suffisamment fiable n’a été détectée sur cette image."
      }
    }
  }

  func analyze(videoURL: URL, at seconds: Double) async throws -> [PoseJoint] {
    let candidates = try await analyzeCandidates(videoURL: videoURL, at: seconds)
    guard let best = candidates.first else { throw PoseError.noPerson }
    return best.joints
  }

  /// Renvoie toutes les personnes détectées sur l'image, triées par qualité visuelle.
  /// L'interface laisse ensuite l'utilisateur choisir explicitement le perchiste afin
  /// d'éviter qu'un spectateur soit utilisé pour les angles ou le suivi de vitesse.
  func analyzeCandidates(videoURL: URL, at seconds: Double) async throws -> [PoseCandidate] {
    let image = try await frame(videoURL: videoURL, at: seconds)
    let request = VNDetectHumanBodyPoseRequest()
    let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
    try handler.perform([request])

    let observations = request.results ?? []
    let candidates = observations.compactMap(makeCandidate)
      .sorted { candidateScore($0) > candidateScore($1) }

    guard !candidates.isEmpty else { throw PoseError.noPerson }
    return candidates
  }

  private func frame(videoURL: URL, at seconds: Double) async throws -> CGImage {
    let asset = AVURLAsset(url: videoURL)
    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = CMTime(value: 1, timescale: 600)
    generator.requestedTimeToleranceAfter = CMTime(value: 1, timescale: 600)

    do {
      return try await generator.image(
        at: CMTime(seconds: max(seconds, 0), preferredTimescale: 600)
      ).image
    } catch {
      throw PoseError.noFrame
    }
  }

  private func makeCandidate(_ observation: VNHumanBodyPoseObservation) -> PoseCandidate? {
    let names: [(String, VNHumanBodyPoseObservation.JointName)] = [
      ("nose", .nose),
      ("neck", .neck),
      ("root", .root),
      ("leftShoulder", .leftShoulder),
      ("leftElbow", .leftElbow),
      ("leftWrist", .leftWrist),
      ("rightShoulder", .rightShoulder),
      ("rightElbow", .rightElbow),
      ("rightWrist", .rightWrist),
      ("leftHip", .leftHip),
      ("leftKnee", .leftKnee),
      ("leftAnkle", .leftAnkle),
      ("rightHip", .rightHip),
      ("rightKnee", .rightKnee),
      ("rightAnkle", .rightAnkle),
    ]

    let joints = names.compactMap { label, name -> PoseJoint? in
      guard let point = try? observation.recognizedPoint(name), point.confidence >= Float(VideoAnalysisConfiguration.Pose.minimumJointConfidence) else {
        return nil
      }
      return PoseJoint(
        id: label,
        point: NormalizedPoint(x: point.location.x, y: 1 - point.location.y).clamped(),
        confidence: Double(point.confidence)
      )
    }

    let ids = Set(joints.map(\.id))
    let hasTorso = ids.contains("root") && (ids.contains("leftShoulder") || ids.contains("rightShoulder"))
      && (ids.contains("leftHip") || ids.contains("rightHip"))
    let hasLowerLimb = (ids.contains("leftKnee") && ids.contains("leftAnkle"))
      || (ids.contains("rightKnee") && ids.contains("rightAnkle"))
    guard joints.count >= VideoAnalysisConfiguration.Pose.minimumJointCount, hasTorso, hasLowerLimb else { return nil }
    let points = joints.map(\.point)
    let minimumX = points.map(\.x).min() ?? 0
    let maximumX = points.map(\.x).max() ?? 1
    let minimumY = points.map(\.y).min() ?? 0
    let maximumY = points.map(\.y).max() ?? 1
    let horizontalPadding = max((maximumX - minimumX) * 0.18, 0.018)
    let verticalPadding = max((maximumY - minimumY) * 0.10, 0.018)
    let box = NormalizedRect(
      x: minimumX - horizontalPadding,
      y: minimumY - verticalPadding,
      width: maximumX - minimumX + horizontalPadding * 2,
      height: maximumY - minimumY + verticalPadding * 2
    ).clamped()
    let confidence = joints.map(\.confidence).reduce(0, +) / Double(joints.count)
    return PoseCandidate(joints: joints, boundingBox: box, confidence: confidence)
  }

  private func candidateScore(_ candidate: PoseCandidate) -> Double {
    let completeness = min(Double(candidate.joints.count) / 15.0, 1)
    let usefulSize = min(candidate.boundingBox.area / 0.12, 1)
    return candidate.confidence * 0.62 + completeness * 0.24 + usefulSize * 0.14
  }
}
