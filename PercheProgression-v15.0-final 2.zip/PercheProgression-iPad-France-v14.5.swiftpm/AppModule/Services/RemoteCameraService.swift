import Combine
import CryptoKit
import Foundation
import Network

/// SwiftUI-facing discovery state. Foundation delegate callbacks are owned by
/// `BonjourCameraDiscoveryWorker`, so this observable object remains safely
/// isolated to the main actor without using an actor-isolated delegate conformance.
@MainActor
final class BonjourCameraDiscovery: ObservableObject {
  @Published private(set) var endpoints: [RemoteCameraEndpoint] = []

  private lazy var worker = BonjourCameraDiscoveryWorker { [weak self] event in
    self?.apply(event)
  }

  func start() {
    worker.start()
  }

  func stop() {
    worker.stop()
  }

  private func apply(_ event: BonjourDiscoveryEvent) {
    BonjourEndpointReducer.apply(event, to: &endpoints)
  }
}

/// Owns `NetServiceBrowser`/`NetService` delegate callbacks.
///
/// `NetServiceBrowser` dispatches delegate callbacks on the run loop on which
/// the search is started. The main-actor wrapper calls `start`/`stop`, keeping
/// all Foundation service objects on that run loop. Only immutable, Sendable
/// `BonjourDiscoveryEvent` values cross into SwiftUI state.
private final class BonjourCameraDiscoveryWorker: NSObject, NetServiceBrowserDelegate, NetServiceDelegate {
  private let browser = NetServiceBrowser()
  private var services: [NetService] = []
  private let emit: @MainActor @Sendable (BonjourDiscoveryEvent) -> Void

  init(emit: @escaping @MainActor @Sendable (BonjourDiscoveryEvent) -> Void) {
    self.emit = emit
    super.init()
    browser.delegate = self
  }

  func start() {
    stop()
    browser.searchForServices(ofType: "_perche-camera._tcp.", inDomain: "local.")
  }

  func stop() {
    browser.stop()
    services.forEach { $0.stop() }
    services.removeAll()
  }

  func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
    guard !services.contains(where: { $0 === service }) else { return }
    services.append(service)
    service.delegate = self
    service.resolve(withTimeout: 5)
  }

  func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool) {
    services.removeAll { $0 === service }
    let name = service.name
    Task { @MainActor [emit] in
      emit(.removed(name: name))
    }
  }

  func netServiceDidResolveAddress(_ sender: NetService) {
    guard let host = sender.hostName, sender.port > 0 else { return }
    var transferPort = sender.port + 1
    var deviceID = sender.name
    if let txt = sender.txtRecordData() {
      let dictionary = NetService.dictionary(fromTXTRecord: txt)
      if let data = dictionary["transferPort"],
        let string = String(data: data, encoding: .utf8),
        let parsed = Int(string)
      {
        transferPort = parsed
      }
      if let data = dictionary["deviceID"],
        let string = String(data: data, encoding: .utf8),
        !string.isEmpty
      {
        deviceID = string
      }
    }

    // Extract Foundation-owned values into our Sendable value type before
    // crossing the main-actor boundary.
    let endpoint = RemoteCameraEndpoint(
      name: sender.name,
      host: host,
      controlPort: sender.port,
      transferPort: transferPort,
      deviceID: deviceID
    )
    Task { @MainActor [emit] in
      emit(.resolved(endpoint))
    }
  }
}

private enum PixelConnectionAttemptEvent: Sendable {
  case ready
  case failed(String)
  case cancelled
}

private let pixelConnectTimeoutNanoseconds: UInt64 = 8_000_000_000
private let pixelRequestTimeoutNanoseconds: UInt64 = 12_000_000_000

actor PixelControlTransport {
  private var connection: NWConnection?
  private var receiveBuffer = Data()
  private var pending: [UUID: CheckedContinuation<RemoteControlResponse, Error>] = [:]
  private var connectContinuation: CheckedContinuation<Void, Error>?
  private var connectGate = RemoteConnectionAttemptGate()
  private let queue = DispatchQueue(label: "PercheProgression.PixelControl")

  func connect(to endpoint: RemoteCameraEndpoint) async throws {
    close()
    guard let port = NWEndpoint.Port(rawValue: UInt16(endpoint.controlPort)) else {
      throw RemoteCameraError.notConnected
    }

    let host = NWEndpoint.Host(endpoint.host)
    let newConnection = NWConnection(host: host, port: port, using: .tcp)
    let attemptID = UUID()
    connection = newConnection

    do {
      try Task.checkCancellation()
      try await withTaskCancellationHandler {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
          connectGate.begin(attemptID)
          connectContinuation = continuation
          newConnection.stateUpdateHandler = { [weak self] state in
            let event: PixelConnectionAttemptEvent?
            switch state {
            case .ready:
              event = .ready
            case .failed(let error):
              event = .failed(error.localizedDescription)
            case .cancelled:
              event = .cancelled
            default:
              event = nil
            }
            guard let event else { return }
            Task { await self?.completeConnectionAttempt(id: attemptID, event: event) }
          }
          newConnection.start(queue: queue)
          Task { [weak self] in
            guard let self else { return }
            do { try await Task.sleep(nanoseconds: pixelConnectTimeoutNanoseconds) }
            catch { return }
            await self.timeoutConnectionAttempt(id: attemptID)
          }
        }
      } onCancel: {
        Task { await self.cancelConnectionAttempt(id: attemptID) }
      }
    } catch {
      if connectGate.claim(attemptID) {
        connectContinuation = nil
      }
      if connection === newConnection {
        newConnection.stateUpdateHandler = nil
        newConnection.cancel()
        connection = nil
      }
      throw error
    }

    receiveNext()
  }

  func close() {
    let activeConnectContinuation = connectContinuation
    connectContinuation = nil
    connectGate.clear()
    activeConnectContinuation?.resume(throwing: RemoteCameraError.notConnected)

    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil

    let continuations = Array(pending.values)
    pending.removeAll()
    continuations.forEach { $0.resume(throwing: RemoteCameraError.notConnected) }
  }

  func request(_ request: RemoteControlRequest) async throws -> RemoteControlResponse {
    guard let connection else { throw RemoteCameraError.notConnected }
    let payload = try JSONEncoder().encode(request) + Data([0x0A])
    let requestID = request.id

    try Task.checkCancellation()
    return try await withTaskCancellationHandler {
      try await withCheckedThrowingContinuation { continuation in
        pending[requestID] = continuation
        connection.send(content: payload, completion: .contentProcessed { [weak self] error in
          guard let error else { return }
          let message = error.localizedDescription
          Task {
            await self?.fail(
              requestID: requestID,
              error: RemoteCameraError.rejected(message)
            )
          }
        })
        Task { [weak self] in
          guard let self else { return }
          do { try await Task.sleep(nanoseconds: pixelRequestTimeoutNanoseconds) }
          catch { return }
          await self.timeoutRequest(requestID)
        }
      }
    } onCancel: {
      Task { await self.cancelRequest(requestID) }
    }
  }

  private func completeConnectionAttempt(id: UUID, event: PixelConnectionAttemptEvent) {
    guard connectGate.claim(id), let continuation = connectContinuation else { return }

    connectContinuation = nil
    connection?.stateUpdateHandler = nil

    switch event {
    case .ready:
      continuation.resume()
    case .failed(let message):
      connection?.cancel()
      connection = nil
      continuation.resume(throwing: RemoteCameraError.rejected(message))
    case .cancelled:
      connection = nil
      continuation.resume(throwing: RemoteCameraError.notConnected)
    }
  }

  private func timeoutConnectionAttempt(id: UUID) {
    guard connectGate.claim(id), let continuation = connectContinuation else { return }
    connectContinuation = nil
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
    continuation.resume(throwing: RemoteCameraError.rejected("Délai de connexion au Pixel dépassé."))
  }

  private func cancelConnectionAttempt(id: UUID) {
    guard connectGate.claim(id), let continuation = connectContinuation else { return }
    connectContinuation = nil
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
    continuation.resume(throwing: CancellationError())
  }

  private func timeoutRequest(_ requestID: UUID) {
    pending.removeValue(forKey: requestID)?.resume(
      throwing: RemoteCameraError.rejected("Le Pixel n’a pas répondu à la commande dans le délai prévu.")
    )
  }

  private func cancelRequest(_ requestID: UUID) {
    pending.removeValue(forKey: requestID)?.resume(throwing: CancellationError())
  }

  private func fail(requestID: UUID, error: Error) {
    pending.removeValue(forKey: requestID)?.resume(throwing: error)
  }

  private func receiveNext() {
    guard let connection else { return }
    connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, complete, error in
      // Foundation/Network objects do not cross actor isolation. Convert any
      // network error to an immutable app error before scheduling actor work.
      let failure = error.map { RemoteCameraError.rejected($0.localizedDescription) }
      Task {
        guard let self else { return }
        if let data { await self.ingest(data) }
        if let failure {
          await self.failAll(failure)
          return
        }
        if complete {
          await self.failAll(RemoteCameraError.notConnected)
          return
        }
        await self.receiveNext()
      }
    }
  }

  private func ingest(_ data: Data) {
    receiveBuffer.append(data)
    while let newline = receiveBuffer.firstIndex(of: 0x0A) {
      let line = receiveBuffer.prefix(upTo: newline)
      receiveBuffer.removeSubrange(...newline)
      guard !line.isEmpty,
        let response = try? JSONDecoder().decode(RemoteControlResponse.self, from: Data(line)),
        let id = response.id
      else { continue }
      pending.removeValue(forKey: id)?.resume(returning: response)
    }
  }

  private func failAll(_ error: Error) {
    let continuations = Array(pending.values)
    pending.removeAll()
    continuations.forEach { $0.resume(throwing: error) }
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
  }
}

actor RemoteVideoTransferService {
  private func stagingDirectory() throws -> URL {
    let support = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let directory = support.appendingPathComponent("PercheProgression/RemoteTransfers", isDirectory: true)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    return directory
  }

  func transfer(manifest: RemoteRecordingManifest, endpoint: RemoteCameraEndpoint, token: String) async throws -> ImportedVideoAsset {
    let safeID = manifest.recordingID.replacingOccurrences(of: "/", with: "_")
    let partial = try stagingDirectory().appendingPathComponent("\(safeID).partial")
    let existingSize = (try? partial.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
    if existingSize > manifest.sizeBytes { try? FileManager.default.removeItem(at: partial) }
    var offset = min(existingSize, manifest.sizeBytes)

    if offset < manifest.sizeBytes {
      let host = endpoint.host.hasSuffix(".") ? String(endpoint.host.dropLast()) : endpoint.host
      var components = URLComponents()
      components.scheme = "http"
      components.host = host
      components.port = endpoint.transferPort
      components.path = manifest.transferPath.hasPrefix("/") ? manifest.transferPath : "/\(manifest.transferPath)"
      guard let url = components.url else { throw RemoteCameraError.invalidTransferResponse }
      var request = URLRequest(url: url)
      request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
      if offset > 0 { request.setValue("bytes=\(offset)-", forHTTPHeaderField: "Range") }
      let (downloadURL, response) = try await URLSession.shared.download(for: request)
      guard let http = response as? HTTPURLResponse else { throw RemoteCameraError.invalidTransferResponse }
      if offset > 0, http.statusCode == 200 {
        try? FileManager.default.removeItem(at: partial)
        offset = 0
      } else if ![200, 206].contains(http.statusCode) {
        throw RemoteCameraError.invalidTransferResponse
      }
      try appendFile(downloadURL, to: partial, truncate: offset == 0)
    }

    let actualSize = (try? partial.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
    guard actualSize == manifest.sizeBytes else {
      throw RemoteCameraError.incompleteTransfer(expected: manifest.sizeBytes, actual: actualSize)
    }
    guard try sha256Streaming(partial).caseInsensitiveCompare(manifest.sha256) == .orderedSame else {
      throw RemoteCameraError.checksumMismatch
    }

    let imported = try await VideoAssetStore.shared.importVideo(from: partial)
    guard imported.sha256?.caseInsensitiveCompare(manifest.sha256) == .orderedSame else {
      try? await VideoAssetStore.shared.removeVideo(storageKey: imported.storageKey)
      throw RemoteCameraError.checksumMismatch
    }
    try? FileManager.default.removeItem(at: partial)
    return imported
  }

  private func appendFile(_ source: URL, to destination: URL, truncate: Bool) throws {
    if truncate || !FileManager.default.fileExists(atPath: destination.path) {
      if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
      FileManager.default.createFile(atPath: destination.path, contents: nil)
    }
    let input = try FileHandle(forReadingFrom: source)
    let output = try FileHandle(forWritingTo: destination)
    defer { try? input.close(); try? output.close() }
    try output.seekToEnd()
    while true {
      let data = try input.read(upToCount: 1_048_576) ?? Data()
      if data.isEmpty { break }
      try output.write(contentsOf: data)
    }
  }

  private func sha256Streaming(_ url: URL) throws -> String {
    let handle = try FileHandle(forReadingFrom: url)
    defer { try? handle.close() }
    var hasher = SHA256()
    while true {
      let data = try handle.read(upToCount: 1_048_576) ?? Data()
      if data.isEmpty { break }
      hasher.update(data: data)
    }
    return hasher.finalize().map { String(format: "%02x", $0) }.joined()
  }
}

@MainActor
final class PixelRemoteCameraController: ObservableObject {
  @Published private(set) var state: RemoteCameraState = .disconnected
  @Published private(set) var configurations: [RemoteCameraConfiguration] = []
  @Published var selectedConfigurationID: String?
  @Published var stabilizationEnabled = false
  @Published var audioEnabled = true
  @Published private(set) var statusMessage = ""
  @Published private(set) var recordingStartedAt: Date?
  @Published private(set) var pendingManifest: RemoteRecordingManifest?

  let discovery = BonjourCameraDiscovery()
  private let control = PixelControlTransport()
  private let transfer = RemoteVideoTransferService()
  private var endpoint: RemoteCameraEndpoint?
  private var token: String?
  private let clientID = UUID().uuidString

  func startDiscovery() { discovery.start() }
  func stopDiscovery() { discovery.stop() }

  func pair(endpoint: RemoteCameraEndpoint, code: String) async {
    state = .connecting
    statusMessage = "Connexion à \(endpoint.name)…"
    do {
      try await control.connect(to: endpoint)
      let response = try await control.request(RemoteControlRequest(type: "pair", pairingCode: code, clientID: clientID))
      guard response.ok, let token = response.token else { throw RemoteCameraError.rejected(response.message ?? "Appairage refusé.") }
      self.endpoint = endpoint
      self.token = token
      state = response.state ?? .ready
      statusMessage = "Pixel appairé · \(endpoint.name)"
      await refreshStatus()
    } catch {
      state = .error
      statusMessage = error.localizedDescription
    }
  }

  func refreshStatus() async {
    guard let token else { return }
    do {
      let response = try await control.request(RemoteControlRequest(type: "status", token: token))
      guard response.ok else { throw RemoteCameraError.rejected(response.message ?? "État distant indisponible.") }
      if let configs = response.configs {
        configurations = configs
        if selectedConfigurationID == nil { selectedConfigurationID = configs.first?.id }
      }
      if let manifest = response.manifest { pendingManifest = manifest }
      state = response.state ?? state
    } catch {
      state = .disconnected
      statusMessage = "Connexion perdue. L’enregistrement finalisé reste conservé sur le Pixel."
    }
  }

  func startRecording() async {
    guard let token else { state = .error; statusMessage = RemoteCameraError.notPaired.localizedDescription; return }
    let selectedConfig = configurations.first { $0.id == selectedConfigurationID }
    let config: RemoteCameraConfiguration?
    if var updatedConfig = selectedConfig {
      let supportsStabilization = updatedConfig.stabilizationSupported
      updatedConfig.stabilizationEnabled = supportsStabilization && stabilizationEnabled
      updatedConfig.audioEnabled = audioEnabled
      config = updatedConfig
    } else {
      config = nil
    }
    do {
      let response = try await control.request(RemoteControlRequest(type: "recordStart", token: token, config: config))
      guard response.ok, response.state == .recording else { throw RemoteCameraError.rejected(response.message ?? "Le Pixel n’a pas confirmé le démarrage.") }
      state = .recording
      recordingStartedAt = .now
      pendingManifest = nil
      statusMessage = "Enregistrement confirmé par le Pixel."
    } catch {
      state = .error
      statusMessage = error.localizedDescription
    }
  }

  func stopRecording() async {
    guard let token else { state = .error; statusMessage = RemoteCameraError.notPaired.localizedDescription; return }
    state = .stopping
    do {
      let response = try await control.request(RemoteControlRequest(type: "recordStop", token: token))
      guard response.ok, let manifest = response.manifest else { throw RemoteCameraError.rejected(response.message ?? "La finalisation Pixel n’a pas été confirmée.") }
      pendingManifest = manifest
      state = .ready
      recordingStartedAt = nil
      statusMessage = "Vidéo finalisée sur le Pixel · prête à transférer."
    } catch {
      state = .disconnected
      statusMessage = "STOP non confirmé. Vérifiez le Pixel : il conserve tout fichier finalisé localement."
    }
  }

  func importPending(existingRemoteIDs: Set<String>) async throws -> (ImportedVideoAsset, RemoteRecordingManifest, RemoteCameraEndpoint) {
    guard let manifest = pendingManifest, let endpoint, let token else { throw RemoteCameraError.notConnected }
    guard !existingRemoteIDs.contains(manifest.recordingID) else { throw RemoteCameraError.duplicateRecording }
    state = .transferring
    do {
      let asset = try await transfer.transfer(manifest: manifest, endpoint: endpoint, token: token)
      state = .imported
      statusMessage = "Transfert vérifié par SHA-256."
      return (asset, manifest, endpoint)
    } catch {
      state = .error
      statusMessage = error.localizedDescription
      throw error
    }
  }
}
