import AVFoundation
import CoreGraphics
import Foundation
import Vision

/// Dynamic-camera front-end for the authoritative `PerspectiveAwareSpeedEngine`.
/// Vision identifies the athlete and a ground-related foot point; dynamic homographies convert
/// that image point to the runway plane. No pixels-per-metre fallback is permitted.
actor VideoMotionAnalysisService {
  enum MotionError: LocalizedError {
    case invalidCalibration
    case invalidSegment
    case noVideoTrack
    case insufficientGroundPoints
    case dynamicPerspectiveLost

    var errorDescription: String? {
      switch self {
      case .invalidCalibration: "La calibration dynamique n’est pas assez fiable. Recalibrez la piste avant de mesurer la vitesse."
      case .invalidSegment: "La zone de mesure doit durer au moins 0,40 seconde."
      case .noVideoTrack: "Aucune piste vidéo exploitable n’a été trouvée."
      case .insufficientGroundPoints: "La position au sol de l’athlète n’est pas identifiable sur assez d’images. Corrigez les points ou choisissez une séquence plus lisible."
      case .dynamicPerspectiveLost: "La perspective dynamique a été perdue. Aucune vitesse métrique n’est enregistrée."
      }
    }
  }

  func analyze(
    videoURL: URL,
    seed: NormalizedPoint,
    dynamicCalibration: DynamicCalibrationTrack,
    startTime: Double,
    endTime: Double,
    requestedFrameRate: Double,
    videoSize suppliedVideoSize: CGSize
  ) async throws -> MotionAnalysisResult {
    guard endTime - startTime >= 0.40 else { throw MotionError.invalidSegment }
    guard dynamicCalibration.isUsable else { throw MotionError.invalidCalibration }

    let asset = AVURLAsset(url: videoURL)
    guard try await !asset.loadTracks(withMediaType: .video).isEmpty else { throw MotionError.noVideoTrack }
    let timeline = try await VideoFrameTimelineService().sampledTimestamps(
      for: videoURL, startTime: startTime, endTime: endTime,
      maximumSamples: VideoAnalysisConfiguration.Sampling.maximumDynamicMotionFrames
    )
    guard timeline.count >= 5 else { throw MotionError.insufficientGroundPoints }

    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = .zero
    generator.requestedTimeToleranceAfter = .zero
    generator.maximumSize = CGSize(width: 1920, height: 1920)

    var observations: [PerspectiveAwareSpeedEngine.Observation] = []
    observations.reserveCapacity(timeline.count)
    var previousPersonCenter: NormalizedPoint? = seed
    var previousCalibrationSample: HomographySample?
    var missingCalibrationRunStart: Double?
    var longestCalibrationGap = 0.0

    for seconds in timeline {
      try Task.checkCancellation()
      guard let calibration = dynamicCalibration.validatedSample(nearest: seconds) else {
        if missingCalibrationRunStart == nil { missingCalibrationRunStart = seconds }
        continue
      }
      if let gapStart = missingCalibrationRunStart {
        longestCalibrationGap = max(longestCalibrationGap, seconds - gapStart)
        missingCalibrationRunStart = nil
      }

      let image: CGImage
      do { image = try await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600)).image }
      catch { continue }

      let request = VNDetectHumanBodyPoseRequest()
      let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
      do { try handler.perform([request]) } catch { continue }
      let candidates = (request.results ?? []).compactMap { poseCandidate(from: $0) }
      guard let candidate = selectAthlete(candidates, previousCenter: previousPersonCenter) else { continue }
      previousPersonCenter = candidate.boundingBox.center
      guard let ground = groundPoint(from: candidate) else { continue }
      guard let metric = calibration.imageToRunway.projectMetric(ground.point) else { continue }

      let calibrationQuality = calibrationQuality(sample: calibration)
      let continuity = homographyContinuity(previous: previousCalibrationSample, current: calibration)
      previousCalibrationSample = calibration
      observations.append(
        PerspectiveAwareSpeedEngine.Observation(
          timeSeconds: seconds,
          imagePoint: ground.point,
          runwayPoint: metric,
          trackingConfidence: candidate.confidence,
          groundPointConfidence: ground.confidence,
          calibrationQuality: calibrationQuality,
          anchorCount: calibration.trackedPointCount,
          anchorStability: min(max(calibration.inlierRatio * calibration.confidence, 0), 1),
          homographyContinuity: continuity,
          groundPointMethod: ground.method
        )
      )
    }

    if let gapStart = missingCalibrationRunStart, let last = timeline.last {
      longestCalibrationGap = max(longestCalibrationGap, last - gapStart)
    }
    guard observations.count >= 5 else { throw MotionError.insufficientGroundPoints }
    if longestCalibrationGap > 0.65 { throw MotionError.dynamicPerspectiveLost }

    let engineResult = try PerspectiveAwareSpeedEngine().analyze(
      observations, expectedStartTime: startTime, expectedEndTime: endTime
    )
    var diagnostics = engineResult.quality.diagnostics
    if longestCalibrationGap > 0.15 {
      diagnostics.append(String(format: "Perspective dynamique perdue pendant %.1f s puis récupérée", longestCalibrationGap))
    }
    var quality = engineResult.quality
    quality.diagnostics = diagnostics

    let methodDescription: String = {
      let methods = Set(observations.map(\.groundPointMethod))
      if methods == [.supportAnkle] { return "appui cheville détecté" }
      if methods.contains(.personGroundEstimate) { return "appui cheville + estimation bas du sujet" }
      return "fusion des appuis de pieds"
    }()

    return MotionAnalysisResult(
      samples: engineResult.samples,
      startTime: engineResult.startTime,
      endTime: engineResult.endTime,
      calibration: VideoCalibration(distanceMeters: dynamicCalibration.initialGrid.zoneLengthMeters),
      trackingSeed: observations.first?.imagePoint ?? seed,
      representativeHorizontalSpeed: engineResult.meanLongitudinalSpeed,
      peakHorizontalSpeed: engineResult.peakLongitudinalSpeed,
      averageConfidence: quality.components.overall,
      modelVersion: PerspectiveAwareSpeedEngine.algorithmVersion,
      dynamicCalibration: dynamicCalibration,
      measurementMode: .dynamicRunway,
      referenceDescription: "Caméra mobile · homographies dynamiques · \(methodDescription) · PTS réels",
      speedQualityReport: quality,
      groundPointMethodRaw: quality.groundPointMethods.joined(separator: ","),
      timeBasisRaw: "presentation-timestamps"
    )
  }

  private func poseCandidate(from observation: VNHumanBodyPoseObservation) -> PoseCandidate? {
    let names: [(String, VNHumanBodyPoseObservation.JointName)] = [
      ("root", .root), ("leftShoulder", .leftShoulder), ("rightShoulder", .rightShoulder),
      ("leftHip", .leftHip), ("rightHip", .rightHip), ("leftKnee", .leftKnee),
      ("rightKnee", .rightKnee), ("leftAnkle", .leftAnkle), ("rightAnkle", .rightAnkle)
    ]
    let joints = names.compactMap { label, name -> PoseJoint? in
      guard let p = try? observation.recognizedPoint(name), p.confidence >= 0.22 else { return nil }
      return PoseJoint(id: label, point: NormalizedPoint(x: p.location.x, y: 1 - p.location.y).clamped(), confidence: Double(p.confidence))
    }
    guard joints.contains(where: { $0.id == "leftAnkle" || $0.id == "rightAnkle" }) || joints.count >= 5 else { return nil }
    let points = joints.map(\.point)
    guard let minX = points.map(\.x).min(), let maxX = points.map(\.x).max(),
          let minY = points.map(\.y).min(), let maxY = points.map(\.y).max() else { return nil }
    let box = NormalizedRect(x: minX - 0.02, y: minY - 0.02, width: maxX-minX+0.04, height: maxY-minY+0.04).clamped()
    let confidence = joints.map(\.confidence).reduce(0,+)/Double(joints.count)
    return PoseCandidate(joints: joints, boundingBox: box, confidence: confidence)
  }

  private func selectAthlete(_ candidates: [PoseCandidate], previousCenter: NormalizedPoint?) -> PoseCandidate? {
    guard let previousCenter else { return candidates.max(by: { $0.confidence < $1.confidence }) }
    return candidates.min { lhs, rhs in
      athleteDistance(lhs.boundingBox.center, previousCenter) - lhs.confidence * 0.08
        < athleteDistance(rhs.boundingBox.center, previousCenter) - rhs.confidence * 0.08
    }
  }

  private func athleteDistance(_ a: NormalizedPoint, _ b: NormalizedPoint) -> Double { hypot(a.x-b.x, a.y-b.y) }

  private func groundPoint(from candidate: PoseCandidate) -> (point: NormalizedPoint, confidence: Double, method: PerspectiveAwareSpeedEngine.GroundPointMethod)? {
    let left = candidate.joints.first(where: { $0.id == "leftAnkle" })
    let right = candidate.joints.first(where: { $0.id == "rightAnkle" })
    if let left, let right {
      // Similar image height generally means both feet are near the same ground plane; midpoint damps alternating-foot jitter.
      if abs(left.point.y - right.point.y) < 0.025 {
        return (NormalizedPoint(x: (left.point.x+right.point.x)/2, y: (left.point.y+right.point.y)/2),
                min(left.confidence,right.confidence), .ankleMidpoint)
      }
      let support = left.point.y > right.point.y ? left : right
      return (support.point, support.confidence, .supportAnkle)
    }
    if let ankle = left ?? right { return (ankle.point, ankle.confidence, .supportAnkle) }
    // Bounding-box bottom is an explicit low-confidence ground estimate, not a pelvis projection.
    let estimate = NormalizedPoint(x: candidate.boundingBox.midX, y: candidate.boundingBox.maxY).clamped()
    return (estimate, candidate.confidence * 0.45, .personGroundEstimate)
  }

  private func calibrationQuality(sample: HomographySample) -> Double {
    let errorScore = sample.estimatedErrorMeters.isFinite ? min(max(1 - sample.estimatedErrorMeters / 0.30, 0), 1) : 0.5
    let anchorScore = min(Double(sample.trackedPointCount) / 6.0, 1)
    return min(max(sample.confidence * 0.50 + sample.inlierRatio * 0.22 + errorScore * 0.18 + anchorScore * 0.10, 0), 1)
  }

  private func homographyContinuity(previous: HomographySample?, current: HomographySample) -> Double {
    guard let previous else { return 0.8 }
    let dt = max(current.timeSeconds - previous.timeSeconds, 1.0/240.0)
    let displacement = zip(previous.grid.imagePoints, current.grid.imagePoints)
      .map { hypot($0.0.x-$0.1.x, $0.0.y-$0.1.y) }.reduce(0,+)/4.0
    let rate = displacement / dt
    return min(max(1 - rate / 1.5, 0), 1)
  }
}
