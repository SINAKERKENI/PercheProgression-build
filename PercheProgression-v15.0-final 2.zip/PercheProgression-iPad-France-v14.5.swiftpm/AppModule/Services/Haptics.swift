import UIKit

@MainActor
enum Haptics {
  static func selection() {
    UISelectionFeedbackGenerator().selectionChanged()
  }

  static func impact(
    _ style: UIImpactFeedbackGenerator.FeedbackStyle = .medium, intensity: CGFloat = 1
  ) {
    let generator = UIImpactFeedbackGenerator(style: style)
    generator.prepare()
    generator.impactOccurred(intensity: intensity)
  }

  static func success() {
    UINotificationFeedbackGenerator().notificationOccurred(.success)
  }

  static func warning() {
    UINotificationFeedbackGenerator().notificationOccurred(.warning)
  }

  static func error() {
    UINotificationFeedbackGenerator().notificationOccurred(.error)
  }
}
