import AVFoundation
import CoreGraphics
import Foundation
import Vision

/// Mesure de type Kinovea/Tracker adaptée à l'iPad :
/// 1) une distance réelle connue fixe l'échelle ;
/// 2) des repères fixes du décor compensent le panoramique, la rotation et un zoom modéré ;
/// 3) le bassin est confirmé manuellement toutes les 0,1 s ;
/// 4) vitesse et accélération proviennent d'une régression polynomiale locale.
actor CalibratedManualMotionAnalysisService {
  enum AnalysisError: LocalizedError {
    case incompletePelvis
    case invalidSegment
    case invalidScale
    case insufficientBackgroundAnchors
    case noVideoTrack
    case frameExtractionFailed
    case backgroundTrackingLost
    case insufficientSamples

    var errorDescription: String? {
      switch self {
      case .incompletePelvis:
        "Confirmez chaque position du bassin avant le calcul final."
      case .invalidSegment:
        "La zone de mesure doit durer au moins 0,40 seconde."
      case .invalidScale:
        "Tracez une référence de distance visible et indiquez sa longueur réelle."
      case .insufficientBackgroundAnchors:
        "Placez au moins deux repères fixes du décor ; trois ou quatre sont recommandés."
      case .noVideoTrack:
        "Aucune piste vidéo exploitable n'a été trouvée."
      case .frameExtractionFailed:
        "Les images nécessaires à la mesure n'ont pas pu être extraites."
      case .backgroundTrackingLost:
        "Le suivi du décor a été perdu. Choisissez des détails fixes plus contrastés."
      case .insufficientSamples:
        "La séquence ne contient pas assez de mesures pour calculer la cinématique."
      }
    }
  }

  private struct PixelPoint {
    var x: Double
    var y: Double

    static func + (lhs: PixelPoint, rhs: PixelPoint) -> PixelPoint {
      PixelPoint(x: lhs.x + rhs.x, y: lhs.y + rhs.y)
    }

    static func - (lhs: PixelPoint, rhs: PixelPoint) -> PixelPoint {
      PixelPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
    }

    static func * (lhs: PixelPoint, rhs: Double) -> PixelPoint {
      PixelPoint(x: lhs.x * rhs, y: lhs.y * rhs)
    }

    var length: Double { hypot(x, y) }
  }

  private struct SimilarityTransform {
    var a: Double
    var b: Double
    var tx: Double
    var ty: Double
    var residualPixels: Double
    var inlierCount: Int

    static let identity = SimilarityTransform(
      a: 1,
      b: 0,
      tx: 0,
      ty: 0,
      residualPixels: 0,
      inlierCount: 0
    )

    func apply(_ point: PixelPoint) -> PixelPoint {
      PixelPoint(
        x: a * point.x - b * point.y + tx,
        y: b * point.x + a * point.y + ty
      )
    }
  }

  private struct TrackedAnchor {
    var observation: VNDetectedObjectObservation
    var referencePoint: PixelPoint
  }

  private struct StabilizedPosition {
    var time: Double
    var imagePoint: NormalizedPoint
    var xMeters: Double
    var yMeters: Double
    var confidence: Double
    var stabilizationConfidence: Double
  }

  func analyze(
    videoURL: URL,
    validation: PelvisValidationSession,
    calibration: VideoCalibration,
    backgroundAnchors: [NormalizedPoint],
    requestedFrameRate: Double,
    suppliedVideoSize: CGSize
  ) async throws -> MotionAnalysisResult {
    guard validation.isComplete else { throw AnalysisError.incompletePelvis }
    guard validation.endTime - validation.startTime >= 0.40 else {
      throw AnalysisError.invalidSegment
    }
    guard backgroundAnchors.count >= 2 else {
      throw AnalysisError.insufficientBackgroundAnchors
    }

    let asset = AVURLAsset(url: videoURL)
    let tracks = try await asset.loadTracks(withMediaType: .video)
    guard let track = tracks.first else { throw AnalysisError.noVideoTrack }

    let naturalSize = try await track.load(.naturalSize)
    let preferredTransform = try await track.load(.preferredTransform)
    let transformed = naturalSize.applying(preferredTransform)
    let assetSize = CGSize(width: abs(transformed.width), height: abs(transformed.height))
    let videoSize = suppliedVideoSize.width > 0 && suppliedVideoSize.height > 0
      ? suppliedVideoSize : assetSize
    let width = max(Double(videoSize.width), 1)
    let height = max(Double(videoSize.height), 1)

    let calibrationStart = pixelPoint(calibration.start, width: width, height: height)
    let calibrationEnd = pixelPoint(calibration.end, width: width, height: height)
    let calibrationVector = calibrationEnd - calibrationStart
    let calibrationPixels = calibrationVector.length
    guard calibration.distanceMeters > 0,
      calibration.distanceMeters <= 100,
      calibrationPixels >= 20
    else {
      throw AnalysisError.invalidScale
    }

    let metersPerPixel = calibration.distanceMeters / calibrationPixels
    let axis = PixelPoint(
      x: calibrationVector.x / calibrationPixels,
      y: calibrationVector.y / calibrationPixels
    )
    let normal = PixelPoint(x: -axis.y, y: axis.x)

    let timelineService = VideoFrameTimelineService()
    let frameTimes = try await timelineService.sampledTimestamps(
      for: videoURL,
      startTime: validation.startTime,
      endTime: validation.endTime,
      maximumSamples: VideoAnalysisConfiguration.Sampling.maximumStabilizationFrames
    )
    guard frameTimes.count >= 5 else { throw AnalysisError.insufficientSamples }
    let analysisRate = VideoFrameTimelineService.effectiveRate(for: frameTimes)
      ?? max(min(requestedFrameRate, 60), 20)
    let frameStep = 1.0 / max(analysisRate, 1)

    let checkpoints = validation.checkpoints.sorted { $0.timeSeconds < $1.timeSeconds }
    guard checkpoints.count >= 5 else { throw AnalysisError.insufficientSamples }

    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = CMTime(seconds: frameStep * 0.45, preferredTimescale: 600)
    generator.requestedTimeToleranceAfter = CMTime(seconds: frameStep * 0.45, preferredTimescale: 600)
    generator.maximumSize = CGSize(width: 1600, height: 1600)

    do {
      _ = try await generator.image(
        at: CMTime(seconds: frameTimes[0], preferredTimescale: 600)
      ).image
    } catch {
      throw AnalysisError.frameExtractionFailed
    }

    let referencePoints = backgroundAnchors.map {
      pixelPoint($0, width: width, height: height)
    }
    let anchorSpread = maximumPairDistance(referencePoints)
    guard anchorSpread >= hypot(width, height) * 0.12 else {
      throw AnalysisError.insufficientBackgroundAnchors
    }
    var trackedAnchors = zip(backgroundAnchors, referencePoints).map {
      TrackedAnchor(observation: makeObservation($0.0), referencePoint: $0.1)
    }
    let sequenceHandler = VNSequenceRequestHandler()
    var latestTransform = SimilarityTransform.identity
    var latestConfidence = 1.0
    var nextCheckpointIndex = 0
    var consecutiveTrackingFailures = 0
    let maximumTrackingFailures = max(Int((0.45 / frameStep).rounded(.up)), 5)
    var positions: [StabilizedPosition] = []
    positions.reserveCapacity(checkpoints.count)

    // Le premier échantillon est déjà dans le repère de référence.
    appendCheckpoint(
      checkpoints[0],
      transform: .identity,
      stabilizationConfidence: 1,
      calibrationStart: calibrationStart,
      axis: axis,
      normal: normal,
      metersPerPixel: metersPerPixel,
      width: width,
      height: height,
      into: &positions
    )
    nextCheckpointIndex = 1

    var processedFrames = 1

    for time in frameTimes.dropFirst() where nextCheckpointIndex < checkpoints.count {
      try Task.checkCancellation()
      let image: CGImage
      do {
        image = try await generator.image(
          at: CMTime(seconds: time, preferredTimescale: 600)
        ).image
      } catch {
        processedFrames += 1
        continue
      }

      var requests: [VNTrackObjectRequest] = []
      requests.reserveCapacity(trackedAnchors.count)
      for anchor in trackedAnchors {
        let request = VNTrackObjectRequest(detectedObjectObservation: anchor.observation)
        request.trackingLevel = .accurate
        requests.append(request)
      }

      do {
        try sequenceHandler.perform(requests, on: image, orientation: .up)
      } catch {
        if processedFrames < 4 { throw AnalysisError.backgroundTrackingLost }
        latestConfidence *= 0.85
        processedFrames += 1
        continue
      }

      var currentPoints: [PixelPoint] = []
      var currentReference: [PixelPoint] = []
      var nextTrackedAnchors: [TrackedAnchor] = []
      var visionConfidences: [Double] = []

      for (index, request) in requests.enumerated() {
        guard trackedAnchors.indices.contains(index),
          let result = request.results?.first as? VNDetectedObjectObservation,
          result.confidence >= Float(VideoAnalysisConfiguration.Tracking.backgroundMinimumConfidence)
        else { continue }
        let normalized = uiCenter(result)
        currentPoints.append(pixelPoint(normalized, width: width, height: height))
        currentReference.append(trackedAnchors[index].referencePoint)
        nextTrackedAnchors.append(
          TrackedAnchor(
            observation: result,
            referencePoint: trackedAnchors[index].referencePoint
          )
        )
        visionConfidences.append(Double(result.confidence))
      }

      if currentPoints.count >= 2,
        let fitted = fitRobustSimilarity(source: currentPoints, destination: currentReference)
      {
        latestTransform = fitted
        let meanVision = visionConfidences.reduce(0, +) / Double(max(visionConfidences.count, 1))
        let inlierRatio = Double(fitted.inlierCount) / Double(max(currentPoints.count, 1))
        let residualScore = exp(-fitted.residualPixels / 8.0)
        let spreadScore = anchorSpreadQuality(currentReference, width: width, height: height)
        latestConfidence = min(
          max(meanVision * 0.38 + inlierRatio * 0.27 + residualScore * 0.22 + spreadScore * 0.13, 0),
          1
        )
        trackedAnchors = nextTrackedAnchors
        consecutiveTrackingFailures = 0
      } else {
        consecutiveTrackingFailures += 1
        latestConfidence *= 0.88
        if consecutiveTrackingFailures > maximumTrackingFailures {
          throw AnalysisError.backgroundTrackingLost
        }
      }

      while nextCheckpointIndex < checkpoints.count,
        checkpoints[nextCheckpointIndex].timeSeconds <= time + frameStep * 0.55
      {
        appendCheckpoint(
          checkpoints[nextCheckpointIndex],
          transform: latestTransform,
          stabilizationConfidence: latestConfidence,
          calibrationStart: calibrationStart,
          axis: axis,
          normal: normal,
          metersPerPixel: metersPerPixel,
          width: width,
          height: height,
          into: &positions
        )
        nextCheckpointIndex += 1
      }

      processedFrames += 1
    }

    // Si la dernière image de validation tombe juste après la dernière image décodée,
    // on conserve la dernière transformation avec une confiance légèrement diminuée.
    while nextCheckpointIndex < checkpoints.count {
      latestConfidence *= 0.92
      appendCheckpoint(
        checkpoints[nextCheckpointIndex],
        transform: latestTransform,
        stabilizationConfidence: latestConfidence,
        calibrationStart: calibrationStart,
        axis: axis,
        normal: normal,
        metersPerPixel: metersPerPixel,
        width: width,
        height: height,
        into: &positions
      )
      nextCheckpointIndex += 1
    }

    guard positions.count >= 5 else { throw AnalysisError.insufficientSamples }
    let samples = calculateKinematics(positions)
    guard samples.count >= 5 else { throw AnalysisError.insufficientSamples }

    let elapsed = max((positions.last?.time ?? 0) - (positions.first?.time ?? 0), 0.001)
    let displacement = abs((positions.last?.xMeters ?? 0) - (positions.first?.xMeters ?? 0))
    let averageSpeed = displacement / elapsed
    let validSpeeds = samples.map { abs($0.horizontalVelocity) }
      .filter { $0.isFinite && $0 >= 0 && $0 < 20 }
      .sorted()
    let peakSpeed = percentile(validSpeeds, fraction: 0.95)
    let averageConfidence = samples.map(\.confidence).reduce(0, +) / Double(samples.count)

    var updatedValidation = validation
    updatedValidation.modelVersion = "Bassin manuel 10 Hz · distance réelle · décor stabilisé v3"

    return MotionAnalysisResult(
      samples: samples,
      startTime: validation.startTime,
      endTime: validation.endTime,
      calibration: calibration,
      trackingSeed: checkpoints.first?.effectivePoint ?? .init(x: 0.5, y: 0.5),
      representativeHorizontalSpeed: averageSpeed,
      peakHorizontalSpeed: peakSpeed,
      averageConfidence: averageConfidence,
      modelVersion: "Mesure physique étalonnée + stabilisation du décor + polynôme local v3",
      dynamicCalibration: nil,
      measurementMode: .calibratedManual,
      referenceDescription: String(
        format: "Distance réelle %.2f m · %d repères fixes · bassin confirmé à 10 Hz · analyse %.1f fps (PTS)",
        calibration.distanceMeters,
        backgroundAnchors.count,
        analysisRate
      ),
      pelvisValidation: updatedValidation,
      backgroundReferencePoints: backgroundAnchors,
      calibrationReferenceTime: validation.startTime
    )
  }

  private func appendCheckpoint(
    _ checkpoint: PelvisCheckpoint,
    transform: SimilarityTransform,
    stabilizationConfidence: Double,
    calibrationStart: PixelPoint,
    axis: PixelPoint,
    normal: PixelPoint,
    metersPerPixel: Double,
    width: Double,
    height: Double,
    into positions: inout [StabilizedPosition]
  ) {
    let currentPixel = pixelPoint(checkpoint.effectivePoint, width: width, height: height)
    let stabilized = transform.apply(currentPixel)
    let relative = stabilized - calibrationStart
    let xMeters = (relative.x * axis.x + relative.y * axis.y) * metersPerPixel
    let yMeters = (relative.x * normal.x + relative.y * normal.y) * metersPerPixel
    let manualConfidence = checkpoint.state == .adjusted ? 0.99 : 0.97
    let confidence = min(max(manualConfidence * 0.62 + stabilizationConfidence * 0.38, 0), 0.995)

    positions.append(
      StabilizedPosition(
        time: checkpoint.timeSeconds,
        imagePoint: checkpoint.effectivePoint,
        xMeters: xMeters,
        yMeters: -yMeters,
        confidence: confidence,
        stabilizationConfidence: stabilizationConfidence
      )
    )
  }

  private func calculateKinematics(_ positions: [StabilizedPosition]) -> [MotionSample] {
    let firstX = positions.first?.xMeters ?? 0
    let lastX = positions.last?.xMeters ?? 0
    let direction = lastX >= firstX ? 1.0 : -1.0

    return positions.indices.map { index in
      let xFit = localQuadraticFit(
        positions: positions,
        index: index,
        radius: 3,
        value: { direction * $0.xMeters }
      )
      let yFit = localQuadraticFit(
        positions: positions,
        index: index,
        radius: 3,
        value: { $0.yMeters }
      )
      let ax = xFit.acceleration
      let ay = yFit.acceleration
      return MotionSample(
        timeSeconds: positions[index].time,
        point: positions[index].imagePoint,
        confidence: positions[index].confidence,
        horizontalVelocity: xFit.velocity,
        verticalVelocity: yFit.velocity,
        acceleration: hypot(ax, ay),
        runwayX: direction * positions[index].xMeters,
        runwayY: positions[index].yMeters,
        calibrationConfidence: positions[index].stabilizationConfidence,
        verticalIsEstimated: true,
        horizontalAcceleration: ax,
        verticalAcceleration: ay
      )
    }
  }

  private func localQuadraticFit(
    positions: [StabilizedPosition],
    index: Int,
    radius: Int,
    value: (StabilizedPosition) -> Double
  ) -> (velocity: Double, acceleration: Double) {
    let lower = max(index - radius, 0)
    let upper = min(index + radius, positions.count - 1)
    let centerTime = positions[index].time
    let window = Array(positions[lower...upper])
    guard window.count >= 3 else { return (0, 0) }

    var matrix = Array(repeating: Array(repeating: 0.0, count: 3), count: 3)
    var vector = Array(repeating: 0.0, count: 3)

    for sample in window {
      let t = sample.time - centerTime
      let basis = [1.0, t, t * t]
      let weight = max(sample.confidence, 0.35)
      let measured = value(sample)
      for row in 0..<3 {
        vector[row] += weight * basis[row] * measured
        for column in 0..<3 {
          matrix[row][column] += weight * basis[row] * basis[column]
        }
      }
    }

    guard let coefficients = solve3x3(matrix, vector) else { return (0, 0) }
    return (coefficients[1], 2 * coefficients[2])
  }

  private func solve3x3(_ inputMatrix: [[Double]], _ inputVector: [Double]) -> [Double]? {
    var augmented = (0..<3).map { row in inputMatrix[row] + [inputVector[row]] }
    for column in 0..<3 {
      guard let pivot = (column..<3).max(by: {
        abs(augmented[$0][column]) < abs(augmented[$1][column])
      }), abs(augmented[pivot][column]) > 1e-12 else {
        return nil
      }
      if pivot != column { augmented.swapAt(pivot, column) }
      let divisor = augmented[column][column]
      for item in column..<4 { augmented[column][item] /= divisor }
      for row in 0..<3 where row != column {
        let factor = augmented[row][column]
        for item in column..<4 {
          augmented[row][item] -= factor * augmented[column][item]
        }
      }
    }
    return augmented.map { $0[3] }
  }

  private func fitRobustSimilarity(
    source: [PixelPoint],
    destination: [PixelPoint]
  ) -> SimilarityTransform? {
    guard source.count == destination.count, source.count >= 2 else { return nil }
    guard var fit = fitSimilarity(source: source, destination: destination) else { return nil }
    let residuals = zip(source, destination).map { pair in
      let projected = fit.apply(pair.0)
      return hypot(projected.x - pair.1.x, projected.y - pair.1.y)
    }
    let med = median(residuals)
    let mad = median(residuals.map { abs($0 - med) })
    let threshold = max(4.0, med + 3.5 * 1.4826 * mad)
    let indices = residuals.indices.filter { residuals[$0] <= threshold }
    if indices.count >= 2, indices.count < source.count {
      let inlierSource = indices.map { source[$0] }
      let inlierDestination = indices.map { destination[$0] }
      if let refined = fitSimilarity(source: inlierSource, destination: inlierDestination) {
        fit = refined
      }
    }
    fit.inlierCount = max(indices.count, 2)
    return fit
  }

  private func fitSimilarity(
    source: [PixelPoint],
    destination: [PixelPoint]
  ) -> SimilarityTransform? {
    guard source.count == destination.count, source.count >= 2 else { return nil }
    let count = Double(source.count)
    let sourceCentroid = PixelPoint(
      x: source.map(\.x).reduce(0, +) / count,
      y: source.map(\.y).reduce(0, +) / count
    )
    let destinationCentroid = PixelPoint(
      x: destination.map(\.x).reduce(0, +) / count,
      y: destination.map(\.y).reduce(0, +) / count
    )

    var numeratorA = 0.0
    var numeratorB = 0.0
    var denominator = 0.0
    for (sourcePoint, destinationPoint) in zip(source, destination) {
      let sx = sourcePoint.x - sourceCentroid.x
      let sy = sourcePoint.y - sourceCentroid.y
      let dx = destinationPoint.x - destinationCentroid.x
      let dy = destinationPoint.y - destinationCentroid.y
      numeratorA += sx * dx + sy * dy
      numeratorB += sx * dy - sy * dx
      denominator += sx * sx + sy * sy
    }
    guard denominator > 1e-8 else { return nil }
    let a = numeratorA / denominator
    let b = numeratorB / denominator
    let tx = destinationCentroid.x - a * sourceCentroid.x + b * sourceCentroid.y
    let ty = destinationCentroid.y - b * sourceCentroid.x - a * sourceCentroid.y
    var residuals: [Double] = []
    let transform = SimilarityTransform(a: a, b: b, tx: tx, ty: ty, residualPixels: 0, inlierCount: source.count)
    for (sourcePoint, destinationPoint) in zip(source, destination) {
      let projected = transform.apply(sourcePoint)
      residuals.append(hypot(projected.x - destinationPoint.x, projected.y - destinationPoint.y))
    }
    return SimilarityTransform(
      a: a,
      b: b,
      tx: tx,
      ty: ty,
      residualPixels: median(residuals),
      inlierCount: source.count
    )
  }

  private func makeObservation(_ point: NormalizedPoint) -> VNDetectedObjectObservation {
    let side = 0.055
    let x = min(max(point.x - side * 0.5, 0), 1 - side)
    let visionY = 1 - point.y
    let y = min(max(visionY - side * 0.5, 0), 1 - side)
    return VNDetectedObjectObservation(
      boundingBox: CGRect(x: x, y: y, width: side, height: side)
    )
  }

  private func uiCenter(_ observation: VNDetectedObjectObservation) -> NormalizedPoint {
    NormalizedPoint(
      x: observation.boundingBox.midX,
      y: 1 - observation.boundingBox.midY
    ).clamped()
  }

  private func pixelPoint(
    _ point: NormalizedPoint,
    width: Double,
    height: Double
  ) -> PixelPoint {
    PixelPoint(x: point.x * width, y: point.y * height)
  }


  private func maximumPairDistance(_ points: [PixelPoint]) -> Double {
    guard points.count >= 2 else { return 0 }
    var maximum = 0.0
    for first in points.indices {
      for second in points.indices where second > first {
        maximum = max(maximum, (points[first] - points[second]).length)
      }
    }
    return maximum
  }

  private func anchorSpreadQuality(
    _ points: [PixelPoint],
    width: Double,
    height: Double
  ) -> Double {
    guard points.count >= 2 else { return 0 }
    var maximumDistance = 0.0
    for first in points.indices {
      for second in points.indices where second > first {
        maximumDistance = max(maximumDistance, (points[first] - points[second]).length)
      }
    }
    let diagonal = max(hypot(width, height), 1)
    return min(max(maximumDistance / (diagonal * 0.45), 0.15), 1)
  }

  private func median(_ values: [Double]) -> Double {
    let sorted = values.filter(\.isFinite).sorted()
    guard !sorted.isEmpty else { return 0 }
    let middle = sorted.count / 2
    if sorted.count.isMultiple(of: 2) {
      return (sorted[middle - 1] + sorted[middle]) * 0.5
    }
    return sorted[middle]
  }

  private func percentile(_ sortedValues: [Double], fraction: Double) -> Double {
    guard !sortedValues.isEmpty else { return 0 }
    let clamped = min(max(fraction, 0), 1)
    let position = clamped * Double(sortedValues.count - 1)
    let lower = Int(position.rounded(.down))
    let upper = Int(position.rounded(.up))
    if lower == upper { return sortedValues[lower] }
    let weight = position - Double(lower)
    return sortedValues[lower] * (1 - weight) + sortedValues[upper] * weight
  }
}
