import Foundation

struct RemoteCameraEndpoint: Identifiable, Equatable, Sendable {
  var id: String { "\(host):\(controlPort)" }
  let name: String
  let host: String
  let controlPort: Int
  let transferPort: Int
  let deviceID: String
}



enum BonjourDiscoveryEvent: Sendable {
  case resolved(RemoteCameraEndpoint)
  case removed(name: String)
}

struct BonjourEndpointReducer: Sendable {
  static func apply(_ event: BonjourDiscoveryEvent, to endpoints: inout [RemoteCameraEndpoint]) {
    switch event {
    case .resolved(let endpoint):
      endpoints.removeAll { $0.deviceID == endpoint.deviceID || $0.name == endpoint.name }
      endpoints.append(endpoint)
      endpoints.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    case .removed(let name):
      endpoints.removeAll { $0.name == name }
    }
  }
}

/// Small value-type gate used inside `PixelControlTransport`'s actor isolation.
/// It makes terminal connection callbacks idempotent: only the first event for
/// the current attempt can claim completion; duplicates and stale callbacks lose.
struct RemoteConnectionAttemptGate: Sendable {
  private(set) var activeID: UUID?

  mutating func begin(_ id: UUID) {
    activeID = id
  }

  mutating func claim(_ id: UUID) -> Bool {
    guard activeID == id else { return false }
    activeID = nil
    return true
  }

  mutating func clear() {
    activeID = nil
  }
}

enum RemoteCameraState: String, Codable, Sendable {
  case disconnected, connecting, ready, recording, stopping, transferring, imported, error

  var title: String {
    switch self {
    case .disconnected: "Déconnecté"
    case .connecting: "Connexion…"
    case .ready: "Prêt"
    case .recording: "Enregistrement"
    case .stopping: "Finalisation…"
    case .transferring: "Transfert…"
    case .imported: "Importé"
    case .error: "Erreur"
    }
  }
}

struct RemoteCameraConfiguration: Codable, Identifiable, Hashable, Sendable {
  let id: String
  let lensLabel: String
  let width: Int
  let height: Int
  let fps: Int
  let stabilizationSupported: Bool
  var stabilizationEnabled: Bool
  var audioEnabled: Bool

  var displayName: String { "\(lensLabel) · \(width)×\(height) · \(fps) i/s" }
}

struct RemoteRecordingManifest: Codable, Equatable, Sendable {
  let recordingID: String
  let filename: String
  let sizeBytes: Int64
  let sha256: String
  let createdAtISO8601: String
  let durationSeconds: Double
  let width: Int
  let height: Int
  let nominalFPS: Double
  let lensLabel: String
  let orientation: String
  let transferPath: String

  var createdAt: Date? { ISO8601DateFormatter().date(from: createdAtISO8601) }
}

struct RemoteControlRequest: Codable, Sendable {
  let id: UUID
  let type: String
  let token: String?
  let pairingCode: String?
  let clientID: String?
  let config: RemoteCameraConfiguration?

  init(type: String, token: String? = nil, pairingCode: String? = nil, clientID: String? = nil, config: RemoteCameraConfiguration? = nil) {
    self.id = UUID()
    self.type = type
    self.token = token
    self.pairingCode = pairingCode
    self.clientID = clientID
    self.config = config
  }
}

struct RemoteControlResponse: Codable, Sendable {
  let id: UUID?
  let type: String
  let ok: Bool
  let token: String?
  let state: RemoteCameraState?
  let message: String?
  let configs: [RemoteCameraConfiguration]?
  let manifest: RemoteRecordingManifest?
  let recordingStartedAtMonotonicNanos: Int64?
}

enum RemoteCameraError: LocalizedError, Sendable {
  case notPaired
  case notConnected
  case invalidResponse
  case rejected(String)
  case checksumMismatch
  case invalidTransferResponse
  case incompleteTransfer(expected: Int64, actual: Int64)
  case duplicateRecording

  var errorDescription: String? {
    switch self {
    case .notPaired: "La caméra distante doit être appairée avant cette action."
    case .notConnected: "La caméra Pixel n’est pas connectée."
    case .invalidResponse: "La réponse de la caméra distante est invalide."
    case .rejected(let message): message
    case .checksumMismatch: "Le contrôle SHA-256 du fichier transféré a échoué. La vidéo corrompue n’a pas été importée."
    case .invalidTransferResponse: "Le serveur de transfert a renvoyé une réponse inattendue."
    case .incompleteTransfer(let expected, let actual): "Transfert incomplet (\(actual) octets reçus sur \(expected))."
    case .duplicateRecording: "Cet enregistrement distant a déjà été importé."
    }
  }
}
