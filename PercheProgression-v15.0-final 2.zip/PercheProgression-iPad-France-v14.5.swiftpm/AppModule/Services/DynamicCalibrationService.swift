import AVFoundation
import CoreGraphics
import Foundation
import ImageIO
import Vision

actor DynamicCalibrationService {
  enum CalibrationError: LocalizedError {
    case invalidGrid
    case invalidSegment
    case noVideoTrack
    case frameExtractionFailed
    case insufficientTracking
    case insufficientSamples

    var errorDescription: String? {
      switch self {
      case .invalidGrid:
        "La grille de piste est invalide. Alignez les quatre poignées sur les bords de la zone d’analyse."
      case .invalidSegment:
        "La zone de calibration dynamique doit durer au moins 0,20 seconde."
      case .noVideoTrack:
        "Aucune piste vidéo exploitable n’a été trouvée."
      case .frameExtractionFailed:
        "Les images nécessaires à la calibration n’ont pas pu être extraites."
      case .insufficientTracking:
        "Le mouvement de caméra est trop important ou la piste manque de texture. Ajoutez une correction manuelle."
      case .insufficientSamples:
        "Pas assez d’images vidéo réelles dans l’intervalle pour calibrer la séquence."
      }
    }
  }

  private struct AnchorSet {
    var observations: [VNDetectedObjectObservation]
    var metricPoints: [MetricRunwayPoint]
  }

  private struct TrackingResult {
    var observations: [VNDetectedObjectObservation]
    var imagePoints: [NormalizedPoint]
    var confidences: [Double]
    var validIndices: [Int]
  }

  private let detector = RunwaySceneDetectionService()

  func analyze(
    videoURL: URL,
    initialGrid: RunwayGridCalibration,
    manualKeyframes: [CalibrationKeyframe],
    startTime: Double,
    endTime: Double,
    requestedFrameRate: Double
  ) async throws -> DynamicCalibrationTrack {
    guard initialGrid.isGeometricallyUsable else { throw CalibrationError.invalidGrid }
    guard endTime - startTime >= 0.20 else { throw CalibrationError.invalidSegment }

    let asset = AVURLAsset(url: videoURL)
    let tracks = try await asset.loadTracks(withMediaType: .video)
    guard !tracks.isEmpty else { throw CalibrationError.noVideoTrack }
    let timelineService = VideoFrameTimelineService()
    let frameTimes = try await timelineService.sampledTimestamps(
      for: videoURL,
      startTime: startTime,
      endTime: endTime,
      maximumSamples: VideoAnalysisConfiguration.Sampling.maximumCalibrationFrames
    )
    guard frameTimes.count >= 6 else { throw CalibrationError.insufficientSamples }
    let analysisRate = VideoFrameTimelineService.effectiveRate(for: frameTimes)
      ?? max(min(requestedFrameRate, 60), 24)
    let temporalStep = 1.0 / max(analysisRate, 1)

    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = .zero
    generator.requestedTimeToleranceAfter = .zero
    generator.maximumSize = CGSize(width: 1280, height: 1280)

    let corrections = manualKeyframes.sorted { $0.timeSeconds < $1.timeSeconds }
    var activeGrid = corrections.last(where: { $0.timeSeconds <= startTime + temporalStep * 0.5 })?.grid ?? initialGrid
    var anchorSet = makeAnchorSet(for: activeGrid)
    let sequenceHandler = VNSequenceRequestHandler()
    var samples: [HomographySample] = []
    var keyframes = corrections
    var lastGoodGrid = activeGrid
    var lastGoodTransform = try HomographyMath.imageToRunway(for: activeGrid)
    var lowConfidenceRun = 0

    for (index, seconds) in frameTimes.enumerated() {
      try Task.checkCancellation()
      let time = CMTime(seconds: seconds, preferredTimescale: 600)
      let image: CGImage
      do {
        image = try await generator.image(at: time).image
      } catch {
        if index == 0 { throw CalibrationError.frameExtractionFailed }
        continue
      }

      var source: CalibrationSource = index == 0 ? .userCorrection : .featureTracking
      var transform = lastGoodTransform
      var trackedPointCount = anchorSet.observations.count
      var inlierRatio = 1.0
      var meanTrackingConfidence = index == 0 ? 1.0 : 0.0
      var fitErrorMeters = 0.0

      if let correction = nearestCorrection(
        to: seconds,
        corrections: corrections,
        tolerance: temporalStep * 0.55
      ) {
        activeGrid = correction.grid
        anchorSet = makeAnchorSet(for: activeGrid)
        transform = correction.imageToRunway
        lastGoodGrid = activeGrid
        lastGoodTransform = transform
        source = .userCorrection
      } else if index > 0 {
        let tracked = trackAnchors(
          observations: anchorSet.observations,
          handler: sequenceHandler,
          image: image
        )
        anchorSet.observations = tracked.observations
        trackedPointCount = tracked.validIndices.count
        meanTrackingConfidence = tracked.validIndices.isEmpty
          ? 0
          : tracked.validIndices.map { tracked.confidences[$0] }.reduce(0, +)
            / Double(tracked.validIndices.count)

        if tracked.validIndices.count >= 4 {
          let sourcePoints = tracked.validIndices.map { tracked.imagePoints[$0] }
          let destinationPoints = tracked.validIndices.map { anchorSet.metricPoints[$0] }
          if let robust = try? HomographyMath.robustImageToRunway(
            source: sourcePoints,
            destination: destinationPoints,
            thresholdMeters: 0.10,
            maximumTrials: 42
          ) {
            transform = robust.matrix
            inlierRatio = Double(robust.inlierIndices.count) / Double(sourcePoints.count)
            if robust.meanMetricError.isFinite { fitErrorMeters = robust.meanMetricError }
            if let reconstructed = HomographyMath.grid(from: transform, template: activeGrid) {
              activeGrid = reconstructed
            }
          } else {
            inlierRatio = 0
          }
        } else {
          inlierRatio = Double(tracked.validIndices.count) / Double(max(anchorSet.observations.count, 1))
        }
      }

      // Ré-ancrage absolu périodique : modèle Core ML facultatif, sinon rectangle Vision.
      if index > 0,
        index.isMultiple(of: max(Int(analysisRate * 0.50), 8)),
        let guess = detector.bestGuess(in: image, template: activeGrid),
        isCompatible(anchor: guess.grid, tracked: activeGrid)
      {
        activeGrid = blend(activeGrid, guess.grid, weight: 0.18)
        anchorSet = makeAnchorSet(for: activeGrid)
        if let anchored = try? HomographyMath.imageToRunway(for: activeGrid) {
          transform = anchored
          source = .detectorAnchor
          // Four exact grid corners do not provide an independent error estimate.
          fitErrorMeters = fitErrorMeters.isFinite ? fitErrorMeters : 0
          keyframes.append(
            CalibrationKeyframe(
              timeSeconds: seconds,
              source: .detectorAnchor,
              grid: activeGrid,
              imageToRunway: anchored,
              confidence: guess.confidence,
              estimatedErrorMeters: 0 // unknown until validated against independent correspondences
            )
          )
        }
      }

      let geometryQuality = min(max(activeGrid.polygonArea / max(initialGrid.polygonArea, 0.001), 0.30), 1)
      let correspondenceQuality = min(Double(trackedPointCount) / Double(max(anchorSet.observations.count, 1)), 1)
      let residualQuality = fitErrorMeters.isFinite && fitErrorMeters > 0
        ? exp(-fitErrorMeters / 0.09)
        : 0.5
      // Heuristic quality score used for triage only; it is not a calibrated probability.
      let confidence = min(
        max(
          meanTrackingConfidence * 0.42
            + inlierRatio * 0.26
            + correspondenceQuality * 0.12
            + geometryQuality * 0.08
            + residualQuality * 0.12,
          0
        ),
        1
      )
      // Never invent a metric uncertainty from the quality score. Zero means “not calibrated”.
      let estimatedError = fitErrorMeters.isFinite && fitErrorMeters > 0 ? fitErrorMeters : 0
      let status: CalibrationStatus
      if confidence >= 0.74, inlierRatio >= 0.72, trackedPointCount >= 7 {
        status = .reliable
        lowConfidenceRun = 0
      } else if confidence >= 0.46, trackedPointCount >= 4 {
        status = .review
        lowConfidenceRun += 1
      } else {
        status = .manualRequired
        lowConfidenceRun += 1
      }

      if activeGrid.isGeometricallyUsable {
        samples.append(
          HomographySample(
            timeSeconds: seconds,
            grid: activeGrid,
            imageToRunway: transform,
            source: source,
            trackedPointCount: trackedPointCount,
            inlierRatio: inlierRatio,
            confidence: confidence,
            estimatedErrorMeters: estimatedError,
            status: status
          )
        )
        if status != .manualRequired {
          lastGoodGrid = activeGrid
          lastGoodTransform = transform
        }
      } else {
        samples.append(
          HomographySample(
            timeSeconds: seconds,
            grid: lastGoodGrid,
            imageToRunway: lastGoodTransform,
            source: .interpolated,
            trackedPointCount: trackedPointCount,
            inlierRatio: inlierRatio,
            confidence: confidence * 0.5,
            estimatedErrorMeters: estimatedError,
            status: .manualRequired
          )
        )
      }

      if lowConfidenceRun > Int(analysisRate * 0.8) {
        activeGrid = lastGoodGrid
        transform = lastGoodTransform
        anchorSet = makeAnchorSet(for: lastGoodGrid)
      }
    }

    guard samples.count >= 5 else { throw CalibrationError.insufficientTracking }
    let average = samples.map(\.confidence).reduce(0, +) / Double(samples.count)
    if !keyframes.contains(where: { abs($0.timeSeconds - startTime) < temporalStep }) {
      keyframes.append(
        CalibrationKeyframe(
          timeSeconds: startTime,
          source: .userCorrection,
          grid: initialGrid,
          imageToRunway: try HomographyMath.imageToRunway(for: initialGrid),
          confidence: 0, // manual keyframe: no probabilistic confidence is claimed
          estimatedErrorMeters: 0
        )
      )
    }

    return DynamicCalibrationTrack(
      initialGrid: samples.first?.grid ?? initialGrid,
      keyframes: keyframes.sorted { $0.timeSeconds < $1.timeSeconds },
      samples: samples,
      startTime: startTime,
      endTime: endTime,
      averageConfidence: average
    )
  }


  private func nearestCorrection(
    to time: Double,
    corrections: [CalibrationKeyframe],
    tolerance: Double
  ) -> CalibrationKeyframe? {
    guard let candidate = corrections.min(by: {
      abs($0.timeSeconds - time) < abs($1.timeSeconds - time)
    }), abs(candidate.timeSeconds - time) <= tolerance
    else { return nil }
    return candidate
  }

  private func makeAnchorSet(for grid: RunwayGridCalibration) -> AnchorSet {
    let longitudinalFractions = [0.0, 1.0 / 3.0, 2.0 / 3.0, 1.0]
    let lateralFractions = [0.0, 0.5, 1.0]
    var imagePoints: [NormalizedPoint] = []
    var metricPoints: [MetricRunwayPoint] = []
    let runwayToImage = (try? HomographyMath.imageToRunway(for: grid))?.inverted()

    for longitudinal in longitudinalFractions {
      for lateral in lateralFractions {
        let metric = MetricRunwayPoint(
          xMeters: longitudinal * grid.zoneLengthMeters,
          yMeters: lateral * grid.runwayWidthMeters
        )
        metricPoints.append(metric)

        if let projected = runwayToImage?.project(
          NormalizedPoint(x: metric.xMeters, y: metric.yMeters)
        ) {
          imagePoints.append(projected.clamped())
        } else {
          let left = interpolate(grid.boxLeft, grid.farLeft, longitudinal)
          let right = interpolate(grid.boxRight, grid.farRight, longitudinal)
          imagePoints.append(interpolate(left, right, lateral))
        }
      }
    }
    return AnchorSet(
      observations: makeObservations(points: imagePoints),
      metricPoints: metricPoints
    )
  }

  private func makeObservations(points: [NormalizedPoint]) -> [VNDetectedObjectObservation] {
    points.map { point in
      let side = 0.050
      let visionY = 1 - point.y
      let rect = CGRect(
        x: min(max(point.x - side / 2, 0), 1 - side),
        y: min(max(visionY - side / 2, 0), 1 - side),
        width: side,
        height: side
      )
      return VNDetectedObjectObservation(boundingBox: rect)
    }
  }

  private func trackAnchors(
    observations: [VNDetectedObjectObservation],
    handler: VNSequenceRequestHandler,
    image: CGImage
  ) -> TrackingResult {
    let requests = observations.map { observation -> VNTrackObjectRequest in
      let request = VNTrackObjectRequest(detectedObjectObservation: observation)
      request.trackingLevel = .accurate
      return request
    }

    do {
      try handler.perform(requests, on: image, orientation: .up)
    } catch {
      return TrackingResult(
        observations: observations,
        imagePoints: observations.map(uiCenter),
        confidences: Array(repeating: 0, count: observations.count),
        validIndices: []
      )
    }

    var nextObservations: [VNDetectedObjectObservation] = []
    var points: [NormalizedPoint] = []
    var confidences: [Double] = []
    var validIndices: [Int] = []

    for (index, request) in requests.enumerated() {
      if let result = request.results?.first as? VNDetectedObjectObservation,
        result.confidence >= 0.12
      {
        nextObservations.append(result)
        points.append(uiCenter(result))
        confidences.append(Double(result.confidence))
        if result.confidence >= Float(VideoAnalysisConfiguration.Tracking.dynamicAnchorMinimumConfidence) { validIndices.append(index) }
      } else {
        nextObservations.append(observations[index])
        points.append(uiCenter(observations[index]))
        confidences.append(0)
      }
    }
    return TrackingResult(
      observations: nextObservations,
      imagePoints: points,
      confidences: confidences,
      validIndices: validIndices
    )
  }

  private func uiCenter(_ observation: VNDetectedObjectObservation) -> NormalizedPoint {
    NormalizedPoint(
      x: observation.boundingBox.midX,
      y: 1 - observation.boundingBox.midY
    ).clamped()
  }

  private func isCompatible(
    anchor: RunwayGridCalibration,
    tracked: RunwayGridCalibration
  ) -> Bool {
    let meanDistance = zip(anchor.imagePoints, tracked.imagePoints).map {
      hypot($0.x - $1.x, $0.y - $1.y)
    }.reduce(0, +) / 4
    let areaRatio = anchor.polygonArea / max(tracked.polygonArea, 0.0001)
    return meanDistance < 0.22 && areaRatio > 0.35 && areaRatio < 2.8
  }

  private func blend(
    _ tracked: RunwayGridCalibration,
    _ anchor: RunwayGridCalibration,
    weight: Double
  ) -> RunwayGridCalibration {
    HomographyMath.interpolatedGrid(from: tracked, to: anchor, fraction: weight)
  }

  private func interpolate(
    _ first: NormalizedPoint,
    _ second: NormalizedPoint,
    _ fraction: Double
  ) -> NormalizedPoint {
    NormalizedPoint(
      x: first.x + (second.x - first.x) * fraction,
      y: first.y + (second.y - first.y) * fraction
    ).clamped()
  }
}
