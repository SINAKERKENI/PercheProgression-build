import Foundation
import SwiftData

struct FFAAthleteDTO: Codable, Identifiable, Hashable, Sendable {
  let id: String
  let firstName: String
  let lastName: String
  let birthYear: Int?
  let club: String?
  let licenseOrPPS: String?

  var displayName: String { "\(firstName) \(lastName)".trimmingCharacters(in: .whitespaces) }
}

struct FFAPerformanceDTO: Codable, Hashable, Sendable, Identifiable {
  let id: String
  let athleteID: String
  let event: String
  let performance: String
  let date: Date
  let indoor: Bool?
  let venue: String?
  let competition: String?
  let place: String?
  let level: String?
  let sourceURL: String?

  var canonicalHeightCM: Int? { FFAHeightParser.centimeters(from: performance) }
  var isPoleVault: Bool { FFAPoleVaultEvent.isPoleVault(event) }
}

struct FFAAthleteSearchQuery: Sendable {
  var firstName: String
  var lastName: String
  var licenseOrPPS: String = ""
  var birthYear: Int? = nil
  var club: String = ""
}

protocol FFAProvider: Sendable {
  func searchAthletes(_ query: FFAAthleteSearchQuery) async throws -> [FFAAthleteDTO]
  func performances(athleteID: String, forceRefresh: Bool) async throws -> [FFAPerformanceDTO]
}

enum FFAError: LocalizedError {
  case unavailable
  case invalidConfiguration
  case invalidResponse
  case serverError(Int)

  var errorDescription: String? {
    switch self {
    case .unavailable: "Le service FFA n’est pas disponible pour le moment. L’historique local est conservé."
    case .invalidConfiguration: "Adresse du backend FFA manquante ou invalide."
    case .invalidResponse: "La réponse du service FFA est invalide."
    case .serverError(let code): "Le service FFA a répondu avec le code \(code). L’historique local n’a pas été supprimé."
    }
  }
}

enum FFAPoleVaultEvent {
  static func isPoleVault(_ value: String) -> Bool {
    let folded = value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "fr_FR"))
      .lowercased().replacingOccurrences(of: "_", with: " ")
    guard folded.contains("perche") else { return false }
    // Exclude obviously unrelated prose while accepting category suffixes such as /TCM.
    return !folded.contains("sans perche")
  }

  static func isIndoor(_ value: String, explicit: Bool?) -> Bool {
    if let explicit { return explicit }
    let folded = value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "fr_FR")).lowercased()
    return folded.contains("salle") || folded.contains("piste courte") || folded.contains("indoor")
  }
}

enum FFAHeightParser {
  /// Parses only a complete height token. Placement, points and dates are never considered.
  static func centimeters(from raw: String) -> Int? {
    let text = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    guard !text.isEmpty else { return nil }
    // Official French notation: 4m76 / 4 m 76 / 4,76 / 4.76 / 476 cm.
    let patterns: [(String, (NSTextCheckingResult, NSString) -> Int?)] = [
      (#"^\s*(\d)\s*m\s*(\d{1,2})\s*(?:cm)?\s*$"#, { match, ns in
        guard let m = Int(ns.substring(with: match.range(at: 1))), let cm = Int(ns.substring(with: match.range(at: 2))), cm < 100 else { return nil }
        return m * 100 + cm
      }),
      (#"^\s*(\d)[\.,](\d{1,2})\s*m?\s*$"#, { match, ns in
        guard let m = Int(ns.substring(with: match.range(at: 1))), let cmText = Optional(ns.substring(with: match.range(at: 2))) else { return nil }
        let cm = Int(cmText.count == 1 ? cmText + "0" : cmText)
        guard let cm, cm < 100 else { return nil }
        return m * 100 + cm
      }),
      (#"^\s*(\d{3})\s*cm\s*$"#, { match, ns in Int(ns.substring(with: match.range(at: 1))) })
    ]
    let ns = text as NSString
    for (pattern, builder) in patterns {
      guard let regex = try? NSRegularExpression(pattern: pattern),
            let match = regex.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)),
            match.range.location != NSNotFound else { continue }
      if let cm = builder(match, ns), (100...700).contains(cm) { return cm }
    }
    return nil
  }
}

actor DisabledFFAProvider: FFAProvider {
  func searchAthletes(_ query: FFAAthleteSearchQuery) async throws -> [FFAAthleteDTO] { throw FFAError.unavailable }
  func performances(athleteID: String, forceRefresh: Bool) async throws -> [FFAPerformanceDTO] { throw FFAError.unavailable }
}

/// Client for the Perche Progression FFA adapter. The adapter is intentionally separate because
/// current public FFA result pages explicitly prohibit copying displayed data; the client therefore
/// never scrapes athle.fr directly and carries no private FFA credential.
actor RemoteFFAProvider: FFAProvider {
  let baseURL: URL
  let session: URLSession

  init(baseURL: URL, session: URLSession = .shared) {
    self.baseURL = baseURL
    self.session = session
  }

  func searchAthletes(_ query: FFAAthleteSearchQuery) async throws -> [FFAAthleteDTO] {
    var components = URLComponents(url: baseURL.appendingPathComponent("ffa/athletes/search"), resolvingAgainstBaseURL: false)
    var items = [
      URLQueryItem(name: "firstName", value: query.firstName),
      URLQueryItem(name: "lastName", value: query.lastName),
    ]
    if !query.licenseOrPPS.isEmpty { items.append(URLQueryItem(name: "licenseOrPPS", value: query.licenseOrPPS)) }
    if let year = query.birthYear { items.append(URLQueryItem(name: "birthYear", value: String(year))) }
    if !query.club.isEmpty { items.append(URLQueryItem(name: "club", value: query.club)) }
    components?.queryItems = items
    guard let url = components?.url else { throw FFAError.invalidConfiguration }
    var request = URLRequest(url: url)
    request.cachePolicy = .returnCacheDataElseLoad
    let (data, response) = try await session.data(for: request)
    try validate(response)
    return try decoder.decode([FFAAthleteDTO].self, from: data)
  }

  func performances(athleteID: String, forceRefresh: Bool = false) async throws -> [FFAPerformanceDTO] {
    var components = URLComponents(url: baseURL.appendingPathComponent("ffa/athletes/\(athleteID)/performances"), resolvingAgainstBaseURL: false)
    components?.queryItems = [URLQueryItem(name: "force", value: forceRefresh ? "true" : "false")]
    guard let url = components?.url else { throw FFAError.invalidConfiguration }
    var request = URLRequest(url: url)
    request.cachePolicy = forceRefresh ? .reloadRevalidatingCacheData : .returnCacheDataElseLoad
    let (data, response) = try await session.data(for: request)
    try validate(response)
    return try decoder.decode([FFAPerformanceDTO].self, from: data)
  }

  private var decoder: JSONDecoder {
    let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d
  }

  private func validate(_ response: URLResponse) throws {
    guard let http = response as? HTTPURLResponse else { throw FFAError.invalidResponse }
    guard (200..<300).contains(http.statusCode) else { throw FFAError.serverError(http.statusCode) }
  }
}

struct FFAImportItem: Equatable, Sendable {
  let externalKey: String
  let dto: FFAPerformanceDTO
  let heightCM: Int
  let indoor: Bool
}

struct FFAImportPlanner: Sendable {
  func relevantItems(athleteID: String, performances: [FFAPerformanceDTO]) -> [FFAImportItem] {
    var byKey: [String: FFAImportItem] = [:]
    for dto in performances where dto.athleteID == athleteID && dto.isPoleVault {
      guard let cm = dto.canonicalHeightCM else { continue }
      let sourceIdentity = dto.id.trimmingCharacters(in: .whitespacesAndNewlines)
      let key = sourceIdentity.isEmpty
        ? deterministicKey(athleteID: athleteID, dto: dto, heightCM: cm)
        : "ffa:\(athleteID):\(sourceIdentity)"
      byKey[key] = FFAImportItem(externalKey: key, dto: dto, heightCM: cm,
                                 indoor: FFAPoleVaultEvent.isIndoor(dto.event, explicit: dto.indoor))
    }
    return byKey.values.sorted { $0.dto.date < $1.dto.date }
  }

  func officialPRPoints(from items: [FFAImportItem]) -> [MetricPoint] {
    var best = 0
    return items.sorted { $0.dto.date < $1.dto.date }.compactMap { item in
      guard item.heightCM > best else { return nil }
      best = item.heightCM
      return MetricPoint(date: item.dto.date, value: Double(item.heightCM) / 100.0,
                         label: String(format: "%.2f m · FFA", Double(item.heightCM) / 100.0))
    }
  }

  private func deterministicKey(athleteID: String, dto: FFAPerformanceDTO, heightCM: Int) -> String {
    let day = ISO8601DateFormatter().string(from: dto.date).prefix(10)
    let canonical = [athleteID, String(day), dto.event.lowercased(), String(heightCM), dto.venue ?? "", dto.competition ?? ""]
      .joined(separator: "|")
    // Stable non-cryptographic FNV-1a is sufficient for a local deduplication key.
    var hash: UInt64 = 1469598103934665603
    for byte in canonical.utf8 { hash ^= UInt64(byte); hash &*= 1099511628211 }
    return "ffa:\(athleteID):\(String(hash, radix: 16))"
  }
}

@MainActor
struct FFAImportService {
  let planner = FFAImportPlanner()

  @discardableResult
  func merge(athlete: AthleteProfile, performances: [FFAPerformanceDTO], context: ModelContext) throws -> (inserted: Int, updated: Int) {
    let items = planner.relevantItems(athleteID: athlete.ffaAthleteID, performances: performances)
    let athleteID = athlete.id
    let existing = try context.fetch(FetchDescriptor<OfficialPerformanceRecord>())
      .filter { $0.athleteID == athleteID }
    var map = Dictionary(uniqueKeysWithValues: existing.map { ($0.externalKey, $0) })
    var inserted = 0, updated = 0
    let now = Date()
    for item in items {
      if let record = map[item.externalKey] {
        record.sourceResultID = item.dto.id
        record.eventName = item.dto.event
        record.performanceCM = item.heightCM
        record.date = item.dto.date
        record.isIndoor = item.indoor
        record.venue = item.dto.venue ?? ""
        record.competition = item.dto.competition ?? ""
        record.place = item.dto.place ?? ""
        record.level = item.dto.level ?? ""
        record.sourceURLString = item.dto.sourceURL ?? ""
        record.lastRefreshedAt = now
        updated += 1
      } else {
        let record = OfficialPerformanceRecord(
          athleteID: athleteID, ffaAthleteID: athlete.ffaAthleteID, externalKey: item.externalKey,
          sourceResultID: item.dto.id, eventName: item.dto.event, performanceCM: item.heightCM,
          date: item.dto.date, isIndoor: item.indoor, venue: item.dto.venue ?? "",
          competition: item.dto.competition ?? "", place: item.dto.place ?? "", level: item.dto.level ?? "",
          sourceURLString: item.dto.sourceURL ?? "", importedAt: now, lastRefreshedAt: now
        )
        context.insert(record); map[item.externalKey] = record; inserted += 1
      }
    }
    athlete.ffaLastSyncAt = now
    athlete.ffaSyncStatusRaw = FFASyncStatus.success.rawValue
    if let officialBest = existing.map(\.performanceCM).max().map({ max($0, items.map(\.heightCM).max() ?? 0) }) ?? items.map(\.heightCM).max() {
      athlete.currentPRCM = officialBest
    }
    athlete.updatedAt = now
    try context.save()
    return (inserted, updated)
  }
}
