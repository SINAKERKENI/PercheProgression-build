import AVFoundation
import Foundation
import ImageIO
import Vision

struct RunwaySceneDetectionService: Sendable {
  private let coreMLDetector = PoleVaultSceneDetectorService()
  enum DetectionError: LocalizedError {
    case noRectangle
    case noSpecializedModel

    var errorDescription: String? {
      switch self {
      case .noRectangle:
        "La piste ou le butoir n’a pas été identifié avec assez de certitude. Placez rapidement les quatre poignées de la grille."
      case .noSpecializedModel:
        "Le butoir n’est pas détectable de façon fiable avec un détecteur générique. Utilisez la stabilisation automatique sans butoir pour les Mesures avancées, ou placez manuellement la grille pour mesurer la marque d’impulsion."
      }
    }
  }

  struct Guess: Sendable {
    var grid: RunwayGridCalibration
    var confidence: Double
    var sourceDescription: String
  }

  func bestGuess(
    videoURL: URL,
    at timeSeconds: Double,
    zoneLengthMeters: Double = 5,
    runwayWidthMeters: Double = 1.22
  ) async throws -> Guess {
    let asset = AVURLAsset(url: videoURL)
    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = CMTime(seconds: 0.02, preferredTimescale: 600)
    generator.requestedTimeToleranceAfter = CMTime(seconds: 0.02, preferredTimescale: 600)
    generator.maximumSize = CGSize(width: 1280, height: 1280)
    let image = try await generator.image(
      at: CMTime(seconds: max(timeSeconds, 0), preferredTimescale: 600)
    ).image

    if let coreMLGuess = coreMLDetector.runwayGuess(
      in: image,
      zoneLengthMeters: zoneLengthMeters,
      runwayWidthMeters: runwayWidthMeters
    ) {
      return coreMLGuess
    }

    guard coreMLDetector.isAvailable else { throw DetectionError.noSpecializedModel }
    throw DetectionError.noRectangle
  }

  func bestGuess(in image: CGImage, template: RunwayGridCalibration) -> Guess? {
    guard coreMLDetector.isAvailable else { return nil }
    return coreMLDetector.runwayGuess(
      in: image,
      zoneLengthMeters: template.zoneLengthMeters,
      runwayWidthMeters: template.runwayWidthMeters
    )
  }

  private func detectRectangles(in image: CGImage) -> [VNRectangleObservation] {
    let request = VNDetectRectanglesRequest()
    request.maximumObservations = 12
    request.minimumConfidence = 0.28
    request.minimumSize = 0.08
    request.minimumAspectRatio = 0.12
    request.maximumAspectRatio = 1.0
    request.quadratureTolerance = 45

    let handler = VNImageRequestHandler(cgImage: image, orientation: .up)
    do {
      try handler.perform([request])
      return request.results ?? []
    } catch {
      return []
    }
  }

  private func score(_ rectangle: VNRectangleObservation) -> Double {
    let widthNear = hypot(
      rectangle.bottomRight.x - rectangle.bottomLeft.x,
      rectangle.bottomRight.y - rectangle.bottomLeft.y
    )
    let widthFar = hypot(
      rectangle.topRight.x - rectangle.topLeft.x,
      rectangle.topRight.y - rectangle.topLeft.y
    )
    let height = hypot(
      rectangle.bottomLeft.x - rectangle.topLeft.x,
      rectangle.bottomLeft.y - rectangle.topLeft.y
    )
    let areaProxy = max(widthNear, widthFar) * height
    let perspectiveBonus = widthNear >= widthFar ? 1.15 : 0.92
    let lowerImageBonus = rectangle.boundingBox.midY < 0.62 ? 1.08 : 0.92
    return Double(rectangle.confidence) * areaProxy * perspectiveBonus * lowerImageBonus
  }

  private func uiPoint(_ point: CGPoint) -> NormalizedPoint {
    NormalizedPoint(x: point.x, y: 1 - point.y).clamped()
  }
}
