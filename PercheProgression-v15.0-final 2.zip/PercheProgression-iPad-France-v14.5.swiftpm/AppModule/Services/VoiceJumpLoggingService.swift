import AVFoundation
import Combine
import Foundation
import Speech

struct VoiceJumpDraft: Equatable, Sendable {
  var result: AttemptResult
  var diagnostics: Set<AttemptDiagnostic>
  var barHeightCM: Int?
  var approach: ApproachLength?
  var poleLengthCM: Int?
  var poleWeightKG: Double?
  var technicalRating: JumpRating
  var gripHeightM: Double?
  var runUpDistanceM: Double?
  var midMarkM: Double?
  var takeoffMarkM: Double?
  var standardsOffsetCM: Int?
  var transcript: String

  var recognizedFieldCount: Int {
    var count = 1
    if barHeightCM != nil { count += 1 }
    if approach != nil { count += 1 }
    if poleLengthCM != nil { count += 1 }
    if poleWeightKG != nil { count += 1 }
    if technicalRating != .unrated { count += 1 }
    if gripHeightM != nil { count += 1 }
    if runUpDistanceM != nil { count += 1 }
    if midMarkM != nil { count += 1 }
    if takeoffMarkM != nil { count += 1 }
    if standardsOffsetCM != nil { count += 1 }
    count += diagnostics.count
    return count
  }
}

enum VoiceJumpParser {
  static func parse(_ transcript: String) -> VoiceJumpDraft {
    let text = normalized(transcript)
    return VoiceJumpDraft(
      result: result(in: text),
      diagnostics: diagnostics(in: text),
      barHeightCM: centimeters(after: ["barre", "hauteur"], in: text)
        ?? centimetersAfterPreposition(in: text),
      approach: approach(in: text),
      poleLengthCM: centimeters(after: ["perche"], in: text),
      poleWeightKG: poleWeight(in: text),
      technicalRating: rating(in: text),
      gripHeightM: meters(after: ["prise", "main haute", "grip"], in: text),
      runUpDistanceM: metricMeters(after: ["course", "elan"], in: text),
      midMarkM: meters(after: ["marque intermediaire", "mi marque", "mid mark"], in: text),
      takeoffMarkM: meters(after: ["impulsion", "take off", "takeoff"], in: text),
      standardsOffsetCM: integerCentimeters(after: ["poteaux", "standards"], in: text),
      transcript: transcript.trimmingCharacters(in: .whitespacesAndNewlines)
    )
  }

  private static func normalized(_ value: String) -> String {
    value
      .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "fr_FR"))
      .lowercased()
      .replacingOccurrences(of: "’", with: "'")
  }

  private static func result(in text: String) -> AttemptResult {
    if containsAny(["impasse", "je passe", "passe cette hauteur"], in: text) { return .pass }
    if containsAny(["course interrompue", "course arretee", "run through", "refus de courir"], in: text) {
      return .runThrough
    }
    if containsAny(["abandon", "abandonne"], in: text) { return .abort }
    if containsAny(["echec", "rate", "barre tombee", "touche la barre", "barre touchee"], in: text) {
      return .miss
    }
    if containsAny(["reussi", "franchi", "franchie", "passe", "valide"], in: text) {
      return .clear
    }
    return .miss
  }

  private static func rating(in text: String) -> JumpRating {
    if containsAny(["excellent", "tres bon", "tres bonne", "super saut"], in: text) { return .great }
    if containsAny(["bon saut", "bonne impulsion", "bon", "bonne"], in: text) { return .good }
    if containsAny(["correct", "moyen", "ok"], in: text) { return .ok }
    if containsAny(["incomplet", "incomplete"], in: text) { return .incomplete }
    return .unrated
  }

  private static func diagnostics(in text: String) -> Set<AttemptDiagnostic> {
    var values: Set<AttemptDiagnostic> = []
    if containsAny(["refus de planter", "refus de plant", "pas plante"], in: text) {
      values.insert(.plantRefusal)
    }
    if containsAny(["impulsion dessous", "trop dessous", "sous la perche"], in: text) {
      values.insert(.takeoffUnder)
    }
    if containsAny(["impulsion dehors", "trop loin", "impulsion loin"], in: text) {
      values.insert(.takeoffOut)
    }
    if containsAny(["touche la barre", "contact barre", "barre touchee"], in: text) {
      values.insert(.barContact)
    }
    if containsAny(["probleme de poteaux", "reglage poteaux", "standards"], in: text) {
      values.insert(.standardsIssue)
    }
    if containsAny(["perche trop souple", "perche molle"], in: text) {
      values.insert(.poleTooSoft)
    }
    if containsAny(["perche trop dure", "perche trop raide"], in: text) {
      values.insert(.poleTooStiff)
    }
    return values
  }

  private static func approach(in text: String) -> ApproachLength? {
    if let number = firstCapture(#"\b(6|8|10|12|14|16|18)\s*(?:foulee|foulees|appui|appuis|pas)\b"#, in: text),
      let value = Int(number)
    {
      return ApproachLength(rawValue: value)
    }

    let names: [(String, ApproachLength)] = [
      ("six", .six), ("huit", .eight), ("dix", .ten), ("douze", .twelve),
      ("quatorze", .fourteen), ("seize", .sixteen), ("dix huit", .eighteen),
      ("dix-huit", .eighteen),
    ]
    for (word, approach) in names where text.contains("\(word) foulee") || text.contains("\(word) appui") {
      return approach
    }
    return nil
  }

  private static func poleWeight(in text: String) -> Double? {
    guard let value = firstCapture(#"\b(\d{2,3}(?:[.,]\d+)?)\s*(?:kg|kilo|kilos)\b"#, in: text) else {
      return nil
    }
    return decimal(value)
  }

  private static func centimeters(after keywords: [String], in text: String) -> Int? {
    guard let segment = segment(after: keywords, in: text) else { return nil }
    if let groups = captures(#"(?<![\d.,])(-?\d)\s*(?:m|metre|metres)\s*(\d{1,2})\b"#, in: segment),
      groups.count >= 2,
      let meters = Int(groups[0]),
      let centimeters = Int(groups[1])
    {
      return meters * 100 + centimeters
    }
    if let value = firstCapture(#"(-?\d+(?:[.,]\d+)?)\s*(?:m|metre|metres)\b"#, in: segment),
      let number = decimal(value)
    {
      return Int((number * 100).rounded())
    }
    if let value = firstCapture(#"(-?\d+(?:[.,]\d+)?)\s*(?:m|metre|metres)?\b"#, in: segment),
      let number = decimal(value)
    {
      if segment.range(of: #"^\s*-?\d{2,3}\s*(?:cm|centimetre|centimetres)"#, options: .regularExpression) != nil {
        return Int(number.rounded())
      }
      if abs(number) > 10 {
        return Int(number.rounded())
      }
      return Int((number * 100).rounded())
    }
    return nil
  }

  private static func centimetersAfterPreposition(in text: String) -> Int? {
    guard let groups = captures(#"\ba\s+(\d{1,2})\s*(?:m|metre|metres)\s*(\d{1,2})\b"#, in: text),
      groups.count >= 2,
      let meters = Int(groups[0]),
      let centimeters = Int(groups[1])
    else {
      guard let value = firstCapture(#"\ba\s+(\d[.,]\d{1,2})\s*(?:m|metre|metres)?\b"#, in: text),
        let meters = decimal(value)
      else { return nil }
      return Int((meters * 100).rounded())
    }
    return meters * 100 + centimeters
  }

  private static func meters(after keywords: [String], in text: String) -> Double? {
    guard let centimeters = centimeters(after: keywords, in: text) else { return nil }
    return Double(centimeters) / 100
  }

  private static func metricMeters(after keywords: [String], in text: String) -> Double? {
    guard let segment = segment(after: keywords, in: text) else { return nil }
    if let groups = captures(#"(?<![\d.,])(-?\d{1,2})\s*(?:m|metre|metres)\s*(\d{1,2})\b"#, in: segment),
      groups.count >= 2,
      let whole = Int(groups[0]),
      let centimeters = Int(groups[1])
    {
      return Double(whole * 100 + centimeters) / 100
    }
    guard let value = firstCapture(#"(-?\d+(?:[.,]\d+)?)\s*(?:m|metre|metres)\b"#, in: segment) else {
      return nil
    }
    return decimal(value)
  }

  private static func integerCentimeters(after keywords: [String], in text: String) -> Int? {
    guard let segment = segment(after: keywords, in: text),
      let value = firstCapture(#"([+-]?\d{1,3})\s*(?:cm|centimetre|centimetres)?\b"#, in: segment)
    else { return nil }
    return Int(value)
  }

  private static func segment(after keywords: [String], in text: String) -> String? {
    for keyword in keywords {
      guard let range = text.range(of: keyword) else { continue }
      let suffix = text[range.upperBound...]
      var value = String(suffix.prefix(48))
      let delimiters = [", ", "; ", ". ", "\n"]
      if let boundary = delimiters.compactMap({ value.range(of: $0)?.lowerBound }).min() {
        value = String(value[..<boundary])
      }
      return value.trimmingCharacters(in: CharacterSet(charactersIn: " :,"))
    }
    return nil
  }

  private static func containsAny(_ values: [String], in text: String) -> Bool {
    values.contains { text.contains($0) }
  }

  private static func decimal(_ value: String) -> Double? {
    Double(value.replacingOccurrences(of: ",", with: "."))
  }

  private static func firstCapture(_ pattern: String, in text: String) -> String? {
    captures(pattern, in: text)?.first
  }

  private static func captures(_ pattern: String, in text: String) -> [String]? {
    guard let expression = try? NSRegularExpression(pattern: pattern) else { return nil }
    let range = NSRange(text.startIndex..<text.endIndex, in: text)
    guard let match = expression.firstMatch(in: text, range: range) else { return nil }
    var values: [String] = []
    for index in 1..<match.numberOfRanges {
      let matchRange = match.range(at: index)
      guard matchRange.location != NSNotFound, let range = Range(matchRange, in: text) else { continue }
      values.append(String(text[range]))
    }
    return values
  }
}

@MainActor
final class VoiceLogCoordinator: NSObject, ObservableObject {
  @Published private(set) var transcript = ""
  @Published private(set) var isRecording = false
  @Published private(set) var errorMessage: String?
  @Published private(set) var usesOnDeviceRecognition = false

  private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "fr_FR"))
  private let audioEngine = AVAudioEngine()
  private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
  private var recognitionTask: SFSpeechRecognitionTask?
  private var hasInstalledTap = false

  func requestAuthorizationAndStart() {
    errorMessage = nil
    SFSpeechRecognizer.requestAuthorization { [weak self] status in
      Task { @MainActor in
        guard let self else { return }
        guard status == .authorized else {
          self.errorMessage = "Autorisez la reconnaissance vocale dans Réglages pour utiliser la dictée."
          return
        }
        let granted = await AVAudioApplication.requestRecordPermission()
        guard granted else {
          self.errorMessage = "Autorisez le microphone dans Réglages pour dicter un saut."
          return
        }
        self.startRecording()
      }
    }
  }

  func stopRecording() {
    if audioEngine.isRunning {
      audioEngine.stop()
    }
    if hasInstalledTap {
      audioEngine.inputNode.removeTap(onBus: 0)
      hasInstalledTap = false
    }
    recognitionRequest?.endAudio()
    recognitionTask?.cancel()
    recognitionTask = nil
    recognitionRequest = nil
    isRecording = false
    try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
  }

  func clear() {
    stopRecording()
    transcript = ""
    errorMessage = nil
  }

  private func startRecording() {
    stopRecording()
    guard let recognizer, recognizer.isAvailable else {
      errorMessage = "La reconnaissance vocale française est temporairement indisponible."
      return
    }

    let request = SFSpeechAudioBufferRecognitionRequest()
    request.shouldReportPartialResults = true
    usesOnDeviceRecognition = recognizer.supportsOnDeviceRecognition
    request.requiresOnDeviceRecognition = usesOnDeviceRecognition
    recognitionRequest = request

    do {
      let session = AVAudioSession.sharedInstance()
      try session.setCategory(.record, mode: .measurement, options: [.duckOthers])
      try session.setActive(true, options: .notifyOthersOnDeactivation)

      let inputNode = audioEngine.inputNode
      let format = inputNode.outputFormat(forBus: 0)
      inputNode.installTap(onBus: 0, bufferSize: 1_024, format: format) { [weak request] buffer, _ in
        request?.append(buffer)
      }
      hasInstalledTap = true
      audioEngine.prepare()
      try audioEngine.start()
      isRecording = true

      recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
        Task { @MainActor in
          guard let self else { return }
          if let result {
            self.transcript = result.bestTranscription.formattedString
            if result.isFinal { self.stopRecording() }
          }
          if let error, self.isRecording {
            self.errorMessage = error.localizedDescription
            self.stopRecording()
          }
        }
      }
    } catch {
      errorMessage = "La dictée n’a pas pu démarrer : \(error.localizedDescription)"
      stopRecording()
    }
  }
}
