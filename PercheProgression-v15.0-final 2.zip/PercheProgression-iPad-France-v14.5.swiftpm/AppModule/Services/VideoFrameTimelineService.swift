import AVFoundation
import CoreMedia
import Foundation

/// Builds a presentation-time index directly from the media samples.
/// This avoids deriving frame positions from nominalFrameRate and supports VFR sources.
actor VideoFrameTimelineService {
  enum TimelineError: LocalizedError {
    case noVideoTrack
    case cannotStartReader
    case noSamples

    var errorDescription: String? {
      switch self {
      case .noVideoTrack: "Aucune piste vidéo exploitable n’a été trouvée."
      case .cannotStartReader: "Impossible de lire les timestamps réels de la vidéo."
      case .noSamples: "La vidéo ne contient aucun échantillon temporel exploitable."
      }
    }
  }

  func timestamps(for videoURL: URL) async throws -> [Double] {
    let asset = AVURLAsset(url: videoURL)
    let tracks = try await asset.loadTracks(withMediaType: .video)
    guard let track = tracks.first else { throw TimelineError.noVideoTrack }

    let reader = try AVAssetReader(asset: asset)
    let output = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
    output.alwaysCopiesSampleData = false
    guard reader.canAdd(output) else { throw TimelineError.cannotStartReader }
    reader.add(output)
    guard reader.startReading() else { throw reader.error ?? TimelineError.cannotStartReader }

    var values: [Double] = []
    values.reserveCapacity(3_600)
    while reader.status == .reading {
      try Task.checkCancellation()
      guard let sample = output.copyNextSampleBuffer() else { break }
      let pts = CMSampleBufferGetPresentationTimeStamp(sample).seconds
      if pts.isFinite, pts >= 0 { values.append(pts) }
    }

    guard !values.isEmpty else { throw reader.error ?? TimelineError.noSamples }
    // A few containers can expose duplicate/non-monotonic timestamps. Navigation needs a strict order.
    var cleaned: [Double] = []
    cleaned.reserveCapacity(values.count)
    for value in values.sorted() where cleaned.last.map({ value - $0 > 1e-7 }) ?? true {
      cleaned.append(value)
    }
    guard !cleaned.isEmpty else { throw TimelineError.noSamples }
    return cleaned
  }
}

extension VideoFrameTimelineService {
  /// Returns real presentation timestamps restricted to an interval and uniformly decimated
  /// by sample index when a processing cap is requested. No synthetic frame times are created.
  func sampledTimestamps(
    for videoURL: URL,
    startTime: Double,
    endTime: Double,
    maximumSamples: Int
  ) async throws -> [Double] {
    let all = try await timestamps(for: videoURL)
    let bounded = all.filter { $0 >= startTime - 1e-6 && $0 <= endTime + 1e-6 }
    guard !bounded.isEmpty else { throw TimelineError.noSamples }
    guard maximumSamples > 1, bounded.count > maximumSamples else { return bounded }

    let stride = Double(bounded.count - 1) / Double(maximumSamples - 1)
    var selected: [Double] = []
    selected.reserveCapacity(maximumSamples)
    var lastIndex = -1
    for slot in 0..<maximumSamples {
      let index = min(Int((Double(slot) * stride).rounded()), bounded.count - 1)
      if index != lastIndex {
        selected.append(bounded[index])
        lastIndex = index
      }
    }
    return selected
  }

  static func effectiveRate(for timestamps: [Double]) -> Double? {
    guard timestamps.count >= 2 else { return nil }
    let deltas = zip(timestamps.dropFirst(), timestamps).map { current, previous in current - previous }.filter { $0 > 1e-6 && $0.isFinite }
    guard !deltas.isEmpty else { return nil }
    let sorted = deltas.sorted()
    let median: Double
    if sorted.count.isMultiple(of: 2) {
      median = (sorted[sorted.count / 2 - 1] + sorted[sorted.count / 2]) * 0.5
    } else {
      median = sorted[sorted.count / 2]
    }
    return median > 0 ? 1.0 / median : nil
  }
}
