import SwiftUI
import UIKit

private struct TrackScreenAwakeModifier: ViewModifier {
  func body(content: Content) -> some View {
    content
      .onAppear {
        UIApplication.shared.isIdleTimerDisabled = true
      }
      .onDisappear {
        UIApplication.shared.isIdleTimerDisabled = false
      }
  }
}

extension View {
  /// Prevents the display from sleeping while the athlete is using Track Mode.
  /// The normal system behavior is restored as soon as the view is dismissed.
  func trackScreenAwake() -> some View {
    modifier(TrackScreenAwakeModifier())
  }
}
