import AVFoundation
import CoreGraphics
import Foundation
import Vision

/// Repli métrique lorsque le butoir n'est jamais visible.
/// Le mouvement de caméra est estimé avec des points statiques de l'arrière-plan,
/// puis la conversion pixel -> mètre est actualisée à partir de la taille connue
/// de l'athlète et de sa boîte suivie. Cette méthode permet des Mesures avancées utiles,
/// mais ne permet pas une marque d'impulsion absolue depuis le butoir.
actor AthleteScaleMotionAnalysisService {
  enum AnalysisError: LocalizedError {
    case invalidSegment
    case invalidAthleteHeight
    case noVideoTrack
    case frameExtractionFailed
    case trackingLost
    case insufficientBackground
    case insufficientSamples

    var errorDescription: String? {
      switch self {
      case .invalidSegment:
        "La zone de suivi doit durer au moins 0,20 seconde."
      case .invalidAthleteHeight:
        "Renseignez la taille réelle de l’athlète dans le profil."
      case .noVideoTrack:
        "Aucune piste vidéo exploitable n’a été trouvée."
      case .frameExtractionFailed:
        "Les images nécessaires au suivi n’ont pas pu être extraites."
      case .trackingLost:
        "Le perchiste sélectionné a été perdu. Recommencez sur une image plus nette."
      case .insufficientBackground:
        "Le décor est trop uniforme ou trop mobile pour compenser le panoramique."
      case .insufficientSamples:
        "La séquence est trop courte pour calculer une vitesse fiable."
      }
    }
  }

  private struct RawPoint {
    var time: Double
    var imagePoint: NormalizedPoint
    var xMeters: Double
    var yMeters: Double
    var confidence: Double
    var scaleConfidence: Double
  }

  func analyze(
    videoURL: URL,
    candidate: PoseCandidate,
    athleteHeightMeters: Double,
    startTime: Double,
    endTime: Double,
    requestedFrameRate: Double,
    suppliedVideoSize: CGSize
  ) async throws -> MotionAnalysisResult {
    guard endTime - startTime >= 0.20 else { throw AnalysisError.invalidSegment }
    guard athleteHeightMeters >= 1.20, athleteHeightMeters <= 2.30 else {
      throw AnalysisError.invalidAthleteHeight
    }

    let asset = AVURLAsset(url: videoURL)
    let tracks = try await asset.loadTracks(withMediaType: .video)
    guard let track = tracks.first else { throw AnalysisError.noVideoTrack }

    let naturalSize = try await track.load(.naturalSize)
    let preferredTransform = try await track.load(.preferredTransform)
    let transformed = naturalSize.applying(preferredTransform)
    let assetVideoSize = CGSize(width: abs(transformed.width), height: abs(transformed.height))
    let videoSize = suppliedVideoSize.width > 0 && suppliedVideoSize.height > 0
      ? suppliedVideoSize : assetVideoSize

    let timelineService = VideoFrameTimelineService()
    let frameTimes = try await timelineService.sampledTimestamps(
      for: videoURL,
      startTime: startTime,
      endTime: endTime,
      maximumSamples: VideoAnalysisConfiguration.Sampling.maximumAthleteScaleFrames
    )
    guard frameTimes.count >= 6 else { throw AnalysisError.insufficientSamples }
    let analysisRate = VideoFrameTimelineService.effectiveRate(for: frameTimes)
      ?? max(min(requestedFrameRate, 60), 24)
    let subjectReanchorInterval = max(Int((analysisRate * 0.5).rounded()), 8)

    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.requestedTimeToleranceBefore = .zero
    generator.requestedTimeToleranceAfter = .zero
    generator.maximumSize = CGSize(width: 1600, height: 1600)

    var subjectObservation = VNDetectedObjectObservation(
      boundingBox: visionRect(from: candidate.boundingBox)
    )
    var backgroundObservations = makeBackgroundObservations(excluding: candidate.boundingBox)
    guard backgroundObservations.count >= 6 else { throw AnalysisError.insufficientBackground }

    var previousSubjectCenter = candidate.pelvisPoint ?? candidate.boundingBox.center
    var previousBackgroundPoints = backgroundObservations.map(uiCenter)
    var accumulatedX = 0.0
    var accumulatedY = 0.0
    var raw: [RawPoint] = []
    let sequenceHandler = VNSequenceRequestHandler()

    for (index, seconds) in frameTimes.enumerated() {
      try Task.checkCancellation()
      let image: CGImage
      do {
        image = try await generator.image(
          at: CMTime(seconds: seconds, preferredTimescale: 600)
        ).image
      } catch {
        if index == 0 { throw AnalysisError.frameExtractionFailed }
        continue
      }

      if index == 0 {
        let initialScale = metersPerPixel(
          athleteHeightMeters: athleteHeightMeters,
          subjectHeightNormalized: candidate.boundingBox.height,
          videoHeight: Double(videoSize.height)
        )
        raw.append(
          RawPoint(
            time: seconds,
            imagePoint: previousSubjectCenter,
            xMeters: 0,
            yMeters: 0,
            confidence: candidate.confidence,
            scaleConfidence: initialScale.confidence
          )
        )
        continue
      }

      let subjectRequest = VNTrackObjectRequest(detectedObjectObservation: subjectObservation)
      subjectRequest.trackingLevel = .accurate
      let backgroundRequests = backgroundObservations.map { observation -> VNTrackObjectRequest in
        let request = VNTrackObjectRequest(detectedObjectObservation: observation)
        request.trackingLevel = .accurate
        return request
      }
      let requests: [VNRequest] = [subjectRequest] + backgroundRequests

      do {
        try sequenceHandler.perform(requests, on: image, orientation: .up)
      } catch {
        if raw.count < 5 { throw AnalysisError.trackingLost }
        break
      }

      guard let trackedSubject = subjectRequest.results?.first as? VNDetectedObjectObservation,
        trackedSubject.confidence >= Float(VideoAnalysisConfiguration.Tracking.subjectMinimumConfidence)
      else {
        if raw.count < 5 { throw AnalysisError.trackingLost }
        break
      }

      let currentSubjectBox = uiRect(trackedSubject.boundingBox)
      let currentSubjectCenter = NormalizedPoint(
        x: currentSubjectBox.midX,
        y: currentSubjectBox.y + currentSubjectBox.height * 0.56
      ).clamped()

      var currentBackgroundPoints: [NormalizedPoint] = []
      var correspondingPrevious: [NormalizedPoint] = []
      var nextBackgroundObservations: [VNDetectedObjectObservation] = []
      var backgroundConfidences: [Double] = []

      for (requestIndex, request) in backgroundRequests.enumerated() {
        if let result = request.results?.first as? VNDetectedObjectObservation,
          result.confidence >= Float(VideoAnalysisConfiguration.Tracking.backgroundMinimumConfidence)
        {
          let point = uiCenter(result)
          // Écarte les points qui ont glissé dans la boîte du perchiste.
          if !currentSubjectBox.contains(point, padding: 0.035) {
            currentBackgroundPoints.append(point)
            correspondingPrevious.append(previousBackgroundPoints[requestIndex])
            nextBackgroundObservations.append(result)
            backgroundConfidences.append(Double(result.confidence))
          }
        }
      }

      guard currentBackgroundPoints.count >= 4 else {
        if raw.count < 5 { throw AnalysisError.insufficientBackground }
        break
      }

      let destination = correspondingPrevious.map {
        MetricRunwayPoint(xMeters: $0.x, yMeters: $0.y)
      }
      let robust = try? HomographyMath.robustImageToRunway(
        source: currentBackgroundPoints,
        destination: destination,
        thresholdMeters: 0.028,
        maximumTrials: 56
      )

      let stabilizedCurrent: NormalizedPoint
      let backgroundQuality: Double
      if let robust, let projected = robust.matrix.project(currentSubjectCenter) {
        stabilizedCurrent = projected
        backgroundQuality = Double(robust.inlierIndices.count) / Double(currentBackgroundPoints.count)
      } else {
        // Repli translation robuste : médiane des déplacements du décor.
        let deltasX = zip(currentBackgroundPoints, correspondingPrevious).map { $0.x - $1.x }
        let deltasY = zip(currentBackgroundPoints, correspondingPrevious).map { $0.y - $1.y }
        let cameraDX = median(deltasX)
        let cameraDY = median(deltasY)
        stabilizedCurrent = NormalizedPoint(
          x: currentSubjectCenter.x - cameraDX,
          y: currentSubjectCenter.y - cameraDY
        )
        backgroundQuality = 0.42
      }

      let scale = metersPerPixel(
        athleteHeightMeters: athleteHeightMeters,
        subjectHeightNormalized: currentSubjectBox.height,
        videoHeight: Double(videoSize.height)
      )
      let dxPixels = (stabilizedCurrent.x - previousSubjectCenter.x) * Double(videoSize.width)
      let dyPixels = (stabilizedCurrent.y - previousSubjectCenter.y) * Double(videoSize.height)
      accumulatedX += dxPixels * scale.value
      accumulatedY += -dyPixels * scale.value

      let meanBackgroundConfidence = backgroundConfidences.isEmpty
        ? 0 : backgroundConfidences.reduce(0, +) / Double(backgroundConfidences.count)
      let confidence = min(
        max(
          Double(trackedSubject.confidence) * 0.46
            + backgroundQuality * 0.32
            + meanBackgroundConfidence * 0.12
            + scale.confidence * 0.10,
          0
        ),
        1
      )

      raw.append(
        RawPoint(
          time: seconds,
          imagePoint: currentSubjectCenter,
          xMeters: accumulatedX,
          yMeters: accumulatedY,
          confidence: confidence,
          scaleConfidence: scale.confidence
        )
      )

      if index.isMultiple(of: subjectReanchorInterval),
        let redetected = redetectSubject(in: image, near: currentSubjectBox)
      {
        // Periodic global re-detection prevents a locally drifting box from becoming the new truth.
        subjectObservation = redetected
      } else {
        subjectObservation = trackedSubject
      }
      // Conserve uniquement les observations fiables et les densifie si nécessaire.
      backgroundObservations = nextBackgroundObservations
      previousBackgroundPoints = currentBackgroundPoints
      if backgroundObservations.count < 7 {
        let refreshed = makeBackgroundObservations(excluding: currentSubjectBox)
        backgroundObservations = refreshed
        previousBackgroundPoints = refreshed.map(uiCenter)
      }
      previousSubjectCenter = currentSubjectCenter
    }

    guard raw.count >= 5 else { throw AnalysisError.insufficientSamples }
    var samples = calculateKinematics(raw)
    samples = smooth(samples)
    guard samples.count >= 5 else { throw AnalysisError.insufficientSamples }

    let speeds = samples.map { abs($0.horizontalVelocity) }.filter(\.isFinite).sorted()
    let topCount = max(Int(Double(speeds.count) * 0.20), 1)
    let representative = median(Array(speeds.suffix(topCount)))
    let peak = speeds.last ?? 0
    let averageConfidence = samples.map(\.confidence).reduce(0, +) / Double(samples.count)
    let seed = candidate.pelvisPoint ?? candidate.boundingBox.center

    return MotionAnalysisResult(
      samples: samples,
      startTime: startTime,
      endTime: endTime,
      calibration: VideoCalibration(
        start: .init(x: candidate.boundingBox.midX, y: candidate.boundingBox.minY),
        end: .init(x: candidate.boundingBox.midX, y: candidate.boundingBox.maxY),
        distanceMeters: athleteHeightMeters
      ),
      trackingSeed: seed,
      representativeHorizontalSpeed: representative,
      peakHorizontalSpeed: peak,
      averageConfidence: averageConfidence,
      modelVersion: "Vision sujet + stabilisation décor + échelle anthropométrique v1",
      dynamicCalibration: nil,
      measurementMode: .athleteScale,
      referenceDescription: String(
        format: "Taille athlète %.2f m · décor stabilisé · sans origine butoir",
        athleteHeightMeters
      )
    )
  }

  private func redetectSubject(
    in image: CGImage,
    near currentSubject: NormalizedRect
  ) -> VNDetectedObjectObservation? {
    let request = VNDetectHumanRectanglesRequest()
    let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
    guard (try? handler.perform([request])) != nil else { return nil }
    let observations = request.results ?? []
    guard !observations.isEmpty else { return nil }

    let currentCenter = currentSubject.center
    let best = observations.max { lhs, rhs in
      redetectionScore(lhs.boundingBox, currentCenter: currentCenter, currentSubject: currentSubject)
        < redetectionScore(rhs.boundingBox, currentCenter: currentCenter, currentSubject: currentSubject)
    }
    guard let best else { return nil }
    let score = redetectionScore(best.boundingBox, currentCenter: currentCenter, currentSubject: currentSubject)
    guard score > 0.15 else { return nil }
    return VNDetectedObjectObservation(boundingBox: best.boundingBox)
  }

  private func redetectionScore(
    _ visionBox: CGRect,
    currentCenter: NormalizedPoint,
    currentSubject: NormalizedRect
  ) -> Double {
    let box = uiRect(visionBox)
    let distance = hypot(box.center.x - currentCenter.x, box.center.y - currentCenter.y)
    let overlap = intersectionOverUnion(box, currentSubject)
    let sizeRatio = min(box.width * box.height, currentSubject.width * currentSubject.height)
      / max(max(box.width * box.height, currentSubject.width * currentSubject.height), 1e-6)
    return overlap * 0.60 + sizeRatio * 0.20 + max(1 - distance / 0.45, 0) * 0.20
  }

  private func intersectionOverUnion(_ a: NormalizedRect, _ b: NormalizedRect) -> Double {
    let left = max(a.minX, b.minX)
    let right = min(a.maxX, b.maxX)
    let top = max(a.minY, b.minY)
    let bottom = min(a.maxY, b.maxY)
    let intersection = max(right - left, 0) * max(bottom - top, 0)
    let union = a.width * a.height + b.width * b.height - intersection
    return union > 1e-9 ? intersection / union : 0
  }

  private func makeBackgroundObservations(excluding subject: NormalizedRect) -> [VNDetectedObjectObservation] {
    let columns = 6
    let rows = 4
    var observations: [VNDetectedObjectObservation] = []
    for row in 0..<rows {
      for column in 0..<columns {
        let point = NormalizedPoint(
          x: 0.07 + Double(column) * (0.86 / Double(columns - 1)),
          y: 0.10 + Double(row) * (0.76 / Double(rows - 1))
        )
        guard !subject.contains(point, padding: 0.09) else { continue }
        let side = 0.055
        let visionY = 1 - point.y
        observations.append(
          VNDetectedObjectObservation(
            boundingBox: CGRect(
              x: min(max(point.x - side * 0.5, 0), 1 - side),
              y: min(max(visionY - side * 0.5, 0), 1 - side),
              width: side,
              height: side
            )
          )
        )
      }
    }
    return observations
  }

  private func metersPerPixel(
    athleteHeightMeters: Double,
    subjectHeightNormalized: Double,
    videoHeight: Double
  ) -> (value: Double, confidence: Double) {
    let bodyPixels = max(subjectHeightNormalized * videoHeight, 24)
    // La boîte issue des articulations comprend un léger padding ; 0,88 rapproche
    // l'étendue visible nez-chevilles de la stature déclarée.
    let value = athleteHeightMeters * 0.88 / bodyPixels
    let confidence = min(max((bodyPixels - 30) / 260, 0.25), 0.90)
    return (value, confidence)
  }

  private func calculateKinematics(_ raw: [RawPoint]) -> [MotionSample] {
    var samples = raw.map {
      MotionSample(
        timeSeconds: $0.time,
        point: $0.imagePoint,
        confidence: min($0.confidence, $0.scaleConfidence),
        runwayX: $0.xMeters,
        runwayY: $0.yMeters,
        calibrationConfidence: $0.scaleConfidence,
        verticalIsEstimated: true
      )
    }
    guard samples.count >= 3 else { return samples }

    let firstX = raw.first?.xMeters ?? 0
    let lastX = raw.last?.xMeters ?? 0
    let direction = lastX >= firstX ? 1.0 : -1.0
    for index in samples.indices {
      let before = max(index - 1, 0)
      let after = min(index + 1, samples.count - 1)
      let dt = samples[after].timeSeconds - samples[before].timeSeconds
      guard dt > 0 else { continue }
      samples[index].horizontalVelocity = direction * (raw[after].xMeters - raw[before].xMeters) / dt
      samples[index].verticalVelocity = (raw[after].yMeters - raw[before].yMeters) / dt
    }
    for index in samples.indices {
      let before = max(index - 1, 0)
      let after = min(index + 1, samples.count - 1)
      let dt = samples[after].timeSeconds - samples[before].timeSeconds
      guard dt > 0 else { continue }
      let dvx = samples[after].horizontalVelocity - samples[before].horizontalVelocity
      let longitudinalAcceleration = dvx / dt
      // Do not combine longitudinal metric motion with an image-derived vertical estimate.
      // `acceleration` remains for backward decoding but now represents |ax| only.
      samples[index].horizontalAcceleration = longitudinalAcceleration
      samples[index].verticalAcceleration = nil
      samples[index].acceleration = abs(longitudinalAcceleration)
    }
    return samples
  }

  private func smooth(_ samples: [MotionSample]) -> [MotionSample] {
    guard samples.count >= 5 else { return samples }
    return samples.indices.map { index in
      let window = samples[max(0, index - 2)...min(samples.count - 1, index + 2)]
      var output = samples[index]
      output.horizontalVelocity = median(window.map(\.horizontalVelocity))
      output.verticalVelocity = median(window.map(\.verticalVelocity))
      output.acceleration = median(window.map(\.acceleration))
      return output
    }
  }

  private func visionRect(from rect: NormalizedRect) -> CGRect {
    CGRect(x: rect.x, y: 1 - rect.maxY, width: rect.width, height: rect.height)
  }

  private func uiRect(_ visionRect: CGRect) -> NormalizedRect {
    NormalizedRect(
      x: visionRect.minX,
      y: 1 - visionRect.maxY,
      width: visionRect.width,
      height: visionRect.height
    ).clamped()
  }

  private func uiCenter(_ observation: VNDetectedObjectObservation) -> NormalizedPoint {
    NormalizedPoint(x: observation.boundingBox.midX, y: 1 - observation.boundingBox.midY).clamped()
  }

  private func median(_ values: [Double]) -> Double {
    let sorted = values.filter(\.isFinite).sorted()
    guard !sorted.isEmpty else { return 0 }
    let middle = sorted.count / 2
    if sorted.count.isMultiple(of: 2) {
      return (sorted[middle - 1] + sorted[middle]) * 0.5
    }
    return sorted[middle]
  }
}
