import Foundation
import SwiftData
import SwiftUI
import UniformTypeIdentifiers

struct VaultBackupDocument: FileDocument {
  static var readableContentTypes: [UTType] { [.json] }

  var data: Data

  init(data: Data = Data()) {
    self.data = data
  }

  init(configuration: ReadConfiguration) throws {
    self.data = configuration.file.regularFileContents ?? Data()
  }

  func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
    FileWrapper(regularFileWithContents: data)
  }
}


enum VaultBackupScope: String, CaseIterable, Identifiable {
  case complete
  case performanceOnly
  case videoAnalysisOnly

  var id: String { rawValue }
  var title: String {
    switch self {
    case .complete: "Sauvegarde complète"
    case .performanceOnly: "Profil + performances"
    case .videoAnalysisOnly: "Analyses vidéo uniquement"
    }
  }
}

@MainActor
enum VaultDataExportService {
  static func makeBackup(context: ModelContext, scope: VaultBackupScope = .complete) throws -> Data {
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

    func iso(_ date: Date?) -> Any {
      guard let date else { return NSNull() }
      return formatter.string(from: date)
    }

    func uuid(_ value: UUID?) -> Any {
      guard let value else { return NSNull() }
      return value.uuidString
    }

    func optional(_ value: Any?) -> Any {
      value ?? NSNull()
    }

    let profiles = try context.fetch(FetchDescriptor<AthleteProfile>()).map {
      [
        "id": $0.id.uuidString,
        "displayName": $0.displayName,
        "category": $0.category,
        "dateOfBirth": iso($0.dateOfBirth),
        "heightCM": $0.heightCM,
        "bodyWeightKG": $0.bodyWeightKG,
        "currentPRCM": $0.currentPRCM,
        "trainingPRCM": $0.trainingPRCM,
        "targetHeightCM": $0.targetHeightCM,
        "legacyCurrentApproachSpeedCache": $0.currentApproachSpeed,
        "targetApproachSpeed": $0.targetApproachSpeed,
        "theoreticalMaximumCM": $0.theoreticalMaximumCM,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let goals = try context.fetch(FetchDescriptor<GoalRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "title": $0.title,
        "targetHeightCM": $0.targetHeightCM,
        "targetDate": iso($0.targetDate),
        "isActive": $0.isActive,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let goalPillars = try context.fetch(FetchDescriptor<GoalPillarRecord>()).map {
      [
        "id": $0.id.uuidString,
        "goalID": $0.goalID.uuidString,
        "title": $0.title,
        "iconSymbol": $0.iconSymbol,
        "sortIndex": $0.sortIndex,
        "accentHex": $0.accentHex,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let goalActions = try context.fetch(FetchDescriptor<GoalActionRecord>()).map {
      [
        "id": $0.id.uuidString,
        "pillarID": $0.pillarID.uuidString,
        "title": $0.title,
        "kind": $0.kindRaw,
        "targetValue": optional($0.targetValue),
        "unit": $0.unit,
        "recurrence": $0.recurrence,
        "currentValue": $0.currentValue,
        "isCompleted": $0.isCompleted,
        "sortIndex": $0.sortIndex,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let checkIns = try context.fetch(FetchDescriptor<ActionCheckInRecord>()).map {
      [
        "id": $0.id.uuidString,
        "actionID": $0.actionID.uuidString,
        "date": iso($0.date),
        "completed": $0.completed,
        "value": optional($0.value),
        "note": $0.note,
      ] as [String: Any]
    }

    let poles = try context.fetch(FetchDescriptor<PoleRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "manufacturer": $0.manufacturer,
        "modelName": $0.modelName,
        "lengthCM": $0.lengthCM,
        "weightKG": $0.weightKG,
        "flexCM": $0.flexCM,
        "nickname": $0.nickname,
        "progressionOrder": $0.progressionOrder,
        "isActive": $0.isActive,
        "notes": $0.notes,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let poleProgress = try context.fetch(FetchDescriptor<PoleApproachProgressRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "poleID": $0.poleID.uuidString,
        "approachSteps": $0.approachSteps,
        "state": $0.stateRaw,
        "validAttempts": $0.validAttempts,
        "clears": $0.clears,
        "firstSuccessfulUse": iso($0.firstSuccessfulUse),
        "masteredAt": iso($0.masteredAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let approaches = try context.fetch(FetchDescriptor<ApproachProfileRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "approachSteps": $0.approachSteps,
        "startMarkM": $0.startMarkM,
        "intermediateMarkM": optional($0.intermediateMarkM),
        "finalCheckMarkM": optional($0.finalCheckMarkM),
        "expectedTakeoffMarkM": optional($0.expectedTakeoffMarkM),
        "notes": $0.notes,
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let sessions = try context.fetch(FetchDescriptor<VaultSessionRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "kind": $0.kindRaw,
        "startedAt": iso($0.startedAt),
        "endedAt": iso($0.endedAt),
        "title": $0.title,
        "notes": $0.notes,
        "locationName": $0.locationName,
        "environment": $0.environmentRaw,
        "weather": $0.weatherRaw,
        "windDirection": $0.windDirectionRaw,
        "windSpeedMPS": optional($0.windSpeedMPS),
        "temperatureC": optional($0.temperatureC),
        "energyLevel": $0.energyLevel,
        "sessionGoal": $0.sessionGoal,
        "isActive": $0.isActive,
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let attempts = try context.fetch(FetchDescriptor<AttemptRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "sessionID": $0.sessionID.uuidString,
        "poleID": $0.poleID.uuidString,
        "result": $0.resultRaw,
        "diagnosticsCSV": $0.diagnosticsCSV,
        "barHeightCM": $0.barHeightCM,
        "approachSteps": $0.approachSteps,
        "attemptNumber": optional($0.attemptNumber),
        "sequenceIndex": $0.sequenceIndex,
        "note": $0.note,
        "technicalRating": $0.technicalRatingRaw,
        "gripHeightM": optional($0.gripHeightM),
        "runUpDistanceM": optional($0.runUpDistanceM),
        "midMarkM": optional($0.midMarkM),
        "standardsOffsetCM": optional($0.standardsOffsetCM),
        "voiceTranscript": $0.voiceTranscript,
        "actualTakeoffMarkM": optional($0.actualTakeoffMarkM),
        "approachSpeedMPS": optional($0.approachSpeedMPS),
        "approachSpeedKind": optional($0.approachSpeedKindRaw),
        "approachSpeedSource": $0.approachSpeedSource,
        "takeoffSpeedMPS": optional($0.takeoffSpeedMPS),
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
        "deletedAt": iso($0.deletedAt),
      ] as [String: Any]
    }

    let physicalMetrics = try context.fetch(FetchDescriptor<PhysicalMetricRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "kind": $0.kindRaw,
        "value": $0.value,
        "unit": $0.unit,
        "source": $0.source,
        "protocolName": $0.protocolName,
        "approachSteps": optional($0.approachSteps),
        "measuredAt": iso($0.measuredAt),
        "note": $0.note,
        "algorithmVersion": $0.algorithmVersion,
        "captureFrameRate": optional($0.captureFrameRate),
        "analysisFrameRate": optional($0.analysisFrameRate),
        "analysisStartTime": optional($0.analysisStartTime),
        "analysisEndTime": optional($0.analysisEndTime),
        "sampleCount": optional($0.sampleCount),
        "qualityStatus": $0.qualityStatusRaw,
        "isEstimated": $0.isEstimated,
        "userVerified": $0.userVerified,
        "parametersJSON": $0.parametersJSON,
      ] as [String: Any]
    }

    let drills = try context.fetch(FetchDescriptor<DrillRecord>()).map {
      [
        "id": $0.id.uuidString,
        "title": $0.title,
        "phase": $0.phaseRaw,
        "faultsCSV": $0.faultsCSV,
        "coachingCues": $0.coachingCues,
        "commonErrors": $0.commonErrors,
        "sets": $0.sets,
        "repetitions": $0.repetitions,
        "restSeconds": $0.restSeconds,
        "difficulty": $0.difficulty,
        "equipment": $0.equipment,
        "videoURLString": $0.videoURLString,
        "safetyNote": $0.safetyNote,
        "isPublished": $0.isPublished,
        "sortIndex": $0.sortIndex,
      ] as [String: Any]
    }

    let exerciseVideos = try context.fetch(FetchDescriptor<ExerciseVideoRecord>()).map {
      [
        "id": $0.id.uuidString,
        "category": $0.categoryRaw,
        "url": $0.urlString,
        "title": $0.title,
        "description": $0.videoDescription,
        "thumbnailURL": optional($0.thumbnailURLString),
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let drillCompletions = try context.fetch(FetchDescriptor<DrillCompletionRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "drillID": $0.drillID.uuidString,
        "sessionID": uuid($0.sessionID),
        "completedSets": $0.completedSets,
        "completedRepetitions": $0.completedRepetitions,
        "rating": $0.rating,
        "note": $0.note,
        "completedAt": iso($0.completedAt),
      ] as [String: Any]
    }

    let videoClips = try context.fetch(FetchDescriptor<VideoClipRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "attemptID": uuid($0.attemptID),
        "localURLString": $0.localURLString,
        "originalFilename": $0.originalFilename,
        "durationSeconds": $0.durationSeconds,
        "frameRate": $0.frameRate,
        "phase": optional($0.phaseRaw),
        "pencilDrawingDataBase64": optional($0.pencilDrawingData?.base64EncodedString()),
        "createdAt": iso($0.createdAt),
        "updatedAt": iso($0.updatedAt),
      ] as [String: Any]
    }

    let vectors = try context.fetch(FetchDescriptor<VectorAnnotationRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "videoID": $0.videoID.uuidString,
        "timeSeconds": $0.timeSeconds,
        "label": $0.label,
        "kind": $0.kindRaw,
        "startX": $0.startX,
        "startY": $0.startY,
        "endX": $0.endX,
        "endY": $0.endY,
        "source": $0.source,
        "createdAt": iso($0.createdAt),
      ] as [String: Any]
    }

    let phaseMarkers = try context.fetch(FetchDescriptor<PhaseMarkerRecord>()).map {
      [
        "id": $0.id.uuidString,
        "athleteID": $0.athleteID.uuidString,
        "videoID": $0.videoID.uuidString,
        "phase": $0.phaseRaw,
        "timeSeconds": $0.timeSeconds,
        "source": $0.source,
        "confidence": optional($0.confidence),
        "createdAt": iso($0.createdAt),
      ] as [String: Any]
    }

    let syncOperations = try context.fetch(FetchDescriptor<SyncOperationRecord>()).map {
      [
        "id": $0.id.uuidString,
        "entityType": $0.entityType,
        "entityID": $0.entityID.uuidString,
        "operation": $0.operation,
        "payloadJSON": $0.payloadJSON,
        "createdAt": iso($0.createdAt),
        "retryCount": $0.retryCount,
        "lastError": $0.lastError,
      ] as [String: Any]
    }

    var payload: [String: Any] = [
      "format": "VaultRoadmapBackup",
      "schemaVersion": 6,
      "exportedAt": iso(Date()),
      "scope": scope.rawValue,
      "videoFilesIncluded": false,
    ]

    switch scope {
    case .complete:
      payload.merge([
        "athleteProfiles": profiles, "goals": goals, "goalPillars": goalPillars,
        "goalActions": goalActions, "actionCheckIns": checkIns, "poles": poles,
        "poleApproachProgress": poleProgress, "approachProfiles": approaches,
        "sessions": sessions, "attempts": attempts, "physicalMetrics": physicalMetrics,
        "drills": drills, "exerciseVideos": exerciseVideos,
        "drillCompletions": drillCompletions,
        "videoClipMetadata": videoClips, "vectors": vectors, "phaseMarkers": phaseMarkers,
        "pendingSyncOperations": syncOperations,
      ]) { _, new in new }
    case .performanceOnly:
      payload.merge([
        "athleteProfiles": profiles, "goals": goals, "goalPillars": goalPillars,
        "goalActions": goalActions, "actionCheckIns": checkIns, "poles": poles,
        "poleApproachProgress": poleProgress, "approachProfiles": approaches,
        "sessions": sessions, "attempts": attempts, "physicalMetrics": physicalMetrics,
      ]) { _, new in new }
    case .videoAnalysisOnly:
      payload.merge([
        "videoClipMetadata": videoClips, "vectors": vectors, "phaseMarkers": phaseMarkers,
      ]) { _, new in new }
    }

    guard JSONSerialization.isValidJSONObject(payload) else {
      throw ExportError.invalidPayload
    }

    return try JSONSerialization.data(
      withJSONObject: payload,
      options: [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
    )
  }

  static func suggestedFilename(profile: AthleteProfile?) -> String {
    let name = (profile?.displayName ?? "Athlète")
      .replacingOccurrences(of: " ", with: "-")
      .filter { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" }
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.dateFormat = "yyyy-MM-dd"
    let date = formatter.string(from: Date())
    return "VaultRoadmap-\(name.isEmpty ? "Athlète" : name)-\(date)"
  }

  enum ExportError: LocalizedError {
    case invalidPayload

    var errorDescription: String? {
      switch self {
      case .invalidPayload:
        "Les données locales n’ont pas pu être converties en sauvegarde JSON valide."
      }
    }
  }
}
