import Foundation

/// Recalcule la cinématique à partir de points de bassin explicitement confirmés
/// par l'utilisateur toutes les 0,1 s. La stabilisation et l'échelle de l'analyse
/// automatique restent la référence, mais les erreurs de suivi du sujet sont remplacées
/// par les positions manuelles.
actor ManualPelvisMotionAnalysisService {
  enum ValidationError: LocalizedError {
    case incompleteCheckpoints
    case insufficientSamples
    case invalidScale
    case invalidAthleteHeight

    var errorDescription: String? {
      switch self {
      case .incompleteCheckpoints:
        "Confirmez tous les points de bassin avant de recalculer les Mesures avancées."
      case .insufficientSamples:
        "Au moins quatre positions espacées de 0,1 s sont nécessaires."
      case .invalidScale:
        "L'analyse automatique ne contient pas d'échelle exploitable. Relancez d'abord le mode sans butoir."
      case .invalidAthleteHeight:
        "La taille de l'athlète doit être comprise entre 1,20 m et 2,30 m."
      }
    }
  }

  private struct CorrectedPosition {
    var time: Double
    var point: NormalizedPoint
    var x: Double
    var y: Double
    var confidence: Double
    var calibrationConfidence: Double
  }

  func recalculate(
    baseline: MotionAnalysisResult,
    validation: PelvisValidationSession,
    athleteHeightMeters: Double,
    videoSize: CGSize
  ) throws -> MotionAnalysisResult {
    guard athleteHeightMeters >= 1.20, athleteHeightMeters <= 2.30 else {
      throw ValidationError.invalidAthleteHeight
    }
    guard validation.isComplete else { throw ValidationError.incompleteCheckpoints }
    let checkpoints = validation.checkpoints.sorted { $0.timeSeconds < $1.timeSeconds }
    guard checkpoints.count >= 4 else { throw ValidationError.insufficientSamples }

    let width = max(Double(videoSize.width), 1)
    let height = max(Double(videoSize.height), 1)
    let scale = baseline.calibration.metersPerPixel(in: videoSize)
      ?? fallbackMetersPerPixel(
        athleteHeightMeters: athleteHeightMeters,
        baseline: baseline,
        videoHeight: height
      )
    guard scale.isFinite, scale > 0, scale < 0.05 else { throw ValidationError.invalidScale }

    var corrected: [CorrectedPosition] = []
    corrected.reserveCapacity(checkpoints.count)

    for checkpoint in checkpoints {
      guard let base = baseline.sample(nearest: checkpoint.timeSeconds) else { continue }
      let confirmed = checkpoint.effectivePoint
      let deltaX = (confirmed.x - base.point.x) * width
      let deltaY = (confirmed.y - base.point.y) * height
      let baseX = base.runwayX ?? 0
      let baseY = base.runwayY ?? 0
      // The point has been explicitly verified by the user; do not invent a statistical
      // confidence for that manual action. The remaining quantitative quality is the
      // quality of the metric calibration/stabilization inherited from the baseline.
      let metricQuality = min(max(base.calibrationConfidence ?? baseline.averageConfidence, 0), 1)

      corrected.append(
        CorrectedPosition(
          time: checkpoint.timeSeconds,
          point: confirmed,
          x: baseX + deltaX * scale,
          y: baseY - deltaY * scale,
          confidence: metricQuality,
          calibrationConfidence: metricQuality
        )
      )
    }

    guard corrected.count >= 4 else { throw ValidationError.insufficientSamples }
    // Les positions sont laissées intactes : la régression temporelle ci-dessous
    // filtre le bruit sans déplacer les extrémités de la séquence.
    let samples = calculateKinematics(corrected)
    guard samples.count >= 4 else { throw ValidationError.insufficientSamples }

    let speedValues = samples.map { abs($0.horizontalVelocity) }
      .filter { $0.isFinite && $0 >= 0 }
      .sorted()
    let elapsed = max((corrected.last?.time ?? 0) - (corrected.first?.time ?? 0), 0.001)
    let displacement = abs((corrected.last?.x ?? 0) - (corrected.first?.x ?? 0))
    let representative = displacement / elapsed
    let peak = percentile(speedValues, fraction: 0.95)
    let averageConfidence = samples.map(\.confidence).reduce(0, +) / Double(samples.count)

    var updatedValidation = validation
    updatedValidation.athleteHeightMeters = athleteHeightMeters
    updatedValidation.modelVersion = "Validation bassin 10 Hz + correction du suivi v3"

    return MotionAnalysisResult(
      samples: samples,
      startTime: checkpoints.first?.timeSeconds ?? validation.startTime,
      endTime: checkpoints.last?.timeSeconds ?? validation.endTime,
      calibration: baseline.calibration,
      trackingSeed: checkpoints.first?.effectivePoint ?? baseline.trackingSeed,
      representativeHorizontalSpeed: representative,
      peakHorizontalSpeed: peak,
      averageConfidence: averageConfidence,
      modelVersion: "Bassin confirmé à 10 Hz + stabilisation caméra v3 · vitesse moyenne de zone",
      dynamicCalibration: baseline.dynamicCalibration,
      takeoffMeasurement: baseline.takeoffMeasurement,
      measurementMode: baseline.measurementMode ?? .athleteScale,
      referenceDescription: String(
        format: "Bassin confirmé manuellement toutes les 0,1 s · taille %.2f m · stabilisation automatique conservée",
        athleteHeightMeters
      ),
      pelvisValidation: updatedValidation
    )
  }

  private func fallbackMetersPerPixel(
    athleteHeightMeters: Double,
    baseline: MotionAnalysisResult,
    videoHeight: Double
  ) -> Double {
    let normalizedHeight = abs(baseline.calibration.end.y - baseline.calibration.start.y)
    let bodyPixels = max(normalizedHeight * videoHeight, 24)
    return athleteHeightMeters * 0.88 / bodyPixels
  }

  private func smoothPositions(_ positions: [CorrectedPosition]) -> [CorrectedPosition] {
    guard positions.count >= 5 else { return positions }
    return positions.indices.map { index in
      let lower = max(index - 2, 0)
      let upper = min(index + 2, positions.count - 1)
      let window = Array(positions[lower...upper])
      let distances = window.map { hypot($0.x - positions[index].x, $0.y - positions[index].y) }
      let distanceMedian = median(distances)
      let accepted = zip(window, distances).filter { $0.1 <= max(distanceMedian * 3.5, 0.035) }.map { $0.0 }
      let usable = accepted.isEmpty ? window : accepted
      let weights = usable.map { max($0.confidence, 0.35) }
      let totalWeight = max(weights.reduce(0, +), 0.001)
      var output = positions[index]
      output.x = zip(usable, weights).map { $0.0.x * $0.1 }.reduce(0, +) / totalWeight
      output.y = zip(usable, weights).map { $0.0.y * $0.1 }.reduce(0, +) / totalWeight
      return output
    }
  }

  private func calculateKinematics(_ positions: [CorrectedPosition]) -> [MotionSample] {
    let direction = (positions.last?.x ?? 0) >= (positions.first?.x ?? 0) ? 1.0 : -1.0
    var horizontalVelocities: [Double] = []
    var verticalVelocities: [Double] = []
    horizontalVelocities.reserveCapacity(positions.count)
    verticalVelocities.reserveCapacity(positions.count)

    for index in positions.indices {
      let horizontal = direction * regressionSlope(
        positions: positions,
        index: index,
        radius: 3,
        value: { $0.x }
      )
      let vertical = regressionSlope(
        positions: positions,
        index: index,
        radius: 3,
        value: { $0.y }
      )
      horizontalVelocities.append(horizontal)
      verticalVelocities.append(vertical)
    }

    let filteredHorizontal = medianFilter(
      winsorize(horizontalVelocities, minimumHalfRange: 2.5),
      radius: 1
    )
    let filteredVertical = medianFilter(
      winsorize(verticalVelocities, minimumHalfRange: 2.0),
      radius: 1
    )
    var longitudinalAccelerations: [Double] = []
    longitudinalAccelerations.reserveCapacity(positions.count)

    for index in positions.indices {
      let ax = regressionSlope(
        times: positions.map(\.time),
        values: filteredHorizontal,
        index: index,
        radius: 3
      )
      longitudinalAccelerations.append(ax)
    }
    let accelerationCenter = median(longitudinalAccelerations)
    let accelerationMAD = median(longitudinalAccelerations.map { abs($0 - accelerationCenter) })
    let robustHalfRange = max(4.5 * 1.4826 * accelerationMAD, 15.0)
    let filteredLongitudinalAcceleration = medianFilter(
      longitudinalAccelerations.map { min(max($0, accelerationCenter - robustHalfRange), accelerationCenter + robustHalfRange) },
      radius: 2
    )

    return positions.indices.map { index in
      MotionSample(
        timeSeconds: positions[index].time,
        point: positions[index].point,
        confidence: positions[index].confidence,
        horizontalVelocity: filteredHorizontal[index],
        verticalVelocity: filteredVertical[index],
        acceleration: abs(filteredLongitudinalAcceleration[index]),
        runwayX: positions[index].x,
        runwayY: positions[index].y,
        calibrationConfidence: positions[index].calibrationConfidence,
        verticalIsEstimated: true,
        horizontalAcceleration: filteredLongitudinalAcceleration[index],
        verticalAcceleration: nil
      )
    }
  }

  private func regressionSlope(
    positions: [CorrectedPosition],
    index: Int,
    radius: Int,
    value: (CorrectedPosition) -> Double
  ) -> Double {
    regressionSlope(
      times: positions.map(\.time),
      values: positions.map(value),
      index: index,
      radius: radius
    )
  }

  private func regressionSlope(
    times: [Double],
    values: [Double],
    index: Int,
    radius: Int
  ) -> Double {
    guard times.count == values.count, !times.isEmpty else { return 0 }
    let lower = max(index - radius, 0)
    let upper = min(index + radius, times.count - 1)
    let localTimes = Array(times[lower...upper])
    let localValues = Array(values[lower...upper])
    guard localTimes.count >= 2 else { return 0 }
    let meanTime = localTimes.reduce(0, +) / Double(localTimes.count)
    let meanValue = localValues.reduce(0, +) / Double(localValues.count)
    var numerator = 0.0
    var denominator = 0.0
    for (time, value) in zip(localTimes, localValues) {
      numerator += (time - meanTime) * (value - meanValue)
      denominator += (time - meanTime) * (time - meanTime)
    }
    guard denominator > 1e-10 else { return 0 }
    return numerator / denominator
  }


  private func winsorize(_ values: [Double], minimumHalfRange: Double) -> [Double] {
    let center = median(values)
    let mad = median(values.map { abs($0 - center) })
    let halfRange = max(4.5 * 1.4826 * mad, minimumHalfRange)
    return values.map { min(max($0, center - halfRange), center + halfRange) }
  }

  private func medianFilter(_ values: [Double], radius: Int) -> [Double] {
    values.indices.map { index in
      let lower = max(index - radius, 0)
      let upper = min(index + radius, values.count - 1)
      return median(Array(values[lower...upper]))
    }
  }

  private func median(_ values: [Double]) -> Double {
    let sorted = values.filter(\.isFinite).sorted()
    guard !sorted.isEmpty else { return 0 }
    let middle = sorted.count / 2
    if sorted.count.isMultiple(of: 2) {
      return (sorted[middle - 1] + sorted[middle]) * 0.5
    }
    return sorted[middle]
  }

  private func percentile(_ sortedValues: [Double], fraction: Double) -> Double {
    guard !sortedValues.isEmpty else { return 0 }
    let clamped = min(max(fraction, 0), 1)
    let position = clamped * Double(sortedValues.count - 1)
    let lower = Int(position.rounded(.down))
    let upper = Int(position.rounded(.up))
    if lower == upper { return sortedValues[lower] }
    let weight = position - Double(lower)
    return sortedValues[lower] * (1 - weight) + sortedValues[upper] * weight
  }
}
