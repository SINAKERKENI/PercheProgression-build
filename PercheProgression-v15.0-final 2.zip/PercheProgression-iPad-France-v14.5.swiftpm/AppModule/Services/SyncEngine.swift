import Foundation
import Observation
import SwiftData

enum SyncConfiguration {
  // Local-first build: do not create a fake remote queue until an authenticated backend is configured.
  static let isRemoteSyncEnabled = false
}

protocol SyncClient: Sendable {
  func push(operations: [SyncEnvelope]) async throws
}

struct SyncEnvelope: Codable, Sendable {
  let id: UUID
  let entityType: String
  let entityID: UUID
  let operation: String
  let payloadJSON: String
  let createdAt: Date
}

struct DisabledSyncClient: SyncClient {
  func push(operations: [SyncEnvelope]) async throws {
    // The native first version is deliberately local-first. Inject a real authenticated
    // client here when the backend contract is ready; trackside writes never wait for it.
  }
}

@MainActor
@Observable
final class SyncEngine {
  enum State: Equatable {
    case localOnly
    case syncing
    case synced(Date)
    case failed(String)
  }

  private(set) var state: State = .localOnly
  private let client: any SyncClient

  init(client: any SyncClient = DisabledSyncClient()) {
    self.client = client
  }

  func flush(context: ModelContext) async {
    guard SyncConfiguration.isRemoteSyncEnabled else {
      state = .localOnly
      return
    }
    let descriptor = FetchDescriptor<SyncOperationRecord>(
      sortBy: [SortDescriptor(\SyncOperationRecord.createdAt)]
    )
    let records: [SyncOperationRecord]
    do {
      records = try context.fetch(descriptor)
    } catch {
      state = .failed("Lecture de la file de synchronisation impossible : \(error.localizedDescription)")
      return
    }
    guard !records.isEmpty else {
      state = .localOnly
      return
    }

    state = .syncing
    let envelopes = records.map {
      SyncEnvelope(
        id: $0.id,
        entityType: $0.entityType,
        entityID: $0.entityID,
        operation: $0.operation,
        payloadJSON: $0.payloadJSON,
        createdAt: $0.createdAt
      )
    }

    do {
      try await client.push(operations: envelopes)
      // DisabledSyncClient intentionally leaves records queued. A production client
      // should return acknowledgements before deletion.
      state = .localOnly
    } catch {
      for record in records {
        record.retryCount += 1
        record.lastError = error.localizedDescription
      }
      PersistenceIssueCenter.shared.save(context)
      state = .failed(error.localizedDescription)
    }
  }
}
