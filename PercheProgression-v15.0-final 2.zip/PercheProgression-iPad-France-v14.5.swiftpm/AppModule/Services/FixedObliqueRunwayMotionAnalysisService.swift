import Foundation

/// Fixed-camera calibrated ground-plane workflow. Metric speed is always computed by
/// `PerspectiveAwareSpeedEngine`; this service only validates the fixed homography and supplies
/// manually confirmed ground observations.
actor FixedObliqueRunwayMotionAnalysisService {
  enum AnalysisError: LocalizedError {
    case incompleteValidation
    case invalidSegment
    case invalidGrid
    case insufficientSamples

    var errorDescription: String? {
      switch self {
      case .incompleteValidation: "Confirmez tous les points de mesure avant le calcul final."
      case .invalidSegment: "La zone de mesure doit durer au moins 0,40 seconde."
      case .invalidGrid: "Calibration insuffisante : ajustez les quatre coins sur un quadrilatère réel du sol et vérifiez ses dimensions."
      case .insufficientSamples: "Pas assez de points au sol valides pour calculer la vitesse longitudinale."
      }
    }
  }

  func analyze(
    validation: PelvisValidationSession,
    grid: RunwayGridCalibration,
    trackingPoint: FixedObliqueTrackingPoint,
    metricOrigin: FixedRunwayMetricOrigin = .box
  ) throws -> MotionAnalysisResult {
    guard validation.isComplete else { throw AnalysisError.incompleteValidation }
    guard validation.endTime - validation.startTime >= 0.40 else { throw AnalysisError.invalidSegment }
    guard grid.isGeometricallyUsable else { throw AnalysisError.invalidGrid }
    let homography: Matrix3x3
    do { homography = try HomographyMath.imageToRunway(for: grid) }
    catch { throw AnalysisError.invalidGrid }

    let geometryQuality = gridGeometryQualityScore(grid)
    guard geometryQuality >= 0.35 else { throw AnalysisError.invalidGrid }
    let pointFactor = trackingPoint == .groundProjection ? 1.0 : 0.45
    let method: PerspectiveAwareSpeedEngine.GroundPointMethod = trackingPoint == .groundProjection
      ? .manualGroundPoint : .pelvisProjectedEstimate

    let observations = validation.checkpoints.sorted { $0.timeSeconds < $1.timeSeconds }.compactMap { checkpoint -> PerspectiveAwareSpeedEngine.Observation? in
      guard let metric = homography.projectMetric(checkpoint.effectivePoint) else { return nil }
      let userConfidence = checkpoint.state == .adjusted ? 1.0 : max(checkpoint.suggestionConfidence, 0.75)
      return PerspectiveAwareSpeedEngine.Observation(
        timeSeconds: checkpoint.timeSeconds,
        imagePoint: checkpoint.effectivePoint,
        runwayPoint: metric,
        trackingConfidence: userConfidence,
        groundPointConfidence: userConfidence * pointFactor,
        calibrationQuality: geometryQuality,
        anchorCount: 4,
        anchorStability: 1,
        homographyContinuity: 1,
        groundPointMethod: method
      )
    }
    guard observations.count >= 5 else { throw AnalysisError.insufficientSamples }

    let engine = try PerspectiveAwareSpeedEngine().analyze(
      observations, expectedStartTime: validation.startTime, expectedEndTime: validation.endTime
    )
    var quality = engine.quality
    if trackingPoint == .pelvisEstimate {
      quality.diagnostics.append("Bassin hors du plan du sol : parallaxe possible, résultat explicitement estimé")
    }

    var updated = validation
    updated.modelVersion = trackingPoint == .groundProjection
      ? "Point sol manuel · homographie fixe · PTS · v15"
      : "Bassin projeté estimé · homographie fixe · PTS · v15"

    let originDescription = metricOrigin == .box ? "origine butoir" : "origine relative"
    let reference = String(
      format: "Caméra fixe · homographie sol %.2f × %.2f m · %@ · %@",
      grid.zoneLengthMeters, grid.runwayWidthMeters, originDescription,
      trackingPoint == .groundProjection ? "point au sol" : "bassin estimé"
    )

    return MotionAnalysisResult(
      samples: engine.samples,
      startTime: engine.startTime,
      endTime: engine.endTime,
      calibration: VideoCalibration(start: grid.farLeft, end: grid.boxLeft, distanceMeters: grid.zoneLengthMeters),
      trackingSeed: observations.first?.imagePoint ?? .init(x: 0.5, y: 0.5),
      representativeHorizontalSpeed: engine.meanLongitudinalSpeed,
      peakHorizontalSpeed: engine.peakLongitudinalSpeed,
      averageConfidence: quality.components.overall * pointFactor,
      modelVersion: PerspectiveAwareSpeedEngine.algorithmVersion,
      measurementMode: .fixedObliqueRunway,
      referenceDescription: reference,
      pelvisValidation: updated,
      calibrationReferenceTime: validation.startTime,
      fixedRunwayGrid: grid,
      fixedRunwayMetricOrigin: metricOrigin,
      speedQualityReport: quality,
      groundPointMethodRaw: method.rawValue,
      timeBasisRaw: "presentation-timestamps"
    )
  }

  private func gridGeometryQualityScore(_ grid: RunwayGridCalibration) -> Double {
    func distance(_ a: NormalizedPoint, _ b: NormalizedPoint) -> Double { hypot(b.x-a.x, b.y-a.y) }
    let near = distance(grid.boxLeft, grid.boxRight)
    let far = distance(grid.farLeft, grid.farRight)
    let left = distance(grid.boxLeft, grid.farLeft)
    let right = distance(grid.boxRight, grid.farRight)
    guard near > 0.02, far > 0.015, left > 0.04, right > 0.04 else { return 0 }
    let area = min(max((grid.polygonArea - 0.004) / 0.07, 0), 1)
    let widthBalance = min(near,far)/max(near,far)
    let lengthBalance = min(left,right)/max(left,right)
    let longitudinalCoverage = min(min(left,right)/0.28,1)
    return min(max(area*0.42 + widthBalance*0.22 + lengthBalance*0.16 + longitudinalCoverage*0.20,0),1)
  }
}
