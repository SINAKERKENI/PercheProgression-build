import Foundation
@preconcurrency import LinkPresentation

enum ExerciseVideoURL {
  static func normalized(from rawValue: String) -> URL? {
    var value = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !value.isEmpty else { return nil }

    if !value.contains("://") {
      value = "https://\(value)"
    }

    guard var components = URLComponents(string: value),
      let scheme = components.scheme?.lowercased(),
      scheme == "https" || scheme == "http",
      components.host?.isEmpty == false
    else {
      return nil
    }

    components.scheme = scheme
    components.fragment = nil
    return components.url
  }

  static func displayHost(for url: URL) -> String {
    guard var host = url.host?.lowercased() else { return url.absoluteString }
    if host.hasPrefix("www.") { host.removeFirst(4) }
    return host
  }

  static func directFileTitle(for url: URL) -> String? {
    let supportedExtensions = ["mp4", "mov", "m4v", "webm"]
    guard supportedExtensions.contains(url.pathExtension.lowercased()) else { return nil }

    let rawName = url.deletingPathExtension().lastPathComponent.removingPercentEncoding
      ?? url.deletingPathExtension().lastPathComponent
    let readableName = rawName
      .replacingOccurrences(of: "[-_]+", with: " ", options: .regularExpression)
      .trimmingCharacters(in: .whitespacesAndNewlines)
    guard !readableName.isEmpty else { return nil }
    return readableName.prefix(1).uppercased() + String(readableName.dropFirst())
  }
}

enum ExerciseVideoMetadataError: LocalizedError {
  case titleUnavailable

  var errorDescription: String? {
    switch self {
    case .titleUnavailable:
      "Le site n’a pas fourni de titre. Vous pouvez le saisir manuellement."
    }
  }
}

struct ExerciseVideoMetadata: Sendable {
  let title: String
  let thumbnailURL: URL?
}

enum ExerciseVideoMetadataService {
  static func metadata(for url: URL) async throws -> ExerciseVideoMetadata {
    if let endpoint = oEmbedEndpoint(for: url),
      let metadata = try? await oEmbedMetadata(from: endpoint)
    {
      return metadata
    }

    if let title = try? await linkPresentationTitle(for: url) {
      return ExerciseVideoMetadata(title: title, thumbnailURL: nil)
    }

    if let fileTitle = ExerciseVideoURL.directFileTitle(for: url) {
      return ExerciseVideoMetadata(title: fileTitle, thumbnailURL: nil)
    }

    throw ExerciseVideoMetadataError.titleUnavailable
  }

  static func title(for url: URL) async throws -> String {
    try await metadata(for: url).title
  }

  private static func linkPresentationTitle(for url: URL) async throws -> String {
    let provider = LPMetadataProvider()
    provider.shouldFetchSubresources = false
    provider.timeout = 12

    let metadata = try await provider.startFetchingMetadata(for: url)
    guard let title = cleaned(metadata.title) else {
      throw ExerciseVideoMetadataError.titleUnavailable
    }
    return title
  }

  private static func oEmbedMetadata(from endpoint: URL) async throws -> ExerciseVideoMetadata {
    var request = URLRequest(url: endpoint)
    request.timeoutInterval = 12
    request.setValue("PercheProgression/14.3", forHTTPHeaderField: "User-Agent")

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let httpResponse = response as? HTTPURLResponse,
      200..<300 ~= httpResponse.statusCode
    else {
      throw ExerciseVideoMetadataError.titleUnavailable
    }

    let payload = try JSONDecoder().decode(OEmbedPayload.self, from: data)
    guard let title = cleaned(payload.title) else {
      throw ExerciseVideoMetadataError.titleUnavailable
    }
    return ExerciseVideoMetadata(
      title: title,
      thumbnailURL: payload.thumbnailURLString.flatMap { URL(string: $0) }
    )
  }

  private static func oEmbedEndpoint(for url: URL) -> URL? {
    guard let host = url.host?.lowercased() else { return nil }
    let baseURLString: String

    if host == "youtu.be" || host.hasSuffix("youtube.com") {
      baseURLString = "https://www.youtube.com/oembed"
    } else if host.hasSuffix("vimeo.com") {
      baseURLString = "https://vimeo.com/api/oembed.json"
    } else if host.hasSuffix("tiktok.com") {
      baseURLString = "https://www.tiktok.com/oembed"
    } else {
      return nil
    }

    guard var components = URLComponents(string: baseURLString) else { return nil }
    components.queryItems = [
      URLQueryItem(name: "url", value: url.absoluteString),
      URLQueryItem(name: "format", value: "json"),
    ]
    return components.url
  }

  private static func cleaned(_ value: String?) -> String? {
    guard let value else { return nil }
    let cleaned = value.trimmingCharacters(in: .whitespacesAndNewlines)
    return cleaned.isEmpty ? nil : cleaned
  }

  private struct OEmbedPayload: Decodable {
    let title: String
    let thumbnailURLString: String?

    private enum CodingKeys: String, CodingKey {
      case title
      case thumbnailURLString = "thumbnail_url"
    }
  }
}
