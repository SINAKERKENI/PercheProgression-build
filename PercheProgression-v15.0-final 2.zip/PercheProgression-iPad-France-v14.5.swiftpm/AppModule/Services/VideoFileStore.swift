
import CryptoKit
import Foundation

enum VideoStoreError: LocalizedError {
  case missingFile
  case invalidStorageKey
  case invalidSource

  var errorDescription: String? {
    switch self {
    case .missingFile:
      return "Le fichier vidéo associé à ce projet est introuvable."
    case .invalidStorageKey:
      return "La référence locale de cette vidéo est invalide."
    case .invalidSource:
      return "Le fichier sélectionné n’est pas une vidéo locale lisible. Téléchargez-le dans Fichiers puis réessayez."
    }
  }
}

struct ImportedVideoAsset: Sendable {
  let storageKey: String
  let url: URL
  let sha256: String?
}

actor VideoAssetStore {
  static let shared = VideoAssetStore()

  private func rootDirectory() throws -> URL {
    let fm = FileManager.default
    let support = try fm.url(
      for: .applicationSupportDirectory,
      in: .userDomainMask,
      appropriateFor: nil,
      create: true
    )
    let root = support
      .appendingPathComponent("PercheProgression", isDirectory: true)
      .appendingPathComponent("Media", isDirectory: true)
    try fm.createDirectory(at: root, withIntermediateDirectories: true)
    return root
  }

  func importVideo(from sourceURL: URL) throws -> ImportedVideoAsset {
    let projectID = UUID().uuidString
    let ext = sourceURL.pathExtension.isEmpty ? "mov" : sourceURL.pathExtension.lowercased()
    let storageKey = "\(projectID)/source.\(ext)"
    let destination = try rootDirectory().appendingPathComponent(storageKey)

    try FileManager.default.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if FileManager.default.fileExists(atPath: destination.path) {
      try FileManager.default.removeItem(at: destination)
    }
    try coordinatedCopy(from: sourceURL, to: destination)

    return ImportedVideoAsset(
      storageKey: storageKey,
      url: destination,
      sha256: sha256(of: destination)
    )
  }

  /// Reads document-provider and iCloud files through a coordinated access,
  /// then copies them into the app-owned media store while the security scope
  /// acquired by the view is still active.
  private func coordinatedCopy(from sourceURL: URL, to destination: URL) throws {
    let coordinator = NSFileCoordinator(filePresenter: nil)
    var coordinationError: NSError?
    var copyError: Error?

    coordinator.coordinate(
      readingItemAt: sourceURL,
      options: .withoutChanges,
      error: &coordinationError
    ) { coordinatedURL in
      do {
        let values = try coordinatedURL.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile != false else {
          throw VideoStoreError.invalidSource
        }
        if let fileSize = values.fileSize, fileSize == 0 {
          throw VideoStoreError.invalidSource
        }
        try FileManager.default.copyItem(at: coordinatedURL, to: destination)
      } catch {
        copyError = error
      }
    }

    if let copyError { throw copyError }
    if let coordinationError { throw coordinationError }
    guard FileManager.default.fileExists(atPath: destination.path) else {
      throw VideoStoreError.invalidSource
    }
  }

  func resolve(_ storageKey: String) throws -> URL {
    guard !storageKey.isEmpty, !storageKey.hasPrefix("/") else {
      throw VideoStoreError.invalidStorageKey
    }
    let root = try rootDirectory().standardizedFileURL
    let candidate = root.appendingPathComponent(storageKey).standardizedFileURL
    guard candidate.path.hasPrefix(root.path) else {
      throw VideoStoreError.invalidStorageKey
    }
    guard FileManager.default.fileExists(atPath: candidate.path) else {
      throw VideoStoreError.missingFile
    }
    return candidate
  }

  /// Migration douce des projets v10 : si l'ancien chemin absolu existe encore,
  /// le fichier est recopié dans le store stable v11 et une clé relative est retournée.
  func migrateLegacyAbsolutePath(_ path: String) throws -> ImportedVideoAsset {
    let url = URL(fileURLWithPath: path)
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw VideoStoreError.missingFile
    }
    return try importVideo(from: url)
  }

  func removeVideo(storageKey: String) throws {
    let url = try resolve(storageKey)
    let parent = url.deletingLastPathComponent()
    if FileManager.default.fileExists(atPath: parent.path) {
      try FileManager.default.removeItem(at: parent)
    }
  }

  func removeVideo(atLegacyURL url: URL) throws {
    guard FileManager.default.fileExists(atPath: url.path) else { return }
    try FileManager.default.removeItem(at: url)
  }

  func sha256(of url: URL) -> String? {
    guard let data = try? Data(contentsOf: url, options: .mappedIfSafe) else { return nil }
    return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
  }

  func matchesSHA256(url: URL, expected: String?) -> Bool {
    guard let expected, !expected.isEmpty, let actual = sha256(of: url) else { return true }
    return actual.caseInsensitiveCompare(expected) == .orderedSame
  }
}

// Alias temporaire pour ne pas casser les appels résiduels pendant la migration v10 → v11.
typealias VideoFileStore = VideoAssetStore
