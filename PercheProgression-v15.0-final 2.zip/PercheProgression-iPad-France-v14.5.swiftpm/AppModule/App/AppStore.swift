
import Foundation
import Observation

@MainActor
@Observable
final class PerformanceState {
  private(set) var revision: Int = 0
  private(set) var lastVideoSpeed: Double?

  func didSaveVideoMeasurement(_ speed: Double) {
    lastVideoSpeed = speed
    revision &+= 1
  }

  func didChangePerformanceData() {
    revision &+= 1
  }
}

@MainActor
@Observable
final class VideoWorkspaceState {
  var isFullScreen = false
  var missingVideoMessage: String?
  var clipNeedingRelinkID: UUID?
}

@MainActor
@Observable
final class AthleteState {
  var selectedAthleteID: UUID?
}

@MainActor
@Observable
final class AppStore {
  let performance = PerformanceState()
  let video = VideoWorkspaceState()
  let athlete = AthleteState()
}
