import SwiftData
import SwiftUI

@main
struct VaultRoadmapApp: App {
  var body: some Scene {
    WindowGroup {
      PersistenceBootstrapView()
        .environment(\.locale, Locale(identifier: "fr_FR"))
    }
  }
}

private struct PersistenceBootstrapView: View {
  @State private var appState = AppState()
  @State private var store = AppStore()
  @State private var container: ModelContainer?
  @State private var persistenceError: String?
  @State private var diagnostic = ""

  var body: some View {
    Group {
      if let container {
        AppRootView()
          .environment(appState)
          .environment(store)
          .environment(store.performance)
          .environment(store.video)
          .environment(store.athlete)
          .modelContainer(container)
      } else if let persistenceError {
        PersistenceFailureView(
          errorMessage: persistenceError,
          diagnostic: diagnostic,
          retry: openStore
        )
      } else {
        ProgressView("Ouverture des données locales…")
      }
    }
    .task { if container == nil, persistenceError == nil { openStore() } }
  }

  @MainActor
  private func openStore() {
    persistenceError = nil
    do {
      container = try ModelContainerFactory.make()
      diagnostic = ModelContainerFactory.diagnosticSummary()
    } catch {
      container = nil
      persistenceError = error.localizedDescription
      diagnostic = ModelContainerFactory.diagnosticSummary(error: error)
    }
  }
}

private struct PersistenceFailureView: View {
  let errorMessage: String
  let diagnostic: String
  let retry: () -> Void
  @State private var showsDiagnostic = false

  var body: some View {
    ScrollView {
      VStack(spacing: 22) {
        Image(systemName: "externaldrive.badge.exclamationmark")
          .font(.system(size: 58, weight: .semibold))
          .foregroundStyle(.red)

        Text("Impossible d’ouvrir les données locales")
          .font(.largeTitle.weight(.black))

        Text(errorMessage)
          .foregroundStyle(.secondary)
          .multilineTextAlignment(.center)
          .frame(maxWidth: 650)

        Text("Aucune base temporaire n’est créée et aucune donnée n’est supprimée automatiquement.")
          .font(.callout)
          .foregroundStyle(.secondary)
          .multilineTextAlignment(.center)
          .frame(maxWidth: 680)

        HStack {
          Button("Réessayer", action: retry)
            .buttonStyle(.borderedProminent)

          Button(showsDiagnostic ? "Masquer le diagnostic" : "Afficher le diagnostic") {
            showsDiagnostic.toggle()
          }
          .buttonStyle(.bordered)
        }

        if showsDiagnostic {
          Text(diagnostic)
            .font(.caption.monospaced())
            .textSelection(.enabled)
            .padding()
            .frame(maxWidth: 760, alignment: .leading)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
        }
      }
      .padding(40)
      .frame(maxWidth: .infinity)
    }
  }
}
