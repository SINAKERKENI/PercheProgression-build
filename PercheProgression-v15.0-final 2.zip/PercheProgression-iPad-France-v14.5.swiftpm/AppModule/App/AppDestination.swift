import SwiftUI

enum AppDestination: String, CaseIterable, Identifiable, Hashable {
  case home
  case roadmap
  case log
  case journal
  case poles
  case progress
  case video
  case library
  case achievements
  case profile

  var id: String { rawValue }

  var title: String {
    switch self {
    case .home: "Accueil"
    case .roadmap: "Feuille de route"
    case .log: "Journal de séance"
    case .journal: "Historique"
    case .poles: "Râtelier de perches"
    case .progress: "Progression"
    case .video: "Analyse vidéo"
    case .library: "Bibliothèque d’exercices"
    case .achievements: "Jalons"
    case .profile: "Profil de l’athlète"
    }
  }

  var symbol: String {
    switch self {
    case .home: "house.fill"
    case .roadmap: "square.grid.3x3.fill"
    case .log: "plus.circle.fill"
    case .journal: "clock.arrow.circlepath"
    case .poles: "line.diagonal"
    case .progress: "chart.xyaxis.line"
    case .video: "video.fill"
    case .library: "books.vertical.fill"
    case .achievements: "trophy.fill"
    case .profile: "person.crop.circle.fill"
    }
  }
}
