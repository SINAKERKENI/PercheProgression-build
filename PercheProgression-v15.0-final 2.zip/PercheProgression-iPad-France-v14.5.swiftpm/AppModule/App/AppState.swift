import Foundation
import Observation

@MainActor
@Observable
final class AppState {
  private static let selectedAthleteKey = "PercheProgression.selectedAthleteID"

  var destination: AppDestination = .home
  var selectedApproach: ApproachLength = .fourteen
  var selectedPoleID: UUID?
  var currentBarHeightCM: Int = 0
  var sessionKind: SessionKind = .training
  var showQuickLogSheet = false
  var shouldPresentVoiceLog = false
  var pendingVideoAttemptID: UUID?
  var pendingVideoAthleteID: UUID?
  var isTrackFocusMode = false
  var lastAchievementTitle: String?
  var selectedSessionID: UUID?
  var selectedAthleteID: UUID? {
    didSet {
      if let selectedAthleteID {
        UserDefaults.standard.set(selectedAthleteID.uuidString, forKey: Self.selectedAthleteKey)
      } else {
        UserDefaults.standard.removeObject(forKey: Self.selectedAthleteKey)
      }
      // A pole selection is athlete-specific and must not leak across profiles.
      selectedPoleID = nil
      selectedSessionID = nil
      pendingVideoAttemptID = nil
      pendingVideoAthleteID = nil
    }
  }

  init() {
    if let raw = UserDefaults.standard.string(forKey: Self.selectedAthleteKey) {
      selectedAthleteID = UUID(uuidString: raw)
    } else {
      selectedAthleteID = nil
    }
  }

  func athlete(in profiles: [AthleteProfile]) -> AthleteProfile? {
    if let selectedAthleteID,
      let selected = profiles.first(where: { $0.id == selectedAthleteID })
    {
      return selected
    }
    return profiles.sorted { $0.createdAt < $1.createdAt }.first
  }

  func ensureAthleteSelection(from profiles: [AthleteProfile]) {
    guard !profiles.isEmpty else {
      selectedAthleteID = nil
      return
    }
    if selectedAthleteID == nil || !profiles.contains(where: { $0.id == selectedAthleteID }) {
      selectedAthleteID = profiles.sorted { $0.createdAt < $1.createdAt }.first?.id
    }
  }

  func adjustBar(by centimeters: Int) {
    currentBarHeightCM = min(max(currentBarHeightCM + centimeters, 0), 700)
    Haptics.selection()
  }

  func openSession(_ sessionID: UUID) {
    selectedSessionID = sessionID
    destination = .journal
  }
}
