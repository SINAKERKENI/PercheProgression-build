import SwiftData
import SwiftUI

struct AppRootView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Query private var profiles: [AthleteProfile]
  @State private var seedError: String?
  @State private var persistenceIssues = PersistenceIssueCenter.shared

  var body: some View {
    @Bindable var appState = appState

    NavigationSplitView {
      sidebar
        .navigationSplitViewColumnWidth(min: 240, ideal: 275, max: 320)
    } detail: {
      NavigationStack {
        destinationView(for: appState.destination)
          .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
              Button {
                appState.showQuickLogSheet = true
                Haptics.impact(.light)
              } label: {
                Label("Saisie rapide", systemImage: "plus.circle.fill")
                  .font(.headline)
              }
              .buttonStyle(.borderedProminent)
              .tint(
                appState.destination == .video
                  ? Color.vaultAnalysisAccent : Color.vaultAccent
              )
              .keyboardShortcut("l", modifiers: [.command])
            }
          }
      }
    }
    .navigationSplitViewStyle(.balanced)
    .tint(
      appState.destination == .video
        ? Color.vaultAnalysisAccent : Color.vaultAccent
    )
    .vaultPage()
    .task {
      do {
        try SeedService.seedIfNeeded(context: modelContext)
        appState.ensureAthleteSelection(from: profiles)
      } catch {
        seedError = error.localizedDescription
      }
    }
    .sheet(isPresented: $appState.showQuickLogSheet) {
      NavigationStack {
        TrackLogView(compactMode: true)
          .toolbar {
            ToolbarItem(placement: .topBarLeading) {
              Button("Fermer") { appState.showQuickLogSheet = false }
            }
          }
      }
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .alert(
      "Erreur d’enregistrement",
      isPresented: Binding(
        get: { persistenceIssues.lastError != nil },
        set: { if !$0 { persistenceIssues.lastError = nil } }
      )
    ) {
      Button("OK", role: .cancel) { persistenceIssues.lastError = nil }
    } message: {
      Text(persistenceIssues.lastError ?? "Erreur inconnue")
    }
    .alert(
      "Impossible de préparer les données locales",
      isPresented: Binding(
        get: { seedError != nil },
        set: { if !$0 { seedError = nil } }
      )
    ) {
      Button("OK", role: .cancel) { seedError = nil }
    } message: {
      Text(seedError ?? "Erreur inconnue")
    }
  }

  private var sidebar: some View {
    List(
      selection: Binding<AppDestination?>(
        get: { appState.destination },
        set: { destination in
          if let destination { appState.destination = destination }
        }
      )
    ) {
      if profiles.count > 1 {
        Section("Athlète actif") {
          Picker("Athlète", selection: Binding<UUID?>(
            get: { appState.selectedAthleteID ?? appState.athlete(in: profiles)?.id },
            set: { appState.selectedAthleteID = $0 }
          )) {
            ForEach(profiles.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }) { profile in
              Text(profile.displayName).tag(Optional(profile.id))
            }
          }
          .pickerStyle(.menu)
        }
      }

      Section {
        sidebarGoalCard
          .listRowBackground(Color.clear)
          .listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 14, trailing: 8))
      }

      Section("Aujourd’hui") {
        ForEach([AppDestination.home, .log, .journal]) { destination in
          Label(destination.title, systemImage: destination.symbol)
            .tag(destination)
        }
      }

      Section("Analyser et progresser") {
        ForEach([AppDestination.video, .progress, .poles, .roadmap]) { destination in
          Label(destination.title, systemImage: destination.symbol)
            .tag(destination)
        }
      }

      Section("Ressources et profil") {
        ForEach([AppDestination.library, .achievements, .profile]) { destination in
          Label(destination.title, systemImage: destination.symbol)
            .tag(destination)
        }
      }

      Section {
        HStack(spacing: 8) {
          Circle()
            .fill(Color.vaultSuccess)
            .frame(width: 8, height: 8)
          Text("Stockage local actif")
          Spacer()
          Image(systemName: "icloud.slash")
        }
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
      }
    }
    .scrollContentBackground(.hidden)
    .background(Color.vaultPanel)
    .navigationTitle("Perche Progression")
  }

  private var sidebarGoalCard: some View {
    let profile = appState.athlete(in: profiles)
    let current = profile?.currentPRCM ?? 0
    let target = profile?.targetHeightCM ?? 0
    let progress = target > 0 ? min(Double(current) / Double(target), 1) : 0

    return VStack(alignment: .leading, spacing: 10) {
      SectionEyebrow(text: "Objectif principal")
      Text(String(format: "%.2f m", Double(target) / 100))
        .font(.system(size: 34, weight: .black, design: .rounded))
        .monospacedDigit()
      ProgressView(value: progress)
        .tint(.white)
      Text(String(format: "Record actuel : %.2f m", Double(current) / 100))
        .font(.caption.weight(.semibold))
        .foregroundStyle(Color.white.opacity(0.82))
    }
    .padding(16)
    .background(
      LinearGradient(
        colors: [.vaultNavy, .vaultNavyLight],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      ),
      in: RoundedRectangle(cornerRadius: 20, style: .continuous)
    )
    .foregroundStyle(.white)
  }

  @ViewBuilder
  private func destinationView(for destination: AppDestination) -> some View {
    switch destination {
    case .home:
      HomeDashboardView()
    case .roadmap:
      RoadmapView()
    case .log:
      TrackLogView()
    case .journal:
      SessionJournalView()
    case .poles:
      PoleLockerView()
    case .progress:
      ProgressDashboardView()
    case .video:
      VideoLabView()
    case .library:
      DrillLibraryView()
    case .achievements:
      AchievementsView()
    case .profile:
      AthleteProfileView()
    }
  }
}
