import Foundation
import SwiftData
import SwiftUI

private enum JournalSection: String, CaseIterable, Identifiable {
  case sessions = "Séances"
  case jumps = "Sauts"
  case videos = "Vidéos"

  var id: String { rawValue }
  var symbol: String {
    switch self {
    case .sessions: "calendar"
    case .jumps: "figure.track.and.field"
    case .videos: "video.fill"
    }
  }
}

struct SessionJournalView: View {
  @Environment(AppState.self) private var appState
  @Query private var profiles: [AthleteProfile]
  @Query(sort: \VaultSessionRecord.startedAt, order: .reverse) private var sessions: [VaultSessionRecord]
  @Query(sort: \AttemptRecord.createdAt, order: .reverse) private var attempts: [AttemptRecord]
  @Query(sort: \VideoClipRecord.createdAt, order: .reverse) private var videos: [VideoClipRecord]
  @Query(sort: \PoleRecord.progressionOrder) private var poles: [PoleRecord]

  @State private var section: JournalSection = .sessions
  @State private var searchText = ""
  @State private var selectedSession: VaultSessionRecord?
  @State private var selectedAttempt: AttemptRecord?

  private var athlete: AthleteProfile? { appState.athlete(in: profiles) }

  private var scopedSessions: [VaultSessionRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return sessions.filter { $0.athleteID == athleteID && matchesSession($0) }
  }

  private var scopedAttempts: [AttemptRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return attempts.filter {
      $0.athleteID == athleteID && $0.deletedAt == nil && matchesAttempt($0)
    }
  }

  private var scopedVideos: [VideoClipRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return videos.filter { $0.athleteID == athleteID && matchesVideo($0) }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        HStack(alignment: .top) {
          VaultScreenHeader(
            title: "Historique",
            subtitle: "Retrouvez chaque séance, saut et vidéo avec leurs conditions et mesures techniques.",
            symbol: "clock.arrow.circlepath"
          )
          Spacer()
          Button {
            appState.destination = .log
          } label: {
            Label("Nouvelle séance", systemImage: "plus")
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAccent)
        }

        summaryStrip

        Picker("Contenu", selection: $section) {
          ForEach(JournalSection.allCases) { item in
            Label(item.rawValue, systemImage: item.symbol).tag(item)
          }
        }
        .pickerStyle(.segmented)

        Group {
          switch section {
          case .sessions: sessionsContent
          case .jumps: jumpsContent
          case .videos: videosContent
          }
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .searchable(text: $searchText, prompt: "Date, lieu, hauteur, perche, commentaire…")
    .sheet(item: $selectedSession) { session in
      SessionDetailSheet(
        session: session,
        attempts: attempts.filter { $0.sessionID == session.id && $0.deletedAt == nil },
        poles: poles,
        videos: videos
      )
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .sheet(item: $selectedAttempt) { attempt in
      AttemptDetailEditor(attempt: attempt, poles: poles)
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
    }
    .onAppear {
      if let selectedID = appState.selectedSessionID,
        let session = sessions.first(where: { $0.id == selectedID && $0.athleteID == athlete?.id })
      {
        selectedSession = session
        appState.selectedSessionID = nil
      }
    }
  }

  private var summaryStrip: some View {
    let athleteID = athlete?.id
    let allSessions = sessions.filter { $0.athleteID == athleteID }
    let allAttempts = attempts.filter { $0.athleteID == athleteID && $0.deletedAt == nil }
    let allVideos = videos.filter { $0.athleteID == athleteID }
    let valid = allAttempts.filter { $0.result.isValidAttempt }
    let clearRate = valid.isEmpty ? 0 : Double(valid.filter { $0.result == .clear }.count) / Double(valid.count)

    return HStack(spacing: 12) {
      MetricPill(title: "Séances", value: "\(allSessions.count)", tint: .vaultNavyLight)
      MetricPill(title: "Sauts", value: "\(allAttempts.count)", tint: .vaultAccent)
      MetricPill(title: "Réussite", value: "\(Int((clearRate * 100).rounded())) %", tint: .vaultSuccess)
      MetricPill(title: "Vidéos", value: "\(allVideos.count)", tint: .vaultCyan)
      Spacer(minLength: 0)
    }
  }

  private var sessionsContent: some View {
    Group {
      if scopedSessions.isEmpty {
        EmptyStateView(
          symbol: "calendar.badge.exclamationmark",
          title: searchText.isEmpty ? "Aucune séance" : "Aucun résultat",
          message: searchText.isEmpty
            ? "Démarrez une séance dans le journal de piste."
            : "Essayez un autre lieu, une autre date ou un autre mot-clé."
        )
      } else {
        LazyVGrid(
          columns: [GridItem(.adaptive(minimum: 330), spacing: VaultSpacing.medium)],
          spacing: VaultSpacing.medium
        ) {
          ForEach(scopedSessions) { session in
            Button {
              selectedSession = session
              Haptics.selection()
            } label: {
              SessionJournalCard(
                session: session,
                attempts: attempts.filter { $0.sessionID == session.id && $0.deletedAt == nil }
              )
            }
            .buttonStyle(.plain)
          }
        }
      }
    }
  }

  private var jumpsContent: some View {
    Group {
      if scopedAttempts.isEmpty {
        EmptyStateView(
          symbol: "figure.track.and.field",
          title: searchText.isEmpty ? "Aucun saut" : "Aucun résultat",
          message: "Les sauts enregistrés sur la piste apparaissent ici."
        )
      } else {
        LazyVStack(spacing: 12) {
          ForEach(scopedAttempts) { attempt in
            Button {
              selectedAttempt = attempt
              Haptics.selection()
            } label: {
              JournalAttemptRow(attempt: attempt, pole: poles.first { $0.id == attempt.poleID })
            }
            .buttonStyle(.plain)
          }
        }
      }
    }
  }

  private var videosContent: some View {
    Group {
      if scopedVideos.isEmpty {
        EmptyStateView(
          symbol: "video.slash",
          title: searchText.isEmpty ? "Aucune vidéo" : "Aucun résultat",
          message: "Importez ou filmez un saut dans le laboratoire vidéo."
        )
      } else {
        LazyVGrid(
          columns: [GridItem(.adaptive(minimum: 300), spacing: VaultSpacing.medium)],
          spacing: VaultSpacing.medium
        ) {
          ForEach(scopedVideos) { clip in
            VStack(alignment: .leading, spacing: 13) {
              HStack {
                Image(systemName: clip.motionAnalysisData == nil ? "video.fill" : "viewfinder")
                  .font(.title2.weight(.bold))
                  .foregroundStyle(clip.motionAnalysisData == nil ? Color.vaultCyan : Color.vaultSuccess)
                  .frame(width: 50, height: 50)
                  .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 15))
                Spacer()
                if clip.motionAnalysisData != nil {
                  Label("Analysée", systemImage: "checkmark.seal.fill")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.vaultSuccess)
                }
              }
              Text(clip.originalFilename)
                .font(.headline.weight(.black))
                .lineLimit(2)
              Text("\(duration(clip.durationSeconds)) · \(Int(clip.frameRate.rounded())) i/s · \(clip.createdAt.formatted(date: .abbreviated, time: .shortened))")
                .font(.caption.monospacedDigit())
                .foregroundStyle(Color.vaultMuted)
              if !clip.analysisNotes.isEmpty {
                Text(clip.analysisNotes)
                  .font(.caption)
                  .foregroundStyle(Color.vaultMuted)
                  .lineLimit(2)
              }
              Button {
                appState.destination = .video
              } label: {
                Label("Ouvrir le laboratoire", systemImage: "arrow.right")
                  .frame(maxWidth: .infinity)
              }
              .buttonStyle(.bordered)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .vaultCard()
          }
        }
      }
    }
  }

  private func matchesSession(_ session: VaultSessionRecord) -> Bool {
    guard !searchText.isEmpty else { return true }
    let haystack = [
      session.title, session.locationName, session.sessionGoal, session.notes,
      session.kind.title, session.startedAt.formatted(date: .long, time: .omitted),
    ].joined(separator: " ")
    return normalized(haystack).contains(normalized(searchText))
  }

  private func matchesAttempt(_ attempt: AttemptRecord) -> Bool {
    guard !searchText.isEmpty else { return true }
    let pole = poles.first { $0.id == attempt.poleID }
    let haystack = [
      attempt.result.title,
      String(format: "%.2f", Double(attempt.barHeightCM) / 100),
      "\(attempt.approachSteps) foulées",
      attempt.note,
      attempt.voiceTranscript,
      attempt.diagnostics.map(\.title).joined(separator: " "),
      pole?.displayName ?? "",
      pole?.manufacturer ?? "",
    ].joined(separator: " ")
    return normalized(haystack).contains(normalized(searchText))
  }

  private func matchesVideo(_ video: VideoClipRecord) -> Bool {
    guard !searchText.isEmpty else { return true }
    let haystack = [video.originalFilename, video.analysisNotes, video.phaseRaw ?? ""]
      .joined(separator: " ")
    return normalized(haystack).contains(normalized(searchText))
  }

  private func normalized(_ text: String) -> String {
    text.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
      .lowercased()
  }

  private func duration(_ seconds: Double) -> String {
    let total = max(Int(seconds.rounded()), 0)
    return String(format: "%d:%02d", total / 60, total % 60)
  }
}

private struct SessionJournalCard: View {
  let session: VaultSessionRecord
  let attempts: [AttemptRecord]

  var body: some View {
    let valid = attempts.filter { $0.result.isValidAttempt }
    let clears = valid.filter { $0.result == .clear }
    let best = clears.map(\.barHeightCM).max()
    let clearRate = valid.isEmpty ? 0 : Double(clears.count) / Double(valid.count)

    VStack(alignment: .leading, spacing: 15) {
      HStack(alignment: .top) {
        Image(systemName: session.kind.symbol)
          .font(.title2.weight(.bold))
          .foregroundStyle(session.isActive ? Color.white : Color.vaultNavy)
          .frame(width: 52, height: 52)
          .background(session.isActive ? Color.vaultSuccess : Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 15))
        VStack(alignment: .leading, spacing: 4) {
          Text(session.title.isEmpty ? session.kind.title : session.title)
            .font(.title3.weight(.black))
          Text(session.startedAt.formatted(date: .abbreviated, time: .shortened))
            .font(.caption.monospacedDigit())
            .foregroundStyle(Color.vaultMuted)
        }
        Spacer()
        if session.isActive {
          Text("EN COURS")
            .font(.caption2.weight(.black))
            .foregroundStyle(Color.vaultSuccess)
        }
      }

      if !session.locationName.isEmpty || !session.sessionGoal.isEmpty {
        VStack(alignment: .leading, spacing: 5) {
          if !session.locationName.isEmpty {
            Label(session.locationName, systemImage: "mappin.and.ellipse")
          }
          if !session.sessionGoal.isEmpty {
            Label(session.sessionGoal, systemImage: "scope")
              .lineLimit(2)
          }
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(Color.vaultMuted)
      }

      HStack(spacing: 9) {
        sessionMetric("Sauts", "\(attempts.count)")
        sessionMetric("Réussite", "\(Int((clearRate * 100).rounded())) %")
        sessionMetric("Meilleur", best.map { String(format: "%.2f m", Double($0) / 100) } ?? "—")
      }

      HStack {
        Label(session.environment.title, systemImage: session.environment.symbol)
        if session.environment == .outdoor, session.weather != .unknown {
          Label(session.weather.title, systemImage: session.weather.symbol)
        }
        Spacer()
        Image(systemName: "chevron.right")
      }
      .font(.caption.weight(.bold))
      .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, minHeight: 230, alignment: .topLeading)
    .foregroundStyle(Color.vaultText)
    .vaultCard()
  }

  private func sessionMetric(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 4) {
      Text(title.uppercased())
        .font(.caption2.weight(.black))
        .foregroundStyle(Color.vaultMuted)
      Text(value)
        .font(.subheadline.monospacedDigit().weight(.black))
    }
    .padding(10)
    .frame(maxWidth: .infinity, alignment: .leading)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 11))
  }
}

private struct JournalAttemptRow: View {
  let attempt: AttemptRecord
  let pole: PoleRecord?

  var body: some View {
    HStack(spacing: 14) {
      Text(attempt.result.competitionMark)
        .font(.title2.monospacedDigit().weight(.black))
        .foregroundStyle(resultColor)
        .frame(width: 52, height: 52)
        .background(resultColor.opacity(0.10), in: Circle())

      VStack(alignment: .leading, spacing: 5) {
        Text(String(format: "%.2f m · %d foulées", Double(attempt.barHeightCM) / 100, attempt.approachSteps))
          .font(.headline.monospacedDigit().weight(.black))
        Text([pole?.displayName ?? "Perche inconnue", attempt.createdAt.formatted(date: .abbreviated, time: .shortened)].joined(separator: " · "))
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
          .lineLimit(1)
        if !attempt.note.isEmpty {
          Text(attempt.note)
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
            .lineLimit(1)
        }
      }

      Spacer()

      if attempt.technicalRating != .unrated {
        Label(attempt.technicalRating.title, systemImage: attempt.technicalRating.symbol)
          .font(.caption.weight(.bold))
          .foregroundStyle(Color.vaultGold)
      }
      if !attempt.voiceTranscript.isEmpty {
        Image(systemName: "waveform.and.mic")
          .foregroundStyle(Color.vaultNavyLight)
      }
      Image(systemName: "chevron.right")
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.vaultMuted)
    }
    .padding(15)
    .foregroundStyle(Color.vaultText)
    .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    .overlay {
      RoundedRectangle(cornerRadius: 18, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }

  private var resultColor: Color {
    switch attempt.result {
    case .clear: .vaultSuccess
    case .miss: .vaultAccent
    case .pass: .vaultCyan
    case .abort, .runThrough: .vaultWarning
    }
  }
}

private struct SessionDetailSheet: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Bindable var session: VaultSessionRecord
  let attempts: [AttemptRecord]
  let poles: [PoleRecord]
  let videos: [VideoClipRecord]

  @State private var selectedAttempt: AttemptRecord?
  @State private var showingSessionSetup = false

  var body: some View {
    NavigationStack {
      ScrollView {
        VStack(alignment: .leading, spacing: VaultSpacing.large) {
          summary
          conditions
          attemptsCard
          linkedVideosCard
          notesCard
        }
        .padding(VaultSpacing.large)
      }
      .vaultPage()
      .navigationTitle(session.title.isEmpty ? session.kind.title : session.title)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Fermer") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer") {
            session.updatedAt = .now
            PersistenceIssueCenter.shared.save(modelContext)
            Haptics.success()
          }
          .fontWeight(.bold)
        }
      }
      .sheet(item: $selectedAttempt) { attempt in
        AttemptDetailEditor(attempt: attempt, poles: poles)
          .presentationDetents([.large])
      }
      .sheet(isPresented: $showingSessionSetup) {
        SessionSetupSheet(
          editingSession: session,
          defaultKind: session.kind,
          onSave: applySessionValues
        )
        .presentationDetents([.large])
      }
    }
  }

  private var summary: some View {
    let valid = attempts.filter { $0.result.isValidAttempt }
    let clears = valid.filter { $0.result == .clear }
    let rate = valid.isEmpty ? 0 : Double(clears.count) / Double(valid.count)
    let best = clears.map(\.barHeightCM).max()

    return VStack(alignment: .leading, spacing: 16) {
      TextField("Titre de la séance", text: $session.title)
        .font(.title2.weight(.black))
      HStack(spacing: 12) {
        MetricPill(title: "Sauts", value: "\(attempts.count)", tint: .vaultAccent)
        MetricPill(title: "Réussite", value: "\(Int((rate * 100).rounded())) %", tint: .vaultSuccess)
        MetricPill(title: "Meilleur", value: best.map { String(format: "%.2f m", Double($0) / 100) } ?? "—", tint: .vaultCyan)
      }
    }
    .vaultCard()
  }

  private var conditions: some View {
    VStack(alignment: .leading, spacing: 13) {
      HStack {
        SectionEyebrow(text: "Contexte")
        Spacer()
        Button("Modifier") { showingSessionSetup = true }
          .font(.caption.weight(.bold))
      }
      LabeledContent("Date", value: session.startedAt.formatted(date: .long, time: .shortened))
      LabeledContent("Lieu") {
        TextField("Non renseigné", text: $session.locationName)
          .multilineTextAlignment(.trailing)
      }
      LabeledContent("Installation", value: session.environment.title)
      if session.environment == .outdoor {
        LabeledContent("Météo", value: session.weather.title)
        LabeledContent("Vent", value: windText)
      }
      LabeledContent("Énergie", value: "\(session.energyLevel) / 5")
      TextField("Objectif de séance", text: $session.sessionGoal, axis: .vertical)
        .lineLimit(2...4)
    }
    .vaultCard()
  }

  private var attemptsCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Sauts")
        Spacer()
        Text("\(attempts.count)")
          .font(.headline.monospacedDigit().weight(.black))
      }
      if attempts.isEmpty {
        Text("Aucun saut enregistré dans cette séance.")
          .foregroundStyle(Color.vaultMuted)
          .padding(.vertical, 18)
      } else {
        ForEach(attempts.sorted { $0.sequenceIndex < $1.sequenceIndex }) { attempt in
          Button {
            selectedAttempt = attempt
          } label: {
            JournalAttemptRow(attempt: attempt, pole: poles.first { $0.id == attempt.poleID })
          }
          .buttonStyle(.plain)
        }
      }
    }
    .vaultCard()
  }

  private var linkedVideosCard: some View {
    let attemptIDs = Set(attempts.map(\.id))
    let linked = videos.filter { clip in
      guard let attemptID = clip.attemptID else { return false }
      return attemptIDs.contains(attemptID)
    }

    return VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Vidéos liées")
      if linked.isEmpty {
        Text("Aucune vidéo n’est encore liée à un saut de cette séance.")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
      } else {
        ForEach(linked) { clip in
          Label(clip.originalFilename, systemImage: "video.fill")
            .font(.subheadline.weight(.bold))
        }
      }
    }
    .vaultCard()
  }

  private var notesCard: some View {
    VStack(alignment: .leading, spacing: 10) {
      SectionEyebrow(text: "Notes de séance")
      VaultCommentEditor(
        text: $session.notes,
        placeholder: "Bilan, points réussis et prochaine priorité…",
        minHeight: 150
      )
    }
    .vaultCard()
  }

  private var windText: String {
    var parts = [session.windDirection.title]
    if let speed = session.windSpeedMPS { parts.append(String(format: "%.1f m/s", speed)) }
    return parts.joined(separator: " · ")
  }

  private func applySessionValues(_ values: SessionSetupValues) {
    session.kind = values.kind
    session.startedAt = values.startedAt
    session.title = values.title
    session.locationName = values.locationName
    session.environment = values.environment
    session.weather = values.weather
    session.windDirection = values.windDirection
    session.windSpeedMPS = values.windSpeedMPS
    session.temperatureC = values.temperatureC
    session.energyLevel = values.energyLevel
    session.sessionGoal = values.sessionGoal
    session.notes = values.notes
    session.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
  }
}

struct AttemptDetailEditor: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Environment(AppState.self) private var appState
  @Query(sort: \VideoClipRecord.createdAt, order: .reverse) private var videos: [VideoClipRecord]
  @Bindable var attempt: AttemptRecord
  let poles: [PoleRecord]

  @State private var gripHeightText: String
  @State private var runUpDistanceText: String
  @State private var midMarkText: String
  @State private var takeoffMarkText: String
  @State private var standardsOffsetText: String

  init(attempt: AttemptRecord, poles: [PoleRecord]) {
    self.attempt = attempt
    self.poles = poles
    _gripHeightText = State(initialValue: Self.text(attempt.gripHeightM))
    _runUpDistanceText = State(initialValue: Self.text(attempt.runUpDistanceM))
    _midMarkText = State(initialValue: Self.text(attempt.midMarkM))
    _takeoffMarkText = State(initialValue: Self.text(attempt.actualTakeoffMarkM))
    _standardsOffsetText = State(initialValue: attempt.standardsOffsetCM.map { String($0) } ?? "")
  }

  var body: some View {
    NavigationStack {
      Form {
        Section("Résultat") {
          Picker("Résultat", selection: Binding(
            get: { attempt.result },
            set: { attempt.result = $0 }
          )) {
            ForEach(AttemptResult.allCases) { item in
              Text("\(item.competitionMark) · \(item.title)").tag(item)
            }
          }
          Stepper(value: $attempt.barHeightCM, in: 0...700, step: 5) {
            LabeledContent("Barre", value: String(format: "%.2f m", Double(attempt.barHeightCM) / 100))
          }
          Picker("Perche", selection: $attempt.poleID) {
            ForEach(poles) { pole in
              Text(pole.displayName).tag(pole.id)
            }
          }
          Picker("Qualité technique", selection: Binding(
            get: { attempt.technicalRating },
            set: { attempt.technicalRating = $0 }
          )) {
            ForEach(JumpRating.allCases) { item in
              Label(item.title, systemImage: item.symbol).tag(item)
            }
          }
        }

        Section("Mesures techniques") {
          measurementField("Hauteur de prise", text: $gripHeightText, unit: "m")
          measurementField("Longueur d’élan", text: $runUpDistanceText, unit: "m")
          measurementField("Marque intermédiaire", text: $midMarkText, unit: "m")
          measurementField("Marque d’impulsion", text: $takeoffMarkText, unit: "m")
          measurementField("Poteaux", text: $standardsOffsetText, unit: "cm")
        }

        Section("Observations") {
          ForEach(AttemptDiagnostic.allCases) { diagnostic in
            Toggle(
              diagnostic.title,
              isOn: Binding(
                get: { attempt.diagnostics.contains(diagnostic) },
                set: { isOn in
                  var values = attempt.diagnostics
                  if isOn { values.insert(diagnostic) } else { values.remove(diagnostic) }
                  attempt.diagnostics = values
                }
              )
            )
          }
          VaultCommentEditor(
            text: $attempt.note,
            placeholder: "Sensations et décision pour le saut suivant…",
            minHeight: 150
          )
        }

        Section("Vidéos du saut") {
          let linked = compatibleVideos.filter { $0.attemptID == attempt.id }
          if linked.isEmpty {
            Text("Aucune vidéo liée à ce saut.")
              .foregroundStyle(.secondary)
          } else {
            ForEach(linked) { clip in
              HStack {
                Label(clip.originalFilename, systemImage: "video.fill")
                Spacer()
                Button("Délier", role: .destructive) {
                  clip.attemptID = nil
                  clip.updatedAt = .now
                  PersistenceIssueCenter.shared.save(modelContext)
                }
              }
            }
          }

          let available = compatibleVideos.filter { $0.attemptID == nil }
          if !available.isEmpty {
            Menu {
              ForEach(available) { clip in
                Button(clip.originalFilename) {
                  clip.attemptID = attempt.id
                  clip.updatedAt = .now
                  PersistenceIssueCenter.shared.save(modelContext)
                  Haptics.success()
                }
              }
            } label: {
              Label("Lier une vidéo existante", systemImage: "link.badge.plus")
            }
          }

          Button {
            appState.pendingVideoAttemptID = attempt.id
            appState.pendingVideoAthleteID = attempt.athleteID
            appState.destination = .video
            dismiss()
          } label: {
            Label("Importer ou filmer dans le laboratoire", systemImage: "video.badge.plus")
          }
        }

        if !attempt.voiceTranscript.isEmpty {
          Section("Transcription d’origine") {
            Text(attempt.voiceTranscript)
              .textSelection(.enabled)
          }
        }
      }
      .navigationTitle("Détail du saut")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Fermer") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer") { save() }
            .fontWeight(.bold)
        }
      }
    }
  }

  private func measurementField(_ title: String, text: Binding<String>, unit: String) -> some View {
    HStack {
      TextField(title, text: text)
        .keyboardType(.numbersAndPunctuation)
      Text(unit).foregroundStyle(.secondary)
    }
  }

  private func save() {
    attempt.gripHeightM = number(gripHeightText)
    attempt.runUpDistanceM = number(runUpDistanceText)
    attempt.midMarkM = number(midMarkText)
    attempt.actualTakeoffMarkM = number(takeoffMarkText)
    attempt.standardsOffsetCM = Int(standardsOffsetText.trimmingCharacters(in: .whitespacesAndNewlines))
    attempt.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
    dismiss()
  }

  private var compatibleVideos: [VideoClipRecord] {
    videos.filter { $0.athleteID == attempt.athleteID }
  }

  private func number(_ value: String) -> Double? {
    let normalized = value.replacingOccurrences(of: ",", with: ".")
      .trimmingCharacters(in: .whitespacesAndNewlines)
    return normalized.isEmpty ? nil : Double(normalized)
  }

  private static func text(_ value: Double?) -> String {
    guard let value else { return "" }
    return String(format: "%.2f", value)
  }
}
