import Foundation
import SwiftUI

struct VoiceJumpLogSheet: View {
  @Environment(\.dismiss) private var dismiss
  @StateObject private var coordinator = VoiceLogCoordinator()

  let poles: [PoleRecord]
  let defaultBarHeightCM: Int
  let defaultApproach: ApproachLength
  let defaultPoleID: UUID?
  let onSave: (VoiceJumpDraft, UUID?) -> Void

  @State private var result: AttemptResult = .miss
  @State private var diagnostics: Set<AttemptDiagnostic> = []
  @State private var barHeightCM: Int
  @State private var approach: ApproachLength
  @State private var selectedPoleID: UUID?
  @State private var technicalRating: JumpRating = .unrated
  @State private var parsedDraft = VoiceJumpParser.parse("")

  init(
    poles: [PoleRecord],
    defaultBarHeightCM: Int,
    defaultApproach: ApproachLength,
    defaultPoleID: UUID?,
    onSave: @escaping (VoiceJumpDraft, UUID?) -> Void
  ) {
    self.poles = poles
    self.defaultBarHeightCM = defaultBarHeightCM
    self.defaultApproach = defaultApproach
    self.defaultPoleID = defaultPoleID
    self.onSave = onSave
    _barHeightCM = State(initialValue: defaultBarHeightCM)
    _approach = State(initialValue: defaultApproach)
    _selectedPoleID = State(initialValue: defaultPoleID)
  }

  var body: some View {
    NavigationStack {
      ScrollView {
        VStack(alignment: .leading, spacing: VaultSpacing.large) {
          instructionCard
          microphoneCard

          if !coordinator.transcript.isEmpty {
            transcriptCard
            reviewCard
            recognizedDetailsCard
          }

          if let error = coordinator.errorMessage {
            Label(error, systemImage: "exclamationmark.triangle.fill")
              .font(.subheadline)
              .foregroundStyle(Color.vaultWarning)
              .padding(15)
              .frame(maxWidth: .infinity, alignment: .leading)
              .background(Color.vaultWarning.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
          }
        }
        .padding(VaultSpacing.large)
      }
      .vaultPage()
      .navigationTitle("Dicter un saut")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Valider le saut") { save() }
            .fontWeight(.bold)
            .disabled(coordinator.transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
      .onChange(of: coordinator.transcript) { _, value in
        applyTranscript(value)
      }
      .onDisappear { coordinator.stopRecording() }
    }
  }

  private var instructionCard: some View {
    VStack(alignment: .leading, spacing: 8) {
      SectionEyebrow(text: "Exemple")
      Text("« Saut réussi, barre 4 mètres 80, 16 foulées, perche 4 mètres 60, 77 kilos, bonne impulsion. »")
        .font(.headline)
      Text("Les champs reconnus restent modifiables avant l’enregistrement. Aucune donnée n’est sauvegardée sans votre validation.")
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)
    }
    .vaultCard(background: Color.vaultNavy.opacity(0.045))
  }

  private var microphoneCard: some View {
    VStack(spacing: 16) {
      Button {
        if coordinator.isRecording {
          coordinator.stopRecording()
        } else {
          coordinator.requestAuthorizationAndStart()
        }
        Haptics.impact(.medium)
      } label: {
        ZStack {
          if coordinator.isRecording {
            Circle()
              .stroke(Color.vaultAccent.opacity(0.22), lineWidth: 14)
              .frame(width: 114, height: 114)
              .scaleEffect(1.12)
          }
          Circle()
            .fill(coordinator.isRecording ? Color.vaultAccent : Color.vaultNavy)
            .frame(width: 102, height: 102)
          Image(systemName: coordinator.isRecording ? "stop.fill" : "mic.fill")
            .font(.system(size: 34, weight: .black))
            .foregroundStyle(.white)
        }
      }
      .buttonStyle(.plain)
      .accessibilityLabel(coordinator.isRecording ? "Arrêter la dictée" : "Commencer la dictée")

      Text(coordinator.isRecording ? "Je vous écoute…" : "Touchez pour dicter")
        .font(.title3.weight(.black))

      if coordinator.usesOnDeviceRecognition {
        Label("Reconnaissance sur l’iPad", systemImage: "lock.shield.fill")
          .font(.caption.weight(.bold))
          .foregroundStyle(Color.vaultSuccess)
      }
    }
    .frame(maxWidth: .infinity)
    .padding(.vertical, 12)
  }

  private var transcriptCard: some View {
    VStack(alignment: .leading, spacing: 10) {
      HStack {
        SectionEyebrow(text: "Transcription")
        Spacer()
        Text("\(parsedDraft.recognizedFieldCount) éléments reconnus")
          .font(.caption.monospacedDigit().weight(.bold))
          .foregroundStyle(Color.vaultSuccess)
      }
      Text(coordinator.transcript)
        .font(.body)
        .textSelection(.enabled)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 14))

      Button {
        coordinator.clear()
        resetToDefaults()
      } label: {
        Label("Recommencer", systemImage: "arrow.counterclockwise")
      }
      .font(.caption.weight(.bold))
    }
    .vaultCard()
  }

  private var reviewCard: some View {
    VStack(alignment: .leading, spacing: 16) {
      SectionEyebrow(text: "Vérification obligatoire")

      ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 9) {
          ForEach(AttemptResult.allCases) { item in
            Button {
              result = item
              Haptics.selection()
            } label: {
              Text("\(item.competitionMark)  \(item.title)")
                .font(.subheadline.weight(.black))
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .foregroundStyle(result == item ? Color.white : Color.vaultText)
                .background(result == item ? Color.vaultNavy : Color.vaultPanelRaised, in: Capsule())
            }
            .buttonStyle(.plain)
          }
        }
      }

      Stepper(value: $barHeightCM, in: 0...700, step: 5) {
        LabeledContent("Hauteur de barre", value: String(format: "%.2f m", Double(barHeightCM) / 100))
          .font(.headline.monospacedDigit())
      }

      VStack(alignment: .leading, spacing: 8) {
        Text("Course d’élan")
          .font(.subheadline.weight(.bold))
        ScrollView(.horizontal, showsIndicators: false) {
          ApproachPicker(selection: $approach)
        }
      }

      Picker("Perche", selection: $selectedPoleID) {
        Text("Choisir une perche").tag(nil as UUID?)
        ForEach(poles) { pole in
          Text(pole.displayName).tag(Optional(pole.id))
        }
      }

      Picker("Qualité technique", selection: $technicalRating) {
        ForEach(JumpRating.allCases) { item in
          Label(item.title, systemImage: item.symbol).tag(item)
        }
      }
    }
    .vaultCard()
  }

  private var recognizedDetailsCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Détails reconnus")

      if diagnostics.isEmpty && parsedDetailRows.isEmpty {
        Text("Aucun détail biomécanique supplémentaire n’a été identifié dans la phrase.")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
      } else {
        ForEach(parsedDetailRows.indices, id: \.self) { index in
          let row = parsedDetailRows[index]
          LabeledContent(row.0, value: row.1)
            .font(.subheadline.monospacedDigit())
        }
        if !diagnostics.isEmpty {
          Divider().overlay(Color.vaultLine)
          Text(diagnostics.map(\.title).sorted().joined(separator: " · "))
            .font(.subheadline.weight(.bold))
            .foregroundStyle(Color.vaultWarning)
        }
      }
    }
    .vaultCard(background: Color.vaultCyan.opacity(0.035))
  }

  private var parsedDetailRows: [(String, String)] {
    var rows: [(String, String)] = []
    if let value = parsedDraft.gripHeightM { rows.append(("Hauteur de prise", meters(value))) }
    if let value = parsedDraft.runUpDistanceM { rows.append(("Longueur d’élan", meters(value))) }
    if let value = parsedDraft.midMarkM { rows.append(("Marque intermédiaire", meters(value))) }
    if let value = parsedDraft.takeoffMarkM { rows.append(("Marque d’impulsion", meters(value))) }
    if let value = parsedDraft.standardsOffsetCM {
      rows.append(("Poteaux", String(format: "%+d cm", value)))
    }
    return rows
  }

  private func applyTranscript(_ transcript: String) {
    guard !transcript.isEmpty else { return }
    let parsed = VoiceJumpParser.parse(transcript)
    parsedDraft = parsed
    result = parsed.result
    diagnostics = parsed.diagnostics
    if let value = parsed.barHeightCM { barHeightCM = value }
    if let value = parsed.approach { approach = value }
    if parsed.technicalRating != .unrated { technicalRating = parsed.technicalRating }

    if let matchingPole = bestPoleMatch(for: parsed) {
      selectedPoleID = matchingPole.id
    }
  }

  private func bestPoleMatch(for draft: VoiceJumpDraft) -> PoleRecord? {
    guard draft.poleLengthCM != nil || draft.poleWeightKG != nil else { return nil }
    guard let best = poles.min(by: { lhs, rhs in
      poleDistance(lhs, draft: draft) < poleDistance(rhs, draft: draft)
    }) else { return nil }
    return poleDistance(best, draft: draft) <= 28 ? best : nil
  }

  private func poleDistance(_ pole: PoleRecord, draft: VoiceJumpDraft) -> Double {
    let length = draft.poleLengthCM.map { Double(abs(pole.lengthCM - $0)) } ?? 0
    let weight = draft.poleWeightKG.map { abs(pole.weightKG - $0) * 4 } ?? 0
    return length + weight
  }

  private func save() {
    var final = parsedDraft
    final.result = result
    final.diagnostics = diagnostics
    final.barHeightCM = barHeightCM
    final.approach = approach
    final.technicalRating = technicalRating
    final.transcript = coordinator.transcript
    onSave(final, selectedPoleID)
    coordinator.stopRecording()
    dismiss()
  }

  private func resetToDefaults() {
    parsedDraft = VoiceJumpParser.parse("")
    result = .miss
    diagnostics = []
    barHeightCM = defaultBarHeightCM
    approach = defaultApproach
    selectedPoleID = defaultPoleID
    technicalRating = .unrated
  }

  private func meters(_ value: Double) -> String {
    String(format: "%.2f m", value)
  }
}
