import Foundation
import SwiftUI

struct SessionSetupValues {
  var kind: SessionKind
  var startedAt: Date
  var title: String
  var locationName: String
  var environment: VaultEnvironment
  var weather: WeatherCondition
  var windDirection: WindDirection
  var windSpeedMPS: Double?
  var temperatureC: Double?
  var energyLevel: Int
  var sessionGoal: String
  var notes: String
}

struct SessionSetupSheet: View {
  @Environment(\.dismiss) private var dismiss

  let editingSession: VaultSessionRecord?
  let onSave: (SessionSetupValues) -> Void

  @State private var kind: SessionKind
  @State private var startedAt: Date
  @State private var title: String
  @State private var locationName: String
  @State private var environment: VaultEnvironment
  @State private var weather: WeatherCondition
  @State private var windDirection: WindDirection
  @State private var windSpeedText: String
  @State private var temperatureText: String
  @State private var energyLevel: Int
  @State private var sessionGoal: String
  @State private var notes: String

  init(
    editingSession: VaultSessionRecord?,
    defaultKind: SessionKind,
    onSave: @escaping (SessionSetupValues) -> Void
  ) {
    self.editingSession = editingSession
    self.onSave = onSave
    _kind = State(initialValue: editingSession?.kind ?? defaultKind)
    _startedAt = State(initialValue: editingSession?.startedAt ?? .now)
    _title = State(initialValue: editingSession?.title ?? "")
    _locationName = State(initialValue: editingSession?.locationName ?? "")
    _environment = State(initialValue: editingSession?.environment ?? .outdoor)
    _weather = State(initialValue: editingSession?.weather ?? .unknown)
    _windDirection = State(initialValue: editingSession?.windDirection ?? .none)
    _windSpeedText = State(initialValue: Self.numberText(editingSession?.windSpeedMPS))
    _temperatureText = State(initialValue: Self.numberText(editingSession?.temperatureC))
    _energyLevel = State(initialValue: editingSession?.energyLevel ?? 3)
    _sessionGoal = State(initialValue: editingSession?.sessionGoal ?? "")
    _notes = State(initialValue: editingSession?.notes ?? "")
  }

  var body: some View {
    NavigationStack {
      Form {
        Section("Séance") {
          Picker("Type", selection: $kind) {
            ForEach(SessionKind.allCases) { item in
              Label(item.title, systemImage: item.symbol).tag(item)
            }
          }
          .pickerStyle(.segmented)

          DatePicker(
            "Début",
            selection: $startedAt,
            displayedComponents: [.date, .hourAndMinute]
          )
          TextField("Titre (facultatif)", text: $title)
          TextField("Lieu", text: $locationName)
        }

        Section("Conditions") {
          Picker("Installation", selection: $environment) {
            ForEach(VaultEnvironment.allCases) { item in
              Label(item.title, systemImage: item.symbol).tag(item)
            }
          }
          .pickerStyle(.segmented)

          if environment == .outdoor {
            Picker("Météo", selection: $weather) {
              ForEach(WeatherCondition.allCases) { item in
                Label(item.title, systemImage: item.symbol).tag(item)
              }
            }

            Picker("Vent", selection: $windDirection) {
              ForEach(WindDirection.allCases) { item in
                Text(item.title).tag(item)
              }
            }

            HStack {
              TextField("Vitesse du vent", text: $windSpeedText)
                .keyboardType(.decimalPad)
              Text("m/s")
                .foregroundStyle(.secondary)
            }
          }

          HStack {
            TextField("Température", text: $temperatureText)
              .keyboardType(.numbersAndPunctuation)
            Text("°C")
              .foregroundStyle(.secondary)
          }
        }

        Section("Disponibilité du jour") {
          Picker("Énergie", selection: $energyLevel) {
            ForEach(1...5, id: \.self) { level in
              Text(energyTitle(level)).tag(level)
            }
          }
          .pickerStyle(.segmented)

          TextField("Objectif de la séance", text: $sessionGoal, axis: .vertical)
            .lineLimit(2...4)
        }

        Section("Notes") {
          VaultCommentEditor(
            text: $notes,
            placeholder: "Échauffement, douleur, consignes du jour, réglages ou points de vigilance…",
            minHeight: 150
          )
        }
      }
      .navigationTitle(editingSession == nil ? "Préparer la séance" : "Modifier la séance")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button(editingSession == nil ? "Démarrer" : "Enregistrer") {
            onSave(
              SessionSetupValues(
                kind: kind,
                startedAt: startedAt,
                title: resolvedTitle,
                locationName: locationName.trimmingCharacters(in: .whitespacesAndNewlines),
                environment: environment,
                weather: environment == .outdoor ? weather : .unknown,
                windDirection: environment == .outdoor ? windDirection : .none,
                windSpeedMPS: environment == .outdoor ? parsedNumber(windSpeedText) : nil,
                temperatureC: parsedNumber(temperatureText),
                energyLevel: energyLevel,
                sessionGoal: sessionGoal.trimmingCharacters(in: .whitespacesAndNewlines),
                notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
              )
            )
            dismiss()
          }
          .fontWeight(.bold)
        }
      }
    }
  }

  private var resolvedTitle: String {
    let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
    if !trimmed.isEmpty { return trimmed }
    return kind == .competition ? "Compétition" : "Séance de perche"
  }

  private func parsedNumber(_ value: String) -> Double? {
    let normalized = value.replacingOccurrences(of: ",", with: ".")
      .trimmingCharacters(in: .whitespacesAndNewlines)
    return normalized.isEmpty ? nil : Double(normalized)
  }

  private func energyTitle(_ level: Int) -> String {
    switch level {
    case 1: "1 · Très faible"
    case 2: "2 · Faible"
    case 3: "3 · Normal"
    case 4: "4 · Bon"
    default: "5 · Excellent"
    }
  }

  private static func numberText(_ value: Double?) -> String {
    guard let value else { return "" }
    return String(format: "%.1f", value)
  }
}
