import SwiftData
import SwiftUI

struct TrackLogView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Query(sort: \PoleRecord.progressionOrder) private var poles: [PoleRecord]
  @Query(sort: \PoleApproachProgressRecord.updatedAt, order: .reverse) private var poleProgress:
    [PoleApproachProgressRecord]
  @Query(sort: \AttemptRecord.createdAt, order: .reverse) private var attempts: [AttemptRecord]
  @Query(sort: \VaultSessionRecord.startedAt, order: .reverse) private var sessions:
    [VaultSessionRecord]
  @Query private var profiles: [AthleteProfile]

  var compactMode = false

  @State private var pendingResult: AttemptResult?
  @State private var selectedDiagnostics: Set<AttemptDiagnostic> = []
  @State private var attemptNote = ""
  @State private var showingDiagnostics = false
  @State private var showingPolePicker = false
  @State private var showingSessionEditor = false
  @State private var showingVoiceLogger = false
  @State private var showPRCelebration = false
  @State private var competitionRuleMessage: String?
  @State private var jumpRating: JumpRating = .unrated
  @State private var showingAdvancedJumpDetails = false
  @State private var gripHeightText = ""
  @State private var runUpDistanceText = ""
  @State private var midMarkText = ""
  @State private var takeoffMarkText = ""
  @State private var standardsOffsetText = ""

  private var profile: AthleteProfile? { appState.athlete(in: profiles) }
  private var activePoles: [PoleRecord] {
    guard let athleteID = profile?.id else { return [] }
    return poles.filter { $0.isActive && $0.athleteID == athleteID }
  }
  private var selectedPole: PoleRecord? {
    if let id = appState.selectedPoleID,
      let pole = activePoles.first(where: { $0.id == id })
    {
      return pole
    }
    return preferredPole
  }

  private var preferredPole: PoleRecord? {
    let approach = appState.selectedApproach.rawValue
    let eligible =
      poleProgress
      .filter {
        $0.athleteID == profile?.id && $0.approachSteps == approach && $0.state >= .unlocked
      }
      .sorted {
        if $0.state.rank != $1.state.rank { return $0.state.rank > $1.state.rank }
        return $0.updatedAt > $1.updatedAt
      }
    if let poleID = eligible.first?.poleID {
      return activePoles.first { $0.id == poleID }
    }
    return activePoles.first
  }

  private var activeSession: VaultSessionRecord? {
    guard let athleteID = profile?.id else { return nil }
    return sessions.first { $0.isActive && $0.athleteID == athleteID }
  }

  private var sessionAttempts: [AttemptRecord] {
    guard let sessionID = activeSession?.id else { return [] }
    return
      attempts
      .filter { $0.sessionID == sessionID && $0.deletedAt == nil }
      .sorted { $0.sequenceIndex < $1.sequenceIndex }
  }

  var body: some View {
    @Bindable var appState = appState

    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        if !compactMode {
          HStack(alignment: .top) {
            VaultScreenHeader(
              title: "Mode piste",
              subtitle: "Enregistrez le prochain saut en quelques secondes, même sans connexion internet.",
              symbol: "plus.circle.fill"
            )
            Spacer()
            HStack(spacing: 10) {
              voiceLogButton
              focusModeToggle
            }
          }
        }

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            setupColumn
              .frame(maxWidth: 520)
            loggingColumn
              .frame(maxWidth: .infinity)
          }
          VStack(spacing: VaultSpacing.large) {
            setupColumn
            loggingColumn
          }
        }
      }
      .padding(compactMode ? VaultSpacing.medium : VaultSpacing.large)
    }
    .vaultPage()
    .trackScreenAwake()
    .onAppear {
      if let activeSession {
        appState.sessionKind = activeSession.kind
      }
      if appState.selectedPoleID == nil {
        appState.selectedPoleID = preferredPole?.id
      }
      if appState.shouldPresentVoiceLog {
        appState.shouldPresentVoiceLog = false
        showingVoiceLogger = true
      }
    }
    .onChange(of: appState.selectedApproach) { _, _ in
      appState.selectedPoleID = preferredPole?.id
    }
    .sheet(isPresented: $showingDiagnostics) {
      DiagnosticSheet(
        result: pendingResult ?? .miss,
        selectedDiagnostics: $selectedDiagnostics,
        note: $attemptNote,
        saveAction: finalizePendingAttempt
      )
      .presentationDetents([.medium, .large])
      .presentationDragIndicator(.visible)
    }
    .sheet(isPresented: $showingPolePicker) {
      PolePickerSheet(
        poles: activePoles,
        selectedPoleID: Binding(
          get: { appState.selectedPoleID },
          set: { appState.selectedPoleID = $0 }
        ),
        approach: appState.selectedApproach,
        progress: poleProgress
      )
      .presentationDetents([.medium, .large])
      .presentationDragIndicator(.visible)
    }
    .sheet(isPresented: $showingSessionEditor) {
      SessionSetupSheet(
        editingSession: activeSession,
        defaultKind: appState.sessionKind,
        onSave: saveSession
      )
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .sheet(isPresented: $showingVoiceLogger) {
      VoiceJumpLogSheet(
        poles: activePoles,
        defaultBarHeightCM: appState.currentBarHeightCM,
        defaultApproach: appState.selectedApproach,
        defaultPoleID: selectedPole?.id,
        onSave: saveVoiceDraft
      )
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .alert(
      "Tentative indisponible en compétition",
      isPresented: Binding(
        get: { competitionRuleMessage != nil },
        set: { if !$0 { competitionRuleMessage = nil } }
      )
    ) {
      Button("OK", role: .cancel) { competitionRuleMessage = nil }
    } message: {
      Text(competitionRuleMessage ?? "Modifiez la hauteur de barre ou démarrez une nouvelle compétition.")
    }
    .overlay {
      if showPRCelebration {
        PRCelebrationOverlay(
          heightCM: appState.currentBarHeightCM,
          dismiss: { showPRCelebration = false }
        )
        .transition(.scale.combined(with: .opacity))
        .zIndex(5)
      }
    }
  }

  private var focusModeToggle: some View {
    Button {
      appState.isTrackFocusMode.toggle()
      Haptics.impact(.light)
    } label: {
      Label(
        appState.isTrackFocusMode ? "Quitter le mode concentré" : "Mode concentré",
        systemImage: appState.isTrackFocusMode ? "eye" : "eye.slash"
      )
    }
    .buttonStyle(.bordered)
  }

  private var voiceLogButton: some View {
    Button {
      showingVoiceLogger = true
      Haptics.impact(.light)
    } label: {
      Label("Dicter un saut", systemImage: "waveform.and.mic")
    }
    .buttonStyle(.borderedProminent)
    .tint(.vaultNavy)
    .disabled(activePoles.isEmpty)
  }

  private var setupColumn: some View {
    VStack(spacing: VaultSpacing.medium) {
      sessionTypeCard
      approachCard
      barCard
      poleCard
      if !appState.isTrackFocusMode {
        jumpDetailsCard
        noteCard
      }
    }
  }

  private var loggingColumn: some View {
    VStack(spacing: VaultSpacing.medium) {
      outcomeCard
      if appState.sessionKind == .competition {
        competitionGridCard
      }
      recentAttemptsCard
    }
  }

  private var sessionTypeCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Séance")
        Spacer()
        if let activeSession {
          Label("En cours", systemImage: "record.circle")
            .font(.caption.weight(.bold))
            .foregroundStyle(Color.vaultSuccess)
            .accessibilityLabel("Séance de \(activeSession.kind.title.lowercased()) en cours")
        }
      }

      Picker(
        "Type de séance",
        selection: Binding(
          get: { appState.sessionKind },
          set: { appState.sessionKind = $0 }
        )
      ) {
        ForEach(SessionKind.allCases) { kind in
          Label(kind.title, systemImage: kind.symbol).tag(kind)
        }
      }
      .pickerStyle(.segmented)
      .disabled(activeSession != nil)

      if let activeSession {
        VStack(alignment: .leading, spacing: 10) {
          HStack {
            Label(activeSession.startedAt.formatted(date: .omitted, time: .shortened), systemImage: "clock")
            if !activeSession.locationName.isEmpty {
              Label(activeSession.locationName, systemImage: "mappin.and.ellipse")
            }
            Label(activeSession.environment.title, systemImage: activeSession.environment.symbol)
          }
          .font(.caption.weight(.semibold))
          .foregroundStyle(Color.vaultMuted)

          if !activeSession.sessionGoal.isEmpty {
            Label(activeSession.sessionGoal, systemImage: "scope")
              .font(.subheadline.weight(.bold))
          }

          HStack {
            Button("Modifier les conditions") { showingSessionEditor = true }
              .font(.caption.weight(.bold))
            Spacer()
            Button("Terminer la séance") { endSession(activeSession) }
              .font(.caption.weight(.bold))
          }
        }
      } else {
        Button {
          showingSessionEditor = true
        } label: {
          Label(
            "Démarrer la séance : \(appState.sessionKind.title.lowercased())", systemImage: "play.fill"
          )
          .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(.vaultAccent)
      }
    }
    .vaultCard()
  }

  private var approachCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Course d’élan")
        Spacer()
        Text("1 foulée = 1 appui")
          .font(.caption2)
          .foregroundStyle(Color.vaultMuted)
      }
      ScrollView(.horizontal, showsIndicators: false) {
        ApproachPicker(
          selection: Binding(
            get: { appState.selectedApproach },
            set: { appState.selectedApproach = $0 }
          ))
      }
    }
    .vaultCard()
  }

  private var barCard: some View {
    HStack(spacing: 18) {
      VStack(alignment: .leading, spacing: 5) {
        SectionEyebrow(text: "Barre")
        Text(String(format: "%.2f m", Double(appState.currentBarHeightCM) / 100.0))
          .font(.system(size: 46, weight: .black, design: .rounded))
          .monospacedDigit()
          .contentTransition(.numericText(value: Double(appState.currentBarHeightCM)))
      }
      Spacer()
      HStack(spacing: 10) {
        barButton(symbol: "minus", delta: -5)
        barButton(symbol: "plus", delta: 5)
      }
    }
    .vaultCard()
  }

  private func barButton(symbol: String, delta: Int) -> some View {
    Button {
      withAnimation(.snappy) {
        appState.adjustBar(by: delta)
      }
    } label: {
      Image(systemName: symbol)
        .font(.title2.weight(.black))
        .frame(width: 54, height: 54)
        .background(Color.vaultPanelRaised, in: Circle())
    }
    .buttonStyle(.plain)
    .accessibilityLabel(delta > 0 ? "Monter la barre de cinq centimètres" : "Descendre la barre de cinq centimètres")
  }

  private var poleCard: some View {
    Button {
      showingPolePicker = true
      Haptics.selection()
    } label: {
      HStack(spacing: 14) {
        Image(systemName: "line.diagonal")
          .font(.title2.weight(.bold))
          .foregroundStyle(Color.vaultAccent)
          .frame(width: 46, height: 46)
          .background(
            Color.vaultAccent.opacity(0.12),
            in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        VStack(alignment: .leading, spacing: 5) {
          SectionEyebrow(text: "Perche")
          if let selectedPole {
            Text(selectedPole.displayName)
              .font(.headline.monospacedDigit().weight(.black))
              .foregroundStyle(Color.vaultText)
            Text(
              [selectedPole.manufacturer, selectedPole.modelName, selectedPole.nickname]
                .filter { !$0.isEmpty }
                .joined(separator: " · ")
            )
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
          } else {
            Text("Choisir une perche")
              .foregroundStyle(Color.vaultMuted)
          }
        }
        Spacer()
        Image(systemName: "chevron.up.chevron.down")
          .foregroundStyle(Color.vaultMuted)
      }
    }
    .buttonStyle(.plain)
    .vaultCard()
  }

  private var jumpDetailsCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack {
        SectionEyebrow(text: "Détails du prochain saut")
        Spacer()
        Picker("Qualité", selection: $jumpRating) {
          ForEach(JumpRating.allCases) { rating in
            Label(rating.title, systemImage: rating.symbol).tag(rating)
          }
        }
        .pickerStyle(.menu)
      }

      DisclosureGroup(isExpanded: $showingAdvancedJumpDetails) {
        LazyVGrid(
          columns: [GridItem(.flexible()), GridItem(.flexible())],
          spacing: 12
        ) {
          jumpNumberField("Hauteur de prise", text: $gripHeightText, unit: "m")
          jumpNumberField("Longueur d’élan", text: $runUpDistanceText, unit: "m")
          jumpNumberField("Marque intermédiaire", text: $midMarkText, unit: "m")
          jumpNumberField("Marque d’impulsion", text: $takeoffMarkText, unit: "m")
          jumpNumberField("Poteaux", text: $standardsOffsetText, unit: "cm")
        }
        .padding(.top, 12)
      } label: {
        Label("Mesures techniques facultatives", systemImage: "ruler")
          .font(.subheadline.weight(.bold))
      }
    }
    .vaultCard(background: Color.vaultCyan.opacity(0.035))
  }

  private func jumpNumberField(_ title: String, text: Binding<String>, unit: String) -> some View {
    VStack(alignment: .leading, spacing: 6) {
      Text(title.uppercased())
        .font(.caption2.weight(.black))
        .tracking(0.7)
        .foregroundStyle(Color.vaultMuted)
      HStack {
        TextField("—", text: text)
          .keyboardType(.numbersAndPunctuation)
          .font(.headline.monospacedDigit())
        Text(unit)
          .font(.caption.weight(.bold))
          .foregroundStyle(Color.vaultMuted)
      }
      .padding(11)
      .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 12))
      .overlay {
        RoundedRectangle(cornerRadius: 12)
          .stroke(Color.vaultLine, lineWidth: 1)
      }
    }
  }

  private var noteCard: some View {
    VStack(alignment: .leading, spacing: 10) {
      SectionEyebrow(text: "Commentaires sur le saut")
      VaultCommentEditor(
        text: $attemptNote,
        placeholder: "Vent, piste, sensations, consigne, réglage des poteaux, décision pour le saut suivant…",
        minHeight: 170
      )
    }
    .vaultCard()
  }

  private var outcomeCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack {
        SectionEyebrow(text: "Résultat du saut")
        Spacer()
        Button {
          showingVoiceLogger = true
        } label: {
          Label("Dicter", systemImage: "mic.fill")
            .font(.caption.weight(.bold))
        }
        .buttonStyle(.bordered)
        .disabled(activePoles.isEmpty)
      }

      LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
        outcomeButton(.clear, tint: .vaultSuccess, prominent: true)
        outcomeButton(.miss, tint: .vaultAccent, prominent: true)
        outcomeButton(.abort, tint: .vaultWarning)
        outcomeButton(.runThrough, tint: .vaultWarning)
        outcomeButton(.pass, tint: .vaultCyan)

        Button {
          undoLastAttempt()
        } label: {
          Label("Annuler le dernier", systemImage: "arrow.uturn.backward")
            .font(.headline.weight(.black))
            .frame(maxWidth: .infinity, minHeight: 58)
            .foregroundStyle(Color.vaultText)
            .background(
              Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(sessionAttempts.isEmpty)
        .opacity(sessionAttempts.isEmpty ? 0.4 : 1)
      }
    }
    .vaultCard()
  }

  private func outcomeButton(_ result: AttemptResult, tint: Color, prominent: Bool = false)
    -> some View
  {
    Button {
      beginLogging(result)
    } label: {
      HStack(spacing: 10) {
        Text(result.competitionMark)
          .font(.title2.monospacedDigit().weight(.black))
        Text(result.title.uppercased())
          .font(.headline.weight(.black))
      }
      .frame(maxWidth: .infinity, minHeight: 58)
      .foregroundStyle(prominent ? Color.white : tint)
      .background(
        prominent ? tint : tint.opacity(0.12),
        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
      )
      .overlay {
        RoundedRectangle(cornerRadius: 15, style: .continuous)
          .stroke(tint.opacity(prominent ? 0 : 0.35), lineWidth: 1)
      }
    }
    .buttonStyle(PressScaleButtonStyle())
  }

  private var recentAttemptsCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Sauts récents")
        Spacer()
        Text("\(sessionAttempts.count)")
          .font(.headline.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultMuted)
      }

      if sessionAttempts.isEmpty {
        Text("Démarrez la séance puis enregistrez un saut. L’application sauvegarde d’abord sur l’iPad.")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
          .padding(.vertical, 12)
      } else {
        ForEach(Array(sessionAttempts.suffix(6).reversed())) { attempt in
          AttemptRow(attempt: attempt, pole: poles.first { $0.id == attempt.poleID })
        }
      }
    }
    .vaultCard()
  }

  private var competitionGridCard: some View {
    let grouped = Dictionary(
      grouping: sessionAttempts.filter { $0.result.isValidAttempt || $0.result == .pass }
    ) { $0.barHeightCM }
    let heights = grouped.keys.sorted()

    return VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Feuille de concours")
      if heights.isEmpty {
        Text("Les essais à chaque hauteur apparaissent sous la forme O, X ou –.")
          .foregroundStyle(Color.vaultMuted)
      } else {
        HStack(spacing: 8) {
          ForEach(heights, id: \.self) { height in
            VStack(spacing: 8) {
              Text(String(format: "%.2f", Double(height) / 100.0))
                .font(.caption.monospacedDigit().weight(.bold))
                .foregroundStyle(Color.vaultMuted)
              HStack(spacing: 3) {
                ForEach(Array(grouped[height, default: []].prefix(3))) { attempt in
                  Text(attempt.result.competitionMark)
                    .font(.headline.monospacedDigit().weight(.black))
                    .foregroundStyle(
                      attempt.result == .clear ? Color.vaultSuccess : Color.vaultAccent)
                }
              }
              .frame(minWidth: 54, minHeight: 28)
            }
            .padding(10)
            .background(
              Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
          }
          Spacer(minLength: 0)
        }
      }
    }
    .vaultCard()
  }

  private func beginLogging(_ result: AttemptResult) {
    guard selectedPole != nil else {
      showingPolePicker = true
      Haptics.warning()
      return
    }

    if let violation = competitionRuleViolation(for: result) {
      competitionRuleMessage = violation
      Haptics.warning()
      return
    }

    pendingResult = result
    selectedDiagnostics = []

    if result == .miss || result == .abort || result == .runThrough {
      showingDiagnostics = true
      Haptics.impact(.light)
    } else {
      saveAttempt(result: result, diagnostics: [], note: attemptNote)
    }
  }

  private func competitionRuleViolation(for result: AttemptResult) -> String? {
    guard appState.sessionKind == .competition else { return nil }

    let officialAttempts = sessionAttempts.filter {
      $0.result == .clear || $0.result == .miss || $0.result == .pass
    }

    var consecutiveFailures = 0
    for attempt in officialAttempts.reversed() {
      if attempt.result == .clear { break }
      if attempt.result == .miss { consecutiveFailures += 1 }
    }
    if consecutiveFailures >= 3 {
      return
        "Trois échecs consécutifs ont terminé ce concours. Terminez la séance ou démarrez un nouveau concours."
    }

    let atHeight = officialAttempts.filter { $0.barHeightCM == appState.currentBarHeightCM }
    if atHeight.contains(where: { $0.result == .clear }) {
      return
        "Cette hauteur est déjà franchie. Montez la barre avant d’enregistrer l’essai officiel suivant."
    }
    if atHeight.count >= 3 {
      return "Les trois essais disponibles à cette hauteur ont déjà été utilisés."
    }

    return nil
  }

  private func finalizePendingAttempt() {
    guard let pendingResult else { return }
    saveAttempt(result: pendingResult, diagnostics: selectedDiagnostics, note: attemptNote)
    self.pendingResult = nil
    selectedDiagnostics = []
    attemptNote = ""
    showingDiagnostics = false
  }

  private func saveAttempt(
    result: AttemptResult,
    diagnostics: Set<AttemptDiagnostic>,
    note: String,
    voiceTranscript: String = ""
  )
  {
    guard let athlete = profile, let pole = selectedPole else { return }
    let session = ensureActiveSession()
    let sequence = sessionAttempts.count
    let attemptNumber: Int?
    if appState.sessionKind == .competition {
      let atHeight = sessionAttempts.filter {
        $0.barHeightCM == appState.currentBarHeightCM
          && ($0.result.isValidAttempt || $0.result == .pass)
      }
      attemptNumber = min(atHeight.count + 1, 3)
    } else {
      attemptNumber = nil
    }

    let attempt = AttemptRecord(
      athleteID: athlete.id,
      sessionID: session.id,
      poleID: pole.id,
      result: result,
      diagnostics: diagnostics,
      barHeightCM: appState.currentBarHeightCM,
      approach: appState.selectedApproach,
      attemptNumber: attemptNumber,
      sequenceIndex: sequence,
      note: note,
      technicalRating: jumpRating,
      gripHeightM: parsedNumber(gripHeightText),
      runUpDistanceM: parsedNumber(runUpDistanceText),
      midMarkM: parsedNumber(midMarkText),
      standardsOffsetCM: parsedInteger(standardsOffsetText),
      voiceTranscript: voiceTranscript,
      actualTakeoffMarkM: parsedNumber(takeoffMarkText)
    )
    modelContext.insert(attempt)

    updatePoleProgress(for: pole, result: result)
    queueSync(for: attempt)

    let previousPR =
      appState.sessionKind == .competition ? athlete.currentPRCM : athlete.trainingPRCM
    if result == .clear && appState.currentBarHeightCM > previousPR {
      if appState.sessionKind == .competition {
        athlete.currentPRCM = appState.currentBarHeightCM
      } else {
        athlete.trainingPRCM = appState.currentBarHeightCM
      }
      athlete.updatedAt = .now
      appState.lastAchievementTitle = "Nouveau record"
      withAnimation(.spring(response: 0.45, dampingFraction: 0.72)) {
        showPRCelebration = true
      }
      Haptics.success()
    } else if result == .clear {
      Haptics.success()
    } else if result == .pass {
      Haptics.selection()
    } else {
      Haptics.warning()
    }

    do {
      try modelContext.save()
    } catch {
      Haptics.error()
    }

    resetJumpDraft()
  }

  private func saveVoiceDraft(_ draft: VoiceJumpDraft, poleID: UUID?) {
    if let barHeightCM = draft.barHeightCM {
      appState.currentBarHeightCM = barHeightCM
    }
    if let approach = draft.approach {
      appState.selectedApproach = approach
    }
    if let poleID {
      appState.selectedPoleID = poleID
    }

    guard selectedPole != nil else {
      showingPolePicker = true
      Haptics.warning()
      return
    }
    if let violation = competitionRuleViolation(for: draft.result) {
      competitionRuleMessage = violation
      Haptics.warning()
      return
    }

    jumpRating = draft.technicalRating
    gripHeightText = numberText(draft.gripHeightM)
    runUpDistanceText = numberText(draft.runUpDistanceM)
    midMarkText = numberText(draft.midMarkM)
    takeoffMarkText = numberText(draft.takeoffMarkM)
    standardsOffsetText = draft.standardsOffsetCM.map { String($0) } ?? ""

    saveAttempt(
      result: draft.result,
      diagnostics: draft.diagnostics,
      note: draft.transcript,
      voiceTranscript: draft.transcript
    )
  }

  private func saveSession(_ values: SessionSetupValues) {
    appState.sessionKind = values.kind
    if let activeSession {
      activeSession.kind = values.kind
      activeSession.startedAt = values.startedAt
      activeSession.title = values.title
      activeSession.locationName = values.locationName
      activeSession.environment = values.environment
      activeSession.weather = values.weather
      activeSession.windDirection = values.windDirection
      activeSession.windSpeedMPS = values.windSpeedMPS
      activeSession.temperatureC = values.temperatureC
      activeSession.energyLevel = values.energyLevel
      activeSession.sessionGoal = values.sessionGoal
      activeSession.notes = values.notes
      activeSession.updatedAt = .now
      PersistenceIssueCenter.shared.save(modelContext)
      Haptics.success()
      return
    }

    guard let athlete = profile else { return }
    for session in sessions where session.isActive && session.athleteID == athlete.id {
      session.isActive = false
      session.endedAt = .now
      session.updatedAt = .now
    }

    let session = VaultSessionRecord(
      athleteID: athlete.id,
      kind: values.kind,
      startedAt: values.startedAt,
      title: values.title,
      notes: values.notes,
      locationName: values.locationName,
      environment: values.environment,
      weather: values.weather,
      windDirection: values.windDirection,
      windSpeedMPS: values.windSpeedMPS,
      temperatureC: values.temperatureC,
      energyLevel: values.energyLevel,
      sessionGoal: values.sessionGoal
    )
    modelContext.insert(session)
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.impact(.medium)
  }

  @discardableResult
  private func ensureActiveSession() -> VaultSessionRecord {
    if let activeSession { return activeSession }
    guard let athlete = profile else {
      let fallbackID = UUID()
      return VaultSessionRecord(athleteID: fallbackID, kind: appState.sessionKind)
    }

    for session in sessions where session.isActive && session.athleteID == athlete.id {
      session.isActive = false
      session.endedAt = .now
      session.updatedAt = .now
    }

    let session = VaultSessionRecord(
      athleteID: athlete.id,
      kind: appState.sessionKind,
      title: appState.sessionKind == .competition ? "Compétition" : "Séance de perche"
    )
    modelContext.insert(session)
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.impact(.medium)
    return session
  }

  private func parsedNumber(_ text: String) -> Double? {
    let value = text.replacingOccurrences(of: ",", with: ".")
      .trimmingCharacters(in: .whitespacesAndNewlines)
    return value.isEmpty ? nil : Double(value)
  }

  private func parsedInteger(_ text: String) -> Int? {
    let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
    return value.isEmpty ? nil : Int(value)
  }

  private func numberText(_ value: Double?) -> String {
    guard let value else { return "" }
    return String(format: "%.2f", value)
  }

  private func resetJumpDraft() {
    attemptNote = ""
    jumpRating = .unrated
    gripHeightText = ""
    runUpDistanceText = ""
    midMarkText = ""
    takeoffMarkText = ""
    standardsOffsetText = ""
  }

  private func endSession(_ session: VaultSessionRecord) {
    session.isActive = false
    session.endedAt = .now
    session.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
  }

  private func updatePoleProgress(for pole: PoleRecord, result: AttemptResult) {
    guard let athlete = profile else { return }
    let approach = appState.selectedApproach.rawValue
    let record: PoleApproachProgressRecord
    if let existing = poleProgress.first(where: {
      $0.athleteID == athlete.id && $0.poleID == pole.id && $0.approachSteps == approach
    }) {
      record = existing
    } else {
      record = PoleApproachProgressRecord(
        athleteID: athlete.id,
        poleID: pole.id,
        approach: appState.selectedApproach,
        state: .unlocked
      )
      modelContext.insert(record)
    }

    if result.isValidAttempt {
      record.validAttempts += 1
    }
    if result == .clear {
      record.clears += 1
      if record.state < .successful {
        record.state = .successful
        record.firstSuccessfulUse = .now
      }
    }
    if record.validAttempts >= 8 && record.clears >= 5 && record.clearRate >= 0.5 {
      if record.state < .mastered {
        record.state = .mastered
        record.masteredAt = .now
        appState.lastAchievementTitle = "Perche maîtrisée"
      }
    }
    record.updatedAt = .now
  }

  private func queueSync(for attempt: AttemptRecord) {
    guard SyncConfiguration.isRemoteSyncEnabled else { return }
    let payload = """
      {"id":"\(attempt.id.uuidString)","result":"\(attempt.result.rawValue)","barHeightCM":\(attempt.barHeightCM),"approachSteps":\(attempt.approachSteps)}
      """
    modelContext.insert(
      SyncOperationRecord(
        entityType: "attempt",
        entityID: attempt.id,
        operation: "upsert",
        payloadJSON: payload
      )
    )
  }

  private func undoLastAttempt() {
    guard let last = sessionAttempts.last else { return }
    let poleID = last.poleID
    let approachSteps = last.approachSteps
    modelContext.delete(last)
    recalculatePoleProgress(poleID: poleID, approachSteps: approachSteps)
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.impact(.light)
  }

  private func recalculatePoleProgress(poleID: UUID, approachSteps: Int) {
    guard
      let record = poleProgress.first(where: {
        $0.athleteID == profile?.id && $0.poleID == poleID && $0.approachSteps == approachSteps
      })
    else { return }
    let relevant = attempts.filter {
      $0.athleteID == profile?.id && $0.id != sessionAttempts.last?.id && $0.poleID == poleID && $0.approachSteps == approachSteps
        && $0.deletedAt == nil
    }
    record.validAttempts = relevant.filter { $0.result.isValidAttempt }.count
    record.clears = relevant.filter { $0.result == .clear }.count
    if record.validAttempts >= 8 && record.clears >= 5 && record.clearRate >= 0.5 {
      record.state = .mastered
    } else if record.clears > 0 {
      record.state = .successful
    } else {
      record.state = .unlocked
    }
    record.updatedAt = .now
  }
}

private struct PressScaleButtonStyle: ButtonStyle {
  func makeBody(configuration: Configuration) -> some View {
    configuration.label
      .scaleEffect(configuration.isPressed ? 0.97 : 1)
      .opacity(configuration.isPressed ? 0.82 : 1)
      .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
  }
}

private struct AttemptRow: View {
  let attempt: AttemptRecord
  let pole: PoleRecord?

  private var resultColor: Color {
    switch attempt.result {
    case .clear: .vaultSuccess
    case .pass: .vaultCyan
    case .miss: .vaultAccent
    case .abort, .runThrough: .vaultWarning
    }
  }

  var body: some View {
    HStack(spacing: 12) {
      Text(attempt.result.competitionMark)
        .font(.title3.monospacedDigit().weight(.black))
        .foregroundStyle(resultColor)
        .frame(width: 34, height: 34)
        .background(resultColor.opacity(0.12), in: Circle())
      VStack(alignment: .leading, spacing: 3) {
        HStack(spacing: 8) {
          Text(String(format: "%.2f m", Double(attempt.barHeightCM) / 100))
            .font(.headline.monospacedDigit().weight(.black))
          Text("· \(attempt.approachSteps) foulées")
            .font(.caption.weight(.semibold))
            .foregroundStyle(Color.vaultMuted)
        }
        if let pole {
          Text(pole.displayName)
            .font(.caption.monospacedDigit())
            .foregroundStyle(Color.vaultMuted)
        }
        if !attempt.diagnostics.isEmpty {
          Text(attempt.diagnostics.map(\.title).sorted().joined(separator: " · "))
            .font(.caption2)
            .foregroundStyle(Color.vaultWarning)
            .lineLimit(1)
        }
      }
      Spacer()
      Text(attempt.createdAt, style: .time)
        .font(.caption.monospacedDigit())
        .foregroundStyle(Color.vaultMuted)
    }
    .padding(.vertical, 5)
  }
}

private struct DiagnosticSheet: View {
  @Environment(\.dismiss) private var dismiss
  let result: AttemptResult
  @Binding var selectedDiagnostics: Set<AttemptDiagnostic>
  @Binding var note: String
  let saveAction: () -> Void

  var body: some View {
    NavigationStack {
      ScrollView {
        VStack(alignment: .leading, spacing: 18) {
          Text("Ajoutez une ou plusieurs observations techniques. Elles alimentent les tendances et les propositions de perche suivante.")
            .foregroundStyle(Color.vaultMuted)

          LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(AttemptDiagnostic.allCases) { diagnostic in
              Button {
                if selectedDiagnostics.contains(diagnostic) {
                  selectedDiagnostics.remove(diagnostic)
                } else {
                  selectedDiagnostics.insert(diagnostic)
                }
                Haptics.selection()
              } label: {
                HStack {
                  Image(systemName: diagnostic.symbol)
                  Text(diagnostic.title)
                    .font(.subheadline.weight(.bold))
                  Spacer()
                  Image(
                    systemName: selectedDiagnostics.contains(diagnostic)
                      ? "checkmark.circle.fill" : "circle")
                }
                .padding(14)
                .foregroundStyle(
                  selectedDiagnostics.contains(diagnostic) ? Color.white : Color.vaultText
                )
                .background(
                  selectedDiagnostics.contains(diagnostic) ? Color.vaultAccent : Color.vaultPanel,
                  in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                )
              }
              .buttonStyle(.plain)
            }
          }

          VaultCommentEditor(
            text: $note,
            placeholder: "Décrivez les sensations, la course, la présentation, l’impulsion et la suite à donner…",
            minHeight: 210
          )
        }
        .padding(20)
      }
      .vaultPage()
      .navigationTitle(result.title)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer le saut") { saveAction() }
            .fontWeight(.bold)
        }
      }
    }
  }
}

private struct PolePickerSheet: View {
  @Environment(\.dismiss) private var dismiss
  let poles: [PoleRecord]
  @Binding var selectedPoleID: UUID?
  let approach: ApproachLength
  let progress: [PoleApproachProgressRecord]

  var body: some View {
    NavigationStack {
      ScrollView {
        LazyVStack(spacing: 12) {
          ForEach(poles) { pole in
            let status =
              progress.first {
                $0.poleID == pole.id && $0.approachSteps == approach.rawValue
              }?.state ?? .locked

            Button {
              selectedPoleID = pole.id
              Haptics.selection()
              dismiss()
            } label: {
              HStack(spacing: 14) {
                Image(systemName: status.symbol)
                  .font(.title3.weight(.bold))
                  .foregroundStyle(status == .mastered ? Color.vaultSuccess : Color.vaultWarning)
                  .frame(width: 44, height: 44)
                  .background(
                    Color.vaultPanelRaised,
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                VStack(alignment: .leading, spacing: 4) {
                  Text(pole.displayName)
                    .font(.headline.monospacedDigit().weight(.black))
                  Text("\(pole.manufacturer) · \(status.title) sur \(approach.title.lowercased())")
                    .font(.caption)
                    .foregroundStyle(Color.vaultMuted)
                }
                Spacer()
                if selectedPoleID == pole.id {
                  Image(systemName: "checkmark.circle.fill")
                    .font(.title2)
                    .foregroundStyle(Color.vaultAccent)
                }
              }
              .foregroundStyle(Color.vaultText)
              .vaultCard()
            }
            .buttonStyle(.plain)
          }
        }
        .padding(20)
      }
      .vaultPage()
      .navigationTitle("Choisir une perche")
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button("Terminé") { dismiss() }
        }
      }
    }
  }
}

private struct PRCelebrationOverlay: View {
  let heightCM: Int
  let dismiss: () -> Void

  var body: some View {
    ZStack {
      Color.black.opacity(0.62).ignoresSafeArea()
        .onTapGesture(perform: dismiss)
      VStack(spacing: 16) {
        Image(systemName: "trophy.fill")
          .font(.system(size: 52, weight: .black))
          .foregroundStyle(Color.vaultWarning)
        Text("NOUVEAU RECORD")
          .font(.caption.weight(.black))
          .tracking(3)
          .foregroundStyle(Color.vaultAccent)
        Text(String(format: "%.2f m", Double(heightCM) / 100))
          .font(.system(size: 58, weight: .black, design: .rounded))
          .monospacedDigit()
        Text("La courbe de progression et la feuille de route ont été mises à jour.")
          .foregroundStyle(Color.vaultMuted)
        Button("Continue", action: dismiss)
          .buttonStyle(.borderedProminent)
          .tint(.vaultAccent)
      }
      .padding(34)
      .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
      .overlay {
        RoundedRectangle(cornerRadius: 28, style: .continuous)
          .stroke(Color.vaultAccent.opacity(0.55), lineWidth: 1)
      }
    }
  }
}
