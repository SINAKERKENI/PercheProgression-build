import SwiftData
import SwiftUI

struct RoadmapView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Query(sort: \GoalPillarRecord.sortIndex) private var pillars: [GoalPillarRecord]
  @Query(sort: \GoalActionRecord.sortIndex) private var actions: [GoalActionRecord]
  @Query private var profiles: [AthleteProfile]
  @Query private var goals: [GoalRecord]

  @State private var selectedPillar: GoalPillarRecord?
  @State private var showingGoalEditor = false

  private var profile: AthleteProfile? { appState.athlete(in: profiles) }
  private var goal: GoalRecord? {
    guard let athleteID = profile?.id else { return nil }
    return goals.first { $0.athleteID == athleteID && $0.isActive }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        HStack(alignment: .top) {
          VaultScreenHeader(
            title: "Feuille de route Harada",
            subtitle: "Huit piliers de performance reliés à un objectif de hauteur mesurable.",
            symbol: "square.grid.3x3.fill"
          )
          Spacer()
          Button {
            showingGoalEditor = true
          } label: {
            Label("Modifier l’objectif", systemImage: "slider.horizontal.3")
          }
          .buttonStyle(.bordered)
        }

        roadmapGrid

        HStack(spacing: VaultSpacing.medium) {
          roadmapSummary
          nextActionsCard
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .sheet(item: $selectedPillar) { pillar in
      NavigationStack {
        PillarDetailView(pillar: pillar)
      }
      .presentationDetents([.medium, .large])
      .presentationDragIndicator(.visible)
    }
    .sheet(isPresented: $showingGoalEditor) {
      if let profile, let goal {
        GoalEditorView(profile: profile, goal: goal)
      }
    }
  }

  private var roadmapGrid: some View {
    let ordered = Array(pillars.prefix(8))
    return LazyVGrid(
      columns: Array(repeating: GridItem(.flexible(), spacing: 14), count: 3),
      spacing: 14
    ) {
      ForEach(0..<9, id: \.self) { index in
        if index == 4 {
          mainGoalCard
        } else if let pillar = pillarForGridIndex(index, from: ordered) {
          PillarCard(
            pillar: pillar,
            progress: progress(for: pillar),
            completedCount: completedCount(for: pillar),
            totalCount: actionCount(for: pillar)
          ) {
            selectedPillar = pillar
            Haptics.selection()
          }
        } else {
          Color.clear.frame(minHeight: 178)
        }
      }
    }
  }

  private var mainGoalCard: some View {
    let current = profile?.currentPRCM ?? 0
    let target = profile?.targetHeightCM ?? goal?.targetHeightCM ?? 0
    let progress = target > 0 ? min(Double(current) / Double(target), 1) : 0

    return Button {
      showingGoalEditor = true
      Haptics.impact(.light)
    } label: {
      VStack(spacing: 12) {
        Text("OBJECTIF")
          .font(.caption.weight(.black))
          .tracking(2)
          .foregroundStyle(Color.white.opacity(0.8))
        Text(String(format: "%.2f m", Double(target) / 100.0))
          .font(.system(size: 43, weight: .black, design: .rounded))
          .monospacedDigit()
        Text(String(format: "%.2f m à gagner", Double(max(target - current, 0)) / 100.0))
          .font(.subheadline.weight(.bold))
          .foregroundStyle(Color.white.opacity(0.86))
        ProgressView(value: progress)
          .tint(.white)
          .scaleEffect(y: 1.35)
          .padding(.horizontal, 8)
        Text("Touchez pour modifier l’objectif")
          .font(.caption2.weight(.semibold))
          .foregroundStyle(Color.white.opacity(0.66))
      }
      .frame(maxWidth: .infinity, minHeight: 178)
      .padding(18)
      .background(
        LinearGradient(
          colors: [.vaultAccent, .vaultCyan],
          startPoint: .topLeading,
          endPoint: .bottomTrailing
        ),
        in: RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
      )
      .shadow(color: Color.vaultAccent.opacity(0.25), radius: 22, y: 10)
    }
    .buttonStyle(.plain)
    .accessibilityLabel("Objectif principal : \(Double(target) / 100.0, specifier: "%.2f") mètre")
  }

  private var roadmapSummary: some View {
    let activeActions = actions.filter { !$0.isArchived }
    let completed = activeActions.filter(\.isCompleted).count
    let total = max(activeActions.count, 1)
    let ratio = Double(completed) / Double(total)

    return VStack(alignment: .leading, spacing: 14) {
      SectionEyebrow(text: "Avancement de la feuille de route")
      HStack(alignment: .lastTextBaseline) {
        Text("\(completed)")
          .font(.system(size: 38, weight: .black, design: .rounded))
        Text("sur \(total) actions")
          .foregroundStyle(Color.vaultMuted)
        Spacer()
        Text("\(Int((ratio * 100).rounded()))%")
          .font(.title2.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultAccent)
      }
      ProgressView(value: ratio)
        .tint(.vaultAccent)
      Text(
        "Validez les habitudes et étapes parce qu’elles servent la performance, et non pour conserver artificiellement une série."
      )
      .font(.footnote)
      .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var nextActionsCard: some View {
    let active = actions.filter { !$0.isArchived && !$0.isCompleted }
    let focused = active.filter(\.isFocused)
    let next = Array((focused.isEmpty ? active : focused).prefix(3))
    return VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "En ce moment")
      ForEach(Array(next)) { action in
        HStack(spacing: 10) {
          Image(systemName: "circle")
            .foregroundStyle(Color.vaultAccent)
          Text(action.title)
            .font(.subheadline.weight(.semibold))
            .lineLimit(2)
          Spacer()
        }
      }
      if next.isEmpty {
        Text("Toutes les actions de la feuille de route sont terminées.")
          .foregroundStyle(Color.vaultMuted)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private func pillarForGridIndex(_ index: Int, from ordered: [GoalPillarRecord])
    -> GoalPillarRecord?
  {
    let mapping = [0, 1, 2, 3, -1, 4, 5, 6, 7]
    let pillarIndex = mapping[index]
    guard pillarIndex >= 0, pillarIndex < ordered.count else { return nil }
    return ordered[pillarIndex]
  }

  private func actions(for pillar: GoalPillarRecord) -> [GoalActionRecord] {
    actions.filter { $0.pillarID == pillar.id && !$0.isArchived }
  }

  private func actionCount(for pillar: GoalPillarRecord) -> Int {
    actions(for: pillar).count
  }

  private func completedCount(for pillar: GoalPillarRecord) -> Int {
    actions(for: pillar).filter(\.isCompleted).count
  }

  private func progress(for pillar: GoalPillarRecord) -> Double {
    let related = actions(for: pillar)
    guard !related.isEmpty else { return 0 }
    return Double(related.filter(\.isCompleted).count) / Double(related.count)
  }
}

private struct PillarCard: View {
  let pillar: GoalPillarRecord
  let progress: Double
  let completedCount: Int
  let totalCount: Int
  let action: () -> Void

  var body: some View {
    Button(action: action) {
      VStack(alignment: .leading, spacing: 14) {
        HStack {
          Image(systemName: pillar.iconSymbol)
            .font(.title2.weight(.bold))
            .foregroundStyle(Color.vaultAccent)
            .frame(width: 42, height: 42)
            .background(
              Color.vaultAccent.opacity(0.12),
              in: RoundedRectangle(cornerRadius: 12, style: .continuous))
          Spacer()
          Text("\(Int((progress * 100).rounded()))%")
            .font(.headline.monospacedDigit().weight(.black))
            .foregroundStyle(Color.vaultMuted)
        }

        Spacer(minLength: 4)

        Text(pillar.title)
          .font(.headline.weight(.bold))
          .foregroundStyle(Color.vaultText)
          .multilineTextAlignment(.leading)
        Text("\(completedCount) sur \(totalCount) actions")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)

        ProgressView(value: progress)
          .tint(.vaultAccent)
      }
      .frame(maxWidth: .infinity, minHeight: 178, alignment: .leading)
      .padding(16)
      .background(
        Color.vaultPanel, in: RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
      )
      .overlay {
        RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
          .stroke(Color.vaultLine, lineWidth: 1)
      }
      .contentShape(RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous))
    }
    .buttonStyle(.plain)
  }
}

private struct PillarDetailView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  let pillar: GoalPillarRecord
  @Query private var allActions: [GoalActionRecord]
  @State private var editingAction: GoalActionRecord?

  private var activeActions: [GoalActionRecord] {
    allActions
      .filter { $0.pillarID == pillar.id && !$0.isArchived }
      .sorted { $0.sortIndex < $1.sortIndex }
  }

  private var archivedActions: [GoalActionRecord] {
    allActions
      .filter { $0.pillarID == pillar.id && $0.isArchived }
      .sorted { $0.sortIndex < $1.sortIndex }
  }

  private var progress: Double {
    guard !activeActions.isEmpty else { return 0 }
    return Double(activeActions.filter(\.isCompleted).count) / Double(activeActions.count)
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        HStack(spacing: 14) {
          Image(systemName: pillar.iconSymbol)
            .font(.title.weight(.bold))
            .foregroundStyle(Color.vaultAccent)
            .frame(width: 56, height: 56)
            .background(
              Color.vaultAccent.opacity(0.12),
              in: RoundedRectangle(cornerRadius: 16, style: .continuous))
          VStack(alignment: .leading, spacing: 5) {
            Text(pillar.title)
              .font(.title.weight(.black))
            Text("\(Int((progress * 100).rounded())) % réalisé")
              .foregroundStyle(Color.vaultMuted)
          }
          Spacer()
        }

        ProgressView(value: progress)
          .tint(.vaultAccent)
          .scaleEffect(y: 1.5)

        if activeActions.isEmpty {
          Text("Aucune action active. Une case vide vaut mieux qu’une action de remplissage : restaurez une action archivée ou adaptez votre feuille de route.")
            .font(.footnote)
            .foregroundStyle(Color.vaultMuted)
            .vaultCard()
        }

        ForEach(activeActions) { action in
          actionRow(action)
        }

        if !archivedActions.isEmpty {
          DisclosureGroup("Actions archivées (\(archivedActions.count))") {
            VStack(spacing: 10) {
              ForEach(archivedActions) { action in
                HStack(spacing: 12) {
                  Text(action.title)
                    .font(.subheadline)
                    .foregroundStyle(Color.vaultMuted)
                  Spacer()
                  Button("Restaurer") {
                    action.isArchived = false
                    action.updatedAt = .now
                    PersistenceIssueCenter.shared.save(modelContext)
                  }
                  .buttonStyle(.bordered)
                  .controlSize(.small)
                }
                .padding(.vertical, 4)
              }
            }
            .padding(.top, 8)
          }
          .font(.subheadline.weight(.bold))
        }
      }
      .padding(22)
    }
    .vaultPage()
    .navigationTitle("Pilier")
    .toolbar {
      ToolbarItem(placement: .topBarTrailing) {
        Button("Terminé") { dismiss() }
      }
    }
    .sheet(item: $editingAction) { action in
      NavigationStack {
        RoadmapActionEditor(action: action)
      }
    }
  }

  private func actionRow(_ action: GoalActionRecord) -> some View {
    HStack(spacing: 12) {
      Button {
        action.isCompleted.toggle()
        action.updatedAt = .now
        modelContext.insert(
          ActionCheckInRecord(
            actionID: action.id,
            completed: action.isCompleted,
            value: action.currentValue
          )
        )
        PersistenceIssueCenter.shared.save(modelContext)
        action.isCompleted ? Haptics.success() : Haptics.selection()
      } label: {
        Image(systemName: action.isCompleted ? "checkmark.circle.fill" : "circle")
          .font(.title3.weight(.semibold))
          .foregroundStyle(action.isCompleted ? Color.vaultSuccess : Color.vaultMuted)
      }
      .buttonStyle(.plain)
      .accessibilityLabel(action.isCompleted ? "Marquer comme non réalisée" : "Marquer comme réalisée")

      VStack(alignment: .leading, spacing: 5) {
        HStack(spacing: 6) {
          if action.isFocused {
            Image(systemName: "scope")
              .foregroundStyle(Color.vaultAccent)
              .accessibilityLabel("Action en ce moment")
          }
          Text(action.title)
            .font(.headline)
            .foregroundStyle(Color.vaultText)
            .strikethrough(action.isCompleted, color: Color.vaultMuted)
        }
        Text("\(action.kind.title) · \(action.recurrence)")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }
      Spacer()

      Menu {
        Button(action.isFocused ? "Retirer de « En ce moment »" : "Mettre dans « En ce moment »") {
          action.isFocused.toggle()
          action.updatedAt = .now
          PersistenceIssueCenter.shared.save(modelContext)
        }
        Button("Modifier") { editingAction = action }
        Button("Monter") { move(action, by: -1) }
        Button("Descendre") { move(action, by: 1) }
        Divider()
        Button("Archiver", role: .destructive) {
          action.isArchived = true
          action.isFocused = false
          action.updatedAt = .now
          PersistenceIssueCenter.shared.save(modelContext)
        }
      } label: {
        Image(systemName: "ellipsis.circle")
          .font(.title3)
      }
      .accessibilityLabel("Options de l’action")
    }
    .vaultCard(background: action.isCompleted ? Color.vaultSuccess.opacity(0.07) : .vaultPanel)
  }

  private func move(_ action: GoalActionRecord, by delta: Int) {
    guard let index = activeActions.firstIndex(where: { $0.id == action.id }) else { return }
    let otherIndex = index + delta
    guard activeActions.indices.contains(otherIndex) else { return }
    let other = activeActions[otherIndex]
    let old = action.sortIndex
    action.sortIndex = other.sortIndex
    other.sortIndex = old
    action.updatedAt = .now
    other.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.selection()
  }
}

private struct RoadmapActionEditor: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Bindable var action: GoalActionRecord
  @State private var hasTarget = false

  var body: some View {
    Form {
      Section("Action") {
        TextField("Action concrète", text: $action.title, axis: .vertical)
        Picker("Type", selection: Binding(
          get: { action.kind },
          set: { action.kind = $0 }
        )) {
          ForEach(GoalActionKind.allCases) { kind in Text(kind.title).tag(kind) }
        }
        Picker("Récurrence", selection: $action.recurrence) {
          ForEach(["À chaque séance", "Hebdomadaire", "Mensuelle", "Compétition", "Saison", "Ponctuelle"], id: \.self) { value in
            Text(value).tag(value)
          }
        }
      }

      Section("Suivi") {
        Toggle("Dans « En ce moment »", isOn: $action.isFocused)
        Toggle("Objectif chiffré", isOn: $hasTarget)
        if hasTarget {
          TextField("Valeur cible", value: Binding(
            get: { action.targetValue ?? 0 },
            set: { action.targetValue = $0 }
          ), format: .number)
          .keyboardType(.decimalPad)
          TextField("Unité", text: $action.unit)
        }
      }
    }
    .navigationTitle("Modifier l’action")
    .navigationBarTitleDisplayMode(.inline)
    .onAppear { hasTarget = action.targetValue != nil }
    .onChange(of: hasTarget) { _, enabled in
      if !enabled { action.targetValue = nil; action.unit = "" }
    }
    .toolbar {
      ToolbarItem(placement: .cancellationAction) { Button("Annuler") { dismiss() } }
      ToolbarItem(placement: .confirmationAction) {
        Button("Enregistrer") {
          action.updatedAt = .now
          PersistenceIssueCenter.shared.save(modelContext)
          dismiss()
        }
        .disabled(action.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
      }
    }
  }
}

private struct GoalEditorView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Bindable var profile: AthleteProfile
  @Bindable var goal: GoalRecord

  var body: some View {
    NavigationStack {
      Form {
        Section("Objectif principal") {
          TextField("Titre de l’objectif", text: $goal.title)
          Stepper(value: $profile.targetHeightCM, in: 0...700, step: 5) {
            LabeledContent(
              "Hauteur de barre visée",
              value: String(format: "%.2f m", Double(profile.targetHeightCM) / 100))
          }
          DatePicker(
            "Date cible",
            selection: Binding(
              get: { goal.targetDate ?? .now },
              set: { goal.targetDate = $0 }
            ),
            displayedComponents: .date
          )
        }

        Section("Point de départ") {
          Stepper(value: $profile.currentPRCM, in: 0...700, step: 1) {
            LabeledContent(
              "Record officiel", value: String(format: "%.2f m", Double(profile.currentPRCM) / 100))
          }
          Stepper(value: $profile.trainingPRCM, in: 0...700, step: 1) {
            LabeledContent(
              "Record à l’entraînement", value: String(format: "%.2f m", Double(profile.trainingPRCM) / 100))
          }
        }

        Section {
          Text(
            "La feuille de route reste entièrement modulable : l’objectif central est une hauteur de barre et chaque pilier peut évoluer selon les besoins de l’athlète."
          )
          .font(.footnote)
          .foregroundStyle(.secondary)
        }
      }
      .navigationTitle("Modifier l’objectif")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer") {
            goal.targetHeightCM = profile.targetHeightCM
            goal.updatedAt = .now
            profile.updatedAt = .now
            PersistenceIssueCenter.shared.save(modelContext)
            Haptics.success()
            dismiss()
          }
        }
      }
    }
  }
}
