import Foundation
import SwiftData
import SwiftUI

struct HomeDashboardView: View {
  @Environment(AppState.self) private var appState
  @Query private var profiles: [AthleteProfile]
  @Query(sort: \VaultSessionRecord.startedAt, order: .reverse) private var sessions: [VaultSessionRecord]
  @Query(sort: \AttemptRecord.createdAt, order: .reverse) private var attempts: [AttemptRecord]
  @Query(sort: \PhysicalMetricRecord.measuredAt, order: .reverse) private var metrics: [PhysicalMetricRecord]
  @Query private var videos: [VideoClipRecord]
  @Query private var poleProgress: [PoleApproachProgressRecord]
  @Query private var drillCompletions: [DrillCompletionRecord]

  private var athlete: AthleteProfile? { appState.athlete(in: profiles) }

  private var scopedSessions: [VaultSessionRecord] {
    guard let id = athlete?.id else { return [] }
    return sessions.filter { $0.athleteID == id }
  }

  private var scopedAttempts: [AttemptRecord] {
    guard let id = athlete?.id else { return [] }
    return attempts.filter { $0.athleteID == id && $0.deletedAt == nil }
  }

  private var activeSession: VaultSessionRecord? {
    scopedSessions.first(where: \.isActive)
  }

  private var achievementSnapshot: AchievementSnapshot {
    AchievementEngine.snapshot(
      athlete: athlete,
      sessions: sessions,
      attempts: attempts,
      videos: videos,
      poleProgress: poleProgress,
      drillCompletions: drillCompletions,
      metrics: metrics
    )
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        greetingHeader
        performanceHero
        quickActions

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            recentSessionsCard
              .frame(maxWidth: .infinity)
            recentJumpsCard
              .frame(maxWidth: .infinity)
          }
          VStack(spacing: VaultSpacing.large) {
            recentSessionsCard
            recentJumpsCard
          }
        }

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            coachingFocusCard
              .frame(maxWidth: .infinity)
            milestoneCard
              .frame(maxWidth: .infinity)
          }
          VStack(spacing: VaultSpacing.large) {
            coachingFocusCard
            milestoneCard
          }
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
  }

  private var greetingHeader: some View {
    HStack(alignment: .center, spacing: 16) {
      VStack(alignment: .leading, spacing: 5) {
        Text(greeting)
          .font(.subheadline.weight(.bold))
          .foregroundStyle(Color.vaultMuted)
        Text(athlete?.displayName ?? "Athlète")
          .font(.system(.largeTitle, design: .rounded, weight: .black))
      }
      Spacer()
      Button {
        if let activeSession {
          appState.sessionKind = activeSession.kind
        }
        appState.destination = .log
        Haptics.impact(.light)
      } label: {
        Label(
          activeSession == nil ? "Démarrer une séance" : "Continuer la séance",
          systemImage: activeSession == nil ? "play.fill" : "arrow.right.circle.fill"
        )
      }
      .buttonStyle(.borderedProminent)
      .tint(activeSession == nil ? .vaultAccent : .vaultSuccess)
    }
  }

  private var performanceHero: some View {
    let current = max(athlete?.currentPRCM ?? 0, athlete?.trainingPRCM ?? 0)
    let target = athlete?.targetHeightCM ?? 0
    let progress = target > 0 ? min(Double(current) / Double(target), 1) : 0
    let valid = scopedAttempts.filter { $0.result.isValidAttempt }
    let clearRate = valid.isEmpty
      ? 0
      : Double(valid.filter { $0.result == .clear }.count) / Double(valid.count)
    let latestSpeed = metrics.first {
      $0.athleteID == athlete?.id && $0.kind.isApproachSpeedFamily
    }?.value ?? 0

    return VStack(alignment: .leading, spacing: 22) {
      HStack(alignment: .top) {
        VStack(alignment: .leading, spacing: 6) {
          Text("RECORD PERSONNEL")
            .font(.caption.weight(.black))
            .tracking(1.4)
            .foregroundStyle(Color.white.opacity(0.67))
          Text(String(format: "%.2f m", Double(current) / 100))
            .font(.system(size: 52, weight: .black, design: .rounded))
            .monospacedDigit()
          if target > 0 {
            Text(String(format: "Objectif %.2f m · %d %%", Double(target) / 100, Int((progress * 100).rounded())))
              .font(.subheadline.weight(.bold))
              .foregroundStyle(Color.white.opacity(0.78))
          } else {
            Text("Définissez votre objectif dans le profil")
              .font(.subheadline.weight(.bold))
              .foregroundStyle(Color.white.opacity(0.78))
          }
        }
        Spacer()
        Image(systemName: "trophy.fill")
          .font(.system(size: 34, weight: .bold))
          .foregroundStyle(Color.vaultGold)
          .frame(width: 70, height: 70)
          .background(Color.white.opacity(0.10), in: Circle())
      }

      ProgressView(value: progress)
        .tint(.vaultGold)

      HStack(spacing: 0) {
        heroMetric("Séances", "\(scopedSessions.count)")
        heroDivider
        heroMetric("Sauts", "\(scopedAttempts.count)")
        heroDivider
        heroMetric("Réussite", "\(Int((clearRate * 100).rounded())) %")
        heroDivider
        heroMetric("Vitesse", latestSpeed > 0 ? String(format: "%.2f m/s", latestSpeed) : "—")
      }
    }
    .padding(28)
    .foregroundStyle(.white)
    .background(
      LinearGradient(
        colors: [.vaultNavy, .vaultNavyLight],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      ),
      in: RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
    )
    .overlay(alignment: .topTrailing) {
      Circle()
        .stroke(Color.white.opacity(0.06), lineWidth: 24)
        .frame(width: 210, height: 210)
        .offset(x: 55, y: -70)
        .allowsHitTesting(false)
    }
  }

  private func heroMetric(_ title: String, _ value: String) -> some View {
    VStack(spacing: 5) {
      Text(value)
        .font(.headline.monospacedDigit().weight(.black))
      Text(title)
        .font(.caption)
        .foregroundStyle(Color.white.opacity(0.65))
    }
    .frame(maxWidth: .infinity)
  }

  private var heroDivider: some View {
    Rectangle()
      .fill(Color.white.opacity(0.14))
      .frame(width: 1, height: 34)
  }

  private var quickActions: some View {
    LazyVGrid(
      columns: [GridItem(.adaptive(minimum: 175), spacing: 12)],
      spacing: 12
    ) {
      quickAction("Saisir un saut", "plus.circle.fill", .log, .vaultAccent)
      Button {
        appState.shouldPresentVoiceLog = true
        appState.destination = .log
        Haptics.impact(.light)
      } label: {
        quickActionLabel("Dicter un saut", "waveform.and.mic", .vaultGold)
      }
      .buttonStyle(.plain)
      quickAction("Analyser une vidéo", "video.fill", .video, .vaultCyan)
      quickAction("Voir la progression", "chart.xyaxis.line", .progress, .vaultSuccess)
      quickAction("Choisir une perche", "line.diagonal", .poles, .vaultWarning)
      quickAction("Trouver un exercice", "books.vertical.fill", .library, .vaultNavyLight)
    }
  }

  private func quickAction(
    _ title: String,
    _ symbol: String,
    _ destination: AppDestination,
    _ tint: Color
  ) -> some View {
    Button {
      appState.destination = destination
      Haptics.selection()
    } label: {
      quickActionLabel(title, symbol, tint)
    }
    .buttonStyle(.plain)
  }

  private func quickActionLabel(_ title: String, _ symbol: String, _ tint: Color) -> some View {
    HStack(spacing: 11) {
      Image(systemName: symbol)
        .font(.headline.weight(.bold))
        .foregroundStyle(tint)
        .frame(width: 38, height: 38)
        .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 11))
      Text(title)
        .font(.subheadline.weight(.black))
        .foregroundStyle(Color.vaultText)
      Spacer(minLength: 0)
    }
    .padding(13)
    .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    .overlay {
      RoundedRectangle(cornerRadius: 16, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }

  private var recentSessionsCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      sectionTitle("Séances récentes", symbol: "calendar", action: "Tout voir") {
        appState.destination = .journal
      }

      if scopedSessions.isEmpty {
        compactEmpty("Aucune séance", "Votre prochaine séance apparaîtra ici.")
      } else {
        ForEach(Array(scopedSessions.prefix(3))) { session in
          Button {
            appState.openSession(session.id)
          } label: {
            sessionRow(session)
          }
          .buttonStyle(.plain)
          if session.id != scopedSessions.prefix(3).last?.id {
            Divider().overlay(Color.vaultLine)
          }
        }
      }
    }
    .vaultCard()
  }

  private func sessionRow(_ session: VaultSessionRecord) -> some View {
    let jumps = scopedAttempts.filter { $0.sessionID == session.id }
    let best = jumps.filter { $0.result == .clear }.map(\.barHeightCM).max()
    return HStack(spacing: 12) {
      Image(systemName: session.kind.symbol)
        .font(.headline.weight(.bold))
        .foregroundStyle(session.isActive ? Color.white : Color.vaultNavy)
        .frame(width: 42, height: 42)
        .background(session.isActive ? Color.vaultSuccess : Color.vaultPanelRaised, in: Circle())
      VStack(alignment: .leading, spacing: 4) {
        Text(session.title.isEmpty ? session.kind.title : session.title)
          .font(.headline.weight(.black))
          .foregroundStyle(Color.vaultText)
        Text(sessionMeta(session, jumpCount: jumps.count))
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }
      Spacer()
      if let best {
        Text(String(format: "%.2f m", Double(best) / 100))
          .font(.headline.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultSuccess)
      }
      Image(systemName: "chevron.right")
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.vaultMuted)
    }
    .contentShape(Rectangle())
  }

  private var recentJumpsCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      sectionTitle("Sauts récents", symbol: "figure.track.and.field", action: "Tout voir") {
        appState.destination = .journal
      }

      if scopedAttempts.isEmpty {
        compactEmpty("Aucun saut", "La saisie piste reste disponible hors connexion.")
      } else {
        ForEach(Array(scopedAttempts.prefix(4))) { attempt in
          HStack(spacing: 12) {
            Text(attempt.result.competitionMark)
              .font(.headline.monospacedDigit().weight(.black))
              .foregroundStyle(attempt.result == .clear ? Color.vaultSuccess : Color.vaultAccent)
              .frame(width: 36, height: 36)
              .background(Color.vaultPanelRaised, in: Circle())
            VStack(alignment: .leading, spacing: 3) {
              Text(String(format: "%.2f m · %d foulées", Double(attempt.barHeightCM) / 100, attempt.approachSteps))
                .font(.subheadline.monospacedDigit().weight(.black))
              Text(attempt.createdAt.formatted(date: .abbreviated, time: .shortened))
                .font(.caption)
                .foregroundStyle(Color.vaultMuted)
            }
            Spacer()
            if attempt.technicalRating != .unrated {
              Label(attempt.technicalRating.title, systemImage: attempt.technicalRating.symbol)
                .labelStyle(.iconOnly)
                .foregroundStyle(Color.vaultGold)
            }
          }
        }
      }
    }
    .vaultCard()
  }

  private var coachingFocusCard: some View {
    let diagnostic = mostFrequentDiagnostic
    return VStack(alignment: .leading, spacing: 14) {
      SectionEyebrow(text: "Priorité technique")
      HStack(alignment: .top, spacing: 14) {
        Image(systemName: diagnostic?.symbol ?? "sparkles")
          .font(.title2.weight(.bold))
          .foregroundStyle(Color.vaultAccent)
          .frame(width: 52, height: 52)
          .background(Color.vaultAccent.opacity(0.10), in: RoundedRectangle(cornerRadius: 15))
        VStack(alignment: .leading, spacing: 5) {
          Text(diagnostic?.title ?? "Construire votre référence")
            .font(.title3.weight(.black))
          Text(diagnostic == nil
            ? "Enregistrez quelques sauts avec leurs observations pour obtenir une priorité fondée sur vos données."
            : "Ce diagnostic revient le plus souvent sur vos douze derniers sauts annotés. La bibliothèque peut être filtrée automatiquement.")
            .font(.subheadline)
            .foregroundStyle(Color.vaultMuted)
        }
      }
      Button {
        appState.destination = .library
      } label: {
        Label("Ouvrir les exercices", systemImage: "arrow.right")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultNavy)
    }
    .vaultCard()
  }

  private var milestoneCard: some View {
    let achievements = AchievementEngine.achievements(for: achievementSnapshot)
    let unlocked = achievements.filter(\.isUnlocked).count
    let next = achievements.filter { !$0.isUnlocked }.max { $0.progress < $1.progress }

    return VStack(alignment: .leading, spacing: 14) {
      HStack {
        SectionEyebrow(text: "Jalons")
        Spacer()
        Text("\(unlocked) / \(achievements.count)")
          .font(.headline.monospacedDigit().weight(.black))
      }
      if let next {
        HStack(spacing: 14) {
          Image(systemName: next.symbol)
            .font(.title2.weight(.bold))
            .foregroundStyle(Color.vaultGold)
            .frame(width: 52, height: 52)
            .background(Color.vaultGold.opacity(0.12), in: Circle())
          VStack(alignment: .leading, spacing: 6) {
            Text(next.title)
              .font(.title3.weight(.black))
            ProgressView(value: next.progress)
              .tint(.vaultGold)
            Text("\(Int((next.progress * 100).rounded())) % accompli")
              .font(.caption.monospacedDigit())
              .foregroundStyle(Color.vaultMuted)
          }
        }
      } else {
        Label("Tous les jalons sont débloqués", systemImage: "checkmark.seal.fill")
          .font(.headline.weight(.black))
          .foregroundStyle(Color.vaultSuccess)
      }
      Button("Voir tous les jalons") {
        appState.destination = .achievements
      }
      .buttonStyle(.bordered)
    }
    .vaultCard(background: Color.vaultGold.opacity(0.035))
  }

  private func sectionTitle(
    _ title: String,
    symbol: String,
    action: String,
    perform: @escaping () -> Void
  ) -> some View {
    HStack {
      Label(title, systemImage: symbol)
        .font(.title3.weight(.black))
      Spacer()
      Button(action, action: perform)
        .font(.caption.weight(.bold))
    }
  }

  private func compactEmpty(_ title: String, _ detail: String) -> some View {
    VStack(spacing: 7) {
      Text(title).font(.headline.weight(.black))
      Text(detail)
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
        .multilineTextAlignment(.center)
    }
    .frame(maxWidth: .infinity, minHeight: 100)
  }

  private func sessionMeta(_ session: VaultSessionRecord, jumpCount: Int) -> String {
    var parts = [session.startedAt.formatted(date: .abbreviated, time: .omitted), "\(jumpCount) sauts"]
    if !session.locationName.isEmpty { parts.append(session.locationName) }
    if session.isActive { parts.append("en cours") }
    return parts.joined(separator: " · ")
  }

  private var mostFrequentDiagnostic: AttemptDiagnostic? {
    let recent = scopedAttempts.prefix(12)
    var counts: [AttemptDiagnostic: Int] = [:]
    for attempt in recent {
      for diagnostic in attempt.diagnostics {
        counts[diagnostic, default: 0] += 1
      }
    }
    return counts.max { $0.value < $1.value }?.key
  }

  private var greeting: String {
    switch Calendar.current.component(.hour, from: .now) {
    case 5..<12: "Bonjour,"
    case 12..<18: "Bon après-midi,"
    default: "Bonsoir,"
    }
  }
}
