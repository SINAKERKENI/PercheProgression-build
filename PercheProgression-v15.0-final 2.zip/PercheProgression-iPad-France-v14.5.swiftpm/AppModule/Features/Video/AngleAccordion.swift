import SwiftUI

struct AngleAccordion: View {
  let title: String
  let angles: [BiomechanicalAngle]
  @State private var expanded = false

  var body: some View {
    DisclosureGroup(isExpanded: $expanded) {
      VStack(spacing: 10) {
        ForEach(angles) { angle in
          VStack(alignment: .leading, spacing: 5) {
            HStack {
              Text(angle.title)
                .foregroundStyle(Color.vaultText)
              Spacer()
              Text(String(format: "%+.1f°", angle.degrees))
                .monospacedDigit()
                .fontWeight(.bold)
            }
            .font(.subheadline)

            HStack(spacing: 8) {
              Text(angle.quality.rawValue)
                .font(.caption2.weight(.bold))
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(qualityColor(angle.quality).opacity(0.15), in: Capsule())
                .foregroundStyle(qualityColor(angle.quality))
              Text(angle.uncertaintyDegrees == nil ? "incertitude angulaire non calibrée" : "incertitude disponible")
                .font(.caption2)
                .foregroundStyle(Color.vaultMuted)
            }
            Text(angle.referenceDescription)
              .font(.caption2)
              .foregroundStyle(Color.vaultMuted)
          }
        }
      }
      .padding(.top, 10)
    } label: {
      HStack {
        Text(title)
          .fontWeight(.bold)
        Spacer()
        Text("\(angles.count) mesures")
          .foregroundStyle(Color.vaultMuted)
          .font(.caption)
      }
    }
    .padding()
    .background(
      Color.vaultPanelRaised,
      in: RoundedRectangle(cornerRadius: 16, style: .continuous)
    )
  }

  private func qualityColor(_ quality: BiomechanicalMeasurementQuality) -> Color {
    switch quality {
    case .automatic: .blue
    case .verifiedManual: .green
    case .lowQuality: .red
    case .review: .vaultAnalysisReview
    }
  }
}
