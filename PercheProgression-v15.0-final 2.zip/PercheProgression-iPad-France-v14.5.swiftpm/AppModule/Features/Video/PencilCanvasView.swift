import PencilKit
import SwiftUI

struct PencilCanvasView: UIViewRepresentable {
  @Binding var drawing: PKDrawing
  @Binding var canvasReference: PKCanvasView?
  let isActive: Bool
  let isEraser: Bool

  func makeCoordinator() -> Coordinator {
    Coordinator(drawing: $drawing)
  }

  func makeUIView(context: Context) -> PKCanvasView {
    let canvas = PKCanvasView()
    canvas.backgroundColor = .clear
    canvas.isOpaque = false
    canvas.delegate = context.coordinator
    // Sur la piste, le doigt doit fonctionner si l’Apple Pencil n’est pas disponible.
    canvas.drawingPolicy = .anyInput
    canvas.alwaysBounceVertical = false
    canvas.alwaysBounceHorizontal = false
    canvas.isScrollEnabled = false
    canvas.drawing = drawing
    updateTool(canvas)
    canvasReference = canvas
    return canvas
  }

  func updateUIView(_ canvas: PKCanvasView, context: Context) {
    canvas.isUserInteractionEnabled = isActive
    if canvasReference !== canvas {
      canvasReference = canvas
    }
    if canvas.drawing.dataRepresentation() != drawing.dataRepresentation() {
      canvas.drawing = drawing
    }
    updateTool(canvas)
  }

  static func dismantleUIView(_ uiView: PKCanvasView, coordinator: Coordinator) {
    uiView.delegate = nil
  }

  private func updateTool(_ canvas: PKCanvasView) {
    if isEraser {
      canvas.tool = PKEraserTool(.vector)
    } else {
      canvas.tool = PKInkingTool(.pen, color: .systemBlue, width: 4)
    }
  }

  final class Coordinator: NSObject, PKCanvasViewDelegate {
    @Binding var drawing: PKDrawing

    init(drawing: Binding<PKDrawing>) {
      _drawing = drawing
    }

    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
      drawing = canvasView.drawing
    }
  }
}
