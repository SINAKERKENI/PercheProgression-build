import SwiftUI
import UIKit

/// Timeline d'analyse pensée pour le geste :
/// - un doigt : glisser la bande sous la tête de lecture fixe ;
/// - tap : aller directement à l'instant visé ;
/// - deux doigts : pincer pour zoomer/dézoomer temporellement.
///
/// Le temps est quantifié sur le PTS réel de l’image la plus proche lorsque
/// l’index du média est disponible. Un mode dégradé FPS est signalé sinon.
struct InteractiveVideoTimeline: View {
  enum Style {
    case fullscreen
    case panel

    var background: Color {
      switch self {
      case .fullscreen: return Color.white.opacity(0.30)
      case .panel: return Color.vaultPanelRaised
      }
    }

    var tick: Color {
      switch self {
      case .fullscreen: return Color.black.opacity(0.88)
      case .panel: return Color.vaultText.opacity(0.72)
      }
    }

    var secondaryTick: Color {
      switch self {
      case .fullscreen: return Color.black.opacity(0.48)
      case .panel: return Color.vaultMuted.opacity(0.50)
      }
    }

    var playhead: Color {
      switch self {
      case .fullscreen: return .white
      case .panel: return .vaultAnalysisAccent
      }
    }

    var label: Color {
      switch self {
      case .fullscreen: return .white
      case .panel: return .vaultText
      }
    }
  }

  @ObservedObject var viewModel: VideoLabViewModel
  var style: Style = .panel
  var height: CGFloat = 64
  var onInteractionChanged: (Bool) -> Void = { _ in }

  @State private var zoomScale: Double = 1
  @State private var panStartTime: Double?
  @State private var pinchStartZoom: Double?

  var body: some View {
    GeometryReader { geometry in
      let width = max(geometry.size.width, 1)
      let visibleDuration = visibleDurationSeconds

      ZStack {
        RoundedRectangle(cornerRadius: height / 2, style: .continuous)
          .fill(style.background)

        Canvas { context, size in
          drawTicks(
            context: &context,
            size: size,
            visibleDuration: visibleDuration
          )
          drawPhaseMarkers(
            context: &context,
            size: size,
            visibleDuration: visibleDuration
          )
        }
        .allowsHitTesting(false)

        // Tête de lecture : la règle bouge sous cette petite flèche fixe.
        VStack(spacing: 0) {
          TimelinePointerShape()
            .fill(style.playhead)
            .frame(width: 18, height: 11)

          Rectangle()
            .fill(style.playhead)
            .frame(width: 2.5, height: max(height - 17, 24))
        }
        .shadow(color: Color.black.opacity(style == .fullscreen ? 0.35 : 0.12), radius: 2, y: 1)
        .allowsHitTesting(false)

        HStack {
          Text(String(format: "%.1f×", zoomScale))
            .font(.caption2.monospacedDigit().weight(.black))
            .foregroundStyle(style.label)
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(.ultraThinMaterial, in: Capsule())

          Spacer()

          Text("Glisser • Pincer pour zoomer")
            .font(.caption2.weight(.semibold))
            .foregroundStyle(style.label.opacity(0.88))
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(.ultraThinMaterial, in: Capsule())
        }
        .padding(.horizontal, 10)
        .offset(y: -(height / 2 + 20))
        .allowsHitTesting(false)

        TimelineGestureSurface(
          onTap: { fraction in
            onInteractionChanged(true)
            viewModel.pausePlayback()
            let target = time(atFraction: fraction, visibleDuration: visibleDuration)
            seekNearestFrame(to: target)
            Haptics.selection()
            onInteractionChanged(false)
          },
          onDoubleTap: {
            onInteractionChanged(true)
            withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) {
              zoomScale = 1
            }
            Haptics.selection()
            onInteractionChanged(false)
          },
          onPanBegan: {
            onInteractionChanged(true)
            viewModel.pausePlayback()
            panStartTime = viewModel.currentTime
          },
          onPanChanged: { translationX in
            guard let panStartTime else { return }
            let secondsPerPoint = visibleDuration / Double(width)
            let target = panStartTime - Double(translationX) * secondsPerPoint
            seekNearestFrame(to: target)
          },
          onPanEnded: {
            panStartTime = nil
            Haptics.selection()
            onInteractionChanged(false)
          },
          onPinchBegan: {
            onInteractionChanged(true)
            pinchStartZoom = zoomScale
          },
          onPinchChanged: { factor in
            guard let pinchStartZoom else { return }
            zoomScale = clampedZoom(pinchStartZoom * Double(factor))
          },
          onPinchEnded: {
            pinchStartZoom = nil
            Haptics.selection()
            onInteractionChanged(false)
          }
        )
        .clipShape(RoundedRectangle(cornerRadius: height / 2, style: .continuous))
      }
      .contentShape(Rectangle())
      .accessibilityElement(children: .ignore)
      .accessibilityLabel("Bande temporelle interactive")
      .accessibilityValue("\(viewModel.preciseTimecode), zoom \(String(format: "%.1f", zoomScale)) fois")
      .accessibilityHint("Glissez avec un doigt pour naviguer, pincez avec deux doigts pour zoomer dans le temps.")
      .accessibilityAdjustableAction { direction in
        switch direction {
        case .increment: viewModel.step(frames: 1)
        case .decrement: viewModel.step(frames: -1)
        @unknown default: break
        }
      }
    }
    .frame(height: height)
    .padding(.top, 26)
  }

  private var visibleDurationSeconds: Double {
    guard viewModel.duration > 0 else { return 1 }
    let minimum = max(viewModel.frameDurationSeconds * 12, 0.12)
    return max(viewModel.duration / max(zoomScale, 1), minimum)
  }

  private var maximumZoom: Double {
    guard viewModel.duration > 0 else { return 1 }
    let minimum = max(viewModel.frameDurationSeconds * 12, 0.12)
    return max(min(viewModel.duration / minimum, 96), 1)
  }

  private func clampedZoom(_ value: Double) -> Double {
    min(max(value, 1), maximumZoom)
  }

  private func seekNearestFrame(to seconds: Double) {
    guard viewModel.duration > 0 else { return }
    let clamped = min(max(seconds, 0), viewModel.duration)
    viewModel.seekToNearestFrame(at: clamped)
  }

  private func time(atFraction fraction: CGFloat, visibleDuration: Double) -> Double {
    let normalized = min(max(Double(fraction), 0), 1)
    return viewModel.currentTime + (normalized - 0.5) * visibleDuration
  }

  private func drawTicks(
    context: inout GraphicsContext,
    size: CGSize,
    visibleDuration: Double
  ) {
    guard viewModel.duration > 0, visibleDuration > 0 else { return }

    let centerX = size.width / 2
    let startTime = viewModel.currentTime - visibleDuration / 2
    let endTime = viewModel.currentTime + visibleDuration / 2

    if !viewModel.frameTimestamps.isEmpty {
      let timestamps = viewModel.frameTimestamps
      let first = firstIndex(atOrAfter: startTime, in: timestamps)
      let last = lastIndex(atOrBefore: endTime, in: timestamps)
      guard first <= last, timestamps.indices.contains(first), timestamps.indices.contains(last) else { return }
      let visibleFrameCount = max(last - first + 1, 1)
      let stepFrames: Int
      switch visibleFrameCount {
      case ...120: stepFrames = 1
      case ...300: stepFrames = 2
      case ...900: stepFrames = 5
      case ...1800: stepFrames = 10
      default: stepFrames = max(visibleFrameCount / 180, 15)
      }

      var frame = first
      while frame <= last {
        let time = timestamps[frame]
        drawTick(
          context: &context,
          size: size,
          centerX: centerX,
          time: time,
          visibleDuration: visibleDuration
        )
        frame += stepFrames
      }
      return
    }

    // Fallback only when the media sample index could not be built.
    let frameDuration = max(viewModel.frameDurationSeconds, 1.0 / max(viewModel.frameRate, 1))
    let firstFrame = max(Int(floor(startTime / frameDuration)), 0)
    let lastFrame = min(Int(ceil(endTime / frameDuration)), viewModel.lastFrameIndex)
    for frame in firstFrame...max(firstFrame, lastFrame) {
      drawTick(
        context: &context,
        size: size,
        centerX: centerX,
        time: Double(frame) * frameDuration,
        visibleDuration: visibleDuration
      )
    }
  }

  private func drawTick(
    context: inout GraphicsContext,
    size: CGSize,
    centerX: CGFloat,
    time: Double,
    visibleDuration: Double
  ) {
    let x = centerX + CGFloat((time - viewModel.currentTime) / visibleDuration) * size.width
    guard x >= 0, x <= size.width else { return }

    let tolerance = max(viewModel.frameDurationSeconds * 0.6, 0.008)
    let nearestSecond = time.rounded()
    let nearestTenth = (time * 10).rounded() / 10
    let isSecond = abs(time - nearestSecond) <= tolerance
    let isTenth = !isSecond && abs(time - nearestTenth) <= tolerance
    let tickHeight: CGFloat = isSecond ? height * 0.76 : (isTenth ? height * 0.54 : height * 0.32)
    let tickWidth: CGFloat = isSecond ? 2.2 : (isTenth ? 1.4 : 0.9)
    let tickColor = isSecond ? style.tick : style.secondaryTick

    var path = Path()
    path.move(to: CGPoint(x: x, y: size.height - 7))
    path.addLine(to: CGPoint(x: x, y: size.height - 7 - tickHeight))
    context.stroke(path, with: .color(tickColor), lineWidth: tickWidth)
  }

  private func firstIndex(atOrAfter time: Double, in values: [Double]) -> Int {
    var low = 0
    var high = values.count
    while low < high {
      let mid = (low + high) / 2
      if values[mid] < time { low = mid + 1 } else { high = mid }
    }
    return min(low, max(values.count - 1, 0))
  }

  private func lastIndex(atOrBefore time: Double, in values: [Double]) -> Int {
    var low = 0
    var high = values.count
    while low < high {
      let mid = (low + high) / 2
      if values[mid] <= time { low = mid + 1 } else { high = mid }
    }
    return max(min(low - 1, values.count - 1), 0)
  }

  private func drawPhaseMarkers(
    context: inout GraphicsContext,
    size: CGSize,
    visibleDuration: Double
  ) {
    guard visibleDuration > 0 else { return }

    let startTime = viewModel.currentTime - visibleDuration / 2
    let endTime = viewModel.currentTime + visibleDuration / 2

    for marker in viewModel.phaseMarkers where marker.timeSeconds >= startTime && marker.timeSeconds <= endTime {
      let ratio = (marker.timeSeconds - startTime) / visibleDuration
      let x = CGFloat(ratio) * size.width
      let rect = CGRect(x: x - 3.5, y: 5, width: 7, height: 7)
      context.fill(Path(ellipseIn: rect), with: .color(color(for: marker.phase)))
    }
  }

  private func color(for phase: VaultPhase) -> Color {
    switch phase {
    case .plant: return .blue
    case .takeoff: return .red
    case .rockBack: return .purple
    case .extensionPhase: return .green
    case .turn: return .indigo
    case .flyAway: return .cyan
    }
  }
}

private struct TimelinePointerShape: Shape {
  func path(in rect: CGRect) -> Path {
    var path = Path()
    path.move(to: CGPoint(x: rect.midX, y: rect.maxY))
    path.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
    path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
    path.closeSubpath()
    return path
  }
}

/// UIKit garantit ici la séparation des gestes : le déplacement de timeline est
/// strictement à un doigt, tandis que le zoom temporel nécessite exactement deux doigts.
private struct TimelineGestureSurface: UIViewRepresentable {
  var onTap: (CGFloat) -> Void
  var onDoubleTap: () -> Void
  var onPanBegan: () -> Void
  var onPanChanged: (CGFloat) -> Void
  var onPanEnded: () -> Void
  var onPinchBegan: () -> Void
  var onPinchChanged: (CGFloat) -> Void
  var onPinchEnded: () -> Void

  func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

  func makeUIView(context: Context) -> UIView {
    let view = UIView()
    view.backgroundColor = .clear
    view.isMultipleTouchEnabled = true

    let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:)))
    tap.numberOfTouchesRequired = 1

    let doubleTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.doubleTap(_:)))
    doubleTap.numberOfTapsRequired = 2
    doubleTap.numberOfTouchesRequired = 1
    tap.require(toFail: doubleTap)

    let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:)))
    pan.minimumNumberOfTouches = 1
    pan.maximumNumberOfTouches = 1

    let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:)))

    tap.require(toFail: pan)
    view.addGestureRecognizer(tap)
    view.addGestureRecognizer(doubleTap)
    view.addGestureRecognizer(pan)
    view.addGestureRecognizer(pinch)
    return view
  }

  func updateUIView(_ uiView: UIView, context: Context) {
    context.coordinator.parent = self
  }

  final class Coordinator: NSObject {
    var parent: TimelineGestureSurface

    init(parent: TimelineGestureSurface) {
      self.parent = parent
    }

    @objc func tap(_ recognizer: UITapGestureRecognizer) {
      guard let view = recognizer.view, view.bounds.width > 0 else { return }
      let point = recognizer.location(in: view)
      parent.onTap(point.x / view.bounds.width)
    }

    @objc func doubleTap(_ recognizer: UITapGestureRecognizer) {
      parent.onDoubleTap()
    }

    @objc func pan(_ recognizer: UIPanGestureRecognizer) {
      guard let view = recognizer.view else { return }
      switch recognizer.state {
      case .began:
        parent.onPanBegan()
      case .changed:
        parent.onPanChanged(recognizer.translation(in: view).x)
      case .ended, .cancelled, .failed:
        parent.onPanEnded()
      default:
        break
      }
    }

    @objc func pinch(_ recognizer: UIPinchGestureRecognizer) {
      switch recognizer.state {
      case .began:
        parent.onPinchBegan()
      case .changed:
        parent.onPinchChanged(recognizer.scale)
      case .ended, .cancelled, .failed:
        parent.onPinchEnded()
      default:
        break
      }
    }
  }
}
