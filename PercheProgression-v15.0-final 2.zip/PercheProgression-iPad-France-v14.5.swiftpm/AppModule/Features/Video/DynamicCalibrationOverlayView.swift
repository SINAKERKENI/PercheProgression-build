import SwiftUI

struct DynamicRunwayGridOverlayView: View {
  @Binding var editableGrid: RunwayGridCalibration
  let dynamicTrack: DynamicCalibrationTrack?
  let currentTime: Double
  let isActive: Bool
  let nearLineIsBoxOrigin: Bool

  @State private var dragOriginGrid: RunwayGridCalibration?
  @State private var scaleOriginGrid: RunwayGridCalibration?
  @State private var rotationOriginGrid: RunwayGridCalibration?
  @State private var activeHandleIndex: Int?
  @State private var selectedHandleIndex: Int?
  @State private var precisionStepPixels: CGFloat = 1

  init(
    editableGrid: Binding<RunwayGridCalibration>,
    dynamicTrack: DynamicCalibrationTrack?,
    currentTime: Double,
    isActive: Bool,
    nearLineIsBoxOrigin: Bool = true
  ) {
    _editableGrid = editableGrid
    self.dynamicTrack = dynamicTrack
    self.currentTime = currentTime
    self.isActive = isActive
    self.nearLineIsBoxOrigin = nearLineIsBoxOrigin
  }

  private var displayGrid: RunwayGridCalibration {
    guard !isActive, let dynamicTrack else { return editableGrid }
    return dynamicTrack.grid(nearest: currentTime)
  }

  private var currentSample: HomographySample? {
    dynamicTrack?.sample(nearest: currentTime)
  }

  private var precisionHandleIndex: Int? {
    activeHandleIndex ?? selectedHandleIndex
  }

  var body: some View {
    GeometryReader { geometry in
      let grid = displayGrid
      ZStack {
        Canvas { context, size in
          drawGrid(grid, context: &context, size: size)
          if let precisionHandleIndex {
            drawPrecisionGuides(
              for: precisionHandleIndex,
              grid: grid,
              context: &context,
              size: size
            )
          }
        }
        .allowsHitTesting(false)

        if isActive {
          ForEach(0..<4, id: \.self) { index in
            handle(index: index, grid: grid, size: geometry.size)
          }

          centerHandle(grid: grid, size: geometry.size)

          if let selectedHandleIndex {
            VStack {
              Spacer()
              HStack {
                precisionNudgePanel(index: selectedHandleIndex, grid: grid, size: geometry.size)
                Spacer()
              }
              .padding(12)
            }
          }

          Text(grid.isGeometricallyUsable
            ? "Glissez un coin puis affinez avec les flèches · le bouton central déplace toute la grille"
            : "Grille invalide : séparez les coins et évitez les lignes croisées")
            .font(.caption2.weight(.black))
            .foregroundStyle(grid.isGeometricallyUsable ? Color.vaultText : Color.white)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(
              grid.isGeometricallyUsable ? Color.white.opacity(0.88) : Color.red.opacity(0.90),
              in: Capsule()
            )
            .position(x: geometry.size.width / 2, y: 24)
            .allowsHitTesting(false)
        }

        if let sample = currentSample, !isActive {
          calibrationBadge(sample: sample)
            .position(x: geometry.size.width - 106, y: 28)
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isActive)
      .simultaneousGesture(scaleGesture)
      .simultaneousGesture(rotationGesture)
    }
  }

  private func drawGrid(
    _ grid: RunwayGridCalibration,
    context: inout GraphicsContext,
    size: CGSize
  ) {
    let boxLeft = point(grid.boxLeft, in: size)
    let boxRight = point(grid.boxRight, in: size)
    let farLeft = point(grid.farLeft, in: size)
    let farRight = point(grid.farRight, in: size)

    var surface = Path()
    surface.move(to: boxLeft)
    surface.addLine(to: boxRight)
    surface.addLine(to: farRight)
    surface.addLine(to: farLeft)
    surface.closeSubpath()
    context.fill(surface, with: .color(Color.vaultCyan.opacity(0.10)))

    let statusColor: Color = {
      if isActive, !grid.isGeometricallyUsable { return Color.red }
      switch currentSample?.status {
      case .reliable: return Color.vaultAnalysisAccent
      case .review: return Color.vaultAnalysisReview
      case .manualRequired: return Color.red
      case .unavailable, .none: return Color.vaultCyan
      }
    }()

    let longitudinalStep = grid.zoneLengthMeters <= 5 ? 0.25 : 0.50
    let subdivisions = max(Int((grid.zoneLengthMeters / longitudinalStep).rounded()), 4)
    for index in 0...subdivisions {
      let t = Double(index) / Double(subdivisions)
      let left = lerp(boxLeft, farLeft, t)
      let right = lerp(boxRight, farRight, t)
      let meters = t * grid.zoneLengthMeters
      let isWholeMeter = abs(meters.rounded() - meters) < 0.001
      let isHalfMeter = abs((meters * 2).rounded() - (meters * 2)) < 0.001

      var line = Path()
      line.move(to: left)
      line.addLine(to: right)
      context.stroke(
        line,
        with: .color(statusColor.opacity(isWholeMeter ? 0.90 : (isHalfMeter ? 0.58 : 0.26))),
        style: StrokeStyle(
          lineWidth: isWholeMeter ? 1.25 : (isHalfMeter ? 0.75 : 0.45),
          dash: isWholeMeter ? [] : (isHalfMeter ? [5, 4] : [2, 4])
        )
      )

      if isWholeMeter || index == subdivisions {
        context.draw(
          Text(String(format: "%.2f m", meters))
            .font(.caption2.monospacedDigit().weight(.bold))
            .foregroundColor(statusColor),
          at: CGPoint(x: left.x - 24, y: left.y),
          anchor: .trailing
        )
      }
    }

    for fraction in [0.0, 0.25, 0.5, 0.75, 1.0] {
      let near = lerp(boxLeft, boxRight, fraction)
      let far = lerp(farLeft, farRight, fraction)
      var line = Path()
      line.move(to: near)
      line.addLine(to: far)
      let isOuterEdge = fraction == 0 || fraction == 1
      let isCenter = fraction == 0.5
      context.stroke(
        line,
        with: .color(statusColor.opacity(isOuterEdge ? 0.9 : (isCenter ? 0.58 : 0.34))),
        style: StrokeStyle(lineWidth: isOuterEdge ? 1.45 : (isCenter ? 0.9 : 0.55))
      )
    }

    var zeroLine = Path()
    zeroLine.move(to: boxLeft)
    zeroLine.addLine(to: boxRight)
    context.stroke(zeroLine, with: .color(statusColor), lineWidth: 2.0)
    context.draw(
      Text(nearLineIsBoxOrigin ? "0,00 m · FOND DU BUTOIR" : "0,00 m · LIGNE DE RÉFÉRENCE")
        .font(.caption2.monospacedDigit().weight(.black))
        .foregroundColor(statusColor),
      at: CGPoint(x: (boxLeft.x + boxRight.x) / 2, y: min(boxLeft.y, boxRight.y) - 16),
      anchor: .center
    )
  }

  private func drawPrecisionGuides(
    for index: Int,
    grid: RunwayGridCalibration,
    context: inout GraphicsContext,
    size: CGSize
  ) {
    guard grid.imagePoints.indices.contains(index) else { return }
    let anchor = point(grid.imagePoints[index], in: size)
    let labels = endpointLabels(for: grid)
    let label = labels.indices.contains(index) ? labels[index] : "Point"

    var horizontal = Path()
    horizontal.move(to: CGPoint(x: 0, y: anchor.y))
    horizontal.addLine(to: CGPoint(x: size.width, y: anchor.y))
    context.stroke(
      horizontal,
      with: .color(Color.white.opacity(0.92)),
      style: StrokeStyle(lineWidth: 0.7, dash: [4, 4])
    )

    var vertical = Path()
    vertical.move(to: CGPoint(x: anchor.x, y: 0))
    vertical.addLine(to: CGPoint(x: anchor.x, y: size.height))
    context.stroke(
      vertical,
      with: .color(Color.white.opacity(0.92)),
      style: StrokeStyle(lineWidth: 0.7, dash: [4, 4])
    )

    let readoutX = min(max(anchor.x + 96, 110), max(size.width - 110, 110))
    let readoutY = max(anchor.y - 72, 44)
    let normalizedXPercent = Double(anchor.x / max(size.width, CGFloat(1)) * 100)
    let normalizedYPercent = Double(anchor.y / max(size.height, CGFloat(1)) * 100)
    let readout = String(
      format: "%@ · x %.1f %% · y %.1f %%",
      label,
      normalizedXPercent,
      normalizedYPercent
    )

    context.draw(
      Text(readout)
        .font(.caption2.monospacedDigit().weight(.black))
        .foregroundColor(.white),
      at: CGPoint(x: readoutX, y: readoutY),
      anchor: .center
    )
  }

  private func handle(index: Int, grid: RunwayGridCalibration, size: CGSize) -> some View {
    let pointValue = grid.imagePoints[index]
    let labels = endpointLabels(for: grid)
    let visualDiameter: CGFloat = 32
    let touchDiameter: CGFloat = 76
    let isSelected = selectedHandleIndex == index

    return ZStack {
      Circle()
        .fill(Color.clear)
        .frame(width: touchDiameter, height: touchDiameter)
        .contentShape(Circle())

      Circle()
        .fill(Color.white.opacity(isSelected ? 0.14 : 0.07))
        .frame(width: visualDiameter, height: visualDiameter)

      Circle()
        .stroke(Color.white, lineWidth: isSelected ? 2.6 : 2.0)
        .frame(width: visualDiameter, height: visualDiameter)

      Circle()
        .stroke(Color.vaultAnalysisAccent, lineWidth: isSelected ? 1.8 : 1.3)
        .frame(width: visualDiameter, height: visualDiameter)

      Rectangle().fill(Color.vaultAnalysisAccent).frame(width: 1, height: 18)
      Rectangle().fill(Color.vaultAnalysisAccent).frame(width: 18, height: 1)
      Circle()
        .fill(Color.white)
        .frame(width: 5, height: 5)
        .overlay(Circle().stroke(Color.vaultAnalysisAccent, lineWidth: 1))

      Text(labels[index])
        .font(.system(size: 11, weight: .black, design: .rounded))
        .foregroundStyle(Color.vaultText)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(.ultraThinMaterial, in: Capsule())
        .offset(y: -34)
    }
    .frame(width: touchDiameter, height: touchDiameter)
    .position(point(pointValue, in: size))
    .accessibilityLabel("Coin de calibration \(labels[index])")
    .accessibilityHint("Faites glisser puis utilisez les flèches de précision pour affiner.")
    .gesture(
      DragGesture(minimumDistance: 0)
        .onChanged { value in
          selectedHandleIndex = index
          activeHandleIndex = index
          editableGrid = editableGrid.replacingPoint(
            at: index,
            with: normalized(value.location, in: size)
          )
        }
        .onEnded { _ in
          activeHandleIndex = nil
          Haptics.selection()
        }
    )
  }

  private func precisionNudgePanel(
    index: Int,
    grid: RunwayGridCalibration,
    size: CGSize
  ) -> some View {
    VStack(spacing: 7) {
      HStack(spacing: 8) {
        Text(endpointLabels(for: grid)[index])
          .font(.caption2.monospacedDigit().weight(.black))
        Button(precisionStepPixels <= 1 ? "Pas 1 px" : "Pas 5 px") {
          precisionStepPixels = precisionStepPixels <= 1 ? 5 : 1
          Haptics.selection()
        }
        .font(.caption2.weight(.bold))
        .buttonStyle(.bordered)
        Button {
          selectedHandleIndex = nil
          activeHandleIndex = nil
        } label: {
          Image(systemName: "checkmark")
        }
        .buttonStyle(.borderedProminent)
        .tint(.vaultAnalysisAccent)
      }

      HStack(spacing: 6) {
        precisionButton(symbol: "arrow.left", index: index, dx: -precisionStepPixels, dy: 0, size: size)
        precisionButton(symbol: "arrow.up", index: index, dx: 0, dy: -precisionStepPixels, size: size)
        precisionButton(symbol: "arrow.down", index: index, dx: 0, dy: precisionStepPixels, size: size)
        precisionButton(symbol: "arrow.right", index: index, dx: precisionStepPixels, dy: 0, size: size)
      }
    }
    .padding(9)
    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    .shadow(color: Color.black.opacity(0.22), radius: 7, y: 3)
  }

  private func precisionButton(
    symbol: String,
    index: Int,
    dx: CGFloat,
    dy: CGFloat,
    size: CGSize
  ) -> some View {
    Button {
      nudgeHandle(index: index, dxPixels: dx, dyPixels: dy, size: size)
    } label: {
      Image(systemName: symbol)
        .font(.caption.weight(.black))
        .frame(width: 30, height: 30)
    }
    .buttonStyle(.bordered)
  }

  private func nudgeHandle(index: Int, dxPixels: CGFloat, dyPixels: CGFloat, size: CGSize) {
    guard editableGrid.imagePoints.indices.contains(index), size.width > 0, size.height > 0 else { return }
    let current = editableGrid.imagePoints[index]
    let next = NormalizedPoint(
      x: current.x + Double(dxPixels / size.width),
      y: current.y + Double(dyPixels / size.height)
    ).clamped()
    editableGrid = editableGrid.replacingPoint(at: index, with: next)
    selectedHandleIndex = index
    Haptics.selection()
  }

  private func centerHandle(grid: RunwayGridCalibration, size: CGSize) -> some View {
    ZStack {
      Circle()
        .fill(Color.clear)
        .frame(width: 68, height: 68)
        .contentShape(Circle())
      Image(systemName: "move.3d")
        .font(.caption2.weight(.black))
        .foregroundStyle(Color.white)
        .frame(width: 30, height: 30)
        .background(Color.vaultAnalysisAccent.opacity(0.90), in: Circle())
        .overlay(Circle().stroke(Color.white, lineWidth: 1.2))
    }
      .frame(width: 68, height: 68)
      .position(point(grid.center, in: size))
      .gesture(
        DragGesture(minimumDistance: 0)
          .onChanged { value in
            selectedHandleIndex = nil
            if dragOriginGrid == nil { dragOriginGrid = editableGrid }
            guard let origin = dragOriginGrid else { return }
            let dx = Double(value.translation.width / max(size.width, 1))
            let dy = Double(value.translation.height / max(size.height, 1))
            editableGrid = origin.translated(dx: dx, dy: dy)
          }
          .onEnded { _ in
            dragOriginGrid = nil
            Haptics.impact(.light)
          }
      )
  }

  private var scaleGesture: some Gesture {
    MagnificationGesture()
      .onChanged { value in
        selectedHandleIndex = nil
        if scaleOriginGrid == nil { scaleOriginGrid = editableGrid }
        guard let origin = scaleOriginGrid else { return }
        editableGrid = origin.scaled(by: Double(value))
      }
      .onEnded { _ in
        scaleOriginGrid = nil
        Haptics.selection()
      }
  }

  private var rotationGesture: some Gesture {
    RotationGesture()
      .onChanged { angle in
        selectedHandleIndex = nil
        if rotationOriginGrid == nil { rotationOriginGrid = editableGrid }
        guard let origin = rotationOriginGrid else { return }
        editableGrid = origin.rotated(by: angle.radians)
      }
      .onEnded { _ in
        rotationOriginGrid = nil
        Haptics.selection()
      }
  }

  private func calibrationBadge(sample: HomographySample) -> some View {
    VStack(alignment: .trailing, spacing: 2) {
      Text(sample.status.title)
        .font(.caption2.weight(.black))
      Text(sample.estimatedErrorMeters > 0
        ? String(format: "Qualité %.0f %% · erreur résiduelle %.0f cm", sample.confidence * 100, sample.estimatedErrorMeters * 100)
        : String(format: "Qualité %.0f %% · incertitude non calibrée", sample.confidence * 100))
        .font(.caption2.monospacedDigit())
    }
    .padding(.horizontal, 9)
    .padding(.vertical, 6)
    .background(.ultraThinMaterial, in: Capsule())
  }

  private func endpointLabels(for grid: RunwayGridCalibration) -> [String] {
    let near = nearLineIsBoxOrigin ? "0 m" : "Réf."
    let far = shortMeters(grid.zoneLengthMeters)
    return ["\(near) G", "\(near) D", "\(far) G", "\(far) D"]
  }

  private func shortMeters(_ value: Double) -> String {
    if abs(value.rounded() - value) < 0.001 {
      return String(format: "%.0f m", value)
    }
    return String(format: "%.2f m", value)
  }

  private func point(_ point: NormalizedPoint, in size: CGSize) -> CGPoint {
    CGPoint(x: point.x * size.width, y: point.y * size.height)
  }

  private func normalized(_ point: CGPoint, in size: CGSize) -> NormalizedPoint {
    guard size.width > 0, size.height > 0 else { return .init(x: 0, y: 0) }
    return NormalizedPoint(x: point.x / size.width, y: point.y / size.height).clamped()
  }

  private func lerp(_ a: CGPoint, _ b: CGPoint, _ t: Double) -> CGPoint {
    CGPoint(x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t)
  }
}

struct TakeoffMeasurementOverlayView: View {
  @Binding var pointValue: NormalizedPoint?
  let measurement: TakeoffMeasurement?
  let isActive: Bool
  let onPointCommitted: () -> Void

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        if let pointValue {
          let position = CGPoint(
            x: pointValue.x * geometry.size.width,
            y: pointValue.y * geometry.size.height
          )
          ZStack {
            Circle().stroke(Color.white, lineWidth: 7).frame(width: 35, height: 35)
            Circle().stroke(Color.vaultAnalysisMarker, lineWidth: 4).frame(width: 35, height: 35)
            Circle().fill(Color.vaultAnalysisMarker).frame(width: 7, height: 7)
            Text(measurement?.formattedDistance ?? "Point d’impulsion")
              .font(.caption2.monospacedDigit().weight(.black))
              .padding(.horizontal, 8)
              .padding(.vertical, 5)
              .background(.ultraThinMaterial, in: Capsule())
              .offset(y: -34)
          }
          .position(position)
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isActive)
      .gesture(
        DragGesture(minimumDistance: 0)
          .onChanged { value in
            guard isActive else { return }
            pointValue = NormalizedPoint(
              x: value.location.x / max(geometry.size.width, 1),
              y: value.location.y / max(geometry.size.height, 1)
            ).clamped()
          }
          .onEnded { _ in
            Haptics.impact(.light)
            onPointCommitted()
          }
      )
    }
  }
}

struct RectifiedRunwayQualityView: View {
  let track: DynamicCalibrationTrack?
  let currentTime: Double

  var body: some View {
    let sample = track?.sample(nearest: currentTime)
    VStack(alignment: .leading, spacing: 10) {
      HStack {
        Label("Contrôle vue rectifiée", systemImage: "rectangle.portrait.and.arrow.forward")
          .font(.subheadline.weight(.bold))
        Spacer()
        Text(sample?.status.title ?? "Non calculé")
          .font(.caption.weight(.bold))
          .foregroundStyle(statusColor(sample?.status))
      }

      Canvas { context, size in
        let rect = CGRect(x: 24, y: 14, width: size.width - 48, height: size.height - 28)
        context.fill(Path(roundedRect: rect, cornerRadius: 12), with: .color(Color.vaultCyan.opacity(0.08)))
        for index in 0...10 {
          let x = rect.minX + rect.width * Double(index) / 10
          var line = Path()
          line.move(to: CGPoint(x: x, y: rect.minY))
          line.addLine(to: CGPoint(x: x, y: rect.maxY))
          context.stroke(line, with: .color(Color.vaultAnalysisAccent.opacity(index.isMultiple(of: 2) ? 0.65 : 0.25)), lineWidth: index.isMultiple(of: 2) ? 1.6 : 0.8)
        }
        var center = Path()
        center.move(to: CGPoint(x: rect.minX, y: rect.midY))
        center.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        context.stroke(center, with: .color(Color.vaultAnalysisAccent.opacity(0.45)), lineWidth: 1)
      }
      .frame(height: 105)

      Text("Dans une rectification correcte, les bords restent parallèles et le butoir demeure immobile pendant le panoramique.")
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
    }
    .padding(14)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
  }

  private func statusColor(_ status: CalibrationStatus?) -> Color {
    switch status {
    case .reliable: .green
    case .review: .vaultAnalysisReview
    case .manualRequired: .red
    case .unavailable, .none: .vaultMuted
    }
  }
}

struct CalibrationTimelineStrip: View {
  let track: DynamicCalibrationTrack?
  let currentTime: Double
  let duration: Double
  let onSeek: (Double) -> Void

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        Capsule().fill(Color.vaultLine.opacity(0.7)).frame(height: 8)

        if let track {
          Canvas { context, size in
            guard duration > 0 else { return }
            let y = size.height / 2
            for sample in track.samples {
              let x = min(max(sample.timeSeconds / duration, 0), 1) * size.width
              let color: Color
              switch sample.status {
              case .reliable: color = .green
              case .review: color = .vaultAnalysisReview
              case .manualRequired: color = .red
              case .unavailable: color = .gray
              }
              context.fill(
                Path(CGRect(x: x - 1.5, y: y - 4, width: 3, height: 8)),
                with: .color(color.opacity(0.75))
              )
            }

            for keyframe in track.keyframes {
              let x = min(max(keyframe.timeSeconds / duration, 0), 1) * size.width
              var diamond = Path()
              diamond.move(to: CGPoint(x: x, y: y - 8))
              diamond.addLine(to: CGPoint(x: x + 7, y: y))
              diamond.addLine(to: CGPoint(x: x, y: y + 8))
              diamond.addLine(to: CGPoint(x: x - 7, y: y))
              diamond.closeSubpath()
              let color: Color = keyframe.source == .userCorrection ? .vaultAnalysisAccent : .vaultCyan
              context.fill(diamond, with: .color(color))
            }
          }
          .allowsHitTesting(false)
        }

        let cursorX = min(max(currentTime / max(duration, 0.001), 0), 1) * geometry.size.width
        Rectangle()
          .fill(Color.vaultText)
          .frame(width: 2, height: 24)
          .position(x: cursorX, y: geometry.size.height / 2)
      }
      .contentShape(Rectangle())
      .gesture(
        DragGesture(minimumDistance: 0)
          .onChanged { value in
            let ratio = min(max(value.location.x / max(geometry.size.width, 1), 0), 1)
            onSeek(ratio * duration)
          }
      )
    }
    .frame(height: 28)
  }
}
