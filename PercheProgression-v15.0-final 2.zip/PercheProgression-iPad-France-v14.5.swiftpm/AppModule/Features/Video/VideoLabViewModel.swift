import AVFoundation
import Combine
import Foundation
import PencilKit

@MainActor
final class VideoLabViewModel: ObservableObject {
  enum Tool: String, CaseIterable, Identifiable {
    case select
    case vector
    case scale
    case background
    case calibration
    case takeoff
    case tracking
    case freehand
    case erase
    case pose

    var id: String { rawValue }
    var title: String {
      switch self {
      case .select: "Sélection"
      case .vector: "Vecteur"
      case .scale: "Échelle réelle"
      case .background: "Repères fixes"
      case .calibration: "Butoir 5 m"
      case .takeoff: "Impulsion"
      case .tracking: "Suivi vitesse"
      case .freehand: "Dessin"
      case .erase: "Gomme"
      case .pose: "Posture"
      }
    }
    var symbol: String {
      switch self {
      case .select: "cursorarrow"
      case .vector: "arrow.up.right"
      case .scale: "ruler"
      case .background: "viewfinder.circle"
      case .calibration: "grid"
      case .takeoff: "shoeprints.fill"
      case .tracking: "scope"
      case .freehand: "pencil.tip"
      case .erase: "eraser"
      case .pose: "figure.arms.open"
      }
    }
  }

  @Published var player: AVPlayer?
  @Published var comparisonPlayer: AVPlayer?
  @Published var comparisonURL: URL?
  @Published var comparisonOffset: Double = 0
  @Published var comparisonMode: VideoComparisonMode = .sideBySide
  @Published var comparisonTakeoffTime: Double?
  @Published var overlayTransform = OverlayVideoTransform(opacity: 0.48)
  @Published var viewportTransform = VideoViewportTransform()
  @Published var comparisonViewportTransform = VideoViewportTransform()
  @Published private(set) var comparisonFrameTimestamps: [Double] = []
  @Published private(set) var comparisonDuration: Double = 0
  @Published private(set) var comparisonFrameRate: Double = 0
  @Published private(set) var comparisonNaturalSize = CGSize(width: 1920, height: 1080)

  @Published var loadedURL: URL?
  @Published var duration: Double = 0
  @Published var currentTime: Double = 0
  @Published var frameRate: Double = 60
  @Published private(set) var frameTimestamps: [Double] = []
  @Published var videoNaturalSize = CGSize(width: 1920, height: 1080)
  @Published var isPlaying = false
  @Published var playbackRate: Float = 1.0

  @Published var tool: Tool = .select
  @Published var selectedVectorKind: VectorKind = .manual
  @Published var vectors: [OverlayVector] = []
  @Published var selectedVectorID: UUID?
  @Published var poseJoints: [PoseJoint] = []
  @Published var poseCandidates: [PoseCandidate] = []
  @Published var selectedAthleteCandidate: PoseCandidate?
  @Published var poseSelectionTime: Double?
  @Published var phaseMarkers: [PhaseMarker] = []
  @Published var currentPhase: VaultPhase = .takeoff
  @Published var pencilDrawing = PKDrawing()

  // L'ancien étalonnage linéaire reste décodable pour les analyses v4.
  @Published var calibration = VideoCalibration()
  @Published var physicalCameraMode: PhysicalCameraMode = .fixedOblique
  @Published var fixedObliqueTrackingPoint: FixedObliqueTrackingPoint = .groundProjection
  @Published var fixedRunwayMetricOrigin: FixedRunwayMetricOrigin = .box

  var isGroundProjectionValidation: Bool {
    physicalCameraMode == .fixedOblique && fixedObliqueTrackingPoint == .groundProjection
  }

  var validationPointTitle: String {
    isGroundProjectionValidation ? "point au sol" : "bassin"
  }

  var validationPointTitleUppercased: String { validationPointTitle.uppercased() }
  var canRefineValidationPointWithVision: Bool { !isGroundProjectionValidation }
  @Published var scaleCalibrationReferenceTime: Double = 0
  @Published var backgroundAnchors: [NormalizedPoint] = []
  @Published var runwayGrid = RunwayGridCalibration()
  @Published var isRunwayGridConfigured = false
  @Published var dynamicCalibration: DynamicCalibrationTrack?
  @Published var manualCalibrationKeyframes: [CalibrationKeyframe] = []
  @Published var isAnalyzingCalibration = false
  @Published var calibrationMessage: String?

  @Published var takeoffPoint: NormalizedPoint?
  @Published var takeoffMeasurement: TakeoffMeasurement?
  @Published var takeoffConvention: TakeoffContactConvention = .toe

  @Published var trackingSeed: NormalizedPoint?
  @Published var trackingStartTime: Double = 0
  @Published var trackingEndTime: Double = 0
  @Published var motionResult: MotionAnalysisResult?
  @Published var isAnalyzingMotion = false
  @Published var isAnalyzingBoxlessMotion = false
  @Published var isAnalyzingCalibratedMotion = false

  // Validation guidée du bassin toutes les 0,1 seconde.
  @Published var pelvisValidation: PelvisValidationSession?
  @Published var pelvisCheckpointIndex: Int = 0
  @Published var isPelvisValidationActive = false
  @Published var isRecalculatingPelvisStats = false
  @Published var pendingPelvisValidationAfterAthleteSelection = false

  @Published var analysisMessage: String?
  @Published var isAnalyzingPose = false

  private var timeObserver: Any?
  private let motionService = VideoMotionAnalysisService()
  private let athleteScaleMotionService = AthleteScaleMotionAnalysisService()
  private let manualPelvisMotionService = ManualPelvisMotionAnalysisService()
  private let calibratedManualMotionService = CalibratedManualMotionAnalysisService()
  private let fixedObliqueMotionService = FixedObliqueRunwayMotionAnalysisService()
  private let calibrationService = DynamicCalibrationService()
  private let sceneDetector = RunwaySceneDetectionService()
  private let frameTimelineService = VideoFrameTimelineService()
  private var analysisTask: Task<Void, Never>?
  private var analysisSessionID = UUID()

  /// Compatibility accessor. Opacity has a single source of truth in OverlayVideoTransform.
  var overlayOpacity: Double {
    get { overlayTransform.opacity }
    set {
      var transform = overlayTransform
      transform.opacity = min(max(newValue, 0.05), 0.95)
      overlayTransform = transform
    }
  }

  var hasExactFrameTimeline: Bool { !frameTimestamps.isEmpty }

  func seekToNearestFrame(at seconds: Double, haptic: Bool = false) {
    let clamped = min(max(seconds, 0), duration)
    if frameTimestamps.isEmpty {
      seek(to: clamped)
      if haptic { Haptics.selection() }
    } else {
      seek(toFrame: nearestFrameIndex(to: clamped), haptic: haptic)
    }
  }

  var frameDurationSeconds: Double {
    guard frameTimestamps.count > 1 else { return 1.0 / max(frameRate, 1) }
    let index = min(max(currentFrameIndex, 0), frameTimestamps.count - 2)
    return max(frameTimestamps[index + 1] - frameTimestamps[index], 1.0 / 240.0)
  }

  var lastFrameIndex: Int {
    if !frameTimestamps.isEmpty { return frameTimestamps.count - 1 }
    guard duration > 0 else { return 0 }
    return max(Int(floor(duration * max(frameRate, 1))) - 1, 0)
  }

  var frameCount: Int { lastFrameIndex + 1 }

  var currentFrameIndex: Int {
    guard !frameTimestamps.isEmpty else {
      return min(max(Int((currentTime * max(frameRate, 1)).rounded()), 0), lastFrameIndex)
    }
    return nearestFrameIndex(to: currentTime)
  }

  var preciseTimecode: String {
    Self.timecode(seconds: currentTime, frameIndex: currentFrameIndex, frameTimestamps: frameTimestamps, fallbackRate: frameRate)
  }

  var currentFrameDescription: String {
    "Image \(currentFrameIndex + 1) / \(frameCount)"
  }

  var currentMotionSample: MotionSample? {
    motionResult?.sample(nearest: currentTime)
  }

  var currentPelvisCheckpoint: PelvisCheckpoint? {
    guard let pelvisValidation, pelvisValidation.checkpoints.indices.contains(pelvisCheckpointIndex) else {
      return nil
    }
    return pelvisValidation.checkpoints[pelvisCheckpointIndex]
  }

  var pelvisValidationProgress: Double {
    pelvisValidation?.progress ?? 0
  }

  var pelvisConfirmedCount: Int {
    pelvisValidation?.confirmedCount ?? 0
  }

  var pelvisCheckpointCount: Int {
    pelvisValidation?.checkpoints.count ?? 0
  }

  var currentCalibrationSample: HomographySample? {
    dynamicCalibration?.sample(nearest: currentTime)
  }

  var biomechanicalAngles: [BiomechanicalAngle] {
    BiomechanicsAngleEngine.calculate(joints: poseJoints, vectors: vectors)
  }

  var processingPhase: VideoProcessingPhase {
    let takeoffTime = phaseMarkers.first(where: { $0.phase == .takeoff })?.timeSeconds
      ?? takeoffMeasurement?.timeSeconds
    let flyAwayTime = phaseMarkers.first(where: { $0.phase == .flyAway })?.timeSeconds

    if let flyAwayTime, currentTime > flyAwayTime + 1 { return .complete }
    if let takeoffTime {
      if currentTime >= takeoffTime + 0.08 { return .aerial }
      if currentTime >= takeoffTime - 0.35 { return .plantTakeoff }
    }
    if currentTime >= trackingStartTime, currentTime <= trackingEndTime { return .metricZone }
    return .earlyApproach
  }

  var hasAnnotations: Bool {
    !vectors.isEmpty || !phaseMarkers.isEmpty || !pencilDrawing.strokes.isEmpty
      || runwayGrid != RunwayGridCalibration()
      || dynamicCalibration != nil || !manualCalibrationKeyframes.isEmpty
      || trackingSeed != nil || motionResult != nil || takeoffPoint != nil
      || pelvisValidation != nil || !backgroundAnchors.isEmpty
      || calibration.distanceMeters > 0
  }

  func load(url: URL) async {
    analysisSessionID = UUID()
    cleanupPlayer()
    loadedURL = url
    let asset = AVURLAsset(url: url)

    do {
      let durationTime = try await asset.load(.duration)
      duration = durationTime.seconds.isFinite ? durationTime.seconds : 0
      let tracks = try await asset.loadTracks(withMediaType: .video)
      if let track = tracks.first {
        let rate = try await track.load(.nominalFrameRate)
        if rate > 0 { frameRate = Double(rate) }
        do {
          let pts = try await frameTimelineService.timestamps(for: url)
          frameTimestamps = pts
          if pts.count > 2 {
            let deltas: [Double] = zip(pts.dropFirst(), pts).compactMap { pair in
              let delta = pair.0 - pair.1
              return delta > 0 ? delta : nil
            }
            if !deltas.isEmpty {
              let sorted = deltas.sorted()
              let medianDelta = sorted[sorted.count / 2]
              frameRate = 1 / max(medianDelta, 1.0 / 240.0)
            }
          }
        } catch {
          frameTimestamps = []
          analysisMessage = "PTS indisponibles : navigation basée sur le FPS déclaré (mode dégradé)."
        }
        let naturalSize = try await track.load(.naturalSize)
        let transform = try await track.load(.preferredTransform)
        let transformed = naturalSize.applying(transform)
        let width = abs(transformed.width)
        let height = abs(transformed.height)
        if width > 0, height > 0 {
          videoNaturalSize = CGSize(width: width, height: height)
        }
      }
    } catch {
      analysisMessage = "Impossible de lire les métadonnées vidéo : \(error.localizedDescription)"
    }

    let newPlayer = AVPlayer(playerItem: AVPlayerItem(asset: asset))
    player = newPlayer
    currentTime = 0
    if trackingEndTime <= trackingStartTime {
      trackingStartTime = 0
      trackingEndTime = min(duration, 5)
    } else {
      trackingEndTime = min(trackingEndTime, duration)
    }
    addTimeObserver(to: newPlayer)
  }

  func loadComparison(url: URL, takeoffTime: Double? = nil) {
    comparisonPlayer?.pause()
    comparisonURL = url
    comparisonTakeoffTime = takeoffTime
    comparisonFrameTimestamps = []
    comparisonDuration = 0
    comparisonFrameRate = 0
    comparisonNaturalSize = CGSize(width: 1920, height: 1080)
    comparisonViewportTransform = VideoViewportTransform()
    comparisonPlayer = AVPlayer(url: url)
    synchronizeComparison()

    Task { [weak self] in
      guard let self else { return }
      await self.loadComparisonMetadata(url: url)
    }
  }

  private func loadComparisonMetadata(url: URL) async {
    do {
      let asset = AVURLAsset(url: url)
      let durationTime = try await asset.load(.duration)
      let tracks = try await asset.loadTracks(withMediaType: .video)
      let timestamps = try await frameTimelineService.timestamps(for: url)
      guard comparisonURL == url else { return }
      comparisonFrameTimestamps = timestamps
      comparisonDuration = durationTime.seconds.isFinite ? durationTime.seconds : (timestamps.last ?? 0)
      comparisonFrameRate = VideoFrameTimelineService.effectiveRate(for: timestamps) ?? 0
      if let track = tracks.first {
        let natural = try await track.load(.naturalSize)
        let transform = try await track.load(.preferredTransform)
        let transformed = natural.applying(transform)
        let width = abs(transformed.width)
        let height = abs(transformed.height)
        if width > 0, height > 0 {
          comparisonNaturalSize = CGSize(width: width, height: height)
        }
      }
      synchronizeComparison()
    } catch {
      guard comparisonURL == url else { return }
      analysisMessage = "Index PTS de la référence indisponible : le pas « 1 image » est désactivé pour éviter une approximation par FPS."
    }
  }

  func clearComparison() {
    comparisonPlayer?.pause()
    comparisonPlayer = nil
    comparisonURL = nil
    comparisonOffset = 0
    comparisonTakeoffTime = nil
    comparisonFrameTimestamps = []
    comparisonDuration = 0
    comparisonFrameRate = 0
    comparisonViewportTransform = VideoViewportTransform()
  }


  func nudgeComparison(by seconds: Double) {
    comparisonOffset = min(max(comparisonOffset + seconds, -15), 15)
    synchronizeComparison()
    Haptics.selection()
  }

  func nudgeComparisonByFrames(_ frames: Int) {
    guard frames != 0, !comparisonFrameTimestamps.isEmpty else {
      analysisMessage = "Le pas image nécessite l’index PTS réel de la vidéo de référence."
      return
    }
    let desiredReferenceTime = max(currentTime + comparisonOffset, 0)
    guard let timestamp = VideoTimelineAlignment.adjacentTimestamp(
      from: desiredReferenceTime,
      step: frames,
      timestamps: comparisonFrameTimestamps
    ) else { return }
    comparisonOffset = min(max(VideoTimelineAlignment.offset(primaryTime: currentTime, referenceTime: timestamp), -15), 15)
    comparisonPlayer?.seek(
      to: CMTime(seconds: timestamp, preferredTimescale: 60_000),
      toleranceBefore: .zero,
      toleranceAfter: .zero
    )
    Haptics.selection()
  }

  func markComparisonTakeoffHere() {
    guard let comparisonPlayer else {
      analysisMessage = "Chargez d’abord une vidéo de référence."
      return
    }
    let seconds = comparisonPlayer.currentTime().seconds
    guard seconds.isFinite else { return }
    comparisonTakeoffTime = max(seconds, 0)
    analysisMessage = String(format: "Impulsion de référence marquée à %.3f s.", max(seconds, 0))
    Haptics.selection()
  }

  func synchronizeOnTakeoff() {
    guard let mainTakeoff = phaseMarkers.first(where: { $0.phase == .takeoff }) else {
      analysisMessage = "Marquez d’abord l’impulsion de la vidéo principale."
      return
    }
    guard let comparisonTakeoffTime else {
      analysisMessage = "Marquez aussi l’impulsion de la vidéo de référence avant la synchronisation."
      return
    }
    comparisonOffset = min(max(comparisonTakeoffTime - mainTakeoff.timeSeconds, -15), 15)
    synchronizeComparison()
    analysisMessage = String(format: "Impulsions synchronisées · décalage %+.3f s.", comparisonOffset)
  }

  func correctComparisonDrift() {
    guard let comparisonPlayer else { return }
    let target = max(currentTime + comparisonOffset, 0)
    let actual = comparisonPlayer.currentTime().seconds
    guard actual.isFinite else { return }
    let referenceFrameDuration: Double = {
      guard let index = VideoTimelineAlignment.nearestIndex(to: target, in: comparisonFrameTimestamps),
            comparisonFrameTimestamps.indices.contains(index),
            comparisonFrameTimestamps.indices.contains(index + 1) else {
        return comparisonFrameRate > 0 ? 1.0 / comparisonFrameRate : 1.0 / 60.0
      }
      return max(comparisonFrameTimestamps[index + 1] - comparisonFrameTimestamps[index], 1.0 / 240.0)
    }()
    let tolerance = max(referenceFrameDuration * 2.5, 0.045)
    if abs(actual - target) > tolerance {
      let seekTolerance = CMTime(seconds: max(referenceFrameDuration, 1.0 / 240.0), preferredTimescale: 60_000)
      comparisonPlayer.seek(
        to: CMTime(seconds: target, preferredTimescale: 60_000),
        toleranceBefore: seekTolerance,
        toleranceAfter: seekTolerance
      )
    }
  }

  func resetViewport() {
    viewportTransform = VideoViewportTransform()
  }

  func resetComparisonViewport() {
    comparisonViewportTransform = VideoViewportTransform()
  }

  func resetOverlayTransform() {
    overlayTransform = OverlayVideoTransform(opacity: 0.5)
  }

  func synchronizeComparison() {
    guard let comparisonPlayer else { return }
    let desired = max(currentTime + comparisonOffset, 0)
    comparisonPlayer.seek(
      to: CMTime(seconds: desired, preferredTimescale: 60_000),
      toleranceBefore: .zero,
      toleranceAfter: .zero
    )
  }

  func selectTool(_ newTool: Tool) {
    if newTool != .select {
      player?.pause()
      comparisonPlayer?.pause()
      isPlaying = false
    }
    tool = newTool
    if newTool == .scale {
      scaleCalibrationReferenceTime = trackingStartTime
      seek(to: trackingStartTime)
      analysisMessage = "Tracez la référence de distance sur l'image de début, puis indiquez sa longueur réelle."
    }
    if newTool == .background {
      seek(to: trackingStartTime)
      analysisMessage = "Touchez trois ou quatre détails fixes et contrastés du décor, éloignés du perchiste."
    }
    if newTool == .calibration, !isRunwayGridConfigured {
      initializeManualRunwayGrid()
    }
    if newTool == .vector {
      analysisMessage = "Vecteur actif : faites glisser directement sur l’image pour tracer une flèche."
    }
    if newTool == .takeoff {
      analysisMessage = "Impulsion active : touchez la pointe du pied au dernier appui. Le repère sera validé à cette image."
    }
    if newTool == .pose {
      analysisMessage = "Posture active : utilisez « Analyser cette image » sur la vidéo pour détecter le perchiste et son squelette."
    }
    Haptics.selection()
  }

  func playPause() {
    guard let player else { return }
    if isPlaying {
      pausePlayback()
    } else {
      if currentTime >= max(duration - frameDurationSeconds, 0) {
        seek(toFrame: 0, haptic: false)
      }
      tool = .select
      synchronizeComparison()
      player.playImmediately(atRate: playbackRate)
      comparisonPlayer?.playImmediately(atRate: playbackRate)
      isPlaying = true
    }
    Haptics.selection()
  }

  func pausePlayback() {
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
  }

  func setPlaybackRate(_ rate: Float) {
    let clamped = min(max(rate, 0.1), 2.0)
    playbackRate = clamped
    if isPlaying {
      player?.rate = clamped
      comparisonPlayer?.rate = clamped
    }
    Haptics.selection()
  }

  func seek(to seconds: Double) {
    guard let player else { return }
    let clamped = min(max(seconds, 0), max(duration, 0))
    player.seek(
      to: CMTime(seconds: clamped, preferredTimescale: 600),
      toleranceBefore: .zero,
      toleranceAfter: .zero
    )
    currentTime = clamped
    synchronizeComparison()
    poseJoints = []
    if let poseSelectionTime, abs(poseSelectionTime - clamped) > 0.5 / max(frameRate, 1) {
      poseCandidates = []
    }
  }

  func seek(toFrame frame: Int, haptic: Bool = false) {
    guard let player else { return }
    pausePlayback()
    let clampedFrame = min(max(frame, 0), lastFrameIndex)
    let targetSeconds: Double
    if frameTimestamps.indices.contains(clampedFrame) {
      targetSeconds = frameTimestamps[clampedFrame]
    } else {
      targetSeconds = min(Double(clampedFrame) / max(frameRate, 1), max(duration, 0))
    }
    let target = CMTime(seconds: targetSeconds, preferredTimescale: 60_000)
    player.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
    currentTime = targetSeconds
    synchronizeComparison()
    poseJoints = []
    if let poseSelectionTime,
      abs(poseSelectionTime - targetSeconds) > 0.5 * frameDurationSeconds
    {
      poseCandidates = []
    }
    if haptic { Haptics.selection() }
  }

  func step(frames: Int) {
    seek(toFrame: currentFrameIndex + frames, haptic: true)
  }

  func jump(seconds: Double) {
    let target = min(max(currentTime + seconds, 0), duration)
    if frameTimestamps.isEmpty {
      seek(to: target)
    } else {
      seek(toFrame: nearestFrameIndex(to: target), haptic: true)
    }
  }

  func jumpToPreviousAnalysisMoment() {
    let moments = importantMoments.filter { $0 < currentTime - frameDurationSeconds * 0.5 }
    seek(to: moments.last ?? 0)
    Haptics.selection()
  }

  func jumpToNextAnalysisMoment() {
    let moments = importantMoments.filter { $0 > currentTime + frameDurationSeconds * 0.5 }
    seek(to: moments.first ?? duration)
    Haptics.selection()
  }

  private func analysisContext() -> (UUID, URL)? {
    guard let loadedURL else { return nil }
    return (analysisSessionID, loadedURL)
  }

  private func isCurrentAnalysis(_ context: (UUID, URL)) -> Bool {
    context.0 == analysisSessionID && context.1 == loadedURL
  }

  private var importantMoments: [Double] {
    var values = [0, trackingStartTime, trackingEndTime, duration]
    values.append(contentsOf: phaseMarkers.map(\.timeSeconds))
    if let takeoffMeasurement { values.append(takeoffMeasurement.timeSeconds) }
    values.append(contentsOf: pelvisValidation?.checkpoints.map(\.timeSeconds) ?? [])
    return Array(Set(values.map { min(max($0, 0), duration) })).sorted()
  }

  private static func timecode(
    seconds: Double,
    frameIndex: Int,
    frameTimestamps: [Double],
    fallbackRate: Double
  ) -> String {
    let wholeSeconds = max(Int(floor(seconds)), 0)
    let secs = wholeSeconds % 60
    let minutes = (wholeSeconds / 60) % 60
    let hours = wholeSeconds / 3600

    if !frameTimestamps.isEmpty {
      let secondStart = Double(wholeSeconds)
      let frameWithinSecond = frameTimestamps[..<min(frameIndex + 1, frameTimestamps.count)]
        .reversed()
        .prefix { $0 >= secondStart }
        .count - 1
      return String(format: "%02d:%02d:%02d:%02d", hours, minutes, secs, max(frameWithinSecond, 0))
    }

    let fps = max(Int(fallbackRate.rounded()), 1)
    let frame = max(Int((seconds * fallbackRate).rounded()), 0) % fps
    return String(format: "%02d:%02d:%02d:%02d", hours, minutes, secs, frame)
  }

  private func nearestFrameIndex(to seconds: Double) -> Int {
    guard !frameTimestamps.isEmpty else { return 0 }
    var low = 0
    var high = frameTimestamps.count
    while low < high {
      let mid = (low + high) / 2
      if frameTimestamps[mid] < seconds { low = mid + 1 } else { high = mid }
    }
    if low == 0 { return 0 }
    if low >= frameTimestamps.count { return frameTimestamps.count - 1 }
    return abs(frameTimestamps[low] - seconds) < abs(frameTimestamps[low - 1] - seconds) ? low : low - 1
  }

  func setTrackingStartHere() {
    trackingStartTime = min(currentTime, max(trackingEndTime - 0.05, 0))
    invalidatePelvisValidationAfterRangeChange()
    Haptics.selection()
  }

  func setTrackingEndHere() {
    trackingEndTime = min(max(currentTime, trackingStartTime + 0.05), duration)
    invalidatePelvisValidationAfterRangeChange()
    Haptics.selection()
  }

  private func invalidatePelvisValidationAfterRangeChange() {
    guard pelvisValidation != nil else { return }
    pelvisValidation = nil
    pelvisCheckpointIndex = 0
    isPelvisValidationActive = false
    if var result = motionResult {
      result.pelvisValidation = nil
      motionResult = result
    }
    analysisMessage = "Zone modifiée : recréez les points de bassin à 0,1 s après le prochain calcul."
  }

  func addPhaseMarker() {
    phaseMarkers.removeAll { $0.phase == currentPhase }
    phaseMarkers.append(PhaseMarker(phase: currentPhase, timeSeconds: currentTime))
    phaseMarkers.sort { $0.timeSeconds < $1.timeSeconds }
    Haptics.success()
  }

  func analyzePose() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingPose = true
    analysisMessage = nil
    defer { isAnalyzingPose = false }

    do {
      let candidates = try await PoseAnalysisService().analyzeCandidates(
        videoURL: loadedURL,
        at: currentTime
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      poseCandidates = candidates
      poseSelectionTime = currentTime
      if candidates.count == 1, let only = candidates.first {
        selectPoseCandidate(only.id)
        analysisMessage = "Le seul sujet détecté a été sélectionné. Vérifiez le cadre bleu."
      } else {
        selectedAthleteCandidate = nil
        poseJoints = []
        analysisMessage = "\(candidates.count) sujets détectés. Touchez le cadre du perchiste, pas un spectateur."
        tool = .pose
      }
      Haptics.success()
    } catch {
      poseCandidates = []
      selectedAthleteCandidate = nil
      poseJoints = []
      analysisMessage = error.localizedDescription
      Haptics.warning()
    }
  }

  func selectPoseCandidate(_ id: UUID) {
    guard let candidate = poseCandidates.first(where: { $0.id == id }) else { return }
    selectedAthleteCandidate = candidate
    poseJoints = candidate.joints
    trackingSeed = candidate.pelvisPoint ?? candidate.boundingBox.center
    poseSelectionTime = currentTime
    trackingStartTime = currentTime
    if trackingEndTime <= currentTime + 0.20 {
      trackingEndTime = min(duration, currentTime + 3.0)
    }
    tool = .pose
    if pendingPelvisValidationAfterAthleteSelection {
      pendingPelvisValidationAfterAthleteSelection = false
      analysisMessage = "Perchiste sélectionné. Création automatique des points bassin à 0,1 s…"
      preparePelvisValidation()
    } else {
      analysisMessage = "Perchiste sélectionné. Le bassin est initialisé sur cette image."
    }
    Haptics.selection()
  }

  func useDetectedPelvisForTracking() {
    guard let candidate = selectedAthleteCandidate,
      let point = candidate.pelvisPoint
    else {
      analysisMessage = "Détectez les sujets puis touchez le cadre du perchiste."
      return
    }
    trackingSeed = point
    trackingStartTime = poseSelectionTime ?? currentTime
    tool = .tracking
    Haptics.success()
  }

  // MARK: - Calibration dynamique

  func initializeManualRunwayGrid(mirrored: Bool = false) {
    runwayGrid = RunwayGridCalibration.manualTemplate(
      zoneLengthMeters: runwayGrid.zoneLengthMeters,
      runwayWidthMeters: runwayGrid.runwayWidthMeters,
      mirrored: mirrored
    )
    isRunwayGridConfigured = true
    dynamicCalibration = nil
    calibrationMessage = "Quadrilatère initialisé. Placez les 4 coins sur le sol : deux près du butoir et deux à la distance connue, sur les deux bords de la zone."
    Haptics.selection()
  }

  func mirrorRunwayGrid() {
    runwayGrid = runwayGrid.mirroredHorizontally()
    isRunwayGridConfigured = true
    dynamicCalibration = nil
    calibrationMessage = "Sens de la grille inversé. Vérifiez les quatre poignées."
    Haptics.selection()
  }

  func proposeAutomaticRunwayGrid() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    player?.pause()
    isPlaying = false
    isAnalyzingCalibration = true
    calibrationMessage = "Recherche du butoir et des bords de piste…"
    defer { isAnalyzingCalibration = false }

    do {
      let guess = try await sceneDetector.bestGuess(
        videoURL: loadedURL,
        at: currentTime,
        zoneLengthMeters: runwayGrid.zoneLengthMeters,
        runwayWidthMeters: runwayGrid.runwayWidthMeters
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      runwayGrid = guess.grid
      isRunwayGridConfigured = true
      calibrationMessage = "Proposition IA affichée. Vérifiez impérativement les quatre poignées puis ajoutez une correction."
      selectTool(.calibration)
      Haptics.success()
    } catch {
      calibrationMessage = error.localizedDescription
      selectTool(.calibration)
      Haptics.warning()
    }
  }

  func addCalibrationCorrection() {
    guard isRunwayGridConfigured else {
      calibrationMessage = "Initialisez d’abord une grille manuelle."
      Haptics.warning()
      return
    }
    guard runwayGrid.isGeometricallyUsable,
      let transform = try? HomographyMath.imageToRunway(for: runwayGrid)
    else {
      calibrationMessage = "La grille se croise ou couvre une surface trop petite."
      Haptics.warning()
      return
    }
    manualCalibrationKeyframes.removeAll { abs($0.timeSeconds - currentTime) < 1.0 / max(frameRate, 1) }
    manualCalibrationKeyframes.append(
      CalibrationKeyframe(
        timeSeconds: currentTime,
        source: .userCorrection,
        grid: runwayGrid,
        imageToRunway: transform,
        confidence: 0, // verified manually; no statistical confidence claimed
        estimatedErrorMeters: 0
      )
    )
    manualCalibrationKeyframes.sort { $0.timeSeconds < $1.timeSeconds }
    calibrationMessage = String(format: "Correction enregistrée à %.3f s.", currentTime)
    Haptics.success()
  }

  func analyzeDynamicCalibration() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    guard isRunwayGridConfigured else {
      calibrationMessage = "Initialisez puis ajustez la grille avant de lancer le suivi."
      Haptics.warning()
      return
    }
    guard runwayGrid.isGeometricallyUsable else {
      calibrationMessage = "Ajustez d’abord la grille sur les bords de la piste."
      Haptics.warning()
      return
    }
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingCalibration = true
    calibrationMessage = "Suivi des quatre ancrages et recalcul de la perspective image par image…"
    defer { isAnalyzingCalibration = false }

    do {
      if manualCalibrationKeyframes.isEmpty { addCalibrationCorrection() }
      let result = try await calibrationService.analyze(
        videoURL: loadedURL,
        initialGrid: runwayGrid,
        manualKeyframes: manualCalibrationKeyframes,
        startTime: trackingStartTime,
        endTime: trackingEndTime,
        requestedFrameRate: frameRate
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      dynamicCalibration = result
      let reviewCount = result.samples.filter { $0.status == .manualRequired }.count
      calibrationMessage = String(
        format: "Calibration dynamique terminée · score qualité %.0f %% · %d image(s) à corriger.",
        result.averageConfidence * 100,
        reviewCount
      )
      seek(to: result.startTime)
      Haptics.success()
    } catch {
      dynamicCalibration = nil
      calibrationMessage = error.localizedDescription
      Haptics.error()
    }
  }

  func useDynamicGridAtCurrentTimeForCorrection() {
    if let sample = dynamicCalibration?.sample(nearest: currentTime) {
      runwayGrid = sample.grid
    } else if !isRunwayGridConfigured {
      initializeManualRunwayGrid()
    }
    isRunwayGridConfigured = true
    selectTool(.calibration)
  }

  func jumpToNextCalibrationIssue() {
    guard let samples = dynamicCalibration?.samples, !samples.isEmpty else { return }
    let issues = samples.filter { $0.status == .manualRequired || $0.status == .review }
    guard !issues.isEmpty else {
      calibrationMessage = "Aucune zone problématique détectée dans cette séquence."
      Haptics.success()
      return
    }
    let next = issues.first(where: { $0.timeSeconds > currentTime + 0.02 }) ?? issues[0]
    seek(to: next.timeSeconds)
    runwayGrid = next.grid
    selectTool(.calibration)
    calibrationMessage = String(
      format: "Contrôlez la grille à %.3f s, puis ajoutez une correction.",
      next.timeSeconds
    )
  }

  func useDetectedFootForTakeoff() {
    let sourceJoints = selectedAthleteCandidate?.joints ?? poseJoints
    let ankles = sourceJoints.filter { $0.id == "leftAnkle" || $0.id == "rightAnkle" }
    guard let foot = ankles.max(by: { $0.point.y < $1.point.y }) else {
      analysisMessage = "Détectez d’abord la posture sur l’image du dernier appui."
      Haptics.warning()
      return
    }
    takeoffPoint = foot.point
    tool = .takeoff
    analysisMessage = "Point de cheville proposé par Vision. Déplacez-le sur la pointe du pied avant de calculer."
    Haptics.success()
  }

  func measureTakeoff() {
    guard let point = takeoffPoint else {
      analysisMessage = "Choisissez Impulsion puis touchez la pointe du pied au dernier appui."
      Haptics.warning()
      return
    }
    guard let sample = dynamicCalibration?.validatedSample(nearest: currentTime),
      let metric = sample.imageToRunway.projectMetric(point)
    else {
      analysisMessage = "Aucune homographie fiable à cette image. Ajoutez une correction de grille."
      Haptics.warning()
      return
    }

    // `confidence` is a quality score, not a calibrated probability.
    let confidence = sample.confidence
    // Only report an uncertainty when the calibration service has an evidence-based estimate.
    let uncertainty: Double? = sample.estimatedErrorMeters > 0 ? sample.estimatedErrorMeters : nil
    let measurement = TakeoffMeasurement(
      timeSeconds: currentTime,
      imagePoint: point,
      distanceFromBoxMeters: metric.xMeters,
      lateralPositionMeters: metric.yMeters,
      confidence: confidence,
      uncertaintyMeters: uncertainty,
      convention: takeoffConvention,
      status: sample.status
    )
    takeoffMeasurement = measurement
    dynamicCalibration?.takeoffMeasurement = measurement
    if motionResult != nil { motionResult?.takeoffMeasurement = measurement }
    analysisMessage = "Marque d’impulsion signée : \(measurement.formattedDistance) depuis le fond du butoir (signe conservé pour détecter une calibration incohérente)."
    Haptics.success()
  }

  // MARK: - Suivi de l'athlète

  func analyzeMotion() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    guard let trackingSeed else {
      analysisMessage = "Sélectionnez le perchiste pour initialiser le suivi. Le calcul métrique utilisera ensuite les appuis/chevilles au sol, pas le bassin."
      Haptics.warning()
      return
    }
    guard let dynamicCalibration, dynamicCalibration.isUsable else {
      analysisMessage = "Lancez d’abord la calibration dynamique de la piste."
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingMotion = true
    pelvisValidation = nil
    isPelvisValidationActive = false
    pelvisCheckpointIndex = 0
    analysisMessage = "Suivi des appuis + perspective dynamique image par image…"
    defer { isAnalyzingMotion = false }

    do {
      var result = try await motionService.analyze(
        videoURL: loadedURL,
        seed: trackingSeed,
        dynamicCalibration: dynamicCalibration,
        startTime: trackingStartTime,
        endTime: trackingEndTime,
        requestedFrameRate: frameRate,
        videoSize: videoNaturalSize
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      result.takeoffMeasurement = takeoffMeasurement
      motionResult = result
      analysisMessage = String(
        format: "Analyse terminée · vitesse représentative %.2f m/s · score qualité %.0f %%",
        result.representativeHorizontalSpeed,
        result.averageConfidence * 100
      )
      seek(to: result.startTime)
      Haptics.success()
    } catch {
      motionResult = nil
      analysisMessage = error.localizedDescription
      Haptics.error()
    }
  }

  func analyzeMotionWithoutBox(athleteHeightCM: Double) async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    guard athleteHeightCM >= 120, athleteHeightCM <= 230 else {
      analysisMessage = "Renseignez la taille réelle de l’athlète (120 à 230 cm) pour convertir le suivi en mètres."
      Haptics.warning()
      return
    }
    guard trackingEndTime > trackingStartTime + 0.20 else {
      analysisMessage = "Définissez une zone d’analyse d’au moins 0,20 s avec Début ici et Fin ici."
      Haptics.warning()
      return
    }
    guard let candidate = selectedAthleteCandidate else {
      analysisMessage = "Détectez les personnes puis sélectionnez le perchiste avant de lancer l’analyse sans butoir."
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingBoxlessMotion = true
    pelvisValidation = nil
    isPelvisValidationActive = false
    pelvisCheckpointIndex = 0
    analysisMessage = "Stabilisation du décor et suivi du perchiste sans utiliser le butoir…"
    defer { isAnalyzingBoxlessMotion = false }

    do {
      let selectionTime = poseSelectionTime ?? trackingStartTime
      let start = max(selectionTime, 0)
      if trackingStartTime < start - 0.02 { trackingStartTime = start }
      var result = try await athleteScaleMotionService.analyze(
        videoURL: loadedURL,
        candidate: candidate,
        athleteHeightMeters: athleteHeightCM / 100.0,
        startTime: trackingStartTime,
        endTime: trackingEndTime,
        requestedFrameRate: frameRate,
        suppliedVideoSize: videoNaturalSize
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      result.takeoffMeasurement = takeoffMeasurement
      motionResult = result
      trackingSeed = result.trackingSeed
      analysisMessage = String(
        format: "Mesures avancées sans butoir terminées · %.2f m/s · score qualité %.0f %%. La marque d’impulsion depuis le butoir reste indisponible.",
        result.representativeHorizontalSpeed,
        result.averageConfidence * 100
      )
      seek(to: result.startTime)
      Haptics.success()
    } catch {
      motionResult = nil
      analysisMessage = error.localizedDescription
      Haptics.error()
    }
  }

  // MARK: - Validation manuelle du bassin à 10 Hz

  func beginPelvisValidationWorkflow(athleteHeightCM: Double = 0) async {
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false

    // In fixed-camera ground-projection mode the measured point is deliberately not a body joint.
    // Do not force a pelvis detector before allowing manual ground-point validation.
    if isGroundProjectionValidation {
      pendingPelvisValidationAfterAthleteSelection = false
      preparePelvisValidation(athleteHeightCM: athleteHeightCM)
      return
    }

    if selectedAthleteCandidate == nil && trackingSeed == nil && motionResult == nil {
      pendingPelvisValidationAfterAthleteSelection = true
      tool = .pose
      analysisMessage = "Étape 4 : détection du perchiste en cours…"
      await analyzePose()

      if selectedAthleteCandidate != nil || trackingSeed != nil || motionResult != nil {
        pendingPelvisValidationAfterAthleteSelection = false
        if pelvisValidation == nil {
          preparePelvisValidation(athleteHeightCM: athleteHeightCM)
        }
      } else if poseCandidates.count > 1 {
        analysisMessage = "Étape 4 : touchez le cadre du perchiste. Les points bassin 0,1 s seront créés automatiquement ensuite."
      } else {
        pendingPelvisValidationAfterAthleteSelection = false
        analysisMessage = "Aucun perchiste exploitable détecté. Placez-vous sur une image où le corps est visible puis réessayez."
      }
      return
    }

    pendingPelvisValidationAfterAthleteSelection = false
    preparePelvisValidation(athleteHeightCM: athleteHeightCM)
  }

  func preparePelvisValidation(athleteHeightCM: Double = 0) {
    if !isGroundProjectionValidation,
      selectedAthleteCandidate == nil && trackingSeed == nil && motionResult == nil
    {
      analysisMessage = "Sélectionnez d’abord le perchiste et son bassin."
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false

    let start = max(trackingStartTime, 0)
    let end = min(trackingEndTime, duration > 0 ? duration : trackingEndTime)
    guard end - start >= 0.40 else {
      analysisMessage = "La zone doit durer au moins 0,40 s pour calculer vitesse et accélération."
      Haptics.warning()
      return
    }

    let interval = 0.1
    var times: [Double] = []
    var time = start
    while time <= end + 0.0001, times.count < 300 {
      times.append((time * 1000).rounded() / 1000)
      time += interval
    }
    if let last = times.last, end - last > 0.045 {
      times.append((end * 1000).rounded() / 1000)
    }

    let fallback = isGroundProjectionValidation
      ? runwayGrid.center
      : (selectedAthleteCandidate?.pelvisPoint
        ?? trackingSeed
        ?? motionResult?.trackingSeed
        ?? NormalizedPoint(x: 0.5, y: 0.5))
    let checkpoints = times.map { checkpointTime -> PelvisCheckpoint in
      if let sample = motionResult?.sample(nearest: checkpointTime) {
        return PelvisCheckpoint(
          timeSeconds: checkpointTime,
          suggestedPoint: sample.point,
          suggestionConfidence: sample.confidence
        )
      }
      return PelvisCheckpoint(
        timeSeconds: checkpointTime,
        suggestedPoint: fallback,
        suggestionConfidence: selectedAthleteCandidate?.confidence ?? 0.30
      )
    }

    guard checkpoints.count >= 5 else {
      analysisMessage = "Impossible de créer suffisamment de points de mesure."
      Haptics.error()
      return
    }

    let storedHeight = athleteHeightCM >= 120 && athleteHeightCM <= 230
      ? athleteHeightCM / 100.0
      : 0
    pelvisValidation = PelvisValidationSession(
      checkpoints: checkpoints,
      intervalSeconds: interval,
      startTime: start,
      endTime: end,
      athleteHeightMeters: storedHeight,
      modelVersion: isGroundProjectionValidation
        ? "Point sol manuel 10 Hz — homographie fixe v13"
        : "Bassin manuel 10 Hz — mesure physique v3"
    )
    pelvisCheckpointIndex = 0
    isPelvisValidationActive = true
    tool = .select
    seek(to: checkpoints[0].timeSeconds)
    analysisMessage = isGroundProjectionValidation
      ? "Point 1 sur \(checkpoints.count) : placez le repère sur le sol sous le bassin ou sur l’appui visible, puis confirmez."
      : "Point 1 sur \(checkpoints.count) : placez le repère au centre du bassin, puis confirmez."
    Haptics.success()
  }

  func setCurrentPelvisPoint(_ point: NormalizedPoint) {
    guard var session = pelvisValidation,
      session.checkpoints.indices.contains(pelvisCheckpointIndex)
    else { return }
    session.checkpoints[pelvisCheckpointIndex].confirmedPoint = point.clamped()
    pelvisValidation = session
  }

  func confirmCurrentPelvisCheckpoint() {
    guard var session = pelvisValidation,
      session.checkpoints.indices.contains(pelvisCheckpointIndex)
    else { return }

    var checkpoint = session.checkpoints[pelvisCheckpointIndex]
    let chosen = checkpoint.confirmedPoint ?? checkpoint.suggestedPoint
    let distance = hypot(
      chosen.x - checkpoint.suggestedPoint.x,
      chosen.y - checkpoint.suggestedPoint.y
    )
    checkpoint.confirmedPoint = chosen.clamped()
    checkpoint.state = distance > 0.006 ? .adjusted : .confirmed
    session.checkpoints[pelvisCheckpointIndex] = checkpoint
    pelvisValidation = session

    if let next = nextPendingCheckpoint(after: pelvisCheckpointIndex, in: session) {
      pelvisCheckpointIndex = next
      seek(to: session.checkpoints[next].timeSeconds)
      analysisMessage = "Point \(next + 1) sur \(session.checkpoints.count) · \(session.confirmedCount) confirmés."
      Haptics.selection()
    } else {
      isPelvisValidationActive = false
      analysisMessage = "Tous les points de \(validationPointTitle) sont confirmés. Vous pouvez maintenant calculer les mesures."
      Haptics.success()
    }
  }

  func movePelvisCheckpoint(by offset: Int) {
    guard let session = pelvisValidation, !session.checkpoints.isEmpty else { return }
    pelvisCheckpointIndex = min(max(pelvisCheckpointIndex + offset, 0), session.checkpoints.count - 1)
    isPelvisValidationActive = true
    seek(to: session.checkpoints[pelvisCheckpointIndex].timeSeconds)
    Haptics.selection()
  }

  func jumpToPelvisCheckpoint(_ index: Int) {
    guard let session = pelvisValidation, session.checkpoints.indices.contains(index) else { return }
    pelvisCheckpointIndex = index
    isPelvisValidationActive = true
    seek(to: session.checkpoints[index].timeSeconds)
    Haptics.selection()
  }

  func resumePelvisValidation() {
    guard let session = pelvisValidation, !session.checkpoints.isEmpty else { return }
    let next = session.checkpoints.firstIndex(where: { !$0.isConfirmed }) ?? min(pelvisCheckpointIndex, session.checkpoints.count - 1)
    pelvisCheckpointIndex = next
    isPelvisValidationActive = true
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    seek(to: session.checkpoints[next].timeSeconds)
  }

  func refineCurrentPelvisSuggestion() async {
    guard canRefineValidationPointWithVision else {
      analysisMessage = "Le mode point au sol exige une validation manuelle : Vision estime le bassin, pas sa projection métrique exacte sur la piste."
      Haptics.warning()
      return
    }
    guard let loadedURL, var session = pelvisValidation,
      session.checkpoints.indices.contains(pelvisCheckpointIndex)
    else { return }
    let checkpoint = session.checkpoints[pelvisCheckpointIndex]
    isAnalyzingPose = true
    defer { isAnalyzingPose = false }
    do {
      let candidates = try await PoseAnalysisService().analyzeCandidates(
        videoURL: loadedURL,
        at: checkpoint.timeSeconds
      )
      guard let matched = candidates.min(by: {
        athleteMatchScore($0, reference: checkpoint.effectivePoint)
          < athleteMatchScore($1, reference: checkpoint.effectivePoint)
      }), let pelvis = matched.pelvisPoint else {
        throw PoseAnalysisService.PoseError.noPerson
      }
      session.checkpoints[pelvisCheckpointIndex].suggestedPoint = pelvis
      session.checkpoints[pelvisCheckpointIndex].suggestionConfidence = matched.confidence
      if session.checkpoints[pelvisCheckpointIndex].confirmedPoint == nil {
        session.checkpoints[pelvisCheckpointIndex].confirmedPoint = pelvis
      }
      pelvisValidation = session
      selectedAthleteCandidate = matched
      poseJoints = matched.joints
      analysisMessage = "Suggestion Vision replacée sur le bassin. Vérifiez puis confirmez."
      Haptics.success()
    } catch {
      analysisMessage = "Vision n’a pas identifié clairement le bassin sur cette image. Placez le repère manuellement."
      Haptics.warning()
    }
  }

  func recalculateStatsFromConfirmedPelvis(athleteHeightCM: Double) async {
    guard let baseline = motionResult, let validation = pelvisValidation else {
      analysisMessage = "Préparez et confirmez d’abord les points de bassin."
      Haptics.warning()
      return
    }
    guard validation.isComplete else {
      analysisMessage = "Il reste \(validation.checkpoints.count - validation.confirmedCount) point(s) à confirmer."
      resumePelvisValidation()
      Haptics.warning()
      return
    }

    isRecalculatingPelvisStats = true
    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    analysisMessage = "Recalcul biomécanique à partir des positions confirmées…"
    defer { isRecalculatingPelvisStats = false }

    do {
      let result = try await manualPelvisMotionService.recalculate(
        baseline: baseline,
        validation: validation,
        athleteHeightMeters: athleteHeightCM / 100.0,
        videoSize: videoNaturalSize
      )
      motionResult = result
      pelvisValidation = result.pelvisValidation
      trackingSeed = result.trackingSeed
      isPelvisValidationActive = false
      seek(to: result.startTime)
      analysisMessage = String(
        format: "Mesures avancées recalculées avec %d positions confirmées · %.2f m/s · score qualité %.0f %%.",
        validation.confirmedCount,
        result.representativeHorizontalSpeed,
        result.averageConfidence * 100
      )
      Haptics.success()
    } catch {
      analysisMessage = error.localizedDescription
      Haptics.error()
    }
  }

  func analyzeFixedObliqueMotion() async {
    guard let analysisContext = analysisContext() else { return }
    guard isRunwayGridConfigured, runwayGrid.isGeometricallyUsable else {
      analysisMessage = "Étape 2 : définissez les quatre coins d’un quadrilatère réel sur le plan de la piste."
      initializeManualRunwayGrid()
      tool = .calibration
      Haptics.warning()
      return
    }
    guard let validation = pelvisValidation, validation.isComplete else {
      let target = fixedObliqueTrackingPoint == .groundProjection ? "point au sol" : "bassin"
      analysisMessage = "Étape 3 : confirmez le \(target) toutes les 0,1 seconde."
      if pelvisValidation == nil { preparePelvisValidation() } else { resumePelvisValidation() }
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingCalibratedMotion = true
    analysisMessage = "Correction de perspective fixe et calcul de la vitesse longitudinale avec les PTS réels…"
    defer { isAnalyzingCalibratedMotion = false }

    do {
      var result = try await fixedObliqueMotionService.analyze(
        validation: validation,
        grid: runwayGrid,
        trackingPoint: fixedObliqueTrackingPoint,
        metricOrigin: fixedRunwayMetricOrigin
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      result.takeoffMeasurement = takeoffMeasurement
      motionResult = result
      pelvisValidation = result.pelvisValidation
      trackingSeed = result.trackingSeed
      isPelvisValidationActive = false
      seek(to: result.startTime)
      let pointSuffix = fixedObliqueTrackingPoint == .pelvisEstimate ? " · bassin estimé, parallaxe possible" : " · point sol"
      let originSuffix = fixedRunwayMetricOrigin == .box ? " · origine butoir" : " · origine relative"
      let suffix = pointSuffix + originSuffix
      analysisMessage = String(
        format: "Perspective corrigée · vitesse moyenne %.2f m/s · pic %.2f m/s · score qualité %.0f %% %@.",
        result.representativeHorizontalSpeed,
        result.peakHorizontalSpeed,
        result.averageConfidence * 100,
        suffix
      )
      Haptics.success()
    } catch {
      analysisMessage = error.localizedDescription
      Haptics.error()
    }
  }

  func analyzePhysicalMotion() async {
    switch physicalCameraMode {
    case .fixedOblique:
      await analyzeFixedObliqueMotion()
    case .mobile:
      guard isRunwayGridConfigured, runwayGrid.isGeometricallyUsable else {
        analysisMessage = "Étape 2 : calibrez un quadrilatère réel sur le plan de la piste."
        initializeManualRunwayGrid()
        selectTool(.calibration)
        Haptics.warning()
        return
      }
      if dynamicCalibration?.isUsable != true {
        await analyzeDynamicCalibration()
      }
      guard dynamicCalibration?.isUsable == true else {
        analysisMessage = "La perspective dynamique n’est pas assez stable : aucune vitesse métrique n’est calculée."
        return
      }
      if trackingSeed == nil, let candidate = selectedAthleteCandidate {
        trackingSeed = candidate.boundingBox.center
      }
      await analyzeMotion()
    }
  }

  func analyzeCalibratedManualMotion() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    guard calibration.distanceMeters > 0,
      calibration.pixelLength(in: videoNaturalSize) >= 20
    else {
      analysisMessage = "Étape 2 : tracez une distance réelle et indiquez sa longueur en mètres."
      tool = .scale
      seek(to: trackingStartTime)
      Haptics.warning()
      return
    }
    guard backgroundAnchors.count >= 2 else {
      analysisMessage = "Étape 3 : placez au moins deux repères fixes du décor ; trois ou quatre sont recommandés."
      tool = .background
      seek(to: trackingStartTime)
      Haptics.warning()
      return
    }
    guard let validation = pelvisValidation, validation.isComplete else {
      analysisMessage = "Étape 4 : confirmez le bassin toutes les 0,1 seconde."
      if pelvisValidation == nil { preparePelvisValidation() } else { resumePelvisValidation() }
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingCalibratedMotion = true
    analysisMessage = "Calcul physique : stabilisation du décor, conversion métrique et dérivées temporelles…"
    defer { isAnalyzingCalibratedMotion = false }

    do {
      var result = try await calibratedManualMotionService.analyze(
        videoURL: loadedURL,
        validation: validation,
        calibration: calibration,
        backgroundAnchors: backgroundAnchors,
        requestedFrameRate: frameRate,
        suppliedVideoSize: videoNaturalSize
      )
      guard isCurrentAnalysis(analysisContext) else { return }
      result.takeoffMeasurement = takeoffMeasurement
      motionResult = result
      pelvisValidation = result.pelvisValidation
      trackingSeed = result.trackingSeed
      isPelvisValidationActive = false
      seek(to: result.startTime)
      analysisMessage = String(
        format: "Mesure terminée · vitesse moyenne %.2f m/s · pic %.2f m/s · score qualité %.0f %%.",
        result.representativeHorizontalSpeed,
        result.peakHorizontalSpeed,
        result.averageConfidence * 100
      )
      Haptics.success()
    } catch {
      analysisMessage = error.localizedDescription
      Haptics.error()
    }
  }

  func resetPhysicalCalibration() {
    calibration = VideoCalibration()
    calibration.distanceMeters = 0
    backgroundAnchors = []
    isRunwayGridConfigured = false
    fixedRunwayMetricOrigin = .box
    dynamicCalibration = nil
    manualCalibrationKeyframes = []
    motionResult = nil
    pelvisValidation = nil
    pelvisCheckpointIndex = 0
    isPelvisValidationActive = false
    analysisMessage = "Étalonnage physique réinitialisé."
    Haptics.warning()
  }

  func placeDefaultBackgroundAnchors() {
    backgroundAnchors = [
      NormalizedPoint(x: 0.16, y: 0.28),
      NormalizedPoint(x: 0.50, y: 0.22),
      NormalizedPoint(x: 0.82, y: 0.31)
    ]
    tool = .background
    seek(to: trackingStartTime)
    analysisMessage = "Déplacez les trois repères sur des détails fixes et contrastés du décor."
    Haptics.selection()
  }

  func clearPelvisValidation() {
    pelvisValidation = nil
    pelvisCheckpointIndex = 0
    isPelvisValidationActive = false
    if var result = motionResult {
      result.pelvisValidation = nil
      motionResult = result
    }
    Haptics.warning()
  }

  private func nextPendingCheckpoint(after index: Int, in session: PelvisValidationSession) -> Int? {
    if index + 1 < session.checkpoints.count,
      let next = session.checkpoints[(index + 1)...].firstIndex(where: { !$0.isConfirmed })
    {
      return next
    }
    return session.checkpoints.firstIndex(where: { !$0.isConfirmed })
  }

  func proposeTakeoffFootForSelectedAthlete() async {
    guard let loadedURL else { return }
    guard let analysisContext = analysisContext() else { return }
    guard selectedAthleteCandidate != nil else {
      analysisMessage = "Sélectionnez d’abord le perchiste à l’étape 2."
      Haptics.warning()
      return
    }

    player?.pause()
    comparisonPlayer?.pause()
    isPlaying = false
    isAnalyzingPose = true
    analysisMessage = "Analyse temporelle du dernier appui sur plusieurs images…"
    defer { isAnalyzingPose = false }

    do {
      let centerFrame = currentFrameIndex
      let indices = (-2...2).map { min(max(centerFrame + $0, 0), lastFrameIndex) }
      let times = Array(Set(indices.map { index -> Double in
        frameTimestamps.indices.contains(index) ? frameTimestamps[index] : Double(index) / max(frameRate, 1)
      })).sorted()
      let referencePoint = currentMotionSample?.point
        ?? selectedAthleteCandidate?.boundingBox.center
        ?? .init(x: 0.5, y: 0.5)

      var matchedFrames: [(time: Double, candidate: PoseCandidate)] = []
      var movingReference = referencePoint
      for time in times {
        let candidates = try await PoseAnalysisService().analyzeCandidates(videoURL: loadedURL, at: time)
        guard let matched = candidates.min(by: {
          athleteMatchScore($0, reference: movingReference) < athleteMatchScore($1, reference: movingReference)
        }) else { continue }
        matchedFrames.append((time, matched))
        movingReference = matched.boundingBox.center
      }
      guard isCurrentAnalysis(analysisContext) else { return }
      guard matchedFrames.count >= 3 else { throw PoseAnalysisService.PoseError.noPerson }

      func contactScore(side: String) -> Double? {
        let ankleID = side + "Ankle"
        let samples = matchedFrames.compactMap { item -> (Double, NormalizedPoint)? in
          guard let ankle = item.candidate.joints.first(where: { $0.id == ankleID }) else { return nil }
          return (item.time, ankle.point)
        }
        guard samples.count >= 3 else { return nil }
        let meanY = samples.map { $0.1.y }.reduce(0, +) / Double(samples.count)
        var motion = 0.0
        for pair in zip(samples.dropFirst(), samples) {
          let dt = max(pair.0.0 - pair.1.0, 1.0 / 240.0)
          motion += hypot(pair.0.1.x - pair.1.1.x, pair.0.1.y - pair.1.1.y) / dt
        }
        let meanMotion = motion / Double(max(samples.count - 1, 1))
        // Lower in image + temporarily slower relative foot motion is more compatible with ground contact.
        return meanY - min(meanMotion, 4) * 0.08
      }

      let leftScore = contactScore(side: "left")
      let rightScore = contactScore(side: "right")
      let selectedSide: String
      switch (leftScore, rightScore) {
      case let (left?, right?): selectedSide = left >= right ? "left" : "right"
      case (_?, nil): selectedSide = "left"
      case (nil, _?): selectedSide = "right"
      default:
        analysisMessage = "Les chevilles ne sont pas assez visibles sur la séquence. Placez le dernier appui manuellement."
        tool = .takeoff
        Haptics.warning()
        return
      }

      let centerMatch = matchedFrames.min(by: { abs($0.time - currentTime) < abs($1.time - currentTime) })!
      guard let foot = centerMatch.candidate.joints.first(where: { $0.id == selectedSide + "Ankle" }) else {
        analysisMessage = "La cheville sélectionnée n’est pas visible sur l’image centrale. Placez le point manuellement."
        tool = .takeoff
        Haptics.warning()
        return
      }

      selectedAthleteCandidate = centerMatch.candidate
      poseCandidates = [centerMatch.candidate]
      poseJoints = centerMatch.candidate.joints
      poseSelectionTime = centerMatch.time
      takeoffPoint = foot.point
      currentPhase = .takeoff
      tool = .takeoff
      analysisMessage = "Dernier appui proposé à partir de 3 à 5 images (hauteur du pied + ralentissement relatif). Ajustez le point sur la chaussure puis validez."
      Haptics.success()
    } catch {
      guard isCurrentAnalysis(analysisContext) else { return }
      analysisMessage = error.localizedDescription
      tool = .takeoff
      Haptics.warning()
    }
  }

  func validateTakeoffWithoutMetricOrigin() {
    guard takeoffPoint != nil else {
      analysisMessage = "Placez d’abord le dernier appui sur la vidéo."
      Haptics.warning()
      return
    }
    phaseMarkers.removeAll { $0.phase == .takeoff }
    phaseMarkers.append(PhaseMarker(phase: .takeoff, timeSeconds: currentTime))
    phaseMarkers.sort { $0.timeSeconds < $1.timeSeconds }
    currentPhase = .takeoff
    takeoffMeasurement = nil
    analysisMessage = String(
      format: "Image d’impulsion validée à %.3f s. Les Mesures avancées restent disponibles ; la distance depuis le butoir nécessite une grille métrique.",
      currentTime
    )
    Haptics.success()
  }

  private func athleteMatchScore(_ candidate: PoseCandidate, reference: NormalizedPoint) -> Double {
    let center = candidate.pelvisPoint ?? candidate.boundingBox.center
    let distance = hypot(center.x - reference.x, center.y - reference.y)
    let sizePenalty = candidate.boundingBox.area < 0.008 ? 0.20 : 0
    return distance + sizePenalty + (1 - candidate.confidence) * 0.08
  }

  func vectorWasCreated() {
    analysisMessage = "Vecteur créé. Ses deux extrémités peuvent être ajustées avec l’outil Sélection."
    Haptics.success()
  }

  func commitTakeoffPoint() {
    guard takeoffPoint != nil else { return }
    phaseMarkers.removeAll { $0.phase == .takeoff }
    phaseMarkers.append(PhaseMarker(phase: .takeoff, timeSeconds: currentTime))
    phaseMarkers.sort { $0.timeSeconds < $1.timeSeconds }
    currentPhase = .takeoff

    if dynamicCalibration?.validatedSample(nearest: currentTime) != nil {
      measureTakeoff()
    } else {
      takeoffMeasurement = nil
      analysisMessage = String(format: "Impulsion marquée à %.3f s. Distance métrique indisponible tant qu’aucune grille fiable n’est disponible.", currentTime)
      Haptics.success()
    }
  }

  func deleteSelectedVector() {
    guard let selectedVectorID else { return }
    vectors.removeAll { $0.id == selectedVectorID }
    self.selectedVectorID = nil
    Haptics.impact(.light)
  }

  func undoNonPencilAnnotation() {
    switch tool {
    case .vector, .select:
      if let selectedVectorID,
        let index = vectors.firstIndex(where: { $0.id == selectedVectorID })
      {
        vectors.remove(at: index)
        self.selectedVectorID = vectors.last?.id
      } else if !vectors.isEmpty {
        _ = vectors.popLast()
        selectedVectorID = vectors.last?.id
      }
    case .tracking:
      if motionResult != nil { motionResult = nil } else { trackingSeed = nil }
    case .scale:
      calibration = VideoCalibration()
      calibration.distanceMeters = 0
    case .background:
      if !backgroundAnchors.isEmpty { _ = backgroundAnchors.popLast() }
    case .calibration:
      if !manualCalibrationKeyframes.isEmpty {
        _ = manualCalibrationKeyframes.popLast()
      } else {
        dynamicCalibration = nil
      }
    case .takeoff:
      takeoffMeasurement = nil
      takeoffPoint = nil
    case .pose:
      poseJoints = []
      poseCandidates = []
      selectedAthleteCandidate = nil
      poseSelectionTime = nil
    case .freehand, .erase:
      break
    }
    Haptics.impact(.light)
  }

  func clearAnnotations() {
    vectors.removeAll()
    phaseMarkers.removeAll()
    poseJoints.removeAll()
    poseCandidates.removeAll()
    selectedAthleteCandidate = nil
    poseSelectionTime = nil
    pencilDrawing = PKDrawing()
    selectedVectorID = nil
    calibration = VideoCalibration()
    scaleCalibrationReferenceTime = 0
    backgroundAnchors.removeAll()
    runwayGrid = RunwayGridCalibration()
    isRunwayGridConfigured = false
    fixedRunwayMetricOrigin = .box
    dynamicCalibration = nil
    manualCalibrationKeyframes.removeAll()
    takeoffPoint = nil
    takeoffMeasurement = nil
    trackingSeed = nil
    motionResult = nil
    pelvisValidation = nil
    pelvisCheckpointIndex = 0
    isPelvisValidationActive = false
    analysisMessage = nil
    calibrationMessage = nil
    Haptics.warning()
  }

  func restore(
    vectors: [OverlayVector],
    phaseMarkers: [PhaseMarker],
    pencilData: Data?,
    calibration: VideoCalibration?,
    dynamicCalibration: DynamicCalibrationTrack?,
    trackingSeed: NormalizedPoint?,
    motionResult: MotionAnalysisResult?
  ) {
    self.vectors = vectors
    self.phaseMarkers = phaseMarkers.sorted { $0.timeSeconds < $1.timeSeconds }
    self.calibration = calibration ?? motionResult?.calibration ?? VideoCalibration()
    self.scaleCalibrationReferenceTime = motionResult?.calibrationReferenceTime ?? motionResult?.startTime ?? 0
    self.backgroundAnchors = motionResult?.backgroundReferencePoints ?? []
    self.dynamicCalibration = dynamicCalibration ?? motionResult?.dynamicCalibration
    self.runwayGrid = self.dynamicCalibration?.initialGrid
      ?? motionResult?.fixedRunwayGrid
      ?? RunwayGridCalibration()
    self.isRunwayGridConfigured = self.dynamicCalibration != nil || motionResult?.fixedRunwayGrid != nil
    self.fixedRunwayMetricOrigin = motionResult?.fixedRunwayMetricOrigin ?? .box
    self.manualCalibrationKeyframes = self.dynamicCalibration?.keyframes.filter {
      $0.source == .userCorrection
    } ?? []
    self.trackingSeed = trackingSeed
    self.motionResult = motionResult
    self.pelvisValidation = motionResult?.pelvisValidation
    self.pelvisCheckpointIndex = self.pelvisValidation?.checkpoints.firstIndex(where: { !$0.isConfirmed }) ?? 0
    self.isPelvisValidationActive = false
    self.poseCandidates = []
    self.selectedAthleteCandidate = nil
    self.poseSelectionTime = nil
    self.poseJoints = []
    self.takeoffMeasurement = motionResult?.takeoffMeasurement ?? self.dynamicCalibration?.takeoffMeasurement
    self.takeoffPoint = self.takeoffMeasurement?.imagePoint
    if let motionResult {
      trackingStartTime = motionResult.startTime
      trackingEndTime = motionResult.endTime
    } else if let dynamicCalibration {
      trackingStartTime = dynamicCalibration.startTime
      trackingEndTime = dynamicCalibration.endTime
    }
    if let pencilData, let drawing = try? PKDrawing(data: pencilData) {
      pencilDrawing = drawing
    } else {
      pencilDrawing = PKDrawing()
    }
  }

  func teardown() {
    analysisTask?.cancel()
    analysisTask = nil
    analysisSessionID = UUID()
    cleanupPlayer()
    loadedURL = nil
    duration = 0
    currentTime = 0
    frameTimestamps = []
    poseCandidates = []
    selectedAthleteCandidate = nil
    poseSelectionTime = nil
    poseJoints = []
    isPelvisValidationActive = false
  }

  private func addTimeObserver(to observedPlayer: AVPlayer) {
    let interval = CMTime(seconds: 1.0 / 30.0, preferredTimescale: 600)
    timeObserver = observedPlayer.addPeriodicTimeObserver(forInterval: interval, queue: nil) {
      [weak self] time in
      Task { @MainActor [weak self] in self?.handlePeriodicTime(time) }
    }
  }

  private func handlePeriodicTime(_ time: CMTime) {
    currentTime = time.seconds.isFinite ? time.seconds : 0
    isPlaying = player?.rate != 0

    if let comparisonPlayer {
      let desired = max(currentTime + comparisonOffset, 0)
      let actual = comparisonPlayer.currentTime().seconds
      if actual.isFinite, abs(actual - desired) > 0.12 {
        let tolerance = CMTime(seconds: max(frameDurationSeconds, 1.0 / 120.0), preferredTimescale: 60_000)
        comparisonPlayer.seek(
          to: CMTime(seconds: desired, preferredTimescale: 60_000),
          toleranceBefore: tolerance,
          toleranceAfter: tolerance
        )
      }
    }
  }

  private func cleanupPlayer() {
    if let timeObserver, let observedPlayer = player {
      observedPlayer.removeTimeObserver(timeObserver)
    }
    timeObserver = nil
    player?.pause()
    player = nil
    comparisonPlayer?.pause()
    comparisonPlayer = nil
    comparisonURL = nil
    isPlaying = false
  }
}
