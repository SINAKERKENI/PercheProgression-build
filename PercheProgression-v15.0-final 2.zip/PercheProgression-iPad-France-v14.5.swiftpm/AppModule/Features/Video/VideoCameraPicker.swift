import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct VideoCameraPicker: UIViewControllerRepresentable {
  @Environment(\.dismiss) private var dismiss
  let onCaptured: (URL) -> Void
  let onError: (Error) -> Void

  func makeCoordinator() -> Coordinator {
    Coordinator(parent: self)
  }

  func makeUIViewController(context: Context) -> UIImagePickerController {
    let picker = UIImagePickerController()
    picker.delegate = context.coordinator
    picker.sourceType = .camera
    picker.mediaTypes = [UTType.movie.identifier]
    picker.cameraCaptureMode = .video
    picker.videoQuality = .typeHigh
    picker.videoMaximumDuration = 90
    picker.allowsEditing = false
    return picker
  }

  func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

  final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    private let parent: VideoCameraPicker

    init(parent: VideoCameraPicker) {
      self.parent = parent
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
      parent.dismiss()
    }

    func imagePickerController(
      _ picker: UIImagePickerController,
      didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
    ) {
      guard let url = info[.mediaURL] as? URL else {
        parent.onError(CameraCaptureError.missingVideoURL)
        parent.dismiss()
        return
      }

      do {
        let stableURL = FileManager.default.temporaryDirectory
          .appendingPathComponent(UUID().uuidString)
          .appendingPathExtension(url.pathExtension.isEmpty ? "mov" : url.pathExtension)
        try FileManager.default.copyItem(at: url, to: stableURL)
        parent.onCaptured(stableURL)
      } catch {
        parent.onError(error)
      }
      parent.dismiss()
    }
  }

  enum CameraCaptureError: LocalizedError {
    case missingVideoURL

    var errorDescription: String? {
      "La caméra n’a pas fourni de fichier vidéo exploitable."
    }
  }
}
