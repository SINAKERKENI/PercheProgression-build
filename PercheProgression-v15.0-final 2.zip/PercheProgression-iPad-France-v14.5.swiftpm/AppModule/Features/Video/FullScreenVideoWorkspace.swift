import AVKit
import PencilKit
import SwiftUI

struct FullScreenVideoWorkspace: View {
  @ObservedObject var viewModel: VideoLabViewModel
  @Environment(\.dismiss) private var dismiss
  @State private var showComparisonControls = true
  @State private var chromeVisible = true
  @State private var chromeHideWorkItem: DispatchWorkItem?
  @State private var timelineInteracting = false
  @State private var pencilCanvas: PKCanvasView?

  var body: some View {
    ZStack {
      Color.black.ignoresSafeArea()

      GeometryReader { geometry in
        let videoRect = aspectFitRect(contentSize: viewModel.videoNaturalSize, in: geometry.size)

        ZStack {
          ZStack {
            if let player = viewModel.player {
              VideoPlayer(player: player)
                .disabled(true)
            }

            if viewModel.comparisonMode == .overlay,
              let comparisonPlayer = viewModel.comparisonPlayer
            {
              VideoPlayer(player: comparisonPlayer)
                .disabled(true)
                .rotationEffect(.degrees(viewModel.overlayTransform.rotationDegrees))
                .scaleEffect(
                  x: viewModel.overlayTransform.mirrorHorizontal ? -viewModel.overlayTransform.scale : viewModel.overlayTransform.scale,
                  y: viewModel.overlayTransform.mirrorVertical ? -viewModel.overlayTransform.scale : viewModel.overlayTransform.scale
                )
                .offset(
                  x: viewModel.overlayTransform.translationX,
                  y: viewModel.overlayTransform.translationY
                )
                .opacity(viewModel.overlayOpacity)
            }

            fullScreenAnalysisLayers
              .frame(width: videoRect.width, height: videoRect.height)
              .position(x: videoRect.midX, y: videoRect.midY)
          }
          .scaleEffect(viewModel.viewportTransform.scale)
          .rotationEffect(.radians(viewModel.viewportTransform.rotationRadians))
          .offset(viewModel.viewportTransform.translation)

          VideoGestureLayer(
            onPan: { delta in
              revealChrome()
              viewModel.viewportTransform.translation.width += delta.width
              viewModel.viewportTransform.translation.height += delta.height
            },
            onScale: { delta in
              revealChrome()
              viewModel.viewportTransform.applyScale(delta)
            },
            onRotation: { delta in
              revealChrome()
              viewModel.viewportTransform.rotationRadians += delta
            }
          )

          if chromeVisible {
            topChrome
              .transition(.opacity)
          }

          persistentTransport
        }
        .contentShape(Rectangle())
        .simultaneousGesture(
          TapGesture().onEnded { revealChrome() }
        )
        .clipped()
      }
    }
    .statusBarHidden(true)
    .onAppear { revealChrome(for: 3.0) }
    .onDisappear { chromeHideWorkItem?.cancel() }
  }

  private var topChrome: some View {
    VStack(spacing: 10) {
      topBar

      if viewModel.comparisonPlayer != nil,
        viewModel.comparisonMode == .overlay,
        showComparisonControls
      {
        comparisonControlBar
          .transition(.move(edge: .top).combined(with: .opacity))
      }

      Spacer()
    }
  }

  private var persistentTransport: some View {
    VStack(spacing: 12) {
      Spacer()

      InteractiveVideoTimeline(
        viewModel: viewModel,
        style: .fullscreen,
        height: 48,
        onInteractionChanged: timelineInteractionChanged
      )

      HStack(spacing: 10) {
        Button {
          revealChrome()
          viewModel.seek(toFrame: max(viewModel.currentFrameIndex - 1, 0), haptic: true)
        } label: {
          Label("-1 image", systemImage: "backward.frame")
        }

        Button {
          revealChrome()
          viewModel.playPause()
        } label: {
          Image(systemName: viewModel.isPlaying ? "pause.fill" : "play.fill")
            .font(.title2)
        }

        Button {
          revealChrome()
          viewModel.seek(
            toFrame: min(viewModel.currentFrameIndex + 1, viewModel.lastFrameIndex),
            haptic: true
          )
        } label: {
          Label("+1 image", systemImage: "forward.frame")
        }
      }
      .buttonStyle(.borderedProminent)
      .tint(.white.opacity(0.20))
      .foregroundStyle(.white)
    }
    .padding(.horizontal, 24)
    .padding(.bottom, 18)
  }

  private var fullScreenAnalysisLayers: some View {
    ZStack {
      VectorOverlayView(
        vectors: $viewModel.vectors,
        selectedVectorID: $viewModel.selectedVectorID,
        currentTime: viewModel.currentTime,
        frameRate: viewModel.frameRate,
        isDrawingEnabled: viewModel.tool == .vector,
        isSelectionEnabled: viewModel.tool == .select,
        selectedKind: viewModel.selectedVectorKind,
        onVectorCreated: viewModel.vectorWasCreated
      )

      CalibrationOverlayView(
        calibration: $viewModel.calibration,
        isActive: viewModel.tool == .scale
      )
      .opacity(viewModel.tool == .scale || viewModel.calibration.distanceMeters > 0 ? 1 : 0)

      BackgroundAnchorOverlayView(
        anchors: $viewModel.backgroundAnchors,
        isActive: viewModel.tool == .background
      )
      .opacity(viewModel.tool == .background || !viewModel.backgroundAnchors.isEmpty ? 1 : 0)

      DynamicRunwayGridOverlayView(
        editableGrid: $viewModel.runwayGrid,
        dynamicTrack: viewModel.dynamicCalibration,
        currentTime: viewModel.currentTime,
        isActive: viewModel.tool == .calibration,
        nearLineIsBoxOrigin: viewModel.physicalCameraMode != .fixedOblique
          || viewModel.fixedRunwayMetricOrigin == .box
      )
      .opacity(
        (viewModel.tool == .scale || viewModel.tool == .background)
          ? 0
          : (((viewModel.tool == .calibration && viewModel.isRunwayGridConfigured)
            || viewModel.dynamicCalibration != nil) ? 1 : 0)
      )

      TakeoffMeasurementOverlayView(
        pointValue: $viewModel.takeoffPoint,
        measurement: viewModel.takeoffMeasurement,
        isActive: viewModel.tool == .takeoff,
        onPointCommitted: viewModel.commitTakeoffPoint
      )

      MotionTrackingOverlayView(
        seed: $viewModel.trackingSeed,
        result: viewModel.motionResult,
        currentTime: viewModel.currentTime,
        isSelectionActive: viewModel.tool == .tracking && !viewModel.isPelvisValidationActive
      )

      PelvisCheckpointOverlayView(
        checkpoint: viewModel.currentPelvisCheckpoint,
        index: viewModel.pelvisCheckpointIndex,
        total: viewModel.pelvisCheckpointCount,
        isActive: viewModel.isPelvisValidationActive,
        onPointChanged: viewModel.setCurrentPelvisPoint
      )
      .opacity(viewModel.pelvisValidation == nil ? 0 : 1)

      PoseSkeletonOverlay(joints: viewModel.poseJoints)
        .allowsHitTesting(false)

      if viewModel.tool == .pose, !viewModel.poseCandidates.isEmpty {
        PoseCandidateSelectionOverlay(
          candidates: viewModel.poseCandidates,
          selectedID: viewModel.selectedAthleteCandidate?.id,
          onSelect: viewModel.selectPoseCandidate
        )
      }

      PencilCanvasView(
        drawing: $viewModel.pencilDrawing,
        canvasReference: $pencilCanvas,
        isActive: viewModel.tool == .freehand || viewModel.tool == .erase,
        isEraser: viewModel.tool == .erase
      )
    }
    .clipped()
  }

  private var topBar: some View {
    HStack(spacing: 10) {
      Button {
        dismiss()
      } label: {
        Label("Fermer", systemImage: "xmark")
          .font(.headline.weight(.bold))
          .padding(.horizontal, 14)
          .padding(.vertical, 10)
          .background(.ultraThinMaterial, in: Capsule())
      }
      .buttonStyle(.plain)
      .foregroundStyle(.white)

      Label(viewModel.tool.title, systemImage: viewModel.tool.symbol)
        .font(.caption.weight(.black))
        .foregroundStyle(.white)
        .padding(.horizontal, 11)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial, in: Capsule())

      Spacer()

      Text(viewModel.preciseTimecode)
        .font(.headline.monospacedDigit().weight(.black))
        .foregroundStyle(.white)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: Capsule())

      if viewModel.comparisonPlayer != nil, viewModel.comparisonMode == .overlay {
        Button {
          revealChrome()
          withAnimation(.spring(response: 0.28, dampingFraction: 0.84)) {
            showComparisonControls.toggle()
          }
        } label: {
          Label("Transparence", systemImage: "circle.lefthalf.filled")
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial, in: Capsule())
        }
        .buttonStyle(.plain)
        .foregroundStyle(.white)
      }

      Button {
        revealChrome()
        viewModel.resetViewport()
      } label: {
        Label("Réinitialiser vue", systemImage: "arrow.counterclockwise")
          .padding(.horizontal, 14)
          .padding(.vertical, 10)
          .background(.ultraThinMaterial, in: Capsule())
      }
      .buttonStyle(.plain)
      .foregroundStyle(.white)
    }
    .padding()
  }

  private var comparisonControlBar: some View {
    ViewThatFits(in: .horizontal) {
      HStack(spacing: 14) { comparisonControlsContent }
      VStack(alignment: .leading, spacing: 10) { comparisonControlsContent }
    }
    .padding(.horizontal, 16)
    .padding(.vertical, 11)
    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    .padding(.horizontal)
    .foregroundStyle(.white)
  }

  @ViewBuilder
  private var comparisonControlsContent: some View {
    HStack(spacing: 10) {
      Label("Transparence", systemImage: "circle.lefthalf.filled")
        .font(.subheadline.weight(.bold))

      Slider(
        value: Binding(
          get: { 1 - viewModel.overlayOpacity },
          set: {
            revealChrome()
            viewModel.overlayOpacity = 1 - min(max($0, 0), 0.95)
          }
        ),
        in: 0...0.95
      )
      .frame(minWidth: 160, idealWidth: 240, maxWidth: 320)
      .tint(.white)

      Text("\(Int(((1 - viewModel.overlayOpacity) * 100).rounded())) %")
        .font(.subheadline.monospacedDigit().weight(.black))
        .frame(width: 48, alignment: .trailing)
    }

    Button("50 %") {
      revealChrome()
      viewModel.overlayOpacity = 0.5
      Haptics.selection()
    }
    .buttonStyle(.bordered)
    .tint(.white)
  }

  private func timelineInteractionChanged(_ active: Bool) {
    timelineInteracting = active
    if active {
      chromeHideWorkItem?.cancel()
      chromeHideWorkItem = nil
      if !chromeVisible {
        withAnimation(.easeInOut(duration: 0.18)) { chromeVisible = true }
      }
    } else {
      // Only optional top chrome resumes its timer. The precision timeline never does.
      revealChrome(for: 2.6)
    }
  }

  private func revealChrome(for duration: TimeInterval = 2.6) {
    if !chromeVisible {
      withAnimation(.easeInOut(duration: 0.18)) {
        chromeVisible = true
      }
    }

    chromeHideWorkItem?.cancel()
    guard !timelineInteracting else { return }
    let workItem = DispatchWorkItem {
      guard !timelineInteracting else { return }
      withAnimation(.easeInOut(duration: 0.22)) {
        chromeVisible = false
      }
    }
    chromeHideWorkItem = workItem
    DispatchQueue.main.asyncAfter(deadline: .now() + duration, execute: workItem)
  }
}
