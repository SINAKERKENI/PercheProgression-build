import SwiftUI

struct VectorOverlayView: View {
  @Binding var vectors: [OverlayVector]
  @Binding var selectedVectorID: UUID?
  let currentTime: Double
  let frameRate: Double
  let isDrawingEnabled: Bool
  let isSelectionEnabled: Bool
  let selectedKind: VectorKind
  let onVectorCreated: () -> Void

  @State private var draftStart: NormalizedPoint?
  @State private var draftEnd: NormalizedPoint?

  private var visibleVectors: [OverlayVector] {
    let tolerance = max(1.5 / max(frameRate, 1), 0.045)
    return vectors.filter { abs($0.timeSeconds - currentTime) <= tolerance }
  }

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        ForEach(visibleVectors) { vector in
          vectorLayer(vector, in: geometry.size)
        }

        if let start = draftStart, let end = draftEnd {
          VectorShape(
            start: point(start, in: geometry.size),
            end: point(end, in: geometry.size)
          )
          .stroke(
            Color.vaultAnalysisAccent, style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isDrawingEnabled || isSelectionEnabled)
      .gesture(
        DragGesture(minimumDistance: 2)
          .onChanged { value in
            guard isDrawingEnabled else { return }
            if draftStart == nil {
              draftStart = normalized(value.startLocation, in: geometry.size)
            }
            draftEnd = normalized(value.location, in: geometry.size)
          }
          .onEnded { value in
            guard isDrawingEnabled, let start = draftStart else {
              draftStart = nil
              draftEnd = nil
              return
            }
            let end = normalized(value.location, in: geometry.size)
            let vector = OverlayVector(
              timeSeconds: currentTime,
              label: selectedKind.title,
              kind: selectedKind,
              start: start,
              end: end
            )
            vectors.append(vector)
            selectedVectorID = vector.id
            draftStart = nil
            draftEnd = nil
            Haptics.impact(.light)
            onVectorCreated()
          }
      , including: isDrawingEnabled ? .all : .none)
    }
  }

  @ViewBuilder
  private func vectorLayer(_ vector: OverlayVector, in size: CGSize) -> some View {
    let start = point(vector.start, in: size)
    let end = point(vector.end, in: size)
    let isSelected = vector.id == selectedVectorID

    ZStack {
      VectorShape(start: start, end: end)
        .stroke(
          vector.source == "ai" ? Color.vaultCyan : Color.vaultAnalysisAccent,
          style: StrokeStyle(lineWidth: isSelected ? 5 : 4, lineCap: .round, lineJoin: .round)
        )
        .shadow(color: Color.black.opacity(0.45), radius: 2)
        .onTapGesture {
          guard isSelectionEnabled || isDrawingEnabled else { return }
          selectedVectorID = vector.id
          Haptics.selection()
        }

      Text("\(vector.label) · \(Int(vector.angleDegrees.rounded()))°")
        .font(.caption2.monospacedDigit().weight(.black))
        .padding(.horizontal, 7)
        .padding(.vertical, 4)
        .background(.ultraThinMaterial, in: Capsule())
        .position(
          x: min(max(end.x + 48, 55), size.width - 55),
          y: min(max(end.y - 18, 16), size.height - 16))

      if isSelected && isSelectionEnabled {
        endpointHandle(for: vector.id, endpoint: .start, position: start, size: size)
        endpointHandle(for: vector.id, endpoint: .end, position: end, size: size)
      }
    }
  }

  private enum Endpoint { case start, end }

  private func endpointHandle(for id: UUID, endpoint: Endpoint, position: CGPoint, size: CGSize)
    -> some View
  {
    Circle()
      .fill(Color.white)
      .overlay(Circle().stroke(Color.vaultAnalysisAccent, lineWidth: 3))
      .frame(width: 22, height: 22)
      .position(position)
      .gesture(
        DragGesture(minimumDistance: 0)
          .onChanged { value in
            guard let index = vectors.firstIndex(where: { $0.id == id }) else { return }
            let point = normalized(value.location, in: size)
            switch endpoint {
            case .start: vectors[index].start = point
            case .end: vectors[index].end = point
            }
          }
          .onEnded { _ in Haptics.selection() }
      )
  }

  private func point(_ point: NormalizedPoint, in size: CGSize) -> CGPoint {
    CGPoint(x: point.x * size.width, y: point.y * size.height)
  }

  private func normalized(_ point: CGPoint, in size: CGSize) -> NormalizedPoint {
    guard size.width > 0, size.height > 0 else { return NormalizedPoint(x: 0, y: 0) }
    return NormalizedPoint(x: point.x / size.width, y: point.y / size.height).clamped()
  }
}

private struct VectorShape: Shape {
  let start: CGPoint
  let end: CGPoint

  func path(in rect: CGRect) -> Path {
    var path = Path()
    path.move(to: start)
    path.addLine(to: end)

    let angle = atan2(end.y - start.y, end.x - start.x)
    let arrowLength: CGFloat = 16
    let wingAngle: CGFloat = .pi / 6
    let firstWing = CGPoint(
      x: end.x - arrowLength * cos(angle - wingAngle),
      y: end.y - arrowLength * sin(angle - wingAngle)
    )
    let secondWing = CGPoint(
      x: end.x - arrowLength * cos(angle + wingAngle),
      y: end.y - arrowLength * sin(angle + wingAngle)
    )
    path.move(to: firstWing)
    path.addLine(to: end)
    path.addLine(to: secondWing)
    return path
  }
}

struct PoseSkeletonOverlay: View {
  let joints: [PoseJoint]

  private let connections: [(String, String)] = [
    ("nose", "neck"),
    ("neck", "leftShoulder"), ("leftShoulder", "leftElbow"), ("leftElbow", "leftWrist"),
    ("neck", "rightShoulder"), ("rightShoulder", "rightElbow"), ("rightElbow", "rightWrist"),
    ("neck", "root"),
    ("root", "leftHip"), ("leftHip", "leftKnee"), ("leftKnee", "leftAnkle"),
    ("root", "rightHip"), ("rightHip", "rightKnee"), ("rightKnee", "rightAnkle"),
  ]

  var body: some View {
    GeometryReader { geometry in
      let map = Dictionary(uniqueKeysWithValues: joints.map { ($0.id, $0) })
      Canvas { context, size in
        for connection in connections {
          guard let first = map[connection.0], let second = map[connection.1] else { continue }
          var path = Path()
          path.move(to: CGPoint(x: first.point.x * size.width, y: first.point.y * size.height))
          path.addLine(to: CGPoint(x: second.point.x * size.width, y: second.point.y * size.height))
          context.stroke(path, with: .color(Color.vaultCyan), lineWidth: 3)
        }

        for joint in joints {
          let point = CGPoint(x: joint.point.x * size.width, y: joint.point.y * size.height)
          let rect = CGRect(x: point.x - 4.5, y: point.y - 4.5, width: 9, height: 9)
          context.fill(Path(ellipseIn: rect), with: .color(Color.white))
          context.stroke(Path(ellipseIn: rect), with: .color(Color.vaultCyan), lineWidth: 2)
        }
      }
    }
    .allowsHitTesting(false)
  }
}

struct PoseCandidateSelectionOverlay: View {
  let candidates: [PoseCandidate]
  let selectedID: UUID?
  let onSelect: (UUID) -> Void

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        ForEach(Array(candidates.enumerated()), id: \.element.id) { index, candidate in
          let box = candidate.boundingBox
          let rect = CGRect(
            x: box.x * geometry.size.width,
            y: box.y * geometry.size.height,
            width: box.width * geometry.size.width,
            height: box.height * geometry.size.height
          )
          let isSelected = candidate.id == selectedID

          Button {
            onSelect(candidate.id)
          } label: {
            ZStack(alignment: .topLeading) {
              RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(isSelected ? Color.vaultAnalysisAccent.opacity(0.13) : Color.black.opacity(0.08))
              RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(
                  isSelected ? Color.vaultAnalysisAccent : Color.white,
                  style: StrokeStyle(lineWidth: isSelected ? 4 : 2, dash: isSelected ? [] : [7, 5])
                )
              Text("\(index + 1)")
                .font(.headline.monospacedDigit().weight(.black))
                .foregroundStyle(Color.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(isSelected ? Color.vaultAnalysisAccent : Color.black.opacity(0.72), in: Capsule())
                .padding(8)
            }
          }
          .buttonStyle(.plain)
          .frame(width: rect.width, height: rect.height)
          .position(x: rect.midX, y: rect.midY)
          .accessibilityLabel("Sujet \(index + 1)")
          .accessibilityHint("Sélectionner ce sujet comme perchiste")
        }
      }
    }
  }
}
