import SwiftUI

func aspectFitRect(contentSize: CGSize, in bounds: CGSize) -> CGRect {
  guard contentSize.width > 0, contentSize.height > 0, bounds.width > 0, bounds.height > 0 else {
    return CGRect(origin: .zero, size: bounds)
  }
  let scale = min(bounds.width / contentSize.width, bounds.height / contentSize.height)
  let size = CGSize(width: contentSize.width * scale, height: contentSize.height * scale)
  return CGRect(
    x: (bounds.width - size.width) / 2,
    y: (bounds.height - size.height) / 2,
    width: size.width,
    height: size.height
  )
}

struct CalibrationOverlayView: View {
  @Binding var calibration: VideoCalibration
  let isActive: Bool

  @State private var draftStart: NormalizedPoint?

  var body: some View {
    GeometryReader { geometry in
      let start = point(calibration.start, in: geometry.size)
      let end = point(calibration.end, in: geometry.size)

      ZStack {
        Canvas { context, _ in
          var line = Path()
          line.move(to: start)
          line.addLine(to: end)
          context.stroke(
            line,
            with: .color(Color.vaultCyan),
            style: StrokeStyle(lineWidth: 1.4, lineCap: .round, dash: [7, 6])
          )

        }
        .allowsHitTesting(false)

        Text(String(format: "%.2f m", calibration.distanceMeters))
          .font(.caption.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultText)
          .padding(.horizontal, 8)
          .padding(.vertical, 5)
          .background(Color.white.opacity(0.92), in: Capsule())
          .position(
            x: (start.x + end.x) / 2,
            y: max((start.y + end.y) / 2 - 20, 16)
          )
          .allowsHitTesting(false)

        if isActive {
          calibrationHandle(endpoint: .start, position: start, size: geometry.size)
          calibrationHandle(endpoint: .end, position: end, size: geometry.size)
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isActive)
      .gesture(
        DragGesture(minimumDistance: 2)
          .onChanged { value in
            if draftStart == nil {
              draftStart = normalized(value.startLocation, in: geometry.size)
              calibration.start = draftStart ?? calibration.start
            }
            calibration.end = normalized(value.location, in: geometry.size)
          }
          .onEnded { _ in
            draftStart = nil
            Haptics.impact(.light)
          }
      )
    }
  }

  private enum Endpoint { case start, end }

  private func calibrationHandle(
    endpoint: Endpoint,
    position: CGPoint,
    size: CGSize
  ) -> some View {
    ZStack {
      Circle()
        .fill(Color.clear)
        .frame(width: 72, height: 72)
        .contentShape(Circle())
      Circle()
        .fill(Color.white.opacity(0.20))
        .frame(width: 28, height: 28)
      Circle()
        .stroke(Color.white, lineWidth: 2.2)
        .frame(width: 28, height: 28)
      Circle()
        .stroke(Color.vaultCyan, lineWidth: 1.3)
        .frame(width: 28, height: 28)
      Rectangle().fill(Color.vaultCyan).frame(width: 1, height: 17)
      Rectangle().fill(Color.vaultCyan).frame(width: 17, height: 1)
      Circle().fill(Color.white).frame(width: 4, height: 4)
    }
    .frame(width: 72, height: 72)
    .position(position)
    .gesture(
      DragGesture(minimumDistance: 0)
        .onChanged { value in
          let next = normalized(value.location, in: size)
          switch endpoint {
          case .start: calibration.start = next
          case .end: calibration.end = next
          }
        }
        .onEnded { _ in Haptics.selection() }
    )
  }

  private func point(_ point: NormalizedPoint, in size: CGSize) -> CGPoint {
    CGPoint(x: point.x * size.width, y: point.y * size.height)
  }

  private func normalized(_ point: CGPoint, in size: CGSize) -> NormalizedPoint {
    guard size.width > 0, size.height > 0 else { return .init(x: 0, y: 0) }
    return NormalizedPoint(x: point.x / size.width, y: point.y / size.height).clamped()
  }
}

struct MotionTrackingOverlayView: View {
  @Binding var seed: NormalizedPoint?
  let result: MotionAnalysisResult?
  let currentTime: Double
  let isSelectionActive: Bool

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        if let result {
          Canvas { context, size in
            var trajectory = Path()
            for (index, sample) in result.samples.enumerated() {
              let p = point(sample.point, in: size)
              if index == 0 { trajectory.move(to: p) } else { trajectory.addLine(to: p) }
            }
            context.stroke(
              trajectory,
              with: .color(Color.vaultCyan.opacity(0.86)),
              style: StrokeStyle(lineWidth: 1.4, lineCap: .round, lineJoin: .round)
            )
          }
          .allowsHitTesting(false)

          if let sample = result.sample(nearest: currentTime) {
            trackedMarker(
              at: point(sample.point, in: geometry.size),
              confidence: sample.confidence,
              label: String(format: "%.2f m/s", abs(sample.horizontalVelocity))
            )
          }
        } else if let seed {
          trackedMarker(
            at: point(seed, in: geometry.size),
            confidence: 1,
            label: "Point de suivi"
          )
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isSelectionActive)
      .gesture(
        DragGesture(minimumDistance: 0)
          .onChanged { value in
            guard isSelectionActive else { return }
            seed = normalized(value.location, in: geometry.size)
          }
          .onEnded { _ in Haptics.impact(.light) }
      )
    }
  }

  private func trackedMarker(at position: CGPoint, confidence: Double, label: String) -> some View {
    ZStack {
      Circle()
        .fill(Color.white.opacity(0.10))
        .frame(width: 34, height: 34)
      Circle()
        .stroke(Color.white, lineWidth: 2.4)
        .frame(width: 34, height: 34)
      Circle()
        .stroke(Color.vaultAnalysisAccent, lineWidth: 1.4)
        .frame(width: 34, height: 34)
      Rectangle()
        .fill(Color.vaultAnalysisAccent)
        .frame(width: 1, height: 20)
      Rectangle()
        .fill(Color.vaultAnalysisAccent)
        .frame(width: 20, height: 1)
      Circle()
        .fill(Color.white)
        .frame(width: 5, height: 5)
        .overlay(Circle().stroke(Color.vaultAnalysisAccent, lineWidth: 1))
      Text(label)
        .font(.caption.monospacedDigit().weight(.black))
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial, in: Capsule())
        .offset(y: -34)
    }
    .opacity(max(confidence, 0.35))
    .position(position)
  }

  private func point(_ point: NormalizedPoint, in size: CGSize) -> CGPoint {
    CGPoint(x: point.x * size.width, y: point.y * size.height)
  }

  private func normalized(_ point: CGPoint, in size: CGSize) -> NormalizedPoint {
    guard size.width > 0, size.height > 0 else { return .init(x: 0, y: 0) }
    return NormalizedPoint(x: point.x / size.width, y: point.y / size.height).clamped()
  }
}

/// Repère guidé utilisé pendant la validation manuelle du bassin à 10 Hz.
/// Le cercle pointillé représente la suggestion automatique ; le repère plein est
/// la position retenue par l'utilisateur pour l'image courante.
struct PelvisCheckpointOverlayView: View {
  let checkpoint: PelvisCheckpoint?
  let index: Int
  let total: Int
  let isActive: Bool
  let onPointChanged: (NormalizedPoint) -> Void

  var body: some View {
    GeometryReader { geometry in
      if let checkpoint {
        let suggested = point(checkpoint.suggestedPoint, in: geometry.size)
        let chosenPoint = checkpoint.confirmedPoint ?? checkpoint.suggestedPoint
        let chosen = point(chosenPoint, in: geometry.size)

        ZStack {
          if checkpoint.confirmedPoint != nil {
            Path { path in
              path.move(to: suggested)
              path.addLine(to: chosen)
            }
            .stroke(
              Color.vaultAnalysisMarker.opacity(0.8),
              style: StrokeStyle(lineWidth: 2, lineCap: .round, dash: [6, 5])
            )
          }

          ZStack {
            Circle()
              .stroke(Color.white.opacity(0.95), style: StrokeStyle(lineWidth: 5, dash: [7, 5]))
              .frame(width: 38, height: 38)
            Circle()
              .stroke(Color.vaultAnalysisMarker, style: StrokeStyle(lineWidth: 2.5, dash: [7, 5]))
              .frame(width: 38, height: 38)
          }
          .position(suggested)
          .allowsHitTesting(false)

          ZStack {
            Circle()
              .fill(Color.white.opacity(0.96))
              .frame(width: 42, height: 42)
            Circle()
              .stroke(Color.vaultAnalysisAccent, lineWidth: 4)
              .frame(width: 42, height: 42)
            Circle()
              .fill(Color.vaultAnalysisAccent)
              .frame(width: 10, height: 10)
            Text("Bassin · \(index + 1)/\(max(total, 1))")
              .font(.caption2.monospacedDigit().weight(.black))
              .foregroundStyle(Color.vaultText)
              .padding(.horizontal, 9)
              .padding(.vertical, 6)
              .background(.ultraThinMaterial, in: Capsule())
              .offset(y: -39)
          }
          .position(chosen)
          .shadow(color: Color.black.opacity(0.24), radius: 4, y: 2)
        }
        .contentShape(Rectangle())
        .allowsHitTesting(isActive)
        .gesture(
          DragGesture(minimumDistance: 0)
            .onChanged { value in
              guard isActive else { return }
              onPointChanged(normalized(value.location, in: geometry.size))
            }
            .onEnded { _ in Haptics.selection() }
        )
      }
    }
  }

  private func point(_ point: NormalizedPoint, in size: CGSize) -> CGPoint {
    CGPoint(x: point.x * size.width, y: point.y * size.height)
  }

  private func normalized(_ point: CGPoint, in size: CGSize) -> NormalizedPoint {
    guard size.width > 0, size.height > 0 else { return .init(x: 0.5, y: 0.5) }
    return NormalizedPoint(x: point.x / size.width, y: point.y / size.height).clamped()
  }
}

struct BackgroundAnchorOverlayView: View {
  @Binding var anchors: [NormalizedPoint]
  let isActive: Bool

  var body: some View {
    GeometryReader { geometry in
      ZStack {
        if anchors.count >= 2 {
          Canvas { context, size in
            var path = Path()
            for (index, anchor) in anchors.enumerated() {
              let point = CGPoint(x: anchor.x * size.width, y: anchor.y * size.height)
              if index == 0 { path.move(to: point) } else { path.addLine(to: point) }
            }
            context.stroke(
              path,
              with: .color(Color.vaultAnalysisMarker.opacity(0.72)),
              style: StrokeStyle(lineWidth: 2, lineCap: .round, dash: [7, 6])
            )
          }
          .allowsHitTesting(false)
        }

        ForEach(Array(anchors.enumerated()), id: \.offset) { index, anchor in
          anchorHandle(index: index, anchor: anchor, size: geometry.size)
        }
      }
      .contentShape(Rectangle())
      .allowsHitTesting(isActive)
      .onTapGesture { location in
        guard isActive, anchors.count < 4,
          geometry.size.width > 0, geometry.size.height > 0
        else { return }
        anchors.append(
          NormalizedPoint(
            x: location.x / geometry.size.width,
            y: location.y / geometry.size.height
          ).clamped()
        )
        Haptics.selection()
      }
    }
  }

  private func anchorHandle(
    index: Int,
    anchor: NormalizedPoint,
    size: CGSize
  ) -> some View {
    ZStack {
      Circle()
        .fill(Color.white)
        .overlay(Circle().stroke(Color.vaultAnalysisMarker, lineWidth: 3))
        .frame(width: 34, height: 34)
      Text(String(index + 1))
        .font(.caption2.monospacedDigit().weight(.black))
        .foregroundStyle(Color.vaultText)
    }
    .position(x: anchor.x * size.width, y: anchor.y * size.height)
    .gesture(
      DragGesture(minimumDistance: 0)
        .onChanged { value in
          guard anchors.indices.contains(index), size.width > 0, size.height > 0 else { return }
          anchors[index] = NormalizedPoint(
            x: value.location.x / size.width,
            y: value.location.y / size.height
          ).clamped()
        }
        .onEnded { _ in Haptics.selection() }
    )
    .contextMenu {
      Button(role: .destructive) {
        guard anchors.indices.contains(index) else { return }
        anchors.remove(at: index)
      } label: {
        Label("Retirer ce repère", systemImage: "trash")
      }
    }
  }
}
