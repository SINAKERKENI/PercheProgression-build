
import CoreGraphics
import Foundation

struct VideoViewportTransform: Equatable {
  var scale: CGFloat = 1
  var translation: CGSize = .zero
  var rotationRadians: CGFloat = 0

  mutating func applyScale(_ delta: CGFloat) {
    scale = min(max(scale * delta, 1), 12)
  }

  mutating func reset() {
    self = VideoViewportTransform()
  }
}

struct OverlayVideoTransform: Codable, Equatable {
  var rotationDegrees: Double = 0
  var mirrorHorizontal = false
  var mirrorVertical = false
  var scale: Double = 1
  var translationX: Double = 0
  var translationY: Double = 0
  var opacity: Double = 0.5

  mutating func applyScale(_ delta: CGFloat) {
    scale = min(max(scale * Double(delta), 0.2), 6)
  }

  mutating func applyPan(_ delta: CGSize) {
    translationX += Double(delta.width)
    translationY += Double(delta.height)
  }

  mutating func applyRotation(_ radians: CGFloat) {
    rotationDegrees += Double(radians) * 180 / .pi
  }
}


/// Pure PTS utilities used by comparison playback and unit tests. A "frame" means an
/// adjacent presentation timestamp from the corresponding media, never nominal FPS.
struct VideoTimelineAlignment {
  static func nearestIndex(to time: Double, in timestamps: [Double]) -> Int? {
    guard !timestamps.isEmpty else { return nil }
    var low = 0
    var high = timestamps.count
    while low < high {
      let mid = (low + high) / 2
      if timestamps[mid] < time { low = mid + 1 } else { high = mid }
    }
    if low == 0 { return 0 }
    if low >= timestamps.count { return timestamps.count - 1 }
    return abs(timestamps[low] - time) < abs(timestamps[low - 1] - time) ? low : low - 1
  }

  static func adjacentTimestamp(
    from time: Double,
    step: Int,
    timestamps: [Double]
  ) -> Double? {
    guard let current = nearestIndex(to: time, in: timestamps), !timestamps.isEmpty else { return nil }
    let target = min(max(current + step, 0), timestamps.count - 1)
    return timestamps[target]
  }

  static func offset(primaryTime: Double, referenceTime: Double) -> Double {
    referenceTime - primaryTime
  }
}
