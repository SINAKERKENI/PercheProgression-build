import Foundation
import SwiftUI

struct PrecisionVideoTransportView: View {
  @ObservedObject var viewModel: VideoLabViewModel
  let saveAction: () -> Void

  @State private var visibleWindowSeconds: Double = 1.0
  @State private var dragStartFrame: Int?
  @State private var directFrameText = ""
  @FocusState private var directFrameFocused: Bool

  private let speedOptions: [Float] = [0.25, 0.5, 1.0, 1.5, 2.0]

  var body: some View {
    VStack(spacing: 18) {
      statusHeader
      fullTimeline
      precisionRuler
      transportButtons
    }
    .vaultCard()
    .onAppear { directFrameText = String(viewModel.currentFrameIndex + 1) }
    .onChange(of: viewModel.currentFrameIndex) { _, value in
      guard !directFrameFocused else { return }
      directFrameText = String(value + 1)
    }
  }

  private var statusHeader: some View {
    ViewThatFits(in: .horizontal) {
      HStack(spacing: 12) { statusMetrics; Spacer(); precisionSettings }
      VStack(alignment: .leading, spacing: 12) { statusMetrics; precisionSettings }
    }
  }

  private var statusMetrics: some View {
    HStack(spacing: 10) {
      MetricPill(title: "Timecode", value: viewModel.preciseTimecode)
      MetricPill(title: "Image", value: "\(viewModel.currentFrameIndex + 1) / \(viewModel.frameCount)")
      MetricPill(
        title: "Pas temporel",
        value: String(format: "%.4f s", viewModel.frameDurationSeconds),
        tint: .vaultCyan
      )
    }
  }

  private var precisionSettings: some View {
    HStack(spacing: 12) {
      Picker("Fenêtre de précision", selection: $visibleWindowSeconds) {
        Text("±0,25 s").tag(0.5)
        Text("±0,50 s").tag(1.0)
        Text("±1,00 s").tag(2.0)
        Text("±2,00 s").tag(4.0)
      }
      .pickerStyle(.menu)

      Menu {
        ForEach(speedOptions, id: \.self) { rate in
          Button {
            viewModel.setPlaybackRate(rate)
          } label: {
            if abs(viewModel.playbackRate - rate) < 0.01 {
              Label(String(format: "%.2g×", rate), systemImage: "checkmark")
            } else {
              Text(String(format: "%.2g×", rate))
            }
          }
        }
      } label: {
        Label(String(format: "%.2g×", viewModel.playbackRate), systemImage: "speedometer")
      }
      .buttonStyle(.bordered)

      HStack(spacing: 6) {
        TextField("Image", text: $directFrameText)
          .keyboardType(.numberPad)
          .textFieldStyle(.roundedBorder)
          .font(.body.monospacedDigit())
          .frame(width: 92)
          .focused($directFrameFocused)
          .onSubmit { seekFromTextField() }

        Button("Aller") { seekFromTextField() }
          .buttonStyle(.bordered)
      }
    }
  }

  private var fullTimeline: some View {
    VStack(alignment: .leading, spacing: 8) {
      HStack {
        Label("Timeline complète", systemImage: "timeline.selection")
          .font(.subheadline.weight(.bold))
        Spacer()
        Text(String(format: "%.3f s / %.3f s", viewModel.currentTime, viewModel.duration))
          .font(.caption.monospacedDigit().weight(.semibold))
          .foregroundStyle(Color.vaultMuted)
      }

      InteractiveVideoTimeline(
        viewModel: viewModel,
        style: .panel,
        height: 54
      )
    }
  }

  private var precisionRuler: some View {
    VStack(alignment: .leading, spacing: 8) {
      HStack {
        Label("Loupe image par image", systemImage: "viewfinder")
          .font(.subheadline.weight(.bold))
        Spacer()
        Text("Glissez la règle sous le repère central")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }

      GeometryReader { geometry in
        let visibleFrames = max(Int((visibleWindowSeconds * viewModel.frameRate).rounded()), 12)
        let pixelsPerFrame = max(geometry.size.width / CGFloat(visibleFrames), 2)

        ZStack {
          RoundedRectangle(cornerRadius: 16, style: .continuous)
            .fill(Color.vaultPanelRaised)

          Canvas { context, size in
            let centerX = size.width / 2
            let halfCount = Int(ceil(size.width / pixelsPerFrame / 2)) + 2
            let tenthSecondFrames = max(Int((viewModel.frameRate / 10).rounded()), 1)
            let secondFrames = max(Int(viewModel.frameRate.rounded()), 1)

            for offset in (-halfCount)...halfCount {
              let frame = viewModel.currentFrameIndex + offset
              guard frame >= 0, frame <= viewModel.lastFrameIndex else { continue }

              let x = centerX + CGFloat(offset) * pixelsPerFrame
              let isSecond = frame % secondFrames == 0
              let isTenth = frame % tenthSecondFrames == 0
              let height: CGFloat = isSecond ? 42 : (isTenth ? 28 : 16)
              let lineWidth: CGFloat = isSecond ? 2.2 : 1
              let color = isSecond ? Color.vaultAnalysisAccent : Color.vaultMuted.opacity(isTenth ? 0.65 : 0.35)

              var path = Path()
              path.move(to: CGPoint(x: x, y: size.height - 12))
              path.addLine(to: CGPoint(x: x, y: size.height - 12 - height))
              context.stroke(path, with: .color(color), lineWidth: lineWidth)
            }
          }
          .allowsHitTesting(false)

          Rectangle()
            .fill(Color.vaultAnalysisAccent)
            .frame(width: 3)
            .padding(.vertical, 8)
            .allowsHitTesting(false)

          VStack(spacing: 2) {
            Text(viewModel.preciseTimecode)
              .font(.headline.monospacedDigit().weight(.black))
            Text("Image \(viewModel.currentFrameIndex + 1)")
              .font(.caption.monospacedDigit().weight(.bold))
              .foregroundStyle(Color.vaultMuted)
          }
          .padding(.horizontal, 12)
          .padding(.vertical, 7)
          .background(.ultraThinMaterial, in: Capsule())
          .offset(y: -24)
          .allowsHitTesting(false)
        }
        .contentShape(Rectangle())
        .gesture(
          DragGesture(minimumDistance: 0)
            .onChanged { value in
              if dragStartFrame == nil {
                dragStartFrame = viewModel.currentFrameIndex
                viewModel.pausePlayback()
              }
              guard let dragStartFrame else { return }
              let delta = Int((-value.translation.width / pixelsPerFrame).rounded())
              viewModel.seek(toFrame: dragStartFrame + delta)
            }
            .onEnded { _ in
              dragStartFrame = nil
              Haptics.selection()
            }
        )
      }
      .frame(height: 118)
    }
  }

  private var transportButtons: some View {
    ViewThatFits(in: .horizontal) {
      HStack(spacing: 10) { transportButtonRow; Spacer(); saveButton }
      VStack(spacing: 12) { transportButtonRow; saveButton }
    }
  }

  private var transportButtonRow: some View {
    HStack(spacing: 8) {
      iconButton("Repère précédent", symbol: "backward.end.fill") {
        viewModel.jumpToPreviousAnalysisMoment()
      }
      iconButton("-0,1 seconde", symbol: "gobackward.10") {
        viewModel.jump(seconds: -0.1)
      }
      frameButton(-10)
      frameButton(-1, emphasized: true)

      Button { viewModel.playPause() } label: {
        Image(systemName: viewModel.isPlaying ? "pause.fill" : "play.fill")
          .font(.title2.weight(.black))
          .frame(width: 62, height: 50)
          .background(Color.vaultAnalysisAccent, in: Capsule())
          .foregroundStyle(Color.white)
      }
      .buttonStyle(.plain)
      .accessibilityLabel(viewModel.isPlaying ? "Pause" : "Lecture")

      frameButton(1, emphasized: true)
      frameButton(10)
      iconButton("+0,1 seconde", symbol: "goforward.10") {
        viewModel.jump(seconds: 0.1)
      }
      iconButton("Repère suivant", symbol: "forward.end.fill") {
        viewModel.jumpToNextAnalysisMoment()
      }
    }
  }

  private var saveButton: some View {
    Button(action: saveAction) {
      Label("Enregistrer l’analyse", systemImage: "square.and.arrow.down")
    }
    .buttonStyle(.borderedProminent)
    .tint(.vaultAnalysisAccent)
  }

  private func frameButton(_ delta: Int, emphasized: Bool = false) -> some View {
    Button {
      viewModel.step(frames: delta)
    } label: {
      VStack(spacing: 1) {
        Image(systemName: delta < 0 ? "chevron.left" : "chevron.right")
          .font(.headline.weight(.black))
        Text(delta == -1 || delta == 1 ? "1 img" : "\(abs(delta)) img")
          .font(.caption2.monospacedDigit().weight(.bold))
      }
      .frame(width: emphasized ? 60 : 56, height: 48)
      .foregroundStyle(emphasized ? Color.white : Color.vaultText)
      .background(
        emphasized ? Color.vaultCyan : Color.vaultPanelRaised,
        in: RoundedRectangle(cornerRadius: 14, style: .continuous)
      )
    }
    .buttonStyle(.plain)
    .disabled(
      delta < 0 ? viewModel.currentFrameIndex == 0 : viewModel.currentFrameIndex >= viewModel.lastFrameIndex
    )
    .accessibilityLabel(delta < 0 ? "Reculer de \(abs(delta)) image(s)" : "Avancer de \(delta) image(s)")
  }

  private func iconButton(_ title: String, symbol: String, action: @escaping () -> Void) -> some View {
    Button(action: action) {
      Image(systemName: symbol)
        .font(.headline.weight(.bold))
        .frame(width: 42, height: 42)
    }
    .buttonStyle(.bordered)
    .accessibilityLabel(title)
  }

  private func seekFromTextField() {
    guard let displayedFrame = Int(directFrameText) else {
      directFrameText = String(viewModel.currentFrameIndex + 1)
      return
    }
    viewModel.seek(toFrame: displayedFrame - 1, haptic: true)
    directFrameText = String(viewModel.currentFrameIndex + 1)
    directFrameFocused = false
  }
}
