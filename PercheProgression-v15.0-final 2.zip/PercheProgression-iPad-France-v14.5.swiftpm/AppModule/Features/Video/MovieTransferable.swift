import CoreTransferable
import Foundation
import UniformTypeIdentifiers

struct MovieTransferable: Transferable {
  let url: URL

  static var transferRepresentation: some TransferRepresentation {
    FileRepresentation(contentType: .movie) { movie in
      SentTransferredFile(movie.url)
    } importing: { received in
      let destination = FileManager.default.temporaryDirectory
        .appendingPathComponent(UUID().uuidString)
        .appendingPathExtension(
          received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension)
      if FileManager.default.fileExists(atPath: destination.path) {
        try FileManager.default.removeItem(at: destination)
      }
      try FileManager.default.copyItem(at: received.file, to: destination)
      return MovieTransferable(url: destination)
    }
  }
}
