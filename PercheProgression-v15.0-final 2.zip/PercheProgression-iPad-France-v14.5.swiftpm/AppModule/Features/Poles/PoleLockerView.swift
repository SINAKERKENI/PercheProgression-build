import SwiftData
import SwiftUI

struct PoleLockerView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Query(sort: \PoleRecord.progressionOrder) private var poles: [PoleRecord]
  @Query(sort: \PoleApproachProgressRecord.updatedAt, order: .reverse) private var progress:
    [PoleApproachProgressRecord]
  @Query(sort: \AttemptRecord.createdAt, order: .reverse) private var attempts: [AttemptRecord]
  @Query private var profiles: [AthleteProfile]
  @Query(sort: \PoleRecommendationDecisionRecord.createdAt, order: .reverse) private var recommendationDecisions: [PoleRecommendationDecisionRecord]

  @State private var showingAddPole = false
  @State private var editingPole: PoleRecord?
  @State private var showingApproachEditor = false

  private var athlete: AthleteProfile? { appState.athlete(in: profiles) }

  /// Every recommendation and progression state must be isolated to the active athlete.
  /// The backing @Query collections can contain several profiles in the same SwiftData store.
  private var scopedPoles: [PoleRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return poles.filter { $0.athleteID == athleteID }
  }

  private var scopedProgress: [PoleApproachProgressRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return progress.filter { $0.athleteID == athleteID }
  }

  private var scopedAttempts: [AttemptRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return attempts.filter { $0.athleteID == athleteID && $0.deletedAt == nil }
  }

  private var currentPole: PoleRecord? {
    if let id = appState.selectedPoleID,
      let selected = scopedPoles.first(where: { $0.id == id })
    {
      return selected
    }
    // The most recently used pole on this approach is a stronger source of truth than rack order.
    if let recentPoleID = scopedAttempts
      .filter({ $0.approachSteps == appState.selectedApproach.rawValue })
      .sorted(by: { $0.createdAt > $1.createdAt })
      .first?.poleID,
      let recent = scopedPoles.first(where: { $0.id == recentPoleID }) {
      return recent
    }
    if let successful = scopedProgress
      .filter({ $0.approachSteps == appState.selectedApproach.rawValue && $0.state >= .successful })
      .sorted(by: { $0.updatedAt > $1.updatedAt })
      .first,
      let pole = scopedPoles.first(where: { $0.id == successful.poleID }) {
      return pole
    }
    return scopedPoles.first(where: \.isActive)
  }

  private var recommendation: PoleRecommendation? {
    guard let currentPole else { return nil }
    let input = PoleRecommendationEngine.Input(
      currentPoleID: currentPole.id,
      approach: appState.selectedApproach,
      poles: scopedPoles.filter(\.isActive).map(\.snapshot),
      progress: scopedProgress.map(\.snapshot),
      recentAttempts: scopedAttempts.map(\.snapshot),
      athlete: PoleAthleteContext(
        bodyWeightKG: athlete?.bodyWeightKG ?? 0,
        heightCM: athlete?.heightCM ?? 0,
        officialPRCM: athlete?.currentPRCM ?? 0,
        trainingPRCM: athlete?.trainingPRCM ?? 0,
        targetHeightCM: athlete?.targetHeightCM ?? 0
      )
    )
    return PoleRecommendationEngine().recommend(input)
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        HStack(alignment: .top) {
          VaultScreenHeader(
            title: "Râtelier de perches",
            subtitle: "La progression est évaluée séparément pour chaque nombre de foulées.",
            symbol: "line.diagonal"
          )
          Spacer()
          Button {
            showingAddPole = true
          } label: {
            Label("Ajouter une perche", systemImage: "plus")
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAccent)
        }

        HStack {
          VStack(alignment: .leading, spacing: 10) {
            SectionEyebrow(text: "Gamme selon le nombre de foulées")
            ScrollView(.horizontal, showsIndicators: false) {
              ApproachPicker(
                selection: Binding(
                  get: { appState.selectedApproach },
                  set: { appState.selectedApproach = $0 }
                ))
            }
          }
          Spacer()
          Button {
            showingApproachEditor = true
          } label: {
            Label("Marques d’élan", systemImage: "ruler")
          }
          .buttonStyle(.bordered)
        }
        .vaultCard()

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            poleList
              .frame(maxWidth: .infinity)
            recommendationColumn
              .frame(width: 360)
          }
          VStack(spacing: VaultSpacing.large) {
            poleList
            recommendationColumn
          }
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .sheet(isPresented: $showingAddPole) {
      if let athlete {
        PoleEditorView(
          athleteID: athlete.id, nextOrder: (scopedPoles.map(\.progressionOrder).max() ?? -1) + 1)
      }
    }
    .sheet(item: $editingPole) { pole in
      if let athlete {
        PoleEditorView(athleteID: athlete.id, pole: pole, nextOrder: pole.progressionOrder)
      }
    }
    .sheet(isPresented: $showingApproachEditor) {
      if let athlete {
        ApproachProfileEditorView(athleteID: athlete.id, approach: appState.selectedApproach)
      }
    }
  }

  private var poleList: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Progression de perches")
        Spacer()
        Text("\(scopedPoles.filter(\.isActive).count) perches actives")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }

      ForEach(scopedPoles.filter(\.isActive)) { pole in
        let record = scopedProgress.first {
          $0.poleID == pole.id && $0.approachSteps == appState.selectedApproach.rawValue
        }
        PoleLockerCard(
          pole: pole,
          progress: record,
          selected: currentPole?.id == pole.id,
          selectAction: {
            appState.selectedPoleID = pole.id
            Haptics.selection()
          },
          editAction: { editingPole = pole },
          updateState: { newState in
            setState(newState, pole: pole, existing: record)
          }
        )
      }

      if scopedPoles.filter(\.isActive).isEmpty {
        EmptyStateView(
          symbol: "line.diagonal",
          title: "Aucune perche enregistrée",
          message: "Ajoutez votre première perche puis construisez une gamme différente pour chaque nombre de foulées."
        )
      }
    }
  }

  private var recommendationColumn: some View {
    VStack(spacing: VaultSpacing.medium) {
      nextPoleCard
      masteryLegend
      equipmentSafetyCard
    }
  }

  private var nextPoleCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack {
        SectionEyebrow(text: "Décision matériel proposée")
        Spacer()
        Image(systemName: "sparkles")
          .foregroundStyle(Color.vaultAccent)
      }

      if let recommendation {
        Text(recommendation.pole.displayName)
          .font(.title2.monospacedDigit().weight(.black))
        Text("\(recommendation.pole.manufacturer) \(recommendation.pole.model)")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)

        Label(recommendation.direction.title, systemImage: recommendation.direction == .stay ? "pause.circle.fill" : "arrow.triangle.swap")
          .font(.headline.weight(.bold))
          .foregroundStyle(Color.vaultAccent)
        Text(recommendation.evaluation.transitionDescription)
          .font(.caption.monospacedDigit())
          .foregroundStyle(Color.vaultMuted)

        HStack(spacing: 10) {
          confidenceBadge(recommendation.confidence)
          Text("PRÉPARATION \(Int((recommendation.readinessScore * 100).rounded()))/100")
            .font(.caption2.monospacedDigit().weight(.black))
            .tracking(0.6)
            .foregroundStyle(Color.vaultCyan)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.vaultCyan.opacity(0.10), in: Capsule())
        }

        Text("Modèle \(recommendation.modelVersion) · \(recommendation.evidenceCount) sauts valables")
          .font(.caption2.monospacedDigit())
          .foregroundStyle(Color.vaultMuted)

        ForEach(recommendation.reasons, id: \.self) { reason in
          Label(reason, systemImage: "checkmark.circle")
            .font(.footnote)
            .foregroundStyle(Color.vaultText)
        }

        ForEach(recommendation.warnings, id: \.self) { warning in
          Label(warning, systemImage: "exclamationmark.triangle")
            .font(.footnote)
            .foregroundStyle(Color.vaultWarning)
        }

        if !recommendation.alternatives.isEmpty {
          Divider().overlay(Color.vaultLine)
          Text("Alternatives")
            .font(.caption.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
          ForEach(recommendation.alternatives) { alternative in
            HStack {
              Text(alternative.pole.displayName).font(.caption.monospacedDigit())
              Spacer()
              Text(alternative.direction.title).font(.caption2.weight(.bold))
            }
          }
        }

        HStack {
          Button("Accepter") { persistDecision("accepte", recommendation: recommendation) }
            .buttonStyle(.borderedProminent)
          Button("Refuser") { persistDecision("refuse", recommendation: recommendation) }
            .buttonStyle(.bordered)
          Button("Ignorer") { persistDecision("ignore", recommendation: recommendation) }
            .buttonStyle(.bordered)
        }
      } else {
        Text("Aucune perche n’est proposée pour le moment.")
          .font(.headline)
        Text(
          "La proposition est masquée lorsque les données du couple élan–perche sont insuffisantes ou lorsque les observations récentes indiquent une instabilité."
        )
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultAccent.opacity(0.06))
  }

  private func confidenceBadge(_ confidence: PoleRecommendation.Confidence) -> some View {
    let color: Color =
      switch confidence {
      case .low: .vaultWarning
      case .medium: .vaultCyan
      case .high: .vaultSuccess
      }
    return Text("CONFIANCE \(confidence.title.uppercased())")
      .font(.caption2.weight(.black))
      .tracking(1)
      .foregroundStyle(color)
      .padding(.horizontal, 10)
      .padding(.vertical, 6)
      .background(color.opacity(0.12), in: Capsule())
  }

  private var masteryLegend: some View {
    VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Niveaux de progression")
      ForEach(PoleProgressState.allCases) { state in
        HStack(spacing: 10) {
          Image(systemName: state.symbol)
            .foregroundStyle(state == .mastered ? Color.vaultSuccess : Color.vaultWarning)
            .frame(width: 24)
          VStack(alignment: .leading, spacing: 2) {
            Text(state.title)
              .font(.subheadline.weight(.bold))
            Text(description(for: state))
              .font(.caption)
              .foregroundStyle(Color.vaultMuted)
          }
        }
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var equipmentSafetyCard: some View {
    Label {
      Text(
        "Les propositions sont des aides transparentes à la décision, jamais des probabilités de réussite. La hauteur de prise, les protocoles de vitesse et les diagnostics réellement enregistrés sont utilisés quand ils sont disponibles ; les limites fabricant restent prioritaires."
      )
      .font(.footnote)
    } icon: {
      Image(systemName: "shield.lefthalf.filled")
        .font(.title3)
        .foregroundStyle(Color.vaultWarning)
    }
    .vaultCard(background: Color.vaultWarning.opacity(0.06))
  }

  private func persistDecision(_ decision: String, recommendation: PoleRecommendation) {
    guard let athlete, let currentPole else { return }
    modelContext.insert(
      PoleRecommendationDecisionRecord(
        athleteID: athlete.id,
        currentPoleID: currentPole.id,
        recommendedPoleID: recommendation.pole.id,
        approachSteps: appState.selectedApproach.rawValue,
        modelVersion: recommendation.modelVersion,
        direction: recommendation.direction,
        readinessScore: recommendation.readinessScore,
        confidence: recommendation.confidence,
        decision: decision
      )
    )
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.selection()
  }

  private func description(for state: PoleProgressState) -> String {
    switch state {
    case .locked: "Cette perche ne fait pas encore partie de cette gamme d’élan."
    case .unlocked: "Disponible pour un essai avec cet élan."
    case .successful: "Au moins un franchissement valable a été enregistré."
    case .mastered: "Utilisation répétée et stable sur plusieurs sauts valables."
    }
  }

  private func setState(
    _ state: PoleProgressState,
    pole: PoleRecord,
    existing: PoleApproachProgressRecord?
  ) {
    guard let athlete else { return }
    let record: PoleApproachProgressRecord
    if let existing {
      record = existing
    } else {
      record = PoleApproachProgressRecord(
        athleteID: athlete.id,
        poleID: pole.id,
        approach: appState.selectedApproach,
        state: state
      )
      modelContext.insert(record)
    }
    record.state = state
    if state == .successful && record.firstSuccessfulUse == nil {
      record.firstSuccessfulUse = .now
    }
    if state == .mastered && record.masteredAt == nil {
      record.masteredAt = .now
    }
    record.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
  }
}

private struct PoleLockerCard: View {
  let pole: PoleRecord
  let progress: PoleApproachProgressRecord?
  let selected: Bool
  let selectAction: () -> Void
  let editAction: () -> Void
  let updateState: (PoleProgressState) -> Void

  private var state: PoleProgressState { progress?.state ?? .locked }

  var body: some View {
    Button(action: selectAction) {
      HStack(spacing: 16) {
        ZStack {
          RoundedRectangle(cornerRadius: 14, style: .continuous)
            .fill(selected ? Color.vaultAccent.opacity(0.16) : Color.vaultPanelRaised)
          Image(systemName: state.symbol)
            .font(.title2.weight(.bold))
            .foregroundStyle(state == .mastered ? Color.vaultSuccess : Color.vaultWarning)
        }
        .frame(width: 54, height: 54)

        VStack(alignment: .leading, spacing: 5) {
          Text(pole.displayName)
            .font(.headline.monospacedDigit().weight(.black))
          Text(
            [pole.manufacturer, pole.modelName, pole.nickname].filter { !$0.isEmpty }.joined(
              separator: " · ")
          )
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
          if let progress {
            Text("\(progress.clears) réussites / \(progress.validAttempts) sauts valables")
              .font(.caption2.monospacedDigit())
              .foregroundStyle(Color.vaultMuted)
          }
        }

        Spacer()

        VStack(alignment: .trailing, spacing: 8) {
          Text(state.title.uppercased())
            .font(.caption2.weight(.black))
            .tracking(0.8)
            .foregroundStyle(state == .mastered ? Color.vaultSuccess : Color.vaultWarning)
          HStack(spacing: 8) {
            Menu {
              ForEach(PoleProgressState.allCases) { item in
                Button {
                  updateState(item)
                } label: {
                  Label(item.title, systemImage: item.symbol)
                }
              }
            } label: {
              Image(systemName: "ellipsis.circle")
            }
            Button(action: editAction) {
              Image(systemName: "pencil")
            }
          }
          .font(.headline)
          .foregroundStyle(Color.vaultMuted)
        }
      }
      .padding(16)
      .background(
        selected ? Color.vaultAccent.opacity(0.06) : Color.vaultPanel,
        in: RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
      )
      .overlay {
        RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
          .stroke(selected ? Color.vaultAccent : Color.vaultLine, lineWidth: selected ? 1.5 : 1)
      }
    }
    .buttonStyle(.plain)
  }
}

private struct PoleEditorView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  let athleteID: UUID
  var pole: PoleRecord?
  let nextOrder: Int

  @State private var manufacturer = "UCS Spirit"
  @State private var modelName = ""
  @State private var lengthCM = 460
  @State private var weightKG = 80.0
  @State private var flexCM = 14.0
  @State private var nickname = ""
  @State private var notes = ""

  var body: some View {
    NavigationStack {
      Form {
        Section("Identité de la perche") {
          Picker("Marque", selection: $manufacturer) {
            ForEach(PoleManufacturer.allCases) { brand in
              Text(brand.rawValue).tag(brand.rawValue)
            }
          }
          .pickerStyle(.menu)

          TextField("Modèle / série", text: $modelName)
          TextField("Surnom ou couleur du ruban", text: $nickname)
        }

        Section("Caractéristiques du fabricant") {
          Stepper(value: $lengthCM, in: 250...550, step: 5) {
            LabeledContent(
              "Longueur réelle", value: String(format: "%.2f m", Double(lengthCM) / 100))
          }
          Stepper(value: $weightKG, in: 20...150, step: 1) {
            LabeledContent("Poids homologué", value: String(format: "%.0f kg", weightKG))
          }
          Stepper(value: $flexCM, in: 5...40, step: 0.1) {
            LabeledContent("Indice de flexion", value: String(format: "%.1f cm", flexCM))
          }
        }

        Section("Commentaires") {
          VaultCommentEditor(
            text: $notes,
            placeholder: "État, numéro de série, disponibilité, sensations, historique d’utilisation…",
            minHeight: 190
          )
        }
      }
      .navigationTitle(pole == nil ? "Ajouter une perche" : "Modifier la perche")
      .onAppear {
        guard let pole else { return }
        manufacturer = pole.manufacturer
        modelName = pole.modelName
        lengthCM = pole.lengthCM
        weightKG = pole.weightKG
        flexCM = pole.flexCM
        nickname = pole.nickname
        notes = pole.notes
      }
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer") { save() }
            .disabled(manufacturer.trimmingCharacters(in: .whitespaces).isEmpty)
        }
      }
    }
  }

  private func save() {
    if let pole {
      pole.manufacturer = manufacturer
      pole.modelName = modelName
      pole.lengthCM = lengthCM
      pole.weightKG = weightKG
      pole.flexCM = flexCM
      pole.nickname = nickname
      pole.notes = notes
      pole.updatedAt = .now
    } else {
      modelContext.insert(
        PoleRecord(
          athleteID: athleteID,
          manufacturer: manufacturer,
          modelName: modelName,
          lengthCM: lengthCM,
          weightKG: weightKG,
          flexCM: flexCM,
          nickname: nickname,
          progressionOrder: nextOrder,
          notes: notes
        )
      )
    }
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
    dismiss()
  }
}

private struct ApproachProfileEditorView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Query private var profiles: [ApproachProfileRecord]
  let athleteID: UUID
  let approach: ApproachLength

  @State private var startMark = 0.0
  @State private var intermediateMark = 0.0
  @State private var finalCheckMark = 0.0
  @State private var takeoffMark = 0.0
  @State private var notes = ""

  private var record: ApproachProfileRecord? {
    profiles.first { $0.athleteID == athleteID && $0.approachSteps == approach.rawValue }
  }

  var body: some View {
    NavigationStack {
      Form {
        Section("Élan de \(approach.title.lowercased())") {
          measurementField("Marque de départ", value: $startMark)
          measurementField("Marque intermédiaire", value: $intermediateMark)
          measurementField("Dernière marque de contrôle", value: $finalCheckMark)
          measurementField("Marque d’impulsion attendue", value: $takeoffMark)
        }
        Section("Référence") {
          Label("Toutes les distances partent du fond du butoir.", systemImage: "ruler")
          VaultCommentEditor(
            text: $notes,
            placeholder: "Piste, vent, conditions, repères visuels, sensations et ajustements…",
            minHeight: 190
          )
        }
      }
      .navigationTitle("Marques d’élan")
      .onAppear(perform: load)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer", action: save)
        }
      }
    }
  }

  private func measurementField(_ title: String, value: Binding<Double>) -> some View {
    HStack {
      Text(title)
      Spacer()
      TextField("0.00", value: value, format: .number.precision(.fractionLength(2)))
        .keyboardType(.decimalPad)
        .multilineTextAlignment(.trailing)
        .frame(width: 100)
      Text("m")
        .foregroundStyle(.secondary)
    }
  }

  private func load() {
    guard let record else { return }
    startMark = record.startMarkM
    intermediateMark = record.intermediateMarkM ?? 0
    finalCheckMark = record.finalCheckMarkM ?? 0
    takeoffMark = record.expectedTakeoffMarkM ?? 0
    notes = record.notes
  }

  private func save() {
    let target: ApproachProfileRecord
    if let record {
      target = record
    } else {
      target = ApproachProfileRecord(
        athleteID: athleteID,
        approach: approach,
        startMarkM: startMark
      )
      modelContext.insert(target)
    }
    target.startMarkM = startMark
    target.intermediateMarkM = intermediateMark == 0 ? nil : intermediateMark
    target.finalCheckMarkM = finalCheckMark == 0 ? nil : finalCheckMark
    target.expectedTakeoffMarkM = takeoffMark == 0 ? nil : takeoffMark
    target.notes = notes
    target.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
    dismiss()
  }
}
