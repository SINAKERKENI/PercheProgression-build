import SwiftData
import SwiftUI

struct AchievementsView: View {
  @Environment(AppState.self) private var appState
  @Query private var profiles: [AthleteProfile]
  @Query private var sessions: [VaultSessionRecord]
  @Query private var attempts: [AttemptRecord]
  @Query private var videos: [VideoClipRecord]
  @Query private var poleProgress: [PoleApproachProgressRecord]
  @Query private var drillCompletions: [DrillCompletionRecord]
  @Query private var metrics: [PhysicalMetricRecord]

  @State private var selectedCategory: AchievementCategory?

  private var athlete: AthleteProfile? { appState.athlete(in: profiles) }

  private var snapshot: AchievementSnapshot {
    AchievementEngine.snapshot(
      athlete: athlete,
      sessions: sessions,
      attempts: attempts,
      videos: videos,
      poleProgress: poleProgress,
      drillCompletions: drillCompletions,
      metrics: metrics
    )
  }

  private var achievements: [VaultAchievement] {
    AchievementEngine.achievements(for: snapshot)
  }

  private var visibleAchievements: [VaultAchievement] {
    guard let selectedCategory else { return achievements }
    return achievements.filter { $0.category == selectedCategory }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        VaultScreenHeader(
          title: "Jalons",
          subtitle: "Des objectifs calculés uniquement à partir de vos vraies séances, mesures, vidéos et perches.",
          symbol: "trophy.fill"
        )

        summaryCard
        categoryPicker

        LazyVGrid(
          columns: [GridItem(.adaptive(minimum: 270), spacing: VaultSpacing.medium)],
          spacing: VaultSpacing.medium
        ) {
          ForEach(visibleAchievements) { achievement in
            AchievementCard(achievement: achievement)
          }
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
  }

  private var summaryCard: some View {
    let unlocked = achievements.filter(\.isUnlocked).count
    let total = achievements.count
    let progress = total > 0 ? Double(unlocked) / Double(total) : 0
    let next = achievements
      .filter { !$0.isUnlocked }
      .min { $0.progress > $1.progress }

    return HStack(spacing: 24) {
      ZStack {
        Circle()
          .stroke(Color.white.opacity(0.16), lineWidth: 12)
        Circle()
          .trim(from: 0, to: progress)
          .stroke(Color.vaultGold, style: StrokeStyle(lineWidth: 12, lineCap: .round))
          .rotationEffect(.degrees(-90))
        VStack(spacing: 2) {
          Text("\(unlocked)")
            .font(.system(size: 34, weight: .black, design: .rounded))
          Text("sur \(total)")
            .font(.caption.weight(.bold))
            .opacity(0.75)
        }
      }
      .frame(width: 126, height: 126)

      VStack(alignment: .leading, spacing: 9) {
        Text("VOTRE PARCOURS")
          .font(.caption.weight(.black))
          .tracking(1.3)
          .foregroundStyle(Color.white.opacity(0.68))
        Text(unlocked == total ? "Tous les jalons sont débloqués" : "Encore \(total - unlocked) jalons à conquérir")
          .font(.title2.weight(.black))
        if let next {
          Label("Prochain : \(next.title) · \(Int((next.progress * 100).rounded())) %", systemImage: next.symbol)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Color.white.opacity(0.82))
        }
      }

      Spacer()
    }
    .padding(26)
    .foregroundStyle(.white)
    .background(
      LinearGradient(
        colors: [.vaultNavy, .vaultNavyLight],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      ),
      in: RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
    )
  }

  private var categoryPicker: some View {
    ScrollView(.horizontal, showsIndicators: false) {
      HStack(spacing: 9) {
        categoryButton(title: "Tous", symbol: "square.grid.2x2.fill", category: nil)
        ForEach(AchievementCategory.allCases) { category in
          categoryButton(title: category.rawValue, symbol: categorySymbol(category), category: category)
        }
      }
    }
  }

  private func categoryButton(
    title: String,
    symbol: String,
    category: AchievementCategory?
  ) -> some View {
    let isSelected = selectedCategory == category
    return Button {
      selectedCategory = category
      Haptics.selection()
    } label: {
      Label(title, systemImage: symbol)
        .font(.subheadline.weight(.bold))
        .padding(.horizontal, 15)
        .padding(.vertical, 10)
        .foregroundStyle(isSelected ? Color.white : Color.vaultText)
        .background(isSelected ? Color.vaultNavy : Color.vaultPanelRaised, in: Capsule())
    }
    .buttonStyle(.plain)
  }

  private func categorySymbol(_ category: AchievementCategory) -> String {
    switch category {
    case .gettingStarted: "sparkles"
    case .performance: "trophy.fill"
    case .consistency: "calendar.badge.checkmark"
    case .technique: "viewfinder"
    case .equipment: "line.diagonal"
    }
  }
}

private struct AchievementCard: View {
  let achievement: VaultAchievement

  var body: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack(alignment: .top) {
        Image(systemName: achievement.symbol)
          .font(.title2.weight(.bold))
          .foregroundStyle(achievement.isUnlocked ? Color.white : Color.vaultMuted)
          .frame(width: 50, height: 50)
          .background(
            achievement.isUnlocked ? Color.vaultSuccess : Color.vaultPanelRaised,
            in: RoundedRectangle(cornerRadius: 15, style: .continuous)
          )
        Spacer()
        Image(systemName: achievement.isUnlocked ? "checkmark.seal.fill" : "lock.fill")
          .font(.title3)
          .foregroundStyle(achievement.isUnlocked ? Color.vaultSuccess : Color.vaultMuted.opacity(0.55))
      }

      VStack(alignment: .leading, spacing: 5) {
        Text(achievement.category.rawValue.uppercased())
          .font(.caption2.weight(.black))
          .tracking(1)
          .foregroundStyle(Color.vaultMuted)
        Text(achievement.title)
          .font(.title3.weight(.black))
        Text(achievement.detail)
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
          .fixedSize(horizontal: false, vertical: true)
      }

      Spacer(minLength: 0)

      HStack {
        ProgressView(value: achievement.progress)
          .tint(achievement.isUnlocked ? .vaultSuccess : .vaultAccent)
        Text(progressText)
          .font(.caption.monospacedDigit().weight(.bold))
          .foregroundStyle(Color.vaultMuted)
      }
    }
    .frame(maxWidth: .infinity, minHeight: 210, alignment: .topLeading)
    .vaultCard(background: achievement.isUnlocked ? Color.vaultSuccess.opacity(0.045) : .vaultPanel)
  }

  private var progressText: String {
    if achievement.id == "quality-session" {
      return "\(Int((achievement.current * 100).rounded())) / \(Int((achievement.target * 100).rounded())) %"
    }
    return "\(Int(achievement.current.rounded())) / \(Int(achievement.target.rounded()))"
  }
}
