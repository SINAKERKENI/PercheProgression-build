import Charts
import SwiftData
import SwiftUI

struct ProgressDashboardView: View {
  @Environment(AppState.self) private var appState
  @Query(sort: \AttemptRecord.createdAt) private var attempts: [AttemptRecord]
  @Query(sort: \PhysicalMetricRecord.measuredAt) private var metrics: [PhysicalMetricRecord]
  @Query private var profiles: [AthleteProfile]
  @Query private var poleProgress: [PoleApproachProgressRecord]
  @Query(sort: \VaultSessionRecord.startedAt) private var sessions: [VaultSessionRecord]
  @Query(sort: \OfficialPerformanceRecord.date) private var officialPerformances: [OfficialPerformanceRecord]

  @State private var selectedMetric: ProgressMetric = .officialPR
  @State private var selectedDate: Date?
  @State private var selectedOfficialPerformance: OfficialPerformanceRecord?

  private var profile: AthleteProfile? { appState.athlete(in: profiles) }

  private var scopedAttempts: [AttemptRecord] {
    guard let athleteID = profile?.id else { return [] }
    return attempts.filter { $0.athleteID == athleteID && $0.deletedAt == nil }
  }

  private var scopedMetrics: [PhysicalMetricRecord] {
    guard let athleteID = profile?.id else { return [] }
    return metrics.filter { $0.athleteID == athleteID }
  }

  private var scopedPoleProgress: [PoleApproachProgressRecord] {
    guard let athleteID = profile?.id else { return [] }
    return poleProgress.filter { $0.athleteID == athleteID }
  }


  private var scopedSessions: [VaultSessionRecord] {
    guard let athleteID = profile?.id else { return [] }
    return sessions.filter { $0.athleteID == athleteID }
  }

  private var scopedOfficialPerformances: [OfficialPerformanceRecord] {
    guard let athleteID = profile?.id else { return [] }
    return officialPerformances.filter { $0.athleteID == athleteID }.sorted { $0.date < $1.date }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        VaultScreenHeader(
          title: "Progression",
          subtitle: "Des courbes dynamiques pour la performance, la vitesse, la course d’élan et la maîtrise des perches.",
          symbol: "chart.xyaxis.line"
        )

        keyMetrics

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            timelineCard
              .frame(maxWidth: .infinity)
            speedGoalCard
              .frame(width: 340)
          }
          VStack(spacing: VaultSpacing.large) {
            timelineCard
            speedGoalCard
          }
        }

        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) {
            officialHistoryCard
            diagnosticTrendsCard
          }
          VStack(spacing: VaultSpacing.large) {
            officialHistoryCard
            diagnosticTrendsCard
          }
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .sheet(item: $selectedOfficialPerformance) { record in
      NavigationStack {
        List {
          LabeledContent("Performance", value: String(format: "%.2f m", Double(record.performanceCM) / 100.0))
          LabeledContent("Épreuve", value: record.eventName)
          LabeledContent("Date", value: record.date.formatted(date: .long, time: .omitted))
          LabeledContent("Condition", value: record.isIndoor ? "Salle" : "Plein air")
          if !record.competition.isEmpty { LabeledContent("Compétition", value: record.competition) }
          if !record.venue.isEmpty { LabeledContent("Lieu", value: record.venue) }
          if !record.place.isEmpty { LabeledContent("Classement", value: record.place) }
          if !record.level.isEmpty { LabeledContent("Niveau", value: record.level) }
          Section { Text("Source : Fédération Française d’Athlétisme · import local distinct des entraînements.") }
        }
        .navigationTitle("Résultat FFA")
      }
    }
  }

  private var keyMetrics: some View {
    let profile = profile
    let mastered = scopedPoleProgress.filter { $0.state == .mastered }.count
    let valid = scopedAttempts.filter { $0.result.isValidAttempt }
    let clearRate =
      valid.isEmpty
      ? 0 : Double(valid.filter { $0.result == .clear }.count) / Double(valid.count) * 100

    return HStack(spacing: 12) {
      MetricPill(
        title: "Record officiel",
        value: String(format: "%.2f m", Double(currentOfficialPRCM) / 100), tint: .vaultAccent
      )
      MetricPill(
        title: "Record à l’entraînement",
        value: String(format: "%.2f m", Double(profile?.trainingPRCM ?? 0) / 100), tint: .vaultCyan)
      MetricPill(
        title: "Vitesse d’élan",
        value: String(format: "%.2f m/s", currentApproachSpeed), tint: .vaultSuccess)
      MetricPill(title: "Taux de réussite", value: "\(Int(clearRate.rounded()))%", tint: .vaultWarning)
      MetricPill(title: "Perches maîtrisées", value: "\(mastered)", tint: .vaultSuccess)
      Spacer(minLength: 0)
    }
  }

  private var timelineCard: some View {
    let points = points(for: selectedMetric)

    return VStack(alignment: .leading, spacing: 16) {
      HStack {
        VStack(alignment: .leading, spacing: 5) {
          SectionEyebrow(text: "Évolution de la mesure")
          Text(selectedMetric.title)
            .font(.title2.weight(.black))
        }
        Spacer()
        Menu {
          ForEach(ProgressMetric.allCases) { metric in
            Button(metric.title) {
              selectedMetric = metric
              selectedDate = nil
              Haptics.selection()
            }
          }
        } label: {
          Label("Mesure", systemImage: "slider.horizontal.3")
        }
        .buttonStyle(.bordered)
      }

      if points.isEmpty {
        EmptyStateView(
          symbol: "chart.line.downtrend.xyaxis",
          title: "Aucune donnée pour le moment",
          message: "Enregistrez des sauts ou des mesures pour construire cette courbe."
        )
      } else {
        Chart(points) { point in
          LineMark(
            x: .value("Date", point.date),
            y: .value(selectedMetric.title, point.value)
          )
          .interpolationMethod(.linear)
          .foregroundStyle(Color.vaultAccent.gradient)
          .lineStyle(StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))

          AreaMark(
            x: .value("Date", point.date),
            yStart: .value("Référence", chartBaseline(for: points)),
            yEnd: .value(selectedMetric.title, point.value)
          )
          .interpolationMethod(.linear)
          .foregroundStyle(
            LinearGradient(
              colors: [Color.vaultAccent.opacity(0.30), Color.vaultAccent.opacity(0.01)],
              startPoint: .top,
              endPoint: .bottom
            )
          )

          PointMark(
            x: .value("Date", point.date),
            y: .value(selectedMetric.title, point.value)
          )
          .foregroundStyle(Color.vaultText)
          .symbolSize(42)
        }
        .chartXAxis {
          AxisMarks(values: .automatic(desiredCount: 6)) { _ in
            AxisGridLine().foregroundStyle(Color.vaultLine.opacity(0.6))
            AxisTick().foregroundStyle(Color.vaultMuted)
            AxisValueLabel(format: .dateTime.month(.abbreviated))
              .foregroundStyle(Color.vaultMuted)
          }
        }
        .chartYAxis {
          AxisMarks(position: .leading) { value in
            AxisGridLine().foregroundStyle(Color.vaultLine.opacity(0.7))
            AxisValueLabel {
              if let number = value.as(Double.self) {
                Text(formatMetric(number, metric: selectedMetric))
                  .foregroundStyle(Color.vaultMuted)
              }
            }
          }
        }
        .chartOverlay { proxy in
          GeometryReader { geometry in
            Rectangle()
              .fill(.clear)
              .contentShape(Rectangle())
              .gesture(
                DragGesture(minimumDistance: 0)
                  .onChanged { value in
                    guard let plotFrame = proxy.plotFrame else { return }
                    let frame = geometry[plotFrame]
                    let x = value.location.x - frame.origin.x
                    guard x >= 0, x <= frame.width,
                      let date: Date = proxy.value(atX: x)
                    else { return }
                    let closest = points.min {
                      abs($0.date.timeIntervalSince(date)) < abs($1.date.timeIntervalSince(date))
                    }
                    if selectedDate != closest?.date {
                      selectedDate = closest?.date
                      Haptics.selection()
                    }
                  }
              )
          }
        }
        .frame(height: 320)
        .overlay(alignment: .topLeading) {
          if let selected = selectedPoint(in: points) {
            VStack(alignment: .leading, spacing: 3) {
              Text(
                selected.label.isEmpty
                  ? formatMetric(selected.value, metric: selectedMetric) : selected.label
              )
              .font(.headline.monospacedDigit().weight(.black))
              Text(selected.date.formatted(date: .abbreviated, time: .omitted))
                .font(.caption)
                .foregroundStyle(Color.vaultMuted)
            }
            .padding(10)
            .background(
              .ultraThinMaterial, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
          }
        }
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var speedGoalCard: some View {
    let current = currentApproachSpeed
    let estimate = VaultPhysicsModel().estimate(
      targetHeightCM: profile?.targetHeightCM ?? 0,
      athleteHeightCM: profile?.heightCM ?? 0,
      currentSpeed: current
    )

    return VStack(alignment: .leading, spacing: 18) {
      SectionEyebrow(text: "Énergie nécessaire pour l’objectif")
      VaultVerticalSpeedGauge(
        current: current,
        target: estimate.targetSpeed,
        progress: estimate.energyProgress
      )
      .frame(maxWidth: .infinity, minHeight: 320)

      HStack {
        VStack(alignment: .leading) {
          Text("Vitesse actuelle")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", current))
            .font(.title3.monospacedDigit().weight(.black))
        }
        Spacer()
        VStack(alignment: .trailing) {
          Text("Vitesse théorique cible")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", estimate.targetSpeed))
            .font(.title3.monospacedDigit().weight(.black))
        }
      }

      Divider().overlay(Color.vaultLine)

      Text(String(format: "%.2f m/s à gagner · %.0f %% de l’énergie cible", estimate.speedGap, estimate.energyProgress * 100))
        .font(.headline.monospacedDigit().weight(.black))
        .foregroundStyle(Color.vaultCyan)
      Text("La jauge suit ½v² : l’effort augmente de façon quadratique. Ce modèle énergétique reste une estimation et n’est pas une garantie de hauteur.")
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var officialHistoryCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      SectionEyebrow(text: "Historique officiel FFA")
      if scopedOfficialPerformances.isEmpty {
        Text("Aucun résultat officiel importé")
          .font(.headline)
        Text("Associez votre profil FFA depuis le profil athlète. Les résultats officiels restent séparés des sauts d’entraînement.")
          .font(.footnote)
          .foregroundStyle(Color.vaultMuted)
      } else {
        ForEach(scopedOfficialPerformances.sorted(by: { $0.date > $1.date }).prefix(8)) { record in
          Button { selectedOfficialPerformance = record } label: {
            HStack {
              VStack(alignment: .leading, spacing: 3) {
                Text(String(format: "%.2f m", Double(record.performanceCM) / 100.0))
                  .font(.headline.monospacedDigit().weight(.black))
                Text([record.competition, record.venue].filter { !$0.isEmpty }.joined(separator: " · "))
                  .font(.caption)
                  .foregroundStyle(Color.vaultMuted)
              }
              Spacer()
              VStack(alignment: .trailing) {
                Text(record.isIndoor ? "SALLE · FFA" : "PLEIN AIR · FFA")
                  .font(.caption2.weight(.black))
                  .foregroundStyle(Color.vaultAccent)
                Text(record.date.formatted(date: .abbreviated, time: .omitted))
                  .font(.caption.monospacedDigit())
                  .foregroundStyle(Color.vaultMuted)
              }
            }
            .contentShape(Rectangle())
          }
          .buttonStyle(.plain)
        }
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var diagnosticTrendsCard: some View {
    let activeAttempts = scopedAttempts
    let counts = AttemptDiagnostic.allCases.map { diagnostic in
      (diagnostic, activeAttempts.filter { $0.diagnostics.contains(diagnostic) }.count)
    }
    let maxCount = max(counts.map(\.1).max() ?? 1, 1)

    return VStack(alignment: .leading, spacing: 16) {
      SectionEyebrow(text: "Fréquence des observations techniques")
      Text("Ce qui revient le plus souvent dans les sauts enregistrés")
        .font(.title3.weight(.black))

      ForEach(counts, id: \.0) { item in
        VStack(alignment: .leading, spacing: 6) {
          HStack {
            Label(item.0.title, systemImage: item.0.symbol)
              .font(.subheadline.weight(.semibold))
            Spacer()
            Text("\(item.1)")
              .font(.subheadline.monospacedDigit().weight(.black))
              .foregroundStyle(Color.vaultMuted)
          }
          GeometryReader { geometry in
            Capsule()
              .fill(Color.vaultPanelRaised)
              .overlay(alignment: .leading) {
                Capsule()
                  .fill(
                    item.0 == .poleTooStiff || item.0 == .plantRefusal
                      ? Color.vaultWarning : Color.vaultAccent
                  )
                  .frame(width: geometry.size.width * CGFloat(item.1) / CGFloat(maxCount))
              }
          }
          .frame(height: 7)
        }
      }

      Text(
        "Cette fréquence décrit les observations saisies ; elle ne démontre pas la cause d’une variation de performance."
      )
      .font(.footnote)
      .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }


  private var currentApproachSpeed: Double {
    return scopedMetrics
      .filter { $0.kind.isApproachSpeedFamily }
      .max(by: { $0.measuredAt < $1.measuredAt })?
      .value ?? 0
  }


  private func points(for metric: ProgressMetric) -> [MetricPoint] {
    switch metric {
    case .officialPR:
      let imported = officialPRPoints
      return imported.isEmpty ? prPoints(sessionKind: .competition) : imported
    case .trainingPR:
      return prPoints(sessionKind: .training)
    case .approachSpeed:
      return approachSpeedPoints()
    case .takeoffSpeed:
      return metricPoints(kind: .takeoffSpeed)
    case .startMark:
      return metricPoints(kind: .startMark)
    case .takeoffMark:
      return metricPoints(kind: .takeoffMark)
    case .clearRate:
      return AnalyticsEngine().clearRatePoints(
        attempts: scopedAttempts.map(\.snapshot))
    }
  }

  private func prPoints(sessionKind: SessionKind) -> [MetricPoint] {
    // Use the authoritative session type. attemptNumber is not a valid proxy for
    // training vs competition and previously polluted the PR curves.
    let sessionIDs = Set(scopedSessions.filter { $0.kind == sessionKind }.map(\.id))
    let snapshots = scopedAttempts
      .filter { sessionIDs.contains($0.sessionID) }
      .map(\.snapshot)
    return AnalyticsEngine().cumulativePRPoints(attempts: snapshots, sessionKindByAttempt: Dictionary(uniqueKeysWithValues: snapshots.map { ($0.id, sessionKind) }), desiredKind: sessionKind)
  }

  private func approachSpeedPoints() -> [MetricPoint] {
    let family = scopedMetrics.filter { $0.kind.isApproachSpeedFamily }
    guard let latestProtocol = family.max(by: { $0.measuredAt < $1.measuredAt })?.kind else { return [] }
    // Never plot heterogeneous protocols on the same longitudinal series.
    return family
      .filter { $0.kind == latestProtocol }
      .map {
        MetricPoint(
          date: $0.measuredAt,
          value: $0.value,
          label: "\(latestProtocol.title) · " + String(format: "%.2f %@", $0.value, $0.unit)
        )
      }
  }

  private func metricPoints(kind: PhysicalMetricKind) -> [MetricPoint] {
    return scopedMetrics
      .filter { $0.kind == kind }
      .map {
        MetricPoint(
          date: $0.measuredAt,
          value: $0.value,
          label: String(format: "%.2f %@", $0.value, $0.unit)
        )
      }
  }

  private func latestMetric(_ kind: PhysicalMetricKind) -> Double? {
    scopedMetrics.last(where: { $0.kind == kind })?.value
  }

  private var officialPRPoints: [MetricPoint] {
    var best = 0
    return scopedOfficialPerformances.compactMap { record in
      guard record.performanceCM > best else { return nil }
      best = record.performanceCM
      return MetricPoint(date: record.date, value: Double(record.performanceCM) / 100.0,
                         label: String(format: "%.2f m · FFA", Double(record.performanceCM) / 100.0))
    }
  }

  private var currentOfficialPRCM: Int {
    scopedOfficialPerformances.map(\.performanceCM).max() ?? profile?.currentPRCM ?? 0
  }

  private func selectedPoint(in points: [MetricPoint]) -> MetricPoint? {
    guard let selectedDate else { return nil }
    return points.min {
      abs($0.date.timeIntervalSince(selectedDate)) < abs($1.date.timeIntervalSince(selectedDate))
    }
  }

  private func chartBaseline(for points: [MetricPoint]) -> Double {
    guard let minimum = points.map(\.value).min() else { return 0 }
    switch selectedMetric {
    case .clearRate: return 0
    default: return minimum * 0.97
    }
  }

  private func formatMetric(_ value: Double, metric: ProgressMetric) -> String {
    switch metric {
    case .clearRate:
      return "\(Int(value.rounded()))%"
    default:
      return String(format: "%.2f", value)
    }
  }
}

struct VaultVerticalSpeedGauge: View {
  let current: Double
  let target: Double
  /// Progression énergétique (vitesse²), et non simple rapport de vitesse.
  let progress: Double

  private var clampedProgress: Double { min(max(progress, 0), 1) }

  var body: some View {
    HStack(alignment: .center, spacing: 30) {
      GeometryReader { geometry in
        let height = max(geometry.size.height, 1)
        let fillHeight = height * clampedProgress

        ZStack(alignment: .bottom) {
          RoundedRectangle(cornerRadius: 20, style: .continuous)
            .fill(Color.vaultPanelRaised)

          RoundedRectangle(cornerRadius: 20, style: .continuous)
            .fill(
              LinearGradient(
                colors: [.vaultCyan, .vaultAccent],
                startPoint: .bottom,
                endPoint: .top
              )
            )
            .frame(height: fillHeight)
            .animation(.spring(response: 0.55, dampingFraction: 0.82), value: clampedProgress)

          ForEach([0.25, 0.50, 0.75, 1.0], id: \.self) { energyFraction in
            let y = height * (1 - energyFraction)
            HStack(spacing: 5) {
              Rectangle()
                .fill(Color.vaultText.opacity(energyFraction == 1 ? 0.62 : 0.28))
                .frame(width: energyFraction == 1 ? 38 : 24, height: energyFraction == 1 ? 2 : 1)
              Text(speedLabel(forEnergyFraction: energyFraction))
                .font(.caption2.monospacedDigit().weight(.bold))
                .foregroundStyle(Color.vaultMuted)
            }
            .position(x: geometry.size.width / 2, y: min(max(y, 12), height - 12))
          }

          VStack(spacing: 4) {
            Text("\(Int((clampedProgress * 100).rounded())) %")
              .font(.title2.monospacedDigit().weight(.black))
              .foregroundStyle(clampedProgress > 0.45 ? Color.white : Color.vaultText)
            Text("énergie")
              .font(.caption.weight(.bold))
              .foregroundStyle(clampedProgress > 0.45 ? Color.white.opacity(0.86) : Color.vaultMuted)
          }
          .padding(.bottom, max(fillHeight / 2 - 22, 14))
        }
        .overlay {
          RoundedRectangle(cornerRadius: 20, style: .continuous)
            .stroke(Color.vaultLine, lineWidth: 1.5)
        }
      }
      .frame(width: 140, height: 280)
      .accessibilityElement(children: .ignore)
      .accessibilityLabel("Jauge verticale d’énergie cinétique")
      .accessibilityValue("\(Int((clampedProgress * 100).rounded())) pour cent")

      VStack(alignment: .leading, spacing: 18) {
        VStack(alignment: .leading, spacing: 5) {
          Text("VITESSE ACTUELLE")
            .font(.caption2.weight(.black))
            .tracking(1)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", current))
            .font(.system(size: 34, weight: .black, design: .rounded))
            .monospacedDigit()
        }

        Divider().overlay(Color.vaultLine)

        VStack(alignment: .leading, spacing: 5) {
          Text("VITESSE THÉORIQUE CIBLE")
            .font(.caption2.weight(.black))
            .tracking(1)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", target))
            .font(.title2.monospacedDigit().weight(.black))
            .foregroundStyle(Color.vaultAccent)
        }

        Text("Échelle non linéaire : E ∝ v²")
          .font(.caption.weight(.bold))
          .foregroundStyle(Color.vaultCyan)

        Spacer(minLength: 0)
      }
      .frame(maxHeight: 280)
    }
  }

  private func speedLabel(forEnergyFraction fraction: Double) -> String {
    guard target > 0 else { return "—" }
    return String(format: "%.1f", target * sqrt(fraction))
  }
}

