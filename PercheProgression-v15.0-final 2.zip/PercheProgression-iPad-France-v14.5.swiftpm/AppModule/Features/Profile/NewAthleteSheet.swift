import SwiftData
import SwiftUI

struct NewAthleteSheet: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext

  let onCreate: (AthleteProfile) -> Void

  @State private var displayName = ""
  @State private var category = "Sénior"
  @State private var heightCM = 0.0
  @State private var bodyWeightKG = 0.0
  @State private var errorMessage: String?

  var body: some View {
    NavigationStack {
      Form {
        Section("Identité sportive") {
          TextField("Nom affiché", text: $displayName)
          TextField("Catégorie", text: $category)
        }

        Section("Morphologie") {
          HStack {
            TextField("Taille", value: $heightCM, format: .number.precision(.fractionLength(1)))
              .keyboardType(.decimalPad)
            Text("cm").foregroundStyle(.secondary)
          }
          HStack {
            TextField("Poids", value: $bodyWeightKG, format: .number.precision(.fractionLength(1)))
              .keyboardType(.decimalPad)
            Text("kg").foregroundStyle(.secondary)
          }
        }

        Section {
          Label(
            "Un profil, une feuille de route et toutes les courses d’élan seront créés localement. Les données resteront strictement séparées des autres athlètes.",
            systemImage: "lock.shield.fill"
          )
          .font(.footnote)
          .foregroundStyle(Color.vaultMuted)
        }

        if let errorMessage {
          Section {
            Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
              .foregroundStyle(Color.vaultWarning)
          }
        }
      }
      .navigationTitle("Nouvel athlète")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Créer") { create() }
            .fontWeight(.bold)
            .disabled(displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
    }
  }

  private func create() {
    do {
      let athlete = try SeedService.createAthlete(
        displayName: displayName.trimmingCharacters(in: .whitespacesAndNewlines),
        category: category.trimmingCharacters(in: .whitespacesAndNewlines),
        heightCM: heightCM,
        bodyWeightKG: bodyWeightKG,
        context: modelContext
      )
      onCreate(athlete)
      Haptics.success()
      dismiss()
    } catch {
      errorMessage = error.localizedDescription
      Haptics.error()
    }
  }
}
