import Charts
import SwiftData
import SwiftUI
import UniformTypeIdentifiers

struct AthleteProfileView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Environment(PerformanceState.self) private var performanceStore
  @Query private var profiles: [AthleteProfile]
  @Query(sort: \PhysicalMetricRecord.measuredAt, order: .reverse) private var metrics:
    [PhysicalMetricRecord]

  @State private var showingMetricEditor = false
  @State private var selectedMetricKind: PhysicalMetricKind = .approachSpeed5mMean
  @State private var backupDocument = VaultBackupDocument()
  @State private var backupFilename = "PercheProgression-Sauvegarde"
  @State private var isExportingBackup = false
  @State private var showingExportScope = false
  @State private var backupError: String?
  @State private var ffaMessage: String?
  @State private var showingNewAthlete = false

  private var profile: AthleteProfile? { appState.athlete(in: profiles) }

  private var currentApproachSpeed: Double {
    guard let athleteID = profile?.id else { return 0 }
    return metrics
      .filter { $0.athleteID == athleteID && $0.kind.isApproachSpeedFamily }
      .max(by: { $0.measuredAt < $1.measuredAt })?
      .value ?? 0
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        HStack(alignment: .top) {
          VaultScreenHeader(
            title: "Profil de l’athlète",
            subtitle: "Historique des tests physiques et paramètres de la jauge de vitesse.",
            symbol: "person.crop.circle.fill"
          )
          Spacer()
          HStack(spacing: 10) {
            Button { showingNewAthlete = true } label: {
              Label("Ajouter un athlète", systemImage: "person.badge.plus")
            }
            .buttonStyle(.bordered)

            Button { showingExportScope = true } label: {
              Label("Exporter une sauvegarde", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(.bordered)

            Button {
              showingMetricEditor = true
            } label: {
              Label("Ajouter une mesure", systemImage: "plus")
            }
            .buttonStyle(.borderedProminent)
            .tint(.vaultAccent)
          }
        }

        if let profile {
          athleteRosterCard

          ViewThatFits(in: .horizontal) {
            HStack(alignment: .top, spacing: VaultSpacing.large) {
              ProfileEditorCard(profile: profile)
                .frame(maxWidth: 560)
              SpeedPotentialCard(profile: profile, currentApproachSpeed: currentApproachSpeed)
                .frame(maxWidth: .infinity)
            }
            VStack(spacing: VaultSpacing.large) {
              ProfileEditorCard(profile: profile)
              SpeedPotentialCard(profile: profile, currentApproachSpeed: currentApproachSpeed)
            }
          }

          iPadWorkspaceCard
          FFAIntegrationCard(profile: profile)
          physicalHistoryCard
        } else {
          EmptyStateView(
            symbol: "person.crop.circle.badge.exclamationmark",
            title: "Profil indisponible",
            message: "Relancez l’application pour recréer le profil local de l’athlète."
          )
        }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .sheet(isPresented: $showingMetricEditor) {
      if let profile {
        MeasurementEditorView(athleteID: profile.id, defaultKind: selectedMetricKind)
      }
    }
    .sheet(isPresented: $showingNewAthlete) {
      NewAthleteSheet { athlete in
        appState.selectedAthleteID = athlete.id
      }
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .confirmationDialog(
      "Choisir les catégories à exporter",
      isPresented: $showingExportScope,
      titleVisibility: .visible
    ) {
      ForEach(VaultBackupScope.allCases) { scope in
        Button(scope.title) { exportBackup(scope: scope) }
      }
      Button("Annuler", role: .cancel) {}
    } message: {
      Text("Les vidéos originales ne sont jamais incluses. Le fichier JSON peut contenir des données personnelles et sportives selon le périmètre choisi.")
    }
    .fileExporter(
      isPresented: $isExportingBackup,
      document: backupDocument,
      contentType: .json,
      defaultFilename: backupFilename
    ) { result in
      switch result {
      case .success:
        Haptics.success()
      case .failure(let error):
        backupError = error.localizedDescription
      }
    }
    .alert(
      "Sauvegarde indisponible",
      isPresented: Binding(
        get: { backupError != nil },
        set: { if !$0 { backupError = nil } }
      )
    ) {
      Button("OK", role: .cancel) { backupError = nil }
    } message: {
      Text(backupError ?? "Erreur inconnue")
    }
  }

  private var athleteRosterCard: some View {
    VStack(alignment: .leading, spacing: 13) {
      HStack {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Athlètes locaux")
          Text("Basculez de profil sans mélanger les séances, vidéos ou perches.")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        }
        Spacer()
        Text("\(profiles.count)")
          .font(.title3.monospacedDigit().weight(.black))
      }

      ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 10) {
          ForEach(profiles.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }) { item in
            Button {
              appState.selectedAthleteID = item.id
              Haptics.selection()
            } label: {
              HStack(spacing: 9) {
                Text(item.displayName.prefix(1).uppercased())
                  .font(.headline.weight(.black))
                  .frame(width: 34, height: 34)
                  .background(Color.white.opacity(0.16), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                  Text(item.displayName)
                    .font(.subheadline.weight(.black))
                  Text(item.category)
                    .font(.caption2)
                    .opacity(0.72)
                }
              }
              .padding(.horizontal, 13)
              .padding(.vertical, 10)
              .foregroundStyle(appState.selectedAthleteID == item.id ? Color.white : Color.vaultText)
              .background(
                appState.selectedAthleteID == item.id ? Color.vaultNavy : Color.vaultPanelRaised,
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
              )
            }
            .buttonStyle(.plain)
          }

          Button {
            showingNewAthlete = true
          } label: {
            Label("Ajouter", systemImage: "plus")
              .font(.subheadline.weight(.bold))
              .padding(.horizontal, 15)
              .padding(.vertical, 16)
          }
          .buttonStyle(.bordered)
        }
      }
    }
    .vaultCard(background: Color.vaultNavy.opacity(0.035))
  }

  private var iPadWorkspaceCard: some View {
    HStack(spacing: 18) {
      Image(systemName: "ipad.gen2")
        .font(.system(size: 34, weight: .bold))
        .foregroundStyle(Color.vaultCyan)
        .frame(width: 64, height: 64)
        .background(Color.vaultCyan.opacity(0.09), in: RoundedRectangle(cornerRadius: 18))

      VStack(alignment: .leading, spacing: 5) {
        Text("Espace de travail natif sur iPad")
          .font(.headline.weight(.black))
        Text("L’application fonctionne comme projet Swift Playground, conserve les données hors connexion et peut exporter une sauvegarde JSON vers Fichiers ou iCloud Drive.")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
      }

      Spacer()

      Button { showingExportScope = true } label: {
        Label("Sauvegarder maintenant", systemImage: "externaldrive.badge.checkmark")
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultCyan)
    }
    .vaultCard(background: Color.vaultCyan.opacity(0.04))
  }

  private func exportBackup(scope: VaultBackupScope) {
    do {
      backupDocument = VaultBackupDocument(
        data: try VaultDataExportService.makeBackup(context: modelContext, scope: scope)
      )
      backupFilename = VaultDataExportService.suggestedFilename(profile: profile)
      isExportingBackup = true
      Haptics.impact(.light)
    } catch {
      backupError = error.localizedDescription
    }
  }

  private var physicalHistoryCard: some View {
    VStack(alignment: .leading, spacing: 16) {
      HStack {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Historique des mesures")
          Text(selectedMetricKind.title)
            .font(.title2.weight(.black))
        }
        Spacer()
        Picker("Mesure", selection: $selectedMetricKind) {
          ForEach(PhysicalMetricKind.userSelectableCases) { kind in
            Text(kind.title).tag(kind)
          }
        }
        .pickerStyle(.menu)
      }

      let points =
        metrics
        .filter { $0.athleteID == profile?.id && $0.kind == selectedMetricKind }
        .sorted { $0.measuredAt < $1.measuredAt }

      if points.isEmpty {
        Text("Aucune mesure de \(selectedMetricKind.title.lowercased()) pour le moment.")
          .foregroundStyle(Color.vaultMuted)
          .frame(maxWidth: .infinity, minHeight: 180)
      } else {
        Chart(points) { point in
          LineMark(
            x: .value("Date", point.measuredAt),
            y: .value(selectedMetricKind.title, point.value)
          )
          .interpolationMethod(.catmullRom)
          .foregroundStyle(Color.vaultCyan)
          .lineStyle(StrokeStyle(lineWidth: 4, lineCap: .round))

          PointMark(
            x: .value("Date", point.measuredAt),
            y: .value(selectedMetricKind.title, point.value)
          )
          .foregroundStyle(Color.vaultText)
          .symbolSize(45)
        }
        .chartXAxis {
          AxisMarks(values: .automatic(desiredCount: 6)) { _ in
            AxisGridLine().foregroundStyle(Color.vaultLine)
            AxisValueLabel(format: .dateTime.month(.abbreviated))
              .foregroundStyle(Color.vaultMuted)
          }
        }
        .chartYAxis {
          AxisMarks(position: .leading) { _ in
            AxisGridLine().foregroundStyle(Color.vaultLine)
            AxisValueLabel().foregroundStyle(Color.vaultMuted)
          }
        }
        .frame(height: 280)
      }

      Divider().overlay(Color.vaultLine)

      ForEach(Array(points.reversed().prefix(6))) { point in
        HStack {
          VStack(alignment: .leading, spacing: 3) {
            Text(String(format: "%.2f %@", point.value, point.unit))
              .font(.headline.monospacedDigit().weight(.black))
            Text(
              [point.source, point.protocolName].filter { !$0.isEmpty }.joined(separator: " · ")
            )
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
          }
          Spacer()
          Text(point.measuredAt.formatted(date: .abbreviated, time: .omitted))
            .font(.caption.monospacedDigit())
            .foregroundStyle(Color.vaultMuted)
        }
      }
    }
    .vaultCard()
  }
}

private struct FFAIntegrationCard: View {
  @Environment(\.modelContext) private var modelContext
  @Query(sort: \OfficialPerformanceRecord.date, order: .reverse) private var officialRecords: [OfficialPerformanceRecord]
  @Bindable var profile: AthleteProfile
  @AppStorage("ffa.backendURL") private var backendURLString = ""
  @State private var message: String?
  @State private var candidates: [FFAAthleteDTO] = []
  @State private var isSearching = false
  @State private var isSyncing = false
  @State private var showConfiguration = false

  private var profileRecords: [OfficialPerformanceRecord] {
    officialRecords.filter { $0.athleteID == profile.id }
  }

  var body: some View {
    VStack(alignment: .leading, spacing: 14) {
      SectionEyebrow(text: "Fédération Française d’Athlétisme")
      HStack {
        VStack(alignment: .leading, spacing: 3) {
          Text(profile.ffaAthleteID.isEmpty ? "Associer un profil FFA" : "Profil FFA associé")
            .font(.title3.weight(.black))
          if !profile.ffaAthleteID.isEmpty {
            Text([profile.firstName, profile.lastName, profile.ffaLinkedClub].filter { !$0.isEmpty }.joined(separator: " · "))
              .font(.footnote)
              .foregroundStyle(Color.vaultMuted)
          }
        }
        Spacer()
        if !profile.ffaAthleteID.isEmpty {
          Label(syncStatusTitle, systemImage: isSyncing ? "arrow.triangle.2.circlepath" : "checkmark.seal.fill")
            .font(.caption.weight(.bold))
            .foregroundStyle(profile.ffaSyncStatusRaw == FFASyncStatus.failed.rawValue ? Color.vaultWarning : Color.vaultSuccess)
        }
      }

      Text("Les résultats officiels sont importés dans un historique distinct des entraînements. L’iPad passe par un adaptateur autorisé et ne scrape pas directement athle.fr.")
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)

      HStack(spacing: 10) {
        TextField("Prénom", text: $profile.firstName).textFieldStyle(.roundedBorder)
        TextField("Nom", text: $profile.lastName).textFieldStyle(.roundedBorder)
      }
      HStack(spacing: 10) {
        TextField("Club", text: $profile.clubName).textFieldStyle(.roundedBorder)
        TextField("Licence / PPS (optionnel)", text: $profile.licenseNumber).textFieldStyle(.roundedBorder)
      }

      if !candidates.isEmpty {
        VStack(alignment: .leading, spacing: 8) {
          Text("Choisissez l’athlète correspondant")
            .font(.caption.weight(.bold))
          ForEach(candidates) { candidate in
            Button {
              link(candidate)
            } label: {
              HStack {
                VStack(alignment: .leading) {
                  Text(candidate.displayName).font(.subheadline.weight(.bold))
                  Text([candidate.club, candidate.birthYear.map(String.init), candidate.licenseOrPPS].compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.caption).foregroundStyle(Color.vaultMuted)
                }
                Spacer()
                Image(systemName: "link")
              }
            }
            .buttonStyle(.bordered)
          }
        }
      }

      if let date = profile.ffaLastSyncAt {
        Text("Dernière synchronisation : \(date.formatted(date: .abbreviated, time: .shortened)) · \(profileRecords.count) résultat(s) officiel(s) conservé(s).")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }

      HStack {
        if profile.ffaAthleteID.isEmpty {
          Button {
            Task { await search() }
          } label: {
            Label(isSearching ? "Recherche…" : "Rechercher mon profil FFA", systemImage: "person.text.rectangle")
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAccent)
          .disabled(isSearching || profile.lastName.trimmingCharacters(in: .whitespaces).isEmpty)
        } else {
          Button {
            Task { await synchronize(force: true) }
          } label: {
            Label(isSyncing ? "Synchronisation…" : "Actualiser", systemImage: "arrow.clockwise")
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAccent)
          .disabled(isSyncing)

          Button(role: .destructive) { unlink() } label: {
            Label("Dissocier", systemImage: "link.badge.minus")
          }
          .buttonStyle(.bordered)
        }
        Spacer()
        Button("Détails") { showConfiguration.toggle() }.buttonStyle(.bordered)
      }

      if showConfiguration {
        VStack(alignment: .leading, spacing: 8) {
          Text("Adaptateur FFA").font(.caption.weight(.bold))
          TextField("https://votre-adaptateur.example", text: $backendURLString)
            .textFieldStyle(.roundedBorder)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
          Text("L’adresse est une configuration locale de l’app. Aucun identifiant privé FFA n’est stocké dans le client.")
            .font(.caption2).foregroundStyle(Color.vaultMuted)
        }
      }

      if let message {
        Text(message).font(.footnote).foregroundStyle(Color.vaultMuted)
      }
    }
    .vaultCard()
  }

  private var syncStatusTitle: String {
    switch FFASyncStatus(rawValue: profile.ffaSyncStatusRaw) {
    case .syncing: return "Synchronisation"
    case .success: return "À jour"
    case .failed: return "Erreur"
    case .linked: return "Associé"
    default: return "Associé"
    }
  }

  private func provider() throws -> RemoteFFAProvider {
    guard let url = URL(string: backendURLString), let scheme = url.scheme, ["https", "http"].contains(scheme) else {
      throw FFAError.invalidConfiguration
    }
    return RemoteFFAProvider(baseURL: url)
  }

  private func search() async {
    isSearching = true; defer { isSearching = false }
    do {
      let year = profile.dateOfBirth.map { Calendar.current.component(.year, from: $0) }
      candidates = try await provider().searchAthletes(
        FFAAthleteSearchQuery(firstName: profile.firstName, lastName: profile.lastName,
                              licenseOrPPS: profile.licenseNumber, birthYear: year, club: profile.clubName)
      )
      message = candidates.isEmpty ? "Aucun athlète correspondant. Vérifiez l’identité ou la configuration de l’adaptateur." : nil
    } catch { message = error.localizedDescription; Haptics.error() }
  }

  private func link(_ candidate: FFAAthleteDTO) {
    profile.ffaAthleteID = candidate.id
    profile.firstName = candidate.firstName
    profile.lastName = candidate.lastName
    profile.ffaLinkedClub = candidate.club ?? ""
    if profile.clubName.isEmpty { profile.clubName = candidate.club ?? "" }
    if profile.licenseNumber.isEmpty { profile.licenseNumber = candidate.licenseOrPPS ?? "" }
    profile.ffaSyncStatusRaw = FFASyncStatus.linked.rawValue
    profile.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    candidates = []
    Task { await synchronize(force: false) }
  }

  private func synchronize(force: Bool) async {
    guard !profile.ffaAthleteID.isEmpty else { return }
    isSyncing = true
    profile.ffaSyncStatusRaw = FFASyncStatus.syncing.rawValue
    PersistenceIssueCenter.shared.save(modelContext)
    defer { isSyncing = false }
    do {
      let performances = try await provider().performances(athleteID: profile.ffaAthleteID, forceRefresh: force)
      let result = try FFAImportService().merge(athlete: profile, performances: performances, context: modelContext)
      message = "Synchronisation terminée : \(result.inserted) ajouté(s), \(result.updated) actualisé(s)."
      Haptics.success()
    } catch {
      profile.ffaSyncStatusRaw = FFASyncStatus.failed.rawValue
      PersistenceIssueCenter.shared.save(modelContext)
      message = error.localizedDescription
      Haptics.error()
    }
  }

  private func unlink() {
    profile.ffaAthleteID = ""
    profile.ffaLinkedClub = ""
    profile.ffaSyncStatusRaw = FFASyncStatus.unlinked.rawValue
    profile.updatedAt = .now
    PersistenceIssueCenter.shared.save(modelContext)
    message = "Profil FFA dissocié. Les résultats déjà importés restent conservés localement."
    Haptics.selection()
  }
}

private struct ProfileEditorCard: View {
  @Environment(\.modelContext) private var modelContext
  @Bindable var profile: AthleteProfile

  var body: some View {
    VStack(alignment: .leading, spacing: 16) {
      SectionEyebrow(text: "Athlète")

      TextField("Nom affiché", text: $profile.displayName)
        .font(.title2.weight(.black))
        .textFieldStyle(.plain)
        .padding(12)
        .background(
          Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))

      HStack(spacing: 12) {
        editableNumber(
          title: "Taille",
          value: $profile.heightCM,
          suffix: "cm",
          range: 0...230,
          step: 0.5
        )
        editableNumber(
          title: "Poids",
          value: $profile.bodyWeightKG,
          suffix: "kg",
          range: 0...150,
          step: 0.1
        )
      }

      TextField("Catégorie", text: $profile.category)
        .textFieldStyle(.roundedBorder)

      Divider().overlay(Color.vaultLine)

      Stepper(value: $profile.currentPRCM, in: 0...700, step: 1) {
        LabeledContent(
          "Record officiel", value: String(format: "%.2f m", Double(profile.currentPRCM) / 100))
      }
      Stepper(value: $profile.trainingPRCM, in: 0...700, step: 1) {
        LabeledContent(
          "Record à l’entraînement", value: String(format: "%.2f m", Double(profile.trainingPRCM) / 100))
      }
      Stepper(value: $profile.targetHeightCM, in: 0...700, step: 5) {
        LabeledContent(
          "Objectif principal", value: String(format: "%.2f m", Double(profile.targetHeightCM) / 100))
      }

      Button {
        let estimate = VaultPhysicsModel().estimate(
          targetHeightCM: profile.targetHeightCM,
          athleteHeightCM: profile.heightCM,
          currentSpeed: 0
        )
        profile.targetApproachSpeed = estimate.targetSpeed
        profile.updatedAt = .now
        PersistenceIssueCenter.shared.save(modelContext)
        Haptics.success()
      } label: {
        Label("Enregistrer le profil", systemImage: "checkmark.circle.fill")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultAccent)
    }
    .vaultCard()
  }

  private func editableNumber(
    title: String,
    value: Binding<Double>,
    suffix: String,
    range: ClosedRange<Double>,
    step: Double
  ) -> some View {
    VStack(alignment: .leading, spacing: 6) {
      Text(title.uppercased())
        .font(.caption2.weight(.black))
        .tracking(1)
        .foregroundStyle(Color.vaultMuted)
      HStack {
        TextField("0", value: value, format: .number.precision(.fractionLength(1)))
          .keyboardType(.decimalPad)
          .font(.headline.monospacedDigit().weight(.black))
        Text(suffix)
          .foregroundStyle(Color.vaultMuted)
      }
      Stepper("", value: value, in: range, step: step)
        .labelsHidden()
    }
    .padding(12)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    .frame(maxWidth: .infinity)
  }
}

private struct SpeedPotentialCard: View {
  @Environment(\.modelContext) private var modelContext
  @Bindable var profile: AthleteProfile
  let currentApproachSpeed: Double

  private var estimate: VaultPhysicsModel.Estimate {
    VaultPhysicsModel().estimate(
      targetHeightCM: profile.targetHeightCM,
      athleteHeightCM: profile.heightCM,
      currentSpeed: currentApproachSpeed
    )
  }

  var body: some View {
    VStack(alignment: .leading, spacing: 18) {
      SectionEyebrow(text: "Modèle énergétique vitesse–hauteur")

      VaultVerticalSpeedGauge(
        current: currentApproachSpeed,
        target: estimate.targetSpeed,
        progress: estimate.energyProgress
      )
      .frame(maxWidth: .infinity, minHeight: 320)

      HStack(spacing: 12) {
        VStack(alignment: .leading, spacing: 6) {
          Text("VITESSE ACTUELLE")
            .font(.caption2.weight(.black))
            .tracking(1)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", currentApproachSpeed))
            .font(.headline.monospacedDigit().weight(.black))
          Text("Dernière mesure enregistrée")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        }
        .padding(12)
        .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12))
        .frame(maxWidth: .infinity, alignment: .leading)
        VStack(alignment: .leading, spacing: 6) {
          Text("VITESSE THÉORIQUE CIBLE")
            .font(.caption2.weight(.black))
            .tracking(1)
            .foregroundStyle(Color.vaultMuted)
          Text(String(format: "%.2f m/s", estimate.targetSpeed))
            .font(.headline.monospacedDigit().weight(.black))
            .foregroundStyle(Color.vaultAccent)
          Text("Calculée depuis l’objectif principal")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        }
        .padding(12)
        .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12))
        .frame(maxWidth: .infinity, alignment: .leading)
      }

      HStack(spacing: 12) {
        MetricPill(
          title: "Énergie actuelle",
          value: String(format: "%.1f J/kg", estimate.currentSpecificKineticEnergy),
          tint: .vaultCyan
        )
        MetricPill(
          title: "Énergie cible",
          value: String(format: "%.1f J/kg", estimate.targetSpecificKineticEnergy),
          tint: .vaultAccent
        )
      }

      Stepper(value: $profile.theoreticalMaximumCM, in: 0...750, step: 5) {
        LabeledContent(
          "Potentiel théorique",
          value: String(format: "%.2f m", Double(profile.theoreticalMaximumCM) / 100)
        )
      }

      Text(
        "La jauge utilise l’énergie cinétique spécifique (½v²) : passer de 8 à 9 m/s demande davantage d’énergie que passer de 7 à 8 m/s. La vitesse cible est une estimation mécanique, pas une garantie de franchissement. \(estimate.modelVersion)."
      )
      .font(.footnote)
      .foregroundStyle(Color.vaultMuted)

      Button {
        profile.targetApproachSpeed = estimate.targetSpeed
        profile.updatedAt = .now
        PersistenceIssueCenter.shared.save(modelContext)
        Haptics.success()
      } label: {
        Label("Enregistrer le modèle calculé", systemImage: "function")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.bordered)
    }
    .vaultCard(background: Color.vaultCyan.opacity(0.05))
  }

  private func speedInput(_ title: String, value: Binding<Double>) -> some View {
    VStack(alignment: .leading, spacing: 6) {
      Text(title.uppercased())
        .font(.caption2.weight(.black))
        .tracking(1)
        .foregroundStyle(Color.vaultMuted)
      HStack {
        TextField("0.00", value: value, format: .number.precision(.fractionLength(2)))
          .keyboardType(.decimalPad)
          .font(.headline.monospacedDigit().weight(.black))
        Text("m/s").foregroundStyle(Color.vaultMuted)
      }
    }
    .padding(12)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12))
    .frame(maxWidth: .infinity)
  }
}

private struct MeasurementEditorView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  let athleteID: UUID
  let defaultKind: PhysicalMetricKind

  @State private var kind: PhysicalMetricKind
  @State private var value = 0.0
  @State private var source = "Manuel"
  @State private var protocolName = ""
  @State private var note = ""
  @State private var approach: ApproachLength = .fourteen
  @State private var includeApproach = false
  @State private var measuredAt = Date.now

  init(athleteID: UUID, defaultKind: PhysicalMetricKind) {
    self.athleteID = athleteID
    self.defaultKind = defaultKind
    _kind = State(initialValue: defaultKind)
  }

  var body: some View {
    NavigationStack {
      Form {
        Section("Mesure") {
          Picker("Mesure", selection: $kind) {
            ForEach(PhysicalMetricKind.userSelectableCases) { item in
              Text(item.title).tag(item)
            }
          }
          HStack {
            TextField("Valeur", value: $value, format: .number.precision(.fractionLength(2)))
              .keyboardType(.decimalPad)
            Text(kind.defaultUnit)
              .foregroundStyle(.secondary)
          }
          DatePicker("Date", selection: $measuredAt, displayedComponents: [.date, .hourAndMinute])
        }

        Section("Méthode") {
          Picker("Source", selection: $source) {
            Text("Manuel").tag("Manuel")
            Text("Vidéo").tag("Vidéo")
            Text("Cellules photoélectriques").tag("Cellules photoélectriques")
            Text("Importé").tag("Importé")
          }
          TextField("Protocole", text: $protocolName)
          Toggle("Associer un nombre de foulées", isOn: $includeApproach)
          if includeApproach {
            Picker("Course d’élan", selection: $approach) {
              ForEach(ApproachLength.allCases) { item in
                Text(item.title).tag(item)
              }
            }
          }
        }

        Section("Commentaires") {
          VaultCommentEditor(
            text: $note,
            placeholder: "Conditions, sensations, protocole détaillé, douleur éventuelle et remarques…",
            minHeight: 190
          )
        }
      }
      .navigationTitle("Ajouter une mesure")
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Annuler") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Enregistrer") { save() }
            .disabled(value <= 0)
        }
      }
    }
  }

  private func save() {
    modelContext.insert(
      PhysicalMetricRecord(
        athleteID: athleteID,
        kind: kind,
        value: value,
        source: source,
        protocolName: protocolName,
        approach: includeApproach ? approach : nil,
        measuredAt: measuredAt,
        note: note
      )
    )
    PersistenceIssueCenter.shared.save(modelContext)
    Haptics.success()
    dismiss()
  }
}
