import AVKit
import SafariServices
import SwiftUI
import UIKit

struct ExerciseVideoPlayerView: View {
  @Environment(\.dismiss) private var dismiss
  @Environment(\.openURL) private var openURL

  let title: String
  let url: URL

  private var isDirectMedia: Bool {
    ["mp4", "mov", "m4v", "m3u8"].contains(url.pathExtension.lowercased())
  }

  var body: some View {
    NavigationStack {
      Group {
        if isDirectMedia {
          DirectExerciseVideoPlayer(url: url)
        } else {
          ExerciseVideoBrowser(url: url)
            .ignoresSafeArea(edges: .bottom)
        }
      }
      .navigationTitle(title)
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .topBarLeading) {
          Button("Fermer") { dismiss() }
        }
        ToolbarItem(placement: .topBarTrailing) {
          Button {
            openURL(url)
          } label: {
            Label("Ouvrir dans le navigateur", systemImage: "safari")
          }
        }
      }
    }
  }
}

private struct DirectExerciseVideoPlayer: View {
  let url: URL
  @State private var player: AVPlayer

  init(url: URL) {
    self.url = url
    _player = State(initialValue: AVPlayer(url: url))
  }

  var body: some View {
    VideoPlayer(player: player)
      .background(Color.black)
      .onAppear { player.play() }
      .onDisappear { player.pause() }
  }
}

private struct ExerciseVideoBrowser: UIViewControllerRepresentable {
  let url: URL

  func makeUIViewController(context: Context) -> SFSafariViewController {
    let configuration = SFSafariViewController.Configuration()
    configuration.entersReaderIfAvailable = false
    configuration.barCollapsingEnabled = true
    let controller = SFSafariViewController(url: url, configuration: configuration)
    controller.dismissButtonStyle = .close
    controller.preferredControlTintColor = UIColor(Color.vaultNavy)
    return controller
  }

  func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}
