import SwiftData
import SwiftUI

private struct ExerciseVideoEditorRoute: Identifiable {
  let id = UUID()
  let category: ExerciseVideoCategory
  let video: ExerciseVideoRecord?
}

private struct ExerciseVideoPlayerRoute: Identifiable {
  let id = UUID()
  let title: String
  let url: URL
}

private enum TrainingLibraryLayout: String, CaseIterable, Identifiable {
  case grid
  case list

  var id: String { rawValue }

  var symbol: String {
    switch self {
    case .grid: "square.grid.2x2"
    case .list: "list.bullet"
    }
  }

  var accessibilityTitle: String {
    switch self {
    case .grid: "Affichage en grille"
    case .list: "Affichage en liste"
    }
  }
}

struct DrillLibraryView: View {
  @Environment(\.modelContext) private var modelContext
  @Query(sort: \ExerciseVideoRecord.createdAt, order: .reverse) private var exerciseVideos:
    [ExerciseVideoRecord]

  @State private var searchText = ""
  @State private var selectedCategory: ExerciseVideoCategory?
  @State private var libraryLayout: TrainingLibraryLayout = .grid
  @State private var videoEditorRoute: ExerciseVideoEditorRoute?
  @State private var videoPlayerRoute: ExerciseVideoPlayerRoute?
  @State private var videoPendingDeletion: ExerciseVideoRecord?

  private var filteredVideos: [ExerciseVideoRecord] {
    let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)

    return exerciseVideos.filter { video in
      let categoryMatches = selectedCategory == nil || video.category == selectedCategory
      guard categoryMatches else { return false }
      guard !query.isEmpty else { return true }

      let host = ExerciseVideoURL.normalized(from: video.urlString)
        .map { ExerciseVideoURL.displayHost(for: $0) } ?? ""
      return [video.title, video.videoDescription, video.category.title, host]
        .contains { $0.localizedCaseInsensitiveContains(query) }
    }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 22) {
        Text("Bibliothèque d’entraînement")
          .font(.headline.weight(.black))
          .frame(maxWidth: .infinity)
          .accessibilityAddTraits(.isHeader)

        trainingLibraryHero
        searchBar
        categoryFilters
        resultsToolbar
        videoResults
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .sheet(item: $videoEditorRoute) { route in
      NavigationStack {
        ExerciseVideoEditorSheet(category: route.category, existingVideo: route.video)
      }
      .presentationDetents([.large])
      .presentationDragIndicator(.visible)
    }
    .fullScreenCover(item: $videoPlayerRoute) { route in
      ExerciseVideoPlayerView(title: route.title, url: route.url)
    }
    .alert(
      "Supprimer cette vidéo ?",
      isPresented: Binding(
        get: { videoPendingDeletion != nil },
        set: { if !$0 { videoPendingDeletion = nil } }
      )
    ) {
      Button("Supprimer", role: .destructive) { deletePendingVideo() }
      Button("Annuler", role: .cancel) { videoPendingDeletion = nil }
    } message: {
      Text("Le lien, son titre, sa vignette et sa description seront retirés de la bibliothèque.")
    }
  }

  private var trainingLibraryHero: some View {
    HStack(alignment: .center, spacing: 20) {
      Image(systemName: "play.rectangle.fill")
        .font(.system(size: 31, weight: .bold))
        .foregroundStyle(Color.white)
        .frame(width: 64, height: 64)
        .background(Color.vaultNavy, in: RoundedRectangle(cornerRadius: 17, style: .continuous))

      VStack(alignment: .leading, spacing: 7) {
        Text("Bibliothèque d’entraînement")
          .font(.system(.title, design: .rounded, weight: .black))
          .foregroundStyle(Color.vaultNavy)
        Text("\(videoCountText(exerciseVideos.count)) dans \(ExerciseVideoCategory.allCases.count) catégories")
          .font(.subheadline.weight(.medium))
          .foregroundStyle(Color.vaultMuted)
      }

      Spacer(minLength: 0)
    }
    .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
    .vaultCard(padding: 24)
  }

  private var searchBar: some View {
    HStack(spacing: 14) {
      HStack(spacing: 11) {
        Image(systemName: "magnifyingglass")
          .font(.title3.weight(.semibold))
          .foregroundStyle(Color.vaultMuted)

        TextField("Rechercher des vidéos ou catégories", text: $searchText)
          .textInputAutocapitalization(.never)
          .submitLabel(.search)

        if !searchText.isEmpty {
          Button {
            searchText = ""
            Haptics.selection()
          } label: {
            Image(systemName: "xmark.circle.fill")
              .foregroundStyle(Color.vaultMuted)
          }
          .buttonStyle(.plain)
          .accessibilityLabel("Effacer la recherche")
        }
      }
      .padding(.horizontal, 18)
      .frame(height: 54)
      .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
      .overlay {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
          .stroke(Color.vaultLine, lineWidth: 1)
      }

      Button {
        presentAddVideo()
      } label: {
        Image(systemName: "plus")
          .font(.title2.weight(.black))
          .foregroundStyle(Color.white)
          .frame(width: 54, height: 54)
          .background(Color.vaultAccent, in: Circle())
          .shadow(color: Color.vaultAccent.opacity(0.24), radius: 10, y: 4)
      }
      .buttonStyle(.plain)
      .accessibilityLabel("Ajouter une vidéo")
      .accessibilityHint("Ouvre le formulaire avec le choix de la catégorie")
    }
  }

  private var categoryFilters: some View {
    ScrollView(.horizontal, showsIndicators: false) {
      HStack(spacing: 9) {
        categoryChip(
          title: "All",
          count: exerciseVideos.count,
          selected: selectedCategory == nil
        ) {
          selectedCategory = nil
        }

        ForEach(ExerciseVideoCategory.allCases) { category in
          categoryChip(
            title: category.title,
            count: videoCount(for: category),
            selected: selectedCategory == category
          ) {
            selectedCategory = category
          }
        }
      }
      .padding(.vertical, 2)
    }
  }

  private func categoryChip(
    title: String,
    count: Int,
    selected: Bool,
    action: @escaping () -> Void
  ) -> some View {
    Button {
      action()
      Haptics.selection()
    } label: {
      HStack(spacing: 6) {
        Text(title)
        Text("\(count)")
          .monospacedDigit()
          .foregroundStyle(selected ? Color.white.opacity(0.78) : Color.vaultMuted)
      }
      .font(.subheadline.weight(.bold))
      .foregroundStyle(selected ? Color.white : Color.vaultText)
      .padding(.horizontal, 15)
      .frame(height: 40)
      .background(
        selected ? Color.vaultNavy : Color.vaultPanel,
        in: Capsule()
      )
      .overlay {
        if !selected {
          Capsule().stroke(Color.vaultLine, lineWidth: 1)
        }
      }
    }
    .buttonStyle(.plain)
    .accessibilityLabel("\(title), \(videoCountText(count))")
    .accessibilityValue(selected ? "Sélectionné" : "Non sélectionné")
  }

  private var resultsToolbar: some View {
    HStack(spacing: 14) {
      VStack(alignment: .leading, spacing: 3) {
        Text(videoCountText(filteredVideos.count))
          .font(.headline.weight(.black))
          .foregroundStyle(Color.vaultText)
        if let selectedCategory {
          Text(selectedCategory.title)
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        }
      }

      Spacer()

      HStack(spacing: 3) {
        ForEach(TrainingLibraryLayout.allCases) { layout in
          Button {
            libraryLayout = layout
            Haptics.selection()
          } label: {
            Image(systemName: layout.symbol)
              .font(.subheadline.weight(.bold))
              .foregroundStyle(libraryLayout == layout ? Color.white : Color.vaultMuted)
              .frame(width: 40, height: 36)
              .background(
                libraryLayout == layout ? Color.vaultNavy : Color.clear,
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
              )
          }
          .buttonStyle(.plain)
          .accessibilityLabel(layout.accessibilityTitle)
          .accessibilityValue(libraryLayout == layout ? "Sélectionné" : "Non sélectionné")
        }
      }
      .padding(4)
      .background(Color.vaultPanel, in: Capsule())
      .overlay { Capsule().stroke(Color.vaultLine, lineWidth: 1) }
    }
  }

  @ViewBuilder
  private var videoResults: some View {
    if filteredVideos.isEmpty {
      libraryEmptyState
    } else if libraryLayout == .grid {
      LazyVGrid(
        columns: [GridItem(.adaptive(minimum: 340), spacing: 18)],
        alignment: .leading,
        spacing: 18
      ) {
        ForEach(filteredVideos) { video in
          ExerciseVideoGridCard(
            video: video,
            onOpen: { open(video) },
            onEdit: { edit(video) },
            onDelete: { videoPendingDeletion = video }
          )
        }
      }
    } else {
      LazyVStack(spacing: 14) {
        ForEach(filteredVideos) { video in
          ExerciseVideoListCard(
            video: video,
            onOpen: { open(video) },
            onEdit: { edit(video) },
            onDelete: { videoPendingDeletion = video }
          )
        }
      }
    }
  }

  private var libraryEmptyState: some View {
    VStack(spacing: 14) {
      Image(systemName: searchText.isEmpty ? "play.rectangle.on.rectangle" : "magnifyingglass")
        .font(.system(size: 34, weight: .semibold))
        .foregroundStyle(Color.vaultCyan)
        .frame(width: 72, height: 72)
        .background(Color.vaultCyan.opacity(0.10), in: Circle())

      Text(searchText.isEmpty ? "Aucune vidéo dans cette sélection" : "Aucun résultat")
        .font(.title3.weight(.black))

      Text(
        searchText.isEmpty
          ? "Ajoutez l’URL d’une vraie vidéo, puis renseignez sa catégorie et sa description."
          : "Essayez un autre titre, une autre catégorie ou effacez la recherche."
      )
      .font(.subheadline)
      .foregroundStyle(Color.vaultMuted)
      .multilineTextAlignment(.center)

      Button {
        if searchText.isEmpty {
          presentAddVideo()
        } else {
          searchText = ""
          Haptics.selection()
        }
      } label: {
        Label(
          searchText.isEmpty ? "Ajouter une vidéo" : "Effacer la recherche",
          systemImage: searchText.isEmpty ? "plus.circle.fill" : "xmark.circle"
        )
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultNavy)
    }
    .frame(maxWidth: .infinity, minHeight: 280)
    .vaultCard(background: Color.vaultPanel.opacity(0.72))
  }

  private func videoCount(for category: ExerciseVideoCategory) -> Int {
    exerciseVideos.lazy.filter { $0.category == category }.count
  }

  private func presentAddVideo() {
    videoEditorRoute = ExerciseVideoEditorRoute(
      category: selectedCategory ?? .warmUp,
      video: nil
    )
    Haptics.selection()
  }

  private func edit(_ video: ExerciseVideoRecord) {
    videoEditorRoute = ExerciseVideoEditorRoute(category: video.category, video: video)
    Haptics.selection()
  }

  private func open(_ video: ExerciseVideoRecord) {
    guard let url = ExerciseVideoURL.normalized(from: video.urlString) else { return }
    videoPlayerRoute = ExerciseVideoPlayerRoute(title: video.title, url: url)
    Haptics.selection()
  }

  private func deletePendingVideo() {
    guard let video = videoPendingDeletion else { return }
    modelContext.delete(video)
    PersistenceIssueCenter.shared.save(
      modelContext,
      operation: "Suppression de la vidéo d’exercice"
    )
    videoPendingDeletion = nil
    Haptics.success()
  }
}

private struct ExerciseVideoGridCard: View {
  let video: ExerciseVideoRecord
  let onOpen: () -> Void
  let onEdit: () -> Void
  let onDelete: () -> Void

  var body: some View {
    VStack(alignment: .leading, spacing: 0) {
      Button(action: onOpen) {
        ExerciseVideoThumbnail(video: video)
          .aspectRatio(16 / 9, contentMode: .fit)
      }
      .buttonStyle(.plain)
      .accessibilityLabel("Ouvrir la vidéo \(video.title)")

      VStack(alignment: .leading, spacing: 10) {
        HStack(alignment: .center, spacing: 10) {
          Text(video.category.title.uppercased())
            .font(.caption2.weight(.black))
            .tracking(0.8)
            .foregroundStyle(Color.vaultCyan)
          Spacer()
          ExerciseVideoActionsMenu(
            title: video.title,
            onEdit: onEdit,
            onDelete: onDelete
          )
        }

        Text(video.title)
          .font(.title3.weight(.black))
          .foregroundStyle(Color.vaultText)
          .lineLimit(2)

        Text(video.videoDescription.isEmpty ? "Aucune description ajoutée." : video.videoDescription)
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
          .lineLimit(3)

        ExerciseVideoSourceLabel(video: video)
      }
      .padding(16)
    }
    .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    .overlay {
      RoundedRectangle(cornerRadius: 20, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
    .shadow(color: Color.vaultText.opacity(0.06), radius: 14, y: 7)
  }
}

private struct ExerciseVideoListCard: View {
  let video: ExerciseVideoRecord
  let onOpen: () -> Void
  let onEdit: () -> Void
  let onDelete: () -> Void

  var body: some View {
    HStack(alignment: .top, spacing: 0) {
      Button(action: onOpen) {
        ExerciseVideoThumbnail(video: video)
          .frame(width: 230, height: 132)
      }
      .buttonStyle(.plain)
      .accessibilityLabel("Ouvrir la vidéo \(video.title)")

      VStack(alignment: .leading, spacing: 8) {
        HStack(spacing: 10) {
          Text(video.category.title.uppercased())
            .font(.caption2.weight(.black))
            .tracking(0.8)
            .foregroundStyle(Color.vaultCyan)
          Spacer()
          ExerciseVideoActionsMenu(
            title: video.title,
            onEdit: onEdit,
            onDelete: onDelete
          )
        }

        Text(video.title)
          .font(.headline.weight(.black))
          .foregroundStyle(Color.vaultText)
          .lineLimit(2)

        Text(video.videoDescription.isEmpty ? "Aucune description ajoutée." : video.videoDescription)
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
          .lineLimit(2)

        Spacer(minLength: 0)
        ExerciseVideoSourceLabel(video: video)
      }
      .padding(15)
    }
    .frame(minHeight: 132)
    .background(Color.vaultPanel, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    .overlay {
      RoundedRectangle(cornerRadius: 18, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }
}

private struct ExerciseVideoThumbnail: View {
  let video: ExerciseVideoRecord

  private var thumbnailURL: URL? {
    guard let value = video.thumbnailURLString else { return nil }
    return URL(string: value)
  }

  var body: some View {
    ZStack {
      thumbnailContent
      LinearGradient(
        colors: [Color.clear, Color.vaultNavy.opacity(0.34)],
        startPoint: .center,
        endPoint: .bottom
      )

      Image(systemName: "play.fill")
        .font(.title3.weight(.black))
        .foregroundStyle(Color.white)
        .frame(width: 50, height: 50)
        .background(Color.vaultNavy.opacity(0.84), in: Circle())
        .overlay { Circle().stroke(Color.white.opacity(0.65), lineWidth: 1) }
        .shadow(color: Color.black.opacity(0.18), radius: 8, y: 3)
    }
    .clipped()
  }

  @ViewBuilder
  private var thumbnailContent: some View {
    if let thumbnailURL {
      AsyncImage(url: thumbnailURL) { image in
        image
          .resizable()
          .scaledToFill()
      } placeholder: {
        thumbnailPlaceholder
      }
    } else {
      thumbnailPlaceholder
    }
  }

  private var thumbnailPlaceholder: some View {
    ZStack {
      LinearGradient(
        colors: [Color.vaultNavyLight, Color.vaultCyan.opacity(0.68)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      )
      Image(systemName: video.category.librarySymbol)
        .font(.system(size: 50, weight: .semibold))
        .foregroundStyle(Color.white.opacity(0.86))
    }
  }
}

private struct ExerciseVideoSourceLabel: View {
  let video: ExerciseVideoRecord

  var body: some View {
    if let url = ExerciseVideoURL.normalized(from: video.urlString) {
      Label(ExerciseVideoURL.displayHost(for: url), systemImage: "arrow.up.right.square")
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.vaultMuted)
        .lineLimit(1)
    } else {
      Label("Adresse invalide", systemImage: "exclamationmark.triangle")
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.red)
    }
  }
}

private struct ExerciseVideoActionsMenu: View {
  let title: String
  let onEdit: () -> Void
  let onDelete: () -> Void

  var body: some View {
    Menu {
      Button(action: onEdit) {
        Label("Modifier", systemImage: "pencil")
      }
      Button(role: .destructive, action: onDelete) {
        Label("Supprimer", systemImage: "trash")
      }
    } label: {
      Image(systemName: "ellipsis.circle")
        .font(.title3)
        .foregroundStyle(Color.vaultMuted)
        .frame(width: 34, height: 30)
    }
    .accessibilityLabel("Actions pour \(title)")
  }
}

private struct ExerciseVideoEditorSheet: View {
  private enum MetadataStatus: Equatable {
    case idle
    case loading
    case success
    case failure(String)
  }

  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @Query private var allVideos: [ExerciseVideoRecord]

  let existingVideo: ExerciseVideoRecord?

  @State private var selectedCategory: ExerciseVideoCategory
  @State private var urlText: String
  @State private var title: String
  @State private var shortDescription: String
  @State private var thumbnailURLString: String
  @State private var lastFetchedURLString: String
  @State private var metadataStatus: MetadataStatus = .idle
  @State private var savingError: String?

  private let descriptionLimit = 280

  init(category: ExerciseVideoCategory, existingVideo: ExerciseVideoRecord?) {
    self.existingVideo = existingVideo
    _selectedCategory = State(initialValue: existingVideo?.category ?? category)
    _urlText = State(initialValue: existingVideo?.urlString ?? "")
    _title = State(initialValue: existingVideo?.title ?? "")
    _shortDescription = State(initialValue: existingVideo?.videoDescription ?? "")
    _thumbnailURLString = State(initialValue: existingVideo?.thumbnailURLString ?? "")
    _lastFetchedURLString = State(initialValue: existingVideo?.urlString ?? "")
  }

  private var normalizedURL: URL? { ExerciseVideoURL.normalized(from: urlText) }

  private var cleanTitle: String {
    title.trimmingCharacters(in: .whitespacesAndNewlines)
  }

  private var canonicalURLString: String? { normalizedURL?.absoluteString }

  private var isDuplicate: Bool {
    guard let canonicalURLString else { return false }
    return allVideos.contains { video in
      video.id != existingVideo?.id
        && video.category == selectedCategory
        && ExerciseVideoURL.normalized(from: video.urlString)?.absoluteString
          == canonicalURLString
    }
  }

  private var canSave: Bool {
    normalizedURL != nil && !cleanTitle.isEmpty && !isDuplicate
      && shortDescription.count <= descriptionLimit
  }

  var body: some View {
    Form {
      Section("Catégorie") {
        Picker("Catégorie de la vidéo", selection: $selectedCategory) {
          ForEach(ExerciseVideoCategory.allCases) { category in
            Label(category.title, systemImage: category.librarySymbol)
              .tag(category)
          }
        }
        .pickerStyle(.navigationLink)
      }

      Section {
        TextField("https://…", text: $urlText)
          .textContentType(.URL)
          .keyboardType(.URL)
          .textInputAutocapitalization(.never)
          .autocorrectionDisabled()
          .submitLabel(.done)

        if !urlText.isEmpty && normalizedURL == nil {
          Label(
            "Saisissez une adresse web http ou https valide.",
            systemImage: "exclamationmark.triangle"
          )
          .font(.caption)
          .foregroundStyle(Color.red)
        }

        metadataStatusView

        Button {
          guard let url = normalizedURL else { return }
          Task { await fetchMetadata(for: url) }
        } label: {
          Label("Récupérer les informations à nouveau", systemImage: "arrow.clockwise")
        }
        .disabled(normalizedURL == nil || metadataStatus == .loading)
      } header: {
        Text("Adresse de la vidéo")
      } footer: {
        Text(
          "Le titre et, lorsque le site la fournit, la vignette sont recherchés automatiquement. YouTube, Vimeo, TikTok et les métadonnées web standard sont pris en charge."
        )
      }

      Section("Titre de la vidéo") {
        TextField("Titre récupéré automatiquement", text: $title, axis: .vertical)
          .lineLimit(2...4)
        Text("Vous pouvez corriger le titre si le site renvoie une formulation incomplète.")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }

      Section("Description courte") {
        VaultCommentEditor(
          text: $shortDescription,
          placeholder: "Objectif de l’exercice, points techniques à observer, niveau conseillé…",
          minHeight: 130
        )
        HStack {
          Text("Visible sous le titre dans la bibliothèque.")
          Spacer()
          Text("\(shortDescription.count) / \(descriptionLimit)")
            .monospacedDigit()
            .foregroundStyle(
              shortDescription.count > descriptionLimit ? Color.red : Color.vaultMuted
            )
        }
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
      }

      if isDuplicate {
        Section {
          Label(
            "Cette URL existe déjà dans la catégorie \(selectedCategory.title).",
            systemImage: "doc.on.doc"
          )
          .foregroundStyle(Color.red)
        }
      }
    }
    .navigationTitle(existingVideo == nil ? "Ajouter une vidéo" : "Modifier la vidéo")
    .navigationBarTitleDisplayMode(.inline)
    .toolbar {
      ToolbarItem(placement: .cancellationAction) {
        Button("Annuler") { dismiss() }
      }
      ToolbarItem(placement: .confirmationAction) {
        Button(existingVideo == nil ? "Ajouter" : "Enregistrer") { save() }
          .fontWeight(.bold)
          .disabled(!canSave)
      }
    }
    .task(id: urlText) { await retrieveMetadataAutomatically() }
    .onChange(of: shortDescription) { _, value in
      if value.count > descriptionLimit {
        shortDescription = String(value.prefix(descriptionLimit))
      }
    }
    .alert(
      "Enregistrement impossible",
      isPresented: Binding(
        get: { savingError != nil },
        set: { if !$0 { savingError = nil } }
      )
    ) {
      Button("OK", role: .cancel) { savingError = nil }
    } message: {
      Text(savingError ?? "Erreur inconnue")
    }
  }

  @ViewBuilder
  private var metadataStatusView: some View {
    switch metadataStatus {
    case .idle:
      EmptyView()
    case .loading:
      HStack(spacing: 9) {
        ProgressView()
        Text("Récupération du titre et de la vignette…")
      }
      .font(.caption)
      .foregroundStyle(Color.vaultMuted)
    case .success:
      Label("Informations récupérées automatiquement", systemImage: "checkmark.circle.fill")
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.vaultSuccess)
    case .failure(let message):
      Label(message, systemImage: "info.circle")
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
    }
  }

  private func retrieveMetadataAutomatically() async {
    guard let url = normalizedURL else {
      metadataStatus = .idle
      return
    }
    guard url.absoluteString != lastFetchedURLString else { return }

    do {
      try await Task.sleep(nanoseconds: 650_000_000)
    } catch {
      return
    }
    guard !Task.isCancelled, url == normalizedURL else { return }
    await fetchMetadata(for: url)
  }

  private func fetchMetadata(for url: URL) async {
    metadataStatus = .loading
    do {
      let metadata = try await ExerciseVideoMetadataService.metadata(for: url)
      guard !Task.isCancelled, url == normalizedURL else { return }
      title = metadata.title
      thumbnailURLString = metadata.thumbnailURL?.absoluteString ?? ""
      lastFetchedURLString = url.absoluteString
      metadataStatus = .success
      Haptics.selection()
    } catch is CancellationError {
      return
    } catch {
      guard url == normalizedURL else { return }
      thumbnailURLString = ""
      metadataStatus = .failure(error.localizedDescription)
    }
  }

  private func save() {
    guard let url = normalizedURL, canSave else { return }
    let description = shortDescription.trimmingCharacters(in: .whitespacesAndNewlines)
    let thumbnail = thumbnailURLString.isEmpty ? nil : thumbnailURLString

    if let existingVideo {
      existingVideo.category = selectedCategory
      existingVideo.urlString = url.absoluteString
      existingVideo.title = cleanTitle
      existingVideo.videoDescription = description
      existingVideo.thumbnailURLString = thumbnail
      existingVideo.updatedAt = .now
    } else {
      modelContext.insert(
        ExerciseVideoRecord(
          category: selectedCategory,
          urlString: url.absoluteString,
          title: cleanTitle,
          videoDescription: description,
          thumbnailURLString: thumbnail
        )
      )
    }

    do {
      try modelContext.save()
      Haptics.success()
      dismiss()
    } catch {
      savingError = error.localizedDescription
      PersistenceIssueCenter.shared.report(
        error,
        operation: "Enregistrement de la vidéo d’exercice"
      )
      Haptics.error()
    }
  }
}

private func videoCountText(_ count: Int) -> String {
  count == 1 ? "1 vidéo" : "\(count) vidéos"
}

private extension ExerciseVideoCategory {
  var librarySymbol: String {
    switch self {
    case .warmUp: "flame.fill"
    case .pvDrills: "figure.run"
    case .medBall: "circle.fill"
    case .strength: "dumbbell.fill"
    case .gym: "figure.gymnastics"
    case .core: "figure.core.training"
    case .plyo: "arrow.up.circle.fill"
    case .flexibility: "figure.flexibility"
    case .rehab: "cross.case.fill"
    case .running: "figure.run"
    }
  }
}
