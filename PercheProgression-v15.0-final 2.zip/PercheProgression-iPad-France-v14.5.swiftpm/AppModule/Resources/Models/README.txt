Détecteur optionnel : PoleVaultSceneDetector.mlmodelc

Le code cherche automatiquement un modèle Core ML compilé portant ce nom.
Classes recommandées : runway, plant_box, zero_line, runway_left_edge, runway_right_edge,
athlete, left_shoe, right_shoe, pole.

Sans ce modèle, l’application reste fonctionnelle et utilise la détection de quadrilatères
Apple Vision puis la correction semi-automatique par quatre poignées.
