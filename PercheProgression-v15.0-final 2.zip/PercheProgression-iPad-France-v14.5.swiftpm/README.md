# Perche Progression v15.0.0

Historique v14.5 :

- sélecteur « Fichiers » réparé avec un seul flux d’import partagé ;
- accès sécurisé et copie coordonnée des vidéos locales/iCloud ;
- 247 vidéos d’exercice intégrées dans leurs dix catégories ;
- amorçage idempotent qui conserve les données déjà présentes ;
- lecteur interne pour les liens directs et les plateformes web ;

- remplacement des anciennes catégories techniques par les dix catégories exactes de la bibliothèque de référence ;
- ordre des filtres : Warm-up, PV Drills, Med Ball, Strength, Gym, Core, Plyo, Flexibility, Rehab et Running ;
- filtre global renommé « All » ;
- compteurs toujours calculés uniquement sur les vidéos réellement enregistrées ;
- migration non destructive des vidéos v14.2 vers les nouvelles catégories ;
- export JSON v6 et version d’application 14.5 (build 33).

Voir `CHANGEMENT_V14_5.md` et `VALIDATION_V14_5.md` pour le détail.

## Version 15.0.0

Cette version remplace les scores radar arbitraires par des mesures traçables, ajoute l’historique officiel FFA, le moteur de décision de perche `pole-decision-v15.0`, l’analyse vidéo perspective unifiée et la caméra distante Pixel.

- Appairage Pixel et récupération : voir `PIXEL_COMPANION.md`.
- Synchronisation FFA : voir `FFA_INTEGRATION.md`.
- Migration : voir `MIGRATION.md`.
- Validation et checklist matériel : voir `VALIDATION.md` et `PHYSICAL_DEVICE_TEST_CHECKLIST.md`.

## Historique v14.2 — bibliothèque d’entraînement vidéo

Nouveautés v14.2 :

- suppression complète de l’interface « Fiches techniques », de ses cartes et de ses filtres ;
- nouvelle bibliothèque inspirée de l’interface de référence : bandeau, recherche, catégories avec compteurs, résultat total et modes grille/liste ;
- cartes vidéo grand format avec vignette distante, titre, description, catégorie et source ;
- bouton d’ajout global avec choix parmi les dix catégories ;
- récupération automatique du titre et de la vignette oEmbed lorsqu’elle est disponible ;
- bibliothèque vide sans contenu d’exemple, avec compteurs calculés uniquement sur les URL réelles ;
- sauvegarde JSON v5 incluant l’URL de vignette ;
- conservation du bundle identifier et des données déjà enregistrées.

Voir `CHANGEMENT_V14_2.md` et `VALIDATION_V14_2.md` pour le détail.

## Historique v14.1.1 — correctif de compilation

Correctifs v14.1.1 :

- initialiseur SwiftUI de la section URL réécrit avec des blocs `content`, `header` et `footer` explicites ;
- récupération LinkPresentation migrée vers `startFetchingMetadata(for:) async` afin de ne plus capturer un objet non `Sendable` ;
- permission microphone migrée vers `AVAudioApplication.requestRecordPermission()` pour iOS 17 et versions ultérieures ;
- aucune modification du schéma SwiftData ni des données sportives.

## Historique v14.1 — bibliothèque vidéo personnalisable

Nouveautés v14.1 :

- suppression des six vidéos de démonstration schématiques intégrées au bundle ;
- vidéothèque vide au premier lancement, organisée en dix catégories : six phases techniques et quatre familles de préparation physique ;
- ajout, modification et suppression d’URL vidéo dans chaque catégorie ;
- récupération automatique du titre via oEmbed ou les métadonnées du lien ;
- description courte personnalisable, contrôle des doublons et ouverture directe de la source ;
- nettoyage non destructif des anciennes références `bundle://` lors de la migration ;
- palette bleu pétrole et violet à contraste renforcé dans tout l’espace Analyse vidéo ;
- sauvegarde JSON v4 incluant les liens de la vidéothèque d’exercices.

## Historique v14.0 — édition fusionnée iPad

Cette version réunit le meilleur du journal d’entraînement moderne présenté dans `Vaults.zip` et le moteur biomécanique de Perche Progression v13.3.

Nouveautés principales :

- accueil synthétique avec record, objectif, vitesse, réussite, séances et actions rapides ;
- historique unifié des séances, sauts et vidéos, avec recherche ;
- contexte de séance complet : lieu, intérieur/extérieur, météo, vent, température, énergie et objectif ;
- détails par saut : qualité technique, hauteur de prise, longueur d’élan, marque intermédiaire, impulsion et poteaux ;
- liaison directe d’une ou plusieurs vidéos à un saut, y compris lors du prochain import ;
- dictée en français avec transcription, extraction locale des champs et validation obligatoire ;
- jalons fondés uniquement sur les données réellement enregistrées ;
- gestion de plusieurs athlètes locaux avec séparation stricte des séances, perches et analyses ;
- identité visuelle bleu marine, orange et ivoire sur les écrans généraux ;
- conservation intégrale du laboratoire vidéo v13.3 : homographies, calibration fixe/oblique, mesures de vitesse, posture, comparaison et PencilKit.

Voir `FUSION_V14.md` pour les choix d’architecture, les fonctions retenues et les limites assumées.

> Historique v13.3 : grille/repères affinés, valeurs de vitesse visibles en mode Mesurer, et bibliothèque enrichie par des ressources vidéo officielles externes.

> **v13.2** : le mode caméra fixe fonctionne désormais même lorsque le butoir est hors champ grâce à une origine métrique relative ; la grille dispose d’un micro-ajustement 1/5 px et le plein écran conserve toutes les couches d’analyse.

> Mise à jour v13.1 : précision de grille renforcée, accès plein écran contextuel dans la vidéo et workflow sans butoir clarifié.

# Perche Progression v12.1 — Swift Playground iPad

Pile : Swift 6, SwiftUI, SwiftData, AVFoundation, Vision/Core ML, PencilKit.

Principales évolutions :
- persistance vidéo stable via `VideoAssetStore`;
- source de vérité unique pour la vitesse;
- `AppStore` + repositories;
- plein écran + timeline frame-aware;
- gestes deux doigts et zoom 8×;
- superposition transformable et offset ±15 s;
- accordéons d’angles;
- saisie manuelle du radar;
- abstraction `FFAProvider` sans scraping direct.


## Correctif v12.1
- correction de la fermeture de calcul des deltas PTS dans `VideoLabViewModel` qui provoquait `Cannot find 'e' in scope`;
- décomposition et typage explicite de l’expression afin d’éviter le timeout du type-checker Swift Playgrounds;
- suppression des avertissements `firstImage` inutilisé et `track` défini mais inutilisé;
- validation syntaxique de l’ensemble des fichiers Swift après correction.


## v12.2 — interactions vidéo corrigées

- Étape 4 : « Commencer la validation du bassin » détecte désormais le perchiste si nécessaire, demande sa sélection lorsqu’il y a plusieurs sujets, puis crée automatiquement les points à 0,1 s.
- Vecteur : retour visuel immédiat sur la vidéo ; glisser crée le vecteur et confirme sa création.
- Posture : un bouton contextuel « Analyser cette image » apparaît directement sur la vidéo lorsque l’outil est actif.
- Impulsion : toucher/glisser sur la pointe du pied valide immédiatement l’instant d’impulsion ; la distance métrique est calculée seulement si une calibration fiable existe.
- Tous les outils donnent désormais un message d’action explicite au lieu de sembler inactifs.

## v12.3 — caméra fixe en vue oblique

Cette version sépare explicitement deux scénarios de mesure :

- **Caméra fixe – vue oblique** : homographie unique du plan de la piste, sans stabilisation du décor.
- **Caméra mobile** : ancien workflow avec repères fixes pour compenser le mouvement caméra.

En mode fixe, l'utilisateur place les quatre coins d'un quadrilatère réel au sol, renseigne sa longueur et sa largeur, puis choisit le point biomécanique suivi :

- **Point au sol (recommandé)** : le point confirmé reste dans le plan calibré et la mesure est interprétée comme une mesure longitudinale de référence monocaméra.
- **Bassin (estimation)** : l'application conserve ce mode pour l'ergonomie, mais signale explicitement l'erreur de parallaxe possible car le bassin n'appartient pas au plan du sol.

La vitesse est calculée après projection dans le repère métrique de piste, uniquement sur l'axe longitudinal X et à partir des PTS réels. Les séquences présentant trop de vitesses ou accélérations non physiologiques sont rejetées avec une demande de recalibration au lieu d'être enregistrées.


## v12.4 — pointeurs de précision

- Les 4 coins de calibration de perspective passent à un repère visuel de 60 pt avec une zone tactile de 88 pt.
- Le point exact est matérialisé par une croix centrale fine et un micro-point.
- Les poignées restent partiellement transparentes pour ne pas masquer le marquage réel de la piste.
- Les étiquettes 0 m G / 0 m D / 5 m G / 5 m D sont agrandies.
- Le bouton central de déplacement de grille est agrandi.
- Les poignées d'étalonnage linéaire utilisent aussi une grande zone tactile et une croix centrale.
- Le point de suivi passe à un marqueur de 58 pt avec croix centrale de précision.
- Les zones tactiles sont plus grandes que les éléments visuels pour faciliter la manipulation au doigt sur iPad.

## v12.4.1 — correction d’installation Swift Playgrounds

- Nettoyage complet de `AppIcon.appiconset` pour une cible iPad iOS 18.
- Suppression des fichiers PNG non assignés (60, 87, 120 et 180 px).
- Suppression de l’entrée iPad 76×76@1x devenue obsolète.
- Conservation uniquement des tailles iPad 2x nécessaires et de l’icône marketing 1024 px.
- Numéro de build incrémenté à 22 et version d’affichage 12.4.1 afin de forcer la reconstruction du preview host.
- Bundle identifier inchangé pour préserver la continuité des données de l’application.


## v13.0 — intégrité quantitative et moteur de décision

- isolation stricte des données par athlète dans Progression et Râtelier ;
- records entraînement/compétition basés sur le vrai type de séance ;
- suppression des comparaisons historiques synthétiques ;
- courbes quantitatives à interpolation linéaire ;
- caméra fixe renommée « face ou biais », avec workflow point au sol réellement indépendant du bassin ;
- score qualité de l’homographie fixe dérivé de la géométrie et de la cohérence cinématique, sans fausse probabilité constante ;
- suivi à homographie dynamique : vitesse principale = déplacement longitudinal métrique / temps PTS réel, pic = P95 ;
- moteur de recommandation de perches `pole-readiness-v13.0` avec score explicable, protocoles de vitesse séparés et signaux bloquants ;
- provenance vidéo enrichie (`groundPlaneReference`, `verticalIsEstimated`, statut estimé/vérifié).
- recalcul manuel du bassin sans confiances 0,94/0,98 artificielles et sans mélange accélération longitudinale/verticale.

Voir `CHANGEMENT_V13.md` pour le détail.