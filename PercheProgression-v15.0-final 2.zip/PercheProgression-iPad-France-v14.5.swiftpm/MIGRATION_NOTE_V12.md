# Note migration SwiftData

La v11.1 ne possédait pas de `VersionedSchema` historique. La v12 **ne fabrique donc pas** un faux schéma v11 : une telle déclaration pourrait rendre un store utilisateur existant incompatible, ce qui contredirait le correctif P0 sur la sécurité des données.

Cette révision :
- supprime tout reset destructif piloté par UserDefaults ;
- conserve un nom de store stable ;
- ajoute uniquement des propriétés avec valeurs par défaut lorsque possible ;
- laisse SwiftData effectuer la migration légère compatible ;
- échoue visiblement si le store ne peut pas être ouvert, sans basculer en mémoire et sans effacer les données.

Pour la prochaine évolution de schéma, figer d’abord un **snapshot v12 réellement expédié et testé sur appareil**, puis l’introduire comme première version d’un `VersionedSchema`/`SchemaMigrationPlan`. La documentation Apple recommande de déclarer les versions de schéma et les étapes de migration explicitement ; l’historique doit toutefois refléter le modèle réellement expédié, pas une reconstruction approximative.
