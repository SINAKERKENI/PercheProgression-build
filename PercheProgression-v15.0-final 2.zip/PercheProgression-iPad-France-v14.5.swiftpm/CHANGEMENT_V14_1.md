# Perche Progression v14.1

## Bibliothèque d’exercices

- Les six clips MP4 schématiques ont été retirés des ressources de l’application.
- Les liens externes présélectionnés ont également été supprimés : aucune vidéo n’est imposée.
- Chaque phase technique — Présentation, Impulsion, Renversement, Extension, Demi-tour et Franchissement — possède un bouton d’ajout d’URL.
- Quatre catégories complémentaires couvrent Abdos & gainage, Gymnastique, Sprint & course d’élan et Force & mobilité.
- Plusieurs vidéos peuvent être enregistrées dans une même catégorie.
- Le titre est recherché automatiquement après la saisie de l’adresse : oEmbed est utilisé pour YouTube, Vimeo et TikTok, puis les métadonnées standard du lien servent de repli.
- Le titre reste modifiable et chaque vidéo accepte une description personnelle de 280 caractères.
- Les doublons dans une même catégorie sont bloqués.
- Les liens peuvent être ouverts, modifiés ou supprimés depuis la bibliothèque et depuis les fiches techniques.

## Migration et données

- Le nouveau modèle SwiftData `ExerciseVideoRecord` conserve la catégorie, l’URL, le titre, la description et les dates de création/modification.
- Au lancement, seules les anciennes références commençant par `bundle://` sont effacées. Les autres liens et toutes les données sportives restent intacts.
- La sauvegarde JSON passe au schéma v4 et inclut `exerciseVideos`.

## Accessibilité de l’analyse vidéo

- L’orange a été retiré de l’ensemble de l’espace Analyse vidéo.
- Les commandes principales utilisent désormais un bleu pétrole foncé à fort contraste sur les panneaux clairs.
- Les états « à vérifier » utilisent un violet distinct, et les repères superposés à l’image un bleu équilibré pour rester visibles sur les plans sombres comme clairs.

## Version

- Version affichée : 14.1
- Build : 28
- Bundle identifier inchangé : `com.tasnim.vaultroadmap.ipad`
