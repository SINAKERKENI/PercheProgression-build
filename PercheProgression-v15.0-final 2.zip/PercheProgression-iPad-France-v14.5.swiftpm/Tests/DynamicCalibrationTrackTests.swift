import XCTest
@testable import AppModule

final class DynamicCalibrationTrackTests: XCTestCase {
  func testManualRequiredSampleNeverFeedsMetric() {
    let matrix = Matrix3x3.identity
    let grid = RunwayGridCalibration()
    let samples = (0..<5).map { index in
      HomographySample(
        timeSeconds: Double(index) / 30.0,
        grid: grid,
        imageToRunway: matrix,
        source: .featureTracking,
        trackedPointCount: 8,
        inlierRatio: 0.9,
        confidence: 0.8,
        estimatedErrorMeters: 0,
        status: index == 2 ? .manualRequired : .reliable
      )
    }
    let track = DynamicCalibrationTrack(
      initialGrid: grid,
      samples: samples,
      startTime: 0,
      endTime: 4.0 / 30.0,
      averageConfidence: 0.8
    )

    XCTAssertNil(track.validatedSample(nearest: 2.0 / 30.0, maximumDelta: 0.001))
    XCTAssertNotNil(track.validatedSample(nearest: 1.0 / 30.0, maximumDelta: 0.001))
  }

  func testTrackRequiresReliableCoverage() {
    let grid = RunwayGridCalibration()
    let samples = (0..<10).map { index in
      HomographySample(
        timeSeconds: Double(index) / 30.0,
        grid: grid,
        imageToRunway: .identity,
        source: .featureTracking,
        trackedPointCount: 8,
        inlierRatio: 0.9,
        confidence: 0.8,
        estimatedErrorMeters: 0,
        status: index < 7 ? .reliable : .manualRequired
      )
    }
    XCTAssertFalse(DynamicCalibrationTrack(initialGrid: grid, samples: samples).isUsable)
  }
}
