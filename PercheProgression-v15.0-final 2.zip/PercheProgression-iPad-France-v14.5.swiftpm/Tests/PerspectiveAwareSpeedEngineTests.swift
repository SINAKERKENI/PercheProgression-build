import XCTest
@testable import AppModule

final class PerspectiveAwareSpeedEngineTests: XCTestCase {
  private let cameras = [
    Matrix3x3(m11: 0.070, m12: 0.010, m13: 0.10, m21: 0.005, m22: 0.18, m23: 0.55, m31: 0.004, m32: 0.002, m33: 1),
    Matrix3x3(m11: 0.055, m12: 0.030, m13: 0.12, m21: -0.012, m22: 0.17, m23: 0.68, m31: 0.018, m32: 0.008, m33: 1),
    Matrix3x3(m11: 0.040, m12: 0.045, m13: 0.18, m21: -0.020, m22: 0.15, m23: 0.76, m31: 0.035, m32: 0.012, m33: 1),
    Matrix3x3(m11: 0.052, m12: -0.035, m13: 0.28, m21: -0.015, m22: 0.16, m23: 0.72, m31: 0.022, m32: -0.010, m33: 1),
  ]

  private func inversePipeline(_ camera: Matrix3x3) throws -> Matrix3x3 {
    let world = [
      MetricRunwayPoint(xMeters: 0, yMeters: 0), MetricRunwayPoint(xMeters: 0, yMeters: 1.2),
      MetricRunwayPoint(xMeters: 10, yMeters: 0), MetricRunwayPoint(xMeters: 10, yMeters: 1.2),
    ]
    let image = world.compactMap { camera.project(.init(x: $0.xMeters, y: $0.yMeters)) }
    return try HomographyMath.imageToRunway(source: image, destination: world)
  }

  private func analyze(camera: Matrix3x3, noise: Double = 0, outliers: Set<Int> = [],
                       variablePTS: Bool = false, calibrationQuality: Double = 0.95) throws -> PerspectiveAwareSpeedEngine.Result {
    let h = try inversePipeline(camera)
    var time = 0.0
    var observations: [PerspectiveAwareSpeedEngine.Observation] = []
    for index in 0...60 {
      if index > 0 { time += variablePTS ? 1.0 / 48.0 + Double((index % 5) - 2) * 0.0007 : 1.25 / 60.0 }
      let x = min(8.0 * time, 10.0)
      var image = try XCTUnwrap(camera.project(.init(x: x, y: 0.6)))
      image.x += noise * sin(Double(index) * 1.7); image.y += noise * cos(Double(index) * 1.3)
      if outliers.contains(index) { image.x += 0.04; image.y -= 0.035 }
      let metric = try XCTUnwrap(h.projectMetric(image))
      observations.append(.init(timeSeconds: time, imagePoint: image, runwayPoint: metric,
        trackingConfidence: 0.95, groundPointConfidence: 0.93, calibrationQuality: calibrationQuality,
        anchorCount: 8, anchorStability: 0.94, homographyContinuity: 0.95, groundPointMethod: .supportAnkle))
    }
    return try PerspectiveAwareSpeedEngine().analyze(observations, expectedStartTime: 0, expectedEndTime: time)
  }

  func testLowObliqueRecoversKnownSpeed() throws { XCTAssertLessThan(abs(try analyze(camera: cameras[0]).meanLongitudinalSpeed - 8) / 8, 0.05) }
  func testModerateObliqueRecoversKnownSpeed() throws { XCTAssertLessThan(abs(try analyze(camera: cameras[1]).meanLongitudinalSpeed - 8) / 8, 0.05) }
  func testSeverePerspectiveRecoversKnownSpeed() throws { XCTAssertLessThan(abs(try analyze(camera: cameras[2]).meanLongitudinalSpeed - 8) / 8, 0.05) }
  func testOffCentreScaledNoiseAndVariablePTS() throws { XCTAssertLessThan(abs(try analyze(camera: cameras[3], noise: 0.0008, variablePTS: true).meanLongitudinalSpeed - 8) / 8, 0.05) }
  func testFewOutliersRemainWithinBudget() throws { XCTAssertLessThan(abs(try analyze(camera: cameras[1], noise: 0.0012, outliers: [17,41], variablePTS: true).meanLongitudinalSpeed - 8) / 8, 0.05) }
  func testBadCalibrationIsRejected() throws { XCTAssertThrowsError(try analyze(camera: cameras[1], calibrationQuality: 0.2)) }
  func testDegenerateHomographyIsRejected() {
    XCTAssertThrowsError(try HomographyMath.imageToRunway(
      source: [.init(x:0.1,y:0.1),.init(x:0.2,y:0.2),.init(x:0.3,y:0.3),.init(x:0.4,y:0.4)],
      destination: [.init(xMeters:0,yMeters:0),.init(xMeters:1,yMeters:0),.init(xMeters:2,yMeters:0),.init(xMeters:3,yMeters:0)]))
  }
}
