import Foundation
import XCTest
@testable import AppModule

final class ExerciseVideoURLTests: XCTestCase {
  func testNormalizationAddsHTTPSAndRemovesFragment() {
    let url = ExerciseVideoURL.normalized(
      from: "  youtube.com/watch?v=abc123#commentaires  ")

    XCTAssertEqual(url?.absoluteString, "https://youtube.com/watch?v=abc123")
  }

  func testNormalizationRejectsNonWebSchemes() {
    XCTAssertNil(ExerciseVideoURL.normalized(from: "file:///tmp/demo.mp4"))
    XCTAssertNil(ExerciseVideoURL.normalized(from: "javascript:alert(1)"))
  }

  func testDirectVideoFilenameBecomesReadableFallbackTitle() {
    let url = URL(string: "https://example.org/videos/swing-up_progression.mp4")!

    XCTAssertEqual(
      ExerciseVideoURL.directFileTitle(for: url),
      "Swing up progression"
    )
  }

  func testDisplayHostRemovesCommonWWWPrefix() {
    let url = URL(string: "https://www.example.org/video")!

    XCTAssertEqual(ExerciseVideoURL.displayHost(for: url), "example.org")
  }

  func testTrainingLibraryCategoriesMatchReferenceOrder() {
    XCTAssertEqual(
      ExerciseVideoCategory.allCases.map(\.title),
      [
        "Warm-up", "PV Drills", "Med Ball", "Strength", "Gym",
        "Core", "Plyo", "Flexibility", "Rehab", "Running",
      ]
    )
  }

  func testLegacyCategoriesAreMigratedWithoutLosingVideos() {
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "plant"), .pvDrills)
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "fly-away"), .pvDrills)
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "gymnastics"), .gym)
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "core"), .core)
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "sprint"), .running)
    XCTAssertEqual(ExerciseVideoCategory.migrated(from: "strength-mobility"), .strength)
  }
}
