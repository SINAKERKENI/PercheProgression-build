import XCTest
@testable import AppModule

final class FixedObliquePerspectiveTests: XCTestCase {
  func testStaticHomographyRecoversLongitudinalDistanceDespitePerspective() throws {
    let grid = RunwayGridCalibration(
      boxLeft: .init(x: 0.70, y: 0.84),
      boxRight: .init(x: 0.93, y: 0.78),
      farLeft: .init(x: 0.18, y: 0.57),
      farRight: .init(x: 0.42, y: 0.53),
      zoneLengthMeters: 5,
      runwayWidthMeters: 1.22
    )
    let h = try HomographyMath.imageToRunway(for: grid)
    let near = try XCTUnwrap(h.projectMetric(grid.boxLeft))
    let far = try XCTUnwrap(h.projectMetric(grid.farLeft))
    XCTAssertEqual(near.xMeters, 0, accuracy: 1e-7)
    XCTAssertEqual(far.xMeters, 5, accuracy: 1e-7)
  }

  func testFixedObliqueServiceUsesMetricDisplacementOverPTS() async throws {
    let grid = RunwayGridCalibration(
      boxLeft: .init(x: 0.70, y: 0.84),
      boxRight: .init(x: 0.93, y: 0.78),
      farLeft: .init(x: 0.18, y: 0.57),
      farRight: .init(x: 0.42, y: 0.53),
      zoneLengthMeters: 5,
      runwayWidthMeters: 1.22
    )
    let inverse = try XCTUnwrap(try HomographyMath.imageToRunway(for: grid).inverted())
    let times = stride(from: 0.0, through: 0.8, by: 0.1).map { $0 }
    let checkpoints = times.map { t -> PelvisCheckpoint in
      let metric = NormalizedPoint(x: 5.0 - 5.0 * t, y: 0.61)
      let image = inverse.project(metric) ?? .init(x: 0.5, y: 0.5)
      return PelvisCheckpoint(
        timeSeconds: t,
        suggestedPoint: image,
        confirmedPoint: image,
        suggestionConfidence: 1,
        state: .confirmed
      )
    }
    let session = PelvisValidationSession(
      checkpoints: checkpoints,
      startTime: 0,
      endTime: 0.8,
      athleteHeightMeters: 1.8
    )
    let result = try await FixedObliqueRunwayMotionAnalysisService().analyze(
      validation: session,
      grid: grid,
      trackingPoint: .groundProjection
    )
    XCTAssertEqual(result.representativeHorizontalSpeed, 5.0, accuracy: 0.05)
    XCTAssertEqual(result.measurementMode, .fixedObliqueRunway)
  }

  func testFixedObliqueRelativeOriginPreservesSpeedAndPersistsGrid() async throws {
    let grid = RunwayGridCalibration(
      boxLeft: .init(x: 0.70, y: 0.84),
      boxRight: .init(x: 0.93, y: 0.78),
      farLeft: .init(x: 0.18, y: 0.57),
      farRight: .init(x: 0.42, y: 0.53),
      zoneLengthMeters: 5,
      runwayWidthMeters: 1.22
    )
    let inverse = try XCTUnwrap(try HomographyMath.imageToRunway(for: grid).inverted())
    let times = stride(from: 0.0, through: 0.8, by: 0.1).map { $0 }
    let checkpoints = times.map { t -> PelvisCheckpoint in
      let metric = NormalizedPoint(x: 5.0 - 5.0 * t, y: 0.61)
      let image = inverse.project(metric) ?? .init(x: 0.5, y: 0.5)
      return PelvisCheckpoint(
        timeSeconds: t,
        suggestedPoint: image,
        confirmedPoint: image,
        suggestionConfidence: 1,
        state: .confirmed
      )
    }
    let session = PelvisValidationSession(
      checkpoints: checkpoints,
      startTime: 0,
      endTime: 0.8,
      athleteHeightMeters: 1.8
    )

    let result = try await FixedObliqueRunwayMotionAnalysisService().analyze(
      validation: session,
      grid: grid,
      trackingPoint: .groundProjection,
      metricOrigin: .freeReference
    )

    XCTAssertEqual(result.representativeHorizontalSpeed, 5.0, accuracy: 0.05)
    XCTAssertEqual(result.fixedRunwayGrid, grid)
    XCTAssertEqual(result.fixedRunwayMetricOrigin, .freeReference)
    XCTAssertTrue(result.referenceDescription?.contains("butoir hors champ") == true)
  }
}
