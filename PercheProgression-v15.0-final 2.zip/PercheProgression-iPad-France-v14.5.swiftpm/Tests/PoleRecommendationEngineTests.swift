import XCTest
@testable import AppModule

final class PoleRecommendationEngineTests: XCTestCase {
  private let athlete = PoleAthleteContext(bodyWeightKG: 72, heightCM: 181, officialPRCM: 450, trainingPRCM: 465, targetHeightCM: 490)

  private func pole(_ id: UUID = UUID(), kg: Double, flex: Double, order: Int, length: Int = 460,
                    manufacturer: String = "UCS Spirit", model: String = "Spirit") -> PoleSnapshot {
    PoleSnapshot(id: id, manufacturer: manufacturer, model: model, lengthCM: length,
                 weightKG: kg, flexCM: flex, progressionOrder: order)
  }

  private func attempt(_ poleID: UUID, _ index: Int, result: AttemptResult = .clear,
                       diagnostics: Set<AttemptDiagnostic> = [], approach: Int = 16,
                       speed: Double? = 8.20, kind: PhysicalMetricKind? = .approachSpeed5mMean,
                       source: String = "cellules-5m", grip: Double? = 4.30,
                       rating: JumpRating = .good) -> AttemptSnapshot {
    AttemptSnapshot(poleID: poleID, approachSteps: approach, result: result, diagnostics: diagnostics,
                    barHeightCM: 450, gripHeightM: grip, approachSpeedMPS: speed,
                    approachSpeedKind: kind, approachSpeedSource: source,
                    technicalRating: rating, createdAt: Date(timeIntervalSince1970: Double(index)))
  }

  private func recommend(current: PoleSnapshot, poles: [PoleSnapshot], attempts: [AttemptSnapshot],
                         approach: ApproachLength = .sixteen) -> PoleRecommendation {
    let result = PoleRecommendationEngine().recommend(.init(currentPoleID: current.id, approach: approach,
      poles: poles, progress: [], recentAttempts: attempts, athlete: athlete))
    return try! XCTUnwrap(result)
  }

  private func goodCurrent(_ poleID: UUID, soft: Bool = false, count: Int = 8) -> [AttemptSnapshot] {
    (0..<count).map { i in
      attempt(poleID, i, result: i == count - 1 ? .miss : .clear,
              diagnostics: soft ? [.poleTooSoft] : [], speed: 8.10 + Double(i) * 0.015,
              grip: 4.30 + Double(i % 2) * 0.005, rating: .good)
    }
  }

  func testReorderingProgressionOrderDoesNotChangeClearlyBestPole() {
    let a = pole(kg: 75, flex: 16, order: 1), bID = UUID(), cID = UUID()
    let b1 = pole(bID, kg: 85, flex: 14, order: 2), c1 = pole(cID, kg: 80, flex: 15, order: 99)
    var attempts = goodCurrent(a.id, soft: true)
    attempts += (20..<25).map { attempt(cID, $0, result: .clear) }
    let first = recommend(current: a, poles: [a,b1,c1], attempts: attempts)
    let b2 = pole(bID, kg: 85, flex: 14, order: 500), c2 = pole(cID, kg: 80, flex: 15, order: -40)
    let second = recommend(current: a, poles: [a,c2,b2], attempts: attempts)
    XCTAssertEqual(first.pole.id, cID); XCTAssertEqual(second.pole.id, cID)
  }

  func testBetterHistoryCanBeatNextRackItem() {
    let a = pole(kg: 75, flex: 16, order: 1), b = pole(kg: 85, flex: 14, order: 2), c = pole(kg: 80, flex: 15, order: 8)
    var attempts = goodCurrent(a.id, soft: true)
    attempts += (30..<35).map { attempt(c.id, $0, result: .clear) }
    XCTAssertEqual(recommend(current: a, poles: [a,b,c], attempts: attempts).pole.id, c.id)
  }

  func testRepeatedTooStiffNeverSelectsUpwardCandidate() {
    let a = pole(kg: 80, flex: 15, order: 1), up = pole(kg: 85, flex: 14, order: 2), down = pole(kg: 75, flex: 16, order: 3)
    let attempts = (0..<7).map { attempt(a.id, $0, result: .miss, diagnostics: [.poleTooStiff, .plantRefusal]) }
    let result = recommend(current: a, poles: [a,up,down], attempts: attempts)
    XCTAssertNotEqual(result.direction, .up); XCTAssertNotEqual(result.pole.id, up.id)
  }

  func testRepeatedTooSoftStableQualityCanProgress() {
    let a = pole(kg: 75, flex: 16, order: 1), up = pole(kg: 80, flex: 15, order: 99)
    let result = recommend(current: a, poles: [a,up], attempts: goodCurrent(a.id, soft: true))
    XCTAssertEqual(result.direction, .up); XCTAssertEqual(result.pole.id, up.id)
  }

  func testCanStayOnCurrentPole() {
    let a = pole(kg: 80, flex: 15, order: 10), up = pole(kg: 85, flex: 14, order: 1)
    let attempts = goodCurrent(a.id, soft: false)
    XCTAssertEqual(recommend(current: a, poles: [up,a], attempts: attempts).direction, .stay)
  }

  func testCanDownshift() {
    let down = pole(kg: 75, flex: 16, order: 99), a = pole(kg: 80, flex: 15, order: 1), up = pole(kg: 85, flex: 14, order: 2)
    var attempts = (0..<7).map { attempt(a.id, $0, result: .miss, diagnostics: [.poleTooStiff, .plantRefusal]) }
    attempts += (20..<25).map { attempt(down.id, $0, result: .clear) }
    let result = recommend(current: a, poles: [a,up,down], attempts: attempts)
    XCTAssertEqual(result.direction, .down); XCTAssertEqual(result.pole.id, down.id)
  }

  func testHistoricalSuccessRaisesCandidateMeaningfully() {
    let a = pole(kg: 75, flex: 16, order: 1), b = pole(kg: 80, flex: 15, order: 2), c = pole(kg: 80, flex: 15, order: 3)
    var attempts = goodCurrent(a.id, soft: true)
    attempts += (30..<35).map { attempt(c.id, $0, result: .clear) }
    XCTAssertEqual(recommend(current: a, poles: [a,b,c], attempts: attempts).pole.id, c.id)
  }

  func testDifferentApproachLengthsRemainIndependent() {
    let a = pole(kg: 75, flex: 16, order: 1), up = pole(kg: 80, flex: 15, order: 2)
    let relevant = goodCurrent(a.id, soft: false)
    let other = (20..<30).map { attempt(a.id, $0, result: .clear, diagnostics: [.poleTooSoft], approach: 12) }
    XCTAssertEqual(recommend(current: a, poles: [a,up], attempts: relevant + other).direction, .stay)
  }

  func testDifferentSpeedProtocolsAreNotMerged() {
    let a = pole(kg: 75, flex: 16, order: 1), up = pole(kg: 80, flex: 15, order: 2)
    var attempts = goodCurrent(a.id, soft: true, count: 6)
    attempts[0] = attempt(a.id, 0, diagnostics: [.poleTooSoft], speed: 5.0, kind: .videoEstimatedSpeed, source: "video-legacy")
    let result = recommend(current: a, poles: [a,up], attempts: attempts)
    XCTAssertTrue(result.warnings.contains { $0.contains("protocoles différents") })
  }

  func testGripHeightChangeChangesContextAndWarning() {
    let a = pole(kg: 75, flex: 16, order: 1), up = pole(kg: 80, flex: 15, order: 2)
    let stable = (0..<6).map { attempt(a.id, $0, diagnostics: [.poleTooSoft], grip: 4.30) }
    let changed = (0..<6).map { attempt(a.id, $0, diagnostics: [.poleTooSoft], grip: 4.10 + Double($0) * 0.05) }
    let stableResult = recommend(current: a, poles: [a,up], attempts: stable)
    let changedResult = recommend(current: a, poles: [a,up], attempts: changed)
    XCTAssertNotEqual(stableResult.evaluation.evidenceScore, changedResult.evaluation.evidenceScore)
    XCTAssertTrue(changedResult.warnings.contains { $0.contains("prise") })
  }

  func testSparseEvidenceStaysWithLowConfidence() {
    let a = pole(kg: 75, flex: 16, order: 9), up = pole(kg: 80, flex: 15, order: 1)
    let result = recommend(current: a, poles: [up,a], attempts: [attempt(a.id, 0), attempt(a.id, 1)])
    XCTAssertEqual(result.direction, .stay); XCTAssertEqual(result.confidence, .low)
  }

  func testCrossManufacturerDoesNotCompareFlexAndReducesConfidence() {
    let a = pole(kg: 75, flex: 16, order: 1), same = pole(kg: 80, flex: 15, order: 2)
    let cross = pole(kg: 80, flex: 10, order: 3, manufacturer: "Pacer", model: "One")
    let attempts = goodCurrent(a.id, soft: true)
    let result = recommend(current: a, poles: [a,same,cross], attempts: attempts)
    let sameEval = ([result.evaluation] + result.alternatives).first { $0.pole.id == same.id }
    let crossEval = ([result.evaluation] + result.alternatives).first { $0.pole.id == cross.id }
    XCTAssertNotNil(sameEval); XCTAssertNotNil(crossEval)
    XCTAssertLessThan(crossEval!.evidenceQuality, sameEval!.evidenceQuality)
    XCTAssertTrue(crossEval!.warnings.contains { $0.contains("flex") && $0.contains("pas") })
  }

  func testIdenticalProgressionOrderStillEvaluatesCharacteristics() {
    let a = pole(kg: 75, flex: 16, order: 1), huge = pole(kg: 90, flex: 12, order: 5), sensible = pole(kg: 80, flex: 15, order: 5)
    XCTAssertEqual(recommend(current: a, poles: [huge,a,sensible], attempts: goodCurrent(a.id, soft: true)).pole.id, sensible.id)
  }

  func testInsertionOrderDoesNotDetermineRanking() {
    let a = pole(kg: 75, flex: 16, order: 1), b = pole(kg: 85, flex: 14, order: 4), c = pole(kg: 80, flex: 15, order: 4)
    var attempts = goodCurrent(a.id, soft: true); attempts += (30..<35).map { attempt(c.id, $0) }
    let x = recommend(current: a, poles: [a,b,c], attempts: attempts)
    let y = recommend(current: a, poles: [c,b,a], attempts: attempts)
    XCTAssertEqual(x.pole.id, c.id); XCTAssertEqual(y.pole.id, c.id)
  }

  func testNoNaNOrInfinityEscapes() {
    let a = pole(kg: 75, flex: 16, order: 1), b = pole(kg: 80, flex: 15, order: 2)
    let result = recommend(current: a, poles: [a,b], attempts: goodCurrent(a.id, soft: true))
    for evaluation in [result.evaluation] + result.alternatives {
      XCTAssertTrue(evaluation.readinessScore.isFinite); XCTAssertTrue(evaluation.evidenceQuality.isFinite)
      XCTAssertTrue(evaluation.contextualFitScore.isFinite); XCTAssertTrue(evaluation.evidenceScore.isFinite)
    }
  }

  func testModelVersionIsV15DecisionModel() {
    XCTAssertEqual(PoleRecommendationEngine.modelVersion, "pole-decision-v15.0")
  }
}
