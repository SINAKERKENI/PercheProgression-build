import XCTest
@testable import AppModule

final class HomographyMathTests: XCTestCase {
  func testNormalizedDLTMapsFourCornersExactlyWithoutClaimingUncertainty() throws {
    let source = [
      NormalizedPoint(x: 0.20, y: 0.72),
      NormalizedPoint(x: 0.78, y: 0.69),
      NormalizedPoint(x: 0.37, y: 0.28),
      NormalizedPoint(x: 0.64, y: 0.27),
    ]
    let destination = [
      MetricRunwayPoint(xMeters: 0, yMeters: 0),
      MetricRunwayPoint(xMeters: 0, yMeters: 1.22),
      MetricRunwayPoint(xMeters: 5, yMeters: 0),
      MetricRunwayPoint(xMeters: 5, yMeters: 1.22),
    ]

    let result = try HomographyMath.robustImageToRunway(source: source, destination: destination)
    XCTAssertTrue(result.meanMetricError.isNaN, "Four exact correspondences do not estimate uncertainty")
    for index in source.indices {
      let projected = try XCTUnwrap(result.matrix.projectMetric(source[index]))
      XCTAssertEqual(projected.xMeters, destination[index].xMeters, accuracy: 1e-7)
      XCTAssertEqual(projected.yMeters, destination[index].yMeters, accuracy: 1e-7)
    }
  }

  func testRobustHomographyRejectsSingleOutlier() throws {
    let source = [
      NormalizedPoint(x: 0.20, y: 0.72), NormalizedPoint(x: 0.78, y: 0.69),
      NormalizedPoint(x: 0.37, y: 0.28), NormalizedPoint(x: 0.64, y: 0.27),
      NormalizedPoint(x: 0.29, y: 0.50), NormalizedPoint(x: 0.70, y: 0.49),
    ]
    var destination = try source.map { point -> MetricRunwayPoint in
      let reference = try HomographyMath.imageToRunway(
        source: Array(source.prefix(4)),
        destination: [
          .init(xMeters: 0, yMeters: 0), .init(xMeters: 0, yMeters: 1.22),
          .init(xMeters: 5, yMeters: 0), .init(xMeters: 5, yMeters: 1.22),
        ]
      )
      return try XCTUnwrap(reference.projectMetric(point))
    }
    destination[5].xMeters += 2.0

    let result = try HomographyMath.robustImageToRunway(
      source: source,
      destination: destination,
      thresholdMeters: 0.10,
      maximumTrials: 64
    )
    XCTAssertGreaterThanOrEqual(result.inlierIndices.count, 5)
    XCTAssertFalse(result.inlierIndices.contains(5))
  }
}
