import XCTest
@testable import AppModule

final class AchievementEngineTests: XCTestCase {
  func testUnlocksOnlyEvidenceBackedMilestones() {
    let snapshot = AchievementSnapshot(
      sessionCount: 5,
      attemptCount: 25,
      clearCount: 10,
      currentPRCM: 480,
      targetHeightCM: 500,
      videoCount: 1,
      analyzedVideoCount: 0,
      masteredPoleCount: 1,
      completedDrillCount: 3,
      speedMeasurementCount: 1,
      consecutiveWeeks: 3,
      bestSessionClearRate: 0.75,
      hasVoiceLog: true
    )

    let values = AchievementEngine.achievements(for: snapshot)
    XCTAssertEqual(values.first(where: { $0.id == "five-sessions" })?.isUnlocked, true)
    XCTAssertEqual(values.first(where: { $0.id == "twenty-five-jumps" })?.isUnlocked, true)
    XCTAssertEqual(values.first(where: { $0.id == "target-reached" })?.isUnlocked, false)
    XCTAssertEqual(values.first(where: { $0.id == "quality-session" })?.isUnlocked, false)
    XCTAssertEqual(values.first(where: { $0.id == "voice-log" })?.isUnlocked, true)
  }

  func testQualitySessionRequiresEightyPercent() {
    var snapshot = AchievementSnapshot.empty
    snapshot = AchievementSnapshot(
      sessionCount: snapshot.sessionCount,
      attemptCount: snapshot.attemptCount,
      clearCount: snapshot.clearCount,
      currentPRCM: snapshot.currentPRCM,
      targetHeightCM: snapshot.targetHeightCM,
      videoCount: snapshot.videoCount,
      analyzedVideoCount: snapshot.analyzedVideoCount,
      masteredPoleCount: snapshot.masteredPoleCount,
      completedDrillCount: snapshot.completedDrillCount,
      speedMeasurementCount: snapshot.speedMeasurementCount,
      consecutiveWeeks: snapshot.consecutiveWeeks,
      bestSessionClearRate: 0.8,
      hasVoiceLog: snapshot.hasVoiceLog
    )

    let achievement = AchievementEngine.achievements(for: snapshot)
      .first(where: { $0.id == "quality-session" })
    XCTAssertEqual(achievement?.isUnlocked, true)
  }
}
