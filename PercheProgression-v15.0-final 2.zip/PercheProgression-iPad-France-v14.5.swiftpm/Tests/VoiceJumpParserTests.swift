import XCTest
@testable import AppModule

final class VoiceJumpParserTests: XCTestCase {
  func testParsesCoreFrenchJumpFields() {
    let draft = VoiceJumpParser.parse(
      "Saut réussi, barre 4 mètres 80, 16 foulées, perche 4,60 mètres 77 kilos, bonne impulsion."
    )

    XCTAssertEqual(draft.result, .clear)
    XCTAssertEqual(draft.barHeightCM, 480)
    XCTAssertEqual(draft.approach, .sixteen)
    XCTAssertEqual(draft.poleLengthCM, 460)
    XCTAssertEqual(draft.poleWeightKG, 77)
    XCTAssertEqual(draft.technicalRating, .good)
  }

  func testParsesDiagnosticsAndTechnicalMarks() {
    let draft = VoiceJumpParser.parse(
      "Échec à 4,50 m, 14 foulées, impulsion dessous à 4,10 m, prise 4,25 m, poteaux 60 cm, perche trop dure."
    )

    XCTAssertEqual(draft.result, .miss)
    XCTAssertEqual(draft.barHeightCM, 450)
    XCTAssertEqual(draft.approach, .fourteen)
    XCTAssertEqual(draft.takeoffMarkM ?? 0, 4.10, accuracy: 0.001)
    XCTAssertEqual(draft.gripHeightM ?? 0, 4.25, accuracy: 0.001)
    XCTAssertEqual(draft.standardsOffsetCM, 60)
    XCTAssertTrue(draft.diagnostics.contains(.takeoffUnder))
    XCTAssertTrue(draft.diagnostics.contains(.poleTooStiff))
  }

  func testParsesWrittenApproachNumber() {
    let draft = VoiceJumpParser.parse("Saut franchi à 4 m 20 avec seize foulées.")

    XCTAssertEqual(draft.result, .clear)
    XCTAssertEqual(draft.barHeightCM, 420)
    XCTAssertEqual(draft.approach, .sixteen)
  }
}
