import XCTest
@testable import AppModule

private actor RemoteAttemptHarness {
  private var gate = RemoteConnectionAttemptGate()

  func begin(_ id: UUID) {
    gate.begin(id)
  }

  func claim(_ id: UUID) -> Bool {
    gate.claim(id)
  }
}

final class RemoteCameraConcurrencyTests: XCTestCase {
  func testSuccessAndTimeoutRaceCompletesOnce() async {
    let id = UUID()
    let harness = RemoteAttemptHarness()
    await harness.begin(id)

    async let success = harness.claim(id)
    async let timeout = harness.claim(id)
    let winners = await [success, timeout].filter { $0 }

    XCTAssertEqual(winners.count, 1)
  }

  func testDisconnectAndNormalCompletionRaceCompletesOnce() async {
    let id = UUID()
    let harness = RemoteAttemptHarness()
    await harness.begin(id)

    async let disconnected = harness.claim(id)
    async let response = harness.claim(id)
    let winners = await [disconnected, response].filter { $0 }

    XCTAssertEqual(winners.count, 1)
  }

  func testCancellationJustBeforeResponseCompletesOnce() async {
    let id = UUID()
    let harness = RemoteAttemptHarness()
    await harness.begin(id)

    async let cancellation = harness.claim(id)
    async let response = harness.claim(id)
    let winners = await [cancellation, response].filter { $0 }

    XCTAssertEqual(winners.count, 1)
  }

  func testDuplicateCallbacksOnlyFirstIsAccepted() {
    let id = UUID()
    var gate = RemoteConnectionAttemptGate()
    gate.begin(id)

    XCTAssertTrue(gate.claim(id))
    XCTAssertFalse(gate.claim(id))
    XCTAssertFalse(gate.claim(id))
  }

  func testRapidDiscoveryEventsRemainDeduplicatedAndSorted() {
    let a1 = RemoteCameraEndpoint(name: "Pixel B", host: "b.local.", controlPort: 9000, transferPort: 9001, deviceID: "b")
    let a2 = RemoteCameraEndpoint(name: "Pixel A", host: "a.local.", controlPort: 9100, transferPort: 9101, deviceID: "a")
    let a2Updated = RemoteCameraEndpoint(name: "Pixel A", host: "a2.local.", controlPort: 9200, transferPort: 9201, deviceID: "a")
    var endpoints: [RemoteCameraEndpoint] = []

    BonjourEndpointReducer.apply(.resolved(a1), to: &endpoints)
    BonjourEndpointReducer.apply(.resolved(a2), to: &endpoints)
    BonjourEndpointReducer.apply(.resolved(a2Updated), to: &endpoints)

    XCTAssertEqual(endpoints.map(\.deviceID), ["a", "b"])
    XCTAssertEqual(endpoints.first?.host, "a2.local.")

    BonjourEndpointReducer.apply(.removed(name: "Pixel B"), to: &endpoints)
    XCTAssertEqual(endpoints.map(\.deviceID), ["a"])
  }
}
