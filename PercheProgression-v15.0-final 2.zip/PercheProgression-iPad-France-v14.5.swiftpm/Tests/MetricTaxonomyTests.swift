import XCTest
@testable import AppModule

final class MetricTaxonomyTests: XCTestCase {
  func testLegacyAggregateIsNotUserSelectable() {
    XCTAssertFalse(PhysicalMetricKind.userSelectableCases.contains(.approachSpeed))
  }

  func testApproachProtocolsRemainDistinct() {
    let expected: [PhysicalMetricKind] = [
      .approachSpeed5mMean, .approachSpeed10mMean, .approachPeakSpeed,
      .videoEstimatedSpeed, .radarSpeed, .takeoffSpeed,
    ]
    XCTAssertTrue(expected.allSatisfy(\.isApproachSpeedFamily))
  }
}
