import XCTest
@testable import AppModule

final class ExerciseVideoSeedTests: XCTestCase {
  func testBundledCatalogContainsTheExpected247Videos() throws {
    let videos = try ExerciseVideoSeedCatalog.load()

    XCTAssertEqual(videos.count, 247)
    XCTAssertEqual(Set(videos.map(\.id)).count, 247)
    XCTAssertEqual(Set(videos.map(\.categoryURLSignature)).count, 247)
    XCTAssertEqual(Set(videos.map(\.urlString)).count, 246)

    let counts = Dictionary(grouping: videos, by: \ExerciseVideoSeedItem.category)
      .mapValues(\.count)
    XCTAssertEqual(counts, ExerciseVideoSeedCatalog.expectedCategoryCounts)
  }
}
