# Intégration FFA

## Architecture

L’application iPad ne scrape pas directement les pages athle.fr. `FFAProvider` reste une abstraction et `RemoteFFAProvider` dialogue avec le petit adaptateur `Backend/FFAAdapter/`. Cela permet de centraliser cache, limitation de requêtes et éventuels accès FFA autorisés sans embarquer de secret dans l’application.

## Association

La recherche peut combiner prénom, nom, licence/PPS, année de naissance et club. Plusieurs candidats sont affichés et l’utilisateur choisit explicitement le bon athlète ; le premier résultat n’est jamais associé silencieusement. L’identifiant stable retenu est stocké dans `AthleteProfile.ffaAthleteID` avec le club, l’état de synchronisation et la date de dernière synchro.

## Import et historique

`FFAImportPlanner` conserve uniquement les variantes reconnues de perche/perche en salle et parse explicitement la hauteur de performance. Les résultats deviennent des `OfficialPerformanceRecord`, jamais des tentatives d’entraînement.

Une clé externe déterministe permet :
- la déduplication des synchronisations répétées ;
- la mise à jour du même record lorsque la source corrige un résultat ;
- la conservation du cache local en cas d’échec réseau.

Le caractère salle/plein air, le lieu, la compétition, le classement, le niveau et la provenance sont conservés lorsqu’ils sont fournis. La progression du record officiel est construite chronologiquement uniquement à partir de ces performances de perche. Le record d’entraînement reste indépendant.

Dissocier le profil FFA supprime le lien de synchronisation mais ne supprime pas les résultats déjà importés sauf action explicite prévue à cet effet.

## Déploiement de `Backend/FFAAdapter/`

1. Créer un environnement Python et installer `requirements.txt`.
2. Configurer l’adaptateur vers une source FFA dont l’usage a été autorisé/documenté pour le déploiement concerné.
3. Déployer derrière HTTPS et renseigner cette URL dans la carte « Adaptateur FFA » du profil athlète.
4. Conserver les identifiants/credentials éventuels côté serveur ; **aucun secret privé ne doit être codé dans l’iPad**.

L’adaptateur ne doit pas contourner authentification, CAPTCHA, limitations de fréquence, robots/directives d’accès ou restrictions d’utilisation FFA. Si la source distante refuse l’accès, il doit échouer proprement et laisser l’historique local intact.
