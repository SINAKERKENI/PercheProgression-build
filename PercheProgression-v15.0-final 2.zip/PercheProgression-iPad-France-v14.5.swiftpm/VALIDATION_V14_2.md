# Validation v14.2

## Contrôles réalisés dans l’environnement Linux

- vérification de l’équilibrage des délimiteurs sur tous les fichiers Swift ;
- contrôle de l’absence de `DrillCard`, `DrillDetailView`, filtres de phase/défaut et libellés « Fiche technique » dans la vue Bibliothèque ;
- contrôle de l’absence de fichiers vidéo d’exemple dans les ressources ;
- contrôle du modèle SwiftData, de son enregistrement dans le schéma et de l’export JSON ;
- contrôle des appels asynchrones LinkPresentation et AVAudioApplication corrigés en v14.1.1 ;
- contrôle d’intégrité de l’archive ZIP finale.

## Validation Apple requise

Le toolchain Xcode/SwiftUI pour iOS n’est pas disponible dans cet environnement Linux. Avant diffusion App Store ou TestFlight, ouvrir le package dans Swift Playgrounds 4.6 ou Xcode 16+, lancer une compilation iPadOS 18, puis vérifier :

1. ajout d’une URL YouTube, Vimeo ou TikTok ;
2. récupération automatique du titre et de la vignette ;
3. modification de la catégorie et de la description ;
4. recherche et filtrage par catégorie ;
5. bascule grille/liste ;
6. ouverture du lien et suppression avec confirmation ;
7. conservation des données d’une installation v14.1.1.
