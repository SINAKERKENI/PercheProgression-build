# Correctif v14.1.1

## Erreurs de compilation corrigées

Les diagnostics `Generic parameter 'Content' could not be inferred`, `Missing argument label 'content:' in call` et `Cannot convert value of type 'String' to expected argument type '() -> Content'` provenaient de l’association d’un titre abrégé avec un pied de section SwiftUI.

Le formulaire emploie désormais l’initialiseur non ambigu :

```swift
Section {
  // contenu
} header: {
  Text("Adresse de la vidéo")
} footer: {
  // aide
}
```

## Avertissements corrigés

- `LPMetadataProvider` : utilisation directe de `try await startFetchingMetadata(for:)`, sans capture de l’objet dans une fermeture `@Sendable`.
- Permission microphone : utilisation de `await AVAudioApplication.requestRecordPermission()` à la place de l’API `AVAudioSession` dépréciée depuis iOS 17.

## Version

- Version affichée : 14.1.1
- Build : 29
- Bundle identifier inchangé : `com.tasnim.vaultroadmap.ipad`
