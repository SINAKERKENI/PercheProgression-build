# Validation v14.3

## Contrôles automatisés

- présence de dix catégories et respect strict de leur ordre ;
- correspondance des dix libellés avec la capture de référence ;
- filtre global « All » ;
- migration des anciennes valeurs vers PV Drills, Core, Gym, Running et Strength ;
- absence des anciens libellés dans la vue de bibliothèque ;
- équilibrage des délimiteurs de tous les fichiers Swift ;
- validité des ressources JSON et plist ;
- absence de vidéo d’exemple embarquée ;
- intégrité de l’archive ZIP finale.

## Validation Apple à effectuer

Le toolchain iOS n’étant pas disponible dans cet environnement Linux, ouvrir le package dans Swift Playgrounds 4.6 ou Xcode 16+ et vérifier sur iPadOS 18 :

1. l’ordre et le défilement horizontal des onze filtres, « All » compris ;
2. les compteurs dynamiques après ajout et suppression d’une vidéo ;
3. le choix des dix catégories dans le formulaire ;
4. la conservation et le reclassement des vidéos créées en v14.2 ;
5. la recherche, la grille et la liste.
