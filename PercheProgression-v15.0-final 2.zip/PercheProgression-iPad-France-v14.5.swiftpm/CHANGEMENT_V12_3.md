# Perche Progression — v12.3 Perspective fixe

## Correction principale

Le moteur de mesure ne confond plus une caméra fixe oblique avec une caméra mobile.

### Caméra fixe – vue oblique

1. Définir la séquence.
2. Placer quatre coins au sol formant un quadrilatère réel.
3. Renseigner longueur et largeur réelles.
4. Choisir `Point au sol` ou `Bassin (estimation)`.
5. Confirmer le point à 10 Hz.
6. Calculer la vitesse longitudinale dans le repère de piste.

Aucun suivi de repères fixes du décor n'est exécuté dans ce mode.

## Géométrie

La transformation image → piste est une homographie fixe calculée par la DLT normalisée déjà présente dans le projet. Les quatre correspondances décrivent un rectangle métrique `longueur × largeur`. Une simple ligne de 5 m n'est plus présentée comme suffisante pour corriger une vue oblique.

## Biomécanique

L'homographie du sol est rigoureusement applicable aux points du plan du sol. Pour cette raison, `Point au sol` est le mode recommandé. Le mode `Bassin` reste disponible mais est marqué comme estimation avec parallaxe possible.

## Cinématique

La vitesse utilisée est exclusivement la composante longitudinale de la position métrique. Les timestamps proviennent des PTS des checkpoints. Un ajustement quadratique local stabilise les dérivées sans mélanger une composante verticale issue de l'image.

## Garde-fous

La mesure est refusée si une proportion excessive des échantillons présente des vitesses hors plage ou des accélérations longitudinales extrêmes. L'application demande alors de vérifier le quadrilatère et les points suivis.
