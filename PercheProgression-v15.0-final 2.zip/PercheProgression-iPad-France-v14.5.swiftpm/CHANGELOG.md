# Changelog

## 15.0.0

### Progression & FFA
- Suppression du radar de performance arbitraire et de son flux d’édition ; `PerformanceDimensionRecord` reste uniquement pour la compatibilité des stores existants.
- Ajout de `OfficialPerformanceRecord` pour conserver les performances officielles séparément des tentatives d’entraînement.
- Association explicite à un athlète FFA, synchronisation, cache local, historique indoor/outdoor, déduplication et mise à jour des résultats corrigés.
- Progression des records officiels calculée chronologiquement à partir des seules performances de perche importées ; le record d’entraînement reste distinct.
- Correction des filtres de `AnalyticsEngine.cumulativePRPoints`.

### Recommandation de perche
- Nouveau moteur candidat-par-candidat `pole-decision-v15.0` : rester, monter, descendre ou changer latéralement.
- Utilisation de l’historique athlète, diagnostics, prise, protocole de vitesse, longueur d’élan, qualité technique et caractéristiques réelles des perches.
- Comparaison de flex limitée aux familles fabricant/modèle compatibles ; transition inter-familles signalée avec confiance réduite.
- `progressionOrder` n’est plus un sélecteur sportif et ne sert qu’au départage final.
- Acceptation, refus ou ignorance d’une recommandation persistés dans SwiftData.

### Analyse vidéo
- `PerspectiveAwareSpeedEngine` devient la source quantitative des vitesses métriques calibrées.
- Homographie fixe ou dynamique, positions au sol issues en priorité des appuis/chevilles, PTS vidéo réels et rejet des géométries non fiables.
- Diagnostics de qualité inspectables : calibration, stabilité/nombre d’ancrages, continuité d’homographie, suivi athlète, confiance du point au sol, couverture trajectoire, outliers et couverture PTS.
- Les anciens modes anthropométriques/bassin restent consultables mais ne peuvent plus enregistrer silencieusement une vitesse métrique calibrée v15.

### Comparaison vidéo & plein écran
- Zoom/panoramique indépendants des vidéos principale et de référence.
- Pas image de la référence basé sur ses propres PTS, y compris lorsque les cadences diffèrent.
- Timeline de précision persistante en plein écran ; le chrome supérieur peut se masquer sans faire disparaître la timeline.
- Arbitrage : gestes à un doigt pour les outils d’annotation, gestes à deux doigts pour le viewport.
- Manipulation directe de la superposition de référence avec transformation dédiée.

### Caméra Pixel distante
- Projet Android `PixelCameraCompanion/` avec CameraX et découverte locale.
- Appairage explicite, canal de contrôle authentifié et transitions d’état acquittées.
- Enregistrement maître sur le Pixel, finalisation avant transfert, reprise HTTP Range, contrôle de taille et SHA-256.
- Import uniquement après vérification d’intégrité dans `VideoAssetStore`, avec prévention des doublons de `remoteRecordingID`.
- Durcissement Swift Concurrency : découverte Bonjour séparée de l’état UI `@MainActor`, continuations réseau possédées par l’acteur de transport et reprises une seule fois, annulation/délais de commande explicites.

### Harada
- Huit piliers spécifiques à la perche avec actions concrètes et non artificiellement remplies.
- Édition, type, récurrence, cible, archivage, réordonnancement et focus « En ce moment » persistés.
- Les feuilles de route existantes ne sont pas réensemencées lors d’une mise à jour.

### Migration
- Bundle identifier conservé : `com.tasnim.vaultroadmap.ipad`.
- Aucune suppression/recréation automatique du store SwiftData.
- Les anciens profils, séances, tentatives, perches, vidéos, annotations, mesures et personnalisations restent dans le même store persistant.
