# Changement v14.5 — import Fichiers et catalogue vidéo

## Sélecteur de fichiers

- Un seul modificateur SwiftUI `fileImporter` pilote désormais l’import initial et la reconnexion d’un média.
- Les formats `movie`, `video`, MP4 et QuickTime sont acceptés.
- L’accès sécurisé est acquis dès le retour du sélecteur et conservé pendant la copie.
- `NSFileCoordinator` sécurise la lecture des médias fournis par Fichiers et iCloud Drive.
- Une annulation utilisateur ne déclenche plus de message d’erreur.

## Bibliothèque d’exercices

- Le catalogue `ExerciseVideoSeed.json` contient exactement 247 fiches.
- Les catégories et totaux sont validés avant toute insertion.
- La migration v9 ajoute uniquement les fiches absentes et conserve les contenus existants.
- L’unicité repose sur le couple catégorie–URL afin de conserver les deux exercices qui partagent volontairement une même URL.

## Lecture

- Les fichiers MP4, MOV, M4V et HLS utilisent `AVPlayer`.
- YouTube, Vimeo, TikTok, Instagram et les autres pages s’ouvrent dans un navigateur sécurisé intégré.
- Un bouton permet toujours d’ouvrir le lien dans Safari si la plateforme refuse la lecture intégrée.

Le bundle identifier reste `com.tasnim.vaultroadmap.ipad` afin de préserver le stockage SwiftData existant.
