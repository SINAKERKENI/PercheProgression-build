# Architecture — décision de perche

**Modèle actif : `pole-decision-v15.0`.**

Le moteur reçoit le râtelier actif et l’historique de tentatives de l’athlète. Il génère une évaluation pour la perche actuelle et pour chaque candidate admissible, puis classe ces évaluations ; il ne cherche pas « la prochaine perche » dans une liste.

## Évidence utilisée

Selon disponibilité : résultats récents, hauteur de barre, diagnostics (`poleTooSoft`, `poleTooStiff`, refus de planter, impulsion dessous/dehors), note technique, longueur d’élan, hauteur de prise, vitesse d’élan et son protocole, vitesse d’impulsion, marques, récence et historique propre à chaque perche. Les vitesses de protocoles différents ne sont pas fusionnées comme si elles étaient interchangeables.

## Transition d’équipement

Le moteur décrit la direction `stay`, `up`, `down` ou `lateral` à partir de la perche actuelle et de la candidate. Longueur, poids et flex peuvent contribuer à la transition lorsqu’ils appartiennent à une même famille fabricant/modèle. Le flex brut de deux familles différentes n’est jamais traité comme une échelle universelle. Une transition inter-familles ajoute un avertissement et réduit la qualité de l’évidence disponible.

L’amplitude de changement est pénalisée lorsqu’elle modifie fortement plusieurs axes sans historique athlète correspondant. Un historique réussi sur une candidate apporte au contraire une évidence spécifique.

## Blocages et données rares

Des signaux répétés de perche trop dure/refus de planter empêchent un simple score positif d’entraîner une nouvelle transition plus dure. Des données très rares favorisent « rester »/recueillir davantage d’évidence et une confiance basse plutôt qu’une précision artificielle.

## Préparation et confiance

La préparation est une appréciation déterministe du contexte actuel, **pas une probabilité de réussite**. La confiance représente quantité, qualité et cohérence de l’évidence disponible. Les explications et avertissements restent affichables séparément.

## `progressionOrder`

`progressionOrder` n’entre pas dans le score sportif des candidates. Il peut uniquement départager des évaluations réellement équivalentes afin de garder un ordre de râtelier stable. Modifier l’ordre seul ne doit donc pas transformer une candidate inférieure en recommandation principale.
