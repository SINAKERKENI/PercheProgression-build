# Changement v14.2 — bibliothèque d’entraînement vidéo

## Interface remplacée

La zone précédemment composée des filtres de phase, des filtres de défaut technique et des six « Fiches techniques » a été entièrement retirée de la vue Bibliothèque d’exercices.

La nouvelle interface reprend la hiérarchie de la bibliothèque de référence :

- bandeau récapitulatif avec nombre réel de vidéos et de catégories ;
- barre de recherche dédiée ;
- filtres horizontaux par catégorie, accompagnés de compteurs réels ;
- nombre de résultats filtrés ;
- sélection entre une grille de grandes cartes et une liste compacte ;
- bouton d’ajout visible en permanence.

Les anciennes fiches restent uniquement dans le schéma de données pour préserver la compatibilité des installations existantes et l’historique des jalons. Elles ne sont plus chargées ni affichées par la bibliothèque.

## Vidéos réelles uniquement

Aucune vidéo d’exemple n’est intégrée. La bibliothèque reste vide tant qu’une URL n’a pas été ajoutée par l’utilisateur.

Chaque vidéo possède :

- une catégorie parmi les dix catégories existantes ;
- une URL web `http` ou `https` ;
- un titre récupéré automatiquement et modifiable ;
- une courte description personnalisable ;
- une vignette oEmbed distante lorsqu’elle est fournie par la plateforme ;
- la date de création et la date de dernière modification.

Les cartes sans vignette distante utilisent un visuel neutre lié à la catégorie, sans simuler de contenu vidéo.

## Compatibilité et données

- Le bundle identifier reste `com.tasnim.vaultroadmap.ipad`.
- Le modèle `ExerciseVideoRecord` reçoit une propriété optionnelle `thumbnailURLString`, compatible avec les anciennes entrées.
- L’export complet passe au schéma JSON v5 et inclut `thumbnailURL`.
- Les liens déjà enregistrés restent disponibles ; leur vignette peut être récupérée en ouvrant l’éditeur et en relançant la récupération des informations.
