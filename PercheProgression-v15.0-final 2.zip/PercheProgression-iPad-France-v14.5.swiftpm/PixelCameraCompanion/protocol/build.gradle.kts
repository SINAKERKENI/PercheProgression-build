plugins { id("com.android.library") }
android {
    namespace = "com.tasnim.perchecamera.protocol"
    compileSdk = 37
    defaultConfig { minSdk = 28 }
}
