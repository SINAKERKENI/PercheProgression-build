package com.tasnim.perchecamera.protocol

fun main() {
    var now = 1_000L
    val auth = PairingAuthority { now }
    val code = auth.currentCode()
    check(auth.pair("000000", "ipad") == null)
    val token = checkNotNull(auth.pair(code, "ipad"))
    check(auth.isAuthorized(token))
    check(!auth.isAuthorized("bad"))

    val state = RemoteCameraStateMachine()
    state.recordingStarted()
    check(state.state == CameraState.RECORDING)
    state.stopRequested()
    val manifest = RecordingManifest("r1", "r1.mp4", 3, "abc", "2026-09-11T20:00:00Z", 1.0, 1920, 1080, 60.0, "1×", "landscape", "/recordings/r1")
    state.recordingFinalized(manifest)
    check(state.state == CameraState.READY)
    check(state.finalizedManifest == manifest)

    now += 13 * 60 * 60_000L
    check(!auth.isAuthorized(token))
    println("ProtocolSelfTest: PASS")
}
