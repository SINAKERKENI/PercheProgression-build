package com.tasnim.perchecamera.protocol

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

enum class CameraState { DISCONNECTED, READY, RECORDING, STOPPING, TRANSFERRING, ERROR }

data class RecordingManifest(
    val recordingID: String,
    val filename: String,
    val sizeBytes: Long,
    val sha256: String,
    val createdAtISO8601: String,
    val durationSeconds: Double,
    val width: Int,
    val height: Int,
    val nominalFPS: Double,
    val lensLabel: String,
    val orientation: String,
    val transferPath: String,
)

data class CameraConfiguration(
    val id: String,
    val lensLabel: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val stabilizationSupported: Boolean,
    val stabilizationEnabled: Boolean = false,
    val audioEnabled: Boolean = true,
)

/** Pure transition logic: control ACKs are emitted only after the camera layer confirms the action. */
class RemoteCameraStateMachine {
    var state: CameraState = CameraState.READY
        private set
    var finalizedManifest: RecordingManifest? = null
        private set

    fun recordingStarted() {
        check(state == CameraState.READY) { "recording can only start from READY" }
        finalizedManifest = null
        state = CameraState.RECORDING
    }

    fun stopRequested() {
        check(state == CameraState.RECORDING) { "stop requires RECORDING" }
        state = CameraState.STOPPING
    }

    fun recordingFinalized(manifest: RecordingManifest) {
        check(state == CameraState.STOPPING || state == CameraState.RECORDING)
        finalizedManifest = manifest
        state = CameraState.READY
    }

    fun recordingFailed() { state = CameraState.ERROR }
    fun recoverReady() { state = CameraState.READY }
}

class PairingAuthority(private val clockMillis: () -> Long = System::currentTimeMillis) {
    private val random = SecureRandom()
    private var pairingCode: String = newCode()
    private var codeCreatedAt = clockMillis()
    private val sessions = mutableMapOf<String, Session>()

    data class Session(val clientID: String, val expiresAtMillis: Long)

    fun currentCode(): String {
        if (clockMillis() - codeCreatedAt > 10 * 60_000L) rotateCode()
        return pairingCode
    }

    fun pair(code: String, clientID: String): String? {
        if (code != currentCode() || clientID.isBlank()) return null
        val token = ByteArray(32).also(random::nextBytes).joinToString("") { "%02x".format(it) }
        sessions[token] = Session(clientID, clockMillis() + 12 * 60 * 60_000L)
        rotateCode() // one-time PIN
        return token
    }

    fun isAuthorized(token: String?): Boolean {
        if (token == null) return false
        val session = sessions[token] ?: return false
        if (session.expiresAtMillis <= clockMillis()) {
            sessions.remove(token)
            return false
        }
        return true
    }

    private fun rotateCode() {
        pairingCode = newCode()
        codeCreatedAt = clockMillis()
    }

    private fun newCode() = (100000 + random.nextInt(900000)).toString()
}

object Hashing {
    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
