package com.tasnim.perchecamera

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var pinView: TextView
    private lateinit var stateView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            pinView.text = "Code d’appairage : ${CompanionRuntime.pairing.currentCode()}"
            stateView.text = "État : ${CompanionRuntime.stateMachine.state.name.lowercase()}"
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 80, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Perche Camera Companion"
            textSize = 28f
        })
        pinView = TextView(this).apply { textSize = 24f; setPadding(0, 48, 0, 24) }
        stateView = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, 24) }
        root.addView(pinView)
        root.addView(stateView)
        root.addView(TextView(this).apply {
            text = "Laissez cette application ouverte ou au premier plan pendant l’appairage. Le fichier maître est enregistré sur ce Pixel avant tout transfert vers l’iPad. Aucun cloud n’est requis."
            textSize = 16f
        })
        setContentView(root)
        requestPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 37) permissions += "android.permission.ACCESS_LOCAL_NETWORK"
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCameraService() else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraService()
        } else {
            stateView.text = "Autorisation caméra requise. Ouvrez les réglages de l’application."
        }
    }

    private fun startCameraService() {
        val intent = Intent(this, CameraRecordingService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }
}
