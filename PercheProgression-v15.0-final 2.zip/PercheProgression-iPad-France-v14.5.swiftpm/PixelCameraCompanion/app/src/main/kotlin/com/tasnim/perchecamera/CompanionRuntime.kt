package com.tasnim.perchecamera

import com.tasnim.perchecamera.protocol.PairingAuthority
import com.tasnim.perchecamera.protocol.RemoteCameraStateMachine

object CompanionRuntime {
    val pairing = PairingAuthority()
    val stateMachine = RemoteCameraStateMachine()
    @Volatile var service: CameraRecordingService? = null
}
