# Fusion v14.0 — journal sportif + biomécanique

## Principe

`Vaults.zip` contient des captures d’écran et non un projet source. Il a donc été utilisé comme référence UX et fonctionnelle. Perche Progression v13.3 reste la base native SwiftUI/SwiftData et conserve l’ensemble de son moteur vidéo.

## Éléments retenus de l’application de référence

- page d’accueil orientée vers l’action ;
- journal détaillé par séance et par saut ;
- liaison des vidéos aux sauts depuis leur fiche ;
- saisie vocale avec écran de vérification ;
- conditions de séance et niveau d’énergie ;
- navigation séparant séances, sauts et vidéos ;
- jalons et progression visible ;
- gestion locale de plusieurs athlètes.

## Éléments conservés et renforcés de Perche Progression

- Swift 6, SwiftUI, SwiftData, AVFoundation, Vision/Core ML et PencilKit ;
- calibration projective du plan de piste et caméra fixe en biais ;
- grille fine, micro-ajustement, origine relative quand le butoir est hors champ ;
- suivi longitudinal, vitesse moyenne, pic P95 et contrôle des incohérences cinématiques ;
- analyse de posture, angles, vecteurs, dessin et comparaison vidéo ;
- recommandation explicable de perches et séparation stricte des protocoles de vitesse ;
- bibliothèque d’exercices et liens vers les sources officielles ;
- stockage vidéo relatif, sauvegarde JSON et absence de remplacement silencieux par une base mémoire.

## Fonctions volontairement non simulées

Le fil communautaire, les invitations, les équipes distantes, la messagerie et la revue vidéo payante de l’application de référence nécessitent un backend, des comptes, une politique de modération et un traitement juridique des vidéos. La v14 ne présente pas de faux écran connecté : elle fournit à la place des profils multi-athlètes locaux, utilisables par un entraîneur sur le même iPad.

## Dictée et sécurité des données

La reconnaissance française utilise le framework Speech d’Apple. Lorsque l’appareil prend en charge la reconnaissance embarquée, elle est demandée en priorité. La phrase transcrite est analysée en mémoire pour proposer : résultat, hauteur, foulées, perche, qualité, repères et diagnostics. Rien n’est enregistré avant la confirmation de l’utilisateur.

## Évolution du modèle de données

Les nouvelles propriétés SwiftData possèdent toutes une valeur par défaut afin de permettre la migration légère du store existant :

- séance : lieu, environnement, météo, vent, température, énergie et objectif ;
- saut : qualité, prise, longueur d’élan, marque intermédiaire, marque d’impulsion, poteaux et transcription.

Le format de sauvegarde JSON passe au schéma 3 et exporte ces nouveaux champs.

## Validation prévue sur iPad

1. Ouvrir le package dans Swift Playgrounds sur iPadOS 18.
2. Autoriser la caméra, les photos, le microphone et la reconnaissance vocale lorsque ces fonctions sont utilisées.
3. Créer une séance, renseigner les conditions et enregistrer un saut manuel.
4. Dicter : « Saut réussi, barre 4 mètres 80, 16 foulées, perche 4 mètres 60, 77 kilos, bonne impulsion. » puis vérifier tous les champs avant validation.
5. Ouvrir l’historique, modifier le saut et contrôler le calcul des jalons.
6. Importer une vidéo et exécuter le protocole de validation `VALIDATION_PROTOCOL_V12.md` pour la calibration et la vitesse.
