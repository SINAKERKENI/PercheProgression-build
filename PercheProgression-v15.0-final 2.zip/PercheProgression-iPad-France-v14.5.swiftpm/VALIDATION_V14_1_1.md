# Validation v14.1.1

Date : 20 août 2026

## Contrôles réussis

- 73 fichiers Swift parcourus : délimiteurs, commentaires et chaînes équilibrés.
- Aucun fichier `.mp4`, `.mov` ou `.m4v` ne subsiste dans les ressources d’exercices.
- Aucun lien de créateur ou catalogue externe n’est présélectionné dans l’interface active.
- Les seules références `bundle://` restantes appartiennent à la migration qui nettoie les anciennes données.
- `ExerciseVideoRecord` est déclaré dans le modèle, enregistré dans le schéma SwiftData et inclus dans l’export JSON complet.
- Les dix catégories sont accessibles sans données d’amorçage : six phases techniques, Abdos & gainage, Gymnastique, Sprint & course d’élan, Force & mobilité.
- L’orange et `vaultAccent` ne sont plus utilisés dans le module `Features/Video`.
- La teinte de navigation et le bouton de saisie rapide passent également au bleu d’analyse lorsque l’écran vidéo est actif.
- Tests unitaires ajoutés pour la normalisation des URL, le rejet des schémas non web, le titre de repli d’un fichier direct, l’affichage de l’hôte et la couverture des catégories.
- Le formulaire URL utilise l’initialiseur complet `Section { } header: { } footer: { }`, compatible avec SwiftUI/iOS 18.
- `LPMetadataProvider` n’est plus capturé dans une fermeture `@Sendable` : son API asynchrone native est utilisée.
- L’appel déprécié `AVAudioSession.requestRecordPermission` a été supprimé au profit de `AVAudioApplication.requestRecordPermission()`.

## Contraste calculé

| Usage | Couleur | Fond ivoire | Fond blanc | Fond noir |
| --- | --- | ---: | ---: | ---: |
| Commandes d’analyse | `#00629B` | 6,08:1 | 6,52:1 | 3,22:1 |
| État à vérifier | `#733591` | 7,40:1 | 7,93:1 | 2,65:1 |
| Repères sur la vidéo | `#0077B6` | 4,54:1 | 4,87:1 | 4,31:1 |

Les couleurs de texte et de commandes dépassent 4,5:1 sur les panneaux clairs. Les repères graphiques dépassent 3:1 sur les images claires et sombres.

## Validation Apple restante

Le conteneur Linux ne fournit pas `swift`, `swiftc`, `xcodebuild` ni les frameworks iOS. La compilation et l’exécution des tests XCTest doivent donc être lancées dans Swift Playgrounds ou Xcode sur macOS/iPadOS avant diffusion App Store.
