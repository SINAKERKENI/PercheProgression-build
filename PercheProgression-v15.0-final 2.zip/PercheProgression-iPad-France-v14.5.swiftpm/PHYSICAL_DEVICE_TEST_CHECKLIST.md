# Checklist appareil réel — v15

## Appairage Pixel
- [ ] Ouvrir le compagnon Pixel.
- [ ] Accorder les permissions demandées.
- [ ] Mettre Pixel et iPad sur le même LAN.
- [ ] Découvrir le Pixel depuis l’iPad.
- [ ] Terminer l’authentification/appairage.
- [ ] Vérifier l’état « prêt » sur les deux appareils.

## Enregistrement distant
- [ ] Choisir une combinaison objectif/FPS réellement annoncée comme supportée.
- [ ] Appuyer sur Enregistrer sur l’iPad.
- [ ] Vérifier la réception de l’ACK Android.
- [ ] Vérifier « enregistrement » sur les deux appareils.
- [ ] Enregistrer environ 10 s.
- [ ] Arrêter depuis l’iPad.
- [ ] Vérifier que l’événement CameraX Finalize est terminé.

## Transfert
- [ ] Vérifier que le transfert démarre.
- [ ] Vérifier la validation finale SHA-256.
- [ ] Vérifier que la vidéo apparaît dans Perche Progression.
- [ ] L’ouvrir dans Analyse vidéo.
- [ ] Contrôler durée, orientation et résolution.

## Reprise
- [ ] Enregistrer une deuxième vidéo puis l’arrêter.
- [ ] Couper le Wi-Fi pendant le transfert.
- [ ] Rétablir le réseau.
- [ ] Vérifier que le transfert reprend correctement.
- [ ] Vérifier que le checksum final réussit.

## Perte réseau pendant l’enregistrement
- [ ] Démarrer un enregistrement.
- [ ] Déconnecter le réseau avant STOP.
- [ ] Vérifier que le Pixel conserve/finalise sans perdre le maître local.

## Haute cadence
- [ ] Choisir une cadence élevée réellement supportée.
- [ ] Filmer un élan court.
- [ ] Transférer la vidéo.
- [ ] Avancer image par image sur l’iPad.
- [ ] Vérifier la chronologie PTS et le pas image.

## Perspective
- [ ] Placer le Pixel avec un angle oblique par rapport à la piste.
- [ ] Filmer un déplacement sur une distance connue.
- [ ] Calibrer le plan de piste.
- [ ] Lancer l’analyse de vitesse.
- [ ] Comparer au temps/distance connus indépendamment.
- [ ] Dégrader volontairement la calibration et vérifier que la mesure est refusée.

## Migration v14.5
- [ ] Sauvegarder un vrai conteneur/store v14.5.
- [ ] L’ouvrir avec v15 sur runtime Apple.
- [ ] Vérifier le profil athlète.
- [ ] Vérifier les séances.
- [ ] Vérifier les tentatives.
- [ ] Vérifier les perches.
- [ ] Vérifier les hauteurs de prise.
- [ ] Vérifier les vidéos.
- [ ] Vérifier les annotations.
- [ ] Vérifier les personnalisations Harada.
