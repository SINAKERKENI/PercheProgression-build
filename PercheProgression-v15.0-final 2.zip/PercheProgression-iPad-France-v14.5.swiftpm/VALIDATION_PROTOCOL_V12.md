# Protocole de validation terrain — v12

## Objectif
Quantifier séparément le biais, la MAE, la RMSE et les limites d’accord de chaque **protocole**. Ne jamais agréger radar, cellules, estimation vidéo anthropométrique et mesure homographique dans un seul score.

## Corpus minimum recommandé
- Au moins 30 athlètes, plusieurs morphologies et niveaux.
- Au moins 10 essais exploitables par athlète, incluant lumière, arrière-plan et angles caméra variés.
- Sous-corpus dédiés : caméra fixe, panoramique modéré, 30/60/120/240 fps, 29,97/59,94 et fichiers VFR.
- Plusieurs appareils iPhone/iPad et focales ; ultra-grand-angle traité séparément.

## Vérités terrain
- Vitesse 5 m / 10 m : cellules photoélectriques ou radar synchronisé.
- Marque d’impulsion : mesure métrique directe depuis le fond du butoir.
- Temps d’événement : annotation image par image par au moins deux experts.
- Angles : système 3D ou protocole 2D calibré lorsque la comparaison 2D est l’objectif.

## Métriques statistiques
Pour chaque protocole et condition :
1. biais moyen signé ;
2. MAE ;
3. RMSE ;
4. médiane et P95 de l’erreur absolue ;
5. Bland–Altman / limites d’accord ;
6. taux d’échec du tracking et taux de frames `manualRequired` ;
7. fiabilité inter-opérateur des corrections manuelles ;
8. latence, chauffe, mémoire et batterie sur iPad cible.

## Critères de libération
Les seuils d’acceptation doivent être définis **avant** l’analyse finale du corpus. Une mesure ne reçoit un affichage « validée » que si son protocole, sa version d’algorithme et sa plage de conditions satisfont ces critères.

## Tests UX iPad
Tester doigt + Apple Pencil, VoiceOver, Dynamic Type maximal, portrait/paysage, vidéos longues, import interrompu, store SwiftData existant, media manquant/corrompu et comparaison de deux vidéos lourdes.
