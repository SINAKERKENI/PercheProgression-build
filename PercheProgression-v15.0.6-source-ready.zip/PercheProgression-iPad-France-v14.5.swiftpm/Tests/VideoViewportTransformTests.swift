import CoreGraphics
import XCTest
@testable import AppModule

final class VideoViewportTransformTests: XCTestCase {
  func testPrimaryAndReferenceTransformsStayIndependent() {
    var primary = VideoViewportTransform()
    var reference = VideoViewportTransform()

    primary.applyScale(2)
    primary.translation = CGSize(width: 20, height: -8)
    primary.rotationRadians = 0.10

    XCTAssertEqual(reference, VideoViewportTransform())

    reference.applyScale(3)
    reference.translation = CGSize(width: -12, height: 6)
    reference.rotationRadians = -0.08

    XCTAssertEqual(primary.scale, 2)
    XCTAssertEqual(primary.translation, CGSize(width: 20, height: -8))
    XCTAssertEqual(primary.rotationRadians, 0.10)
  }

  func testResetAffectsOnlySelectedViewport() {
    var primary = VideoViewportTransform(scale: 2, translation: CGSize(width: 10, height: 5), rotationRadians: 0.05)
    var reference = VideoViewportTransform(scale: 4, translation: CGSize(width: -30, height: 12), rotationRadians: -0.12)

    reference.reset()

    XCTAssertEqual(reference, VideoViewportTransform())
    XCTAssertEqual(primary.scale, 2)
    XCTAssertEqual(primary.translation, CGSize(width: 10, height: 5))
    XCTAssertEqual(primary.rotationRadians, 0.05)
  }

  func testZoomIsClampedToUsefulRange() {
    var transform = VideoViewportTransform()
    transform.applyScale(50)
    XCTAssertEqual(transform.scale, 12)
    transform.applyScale(0.001)
    XCTAssertEqual(transform.scale, 1)
  }
}
