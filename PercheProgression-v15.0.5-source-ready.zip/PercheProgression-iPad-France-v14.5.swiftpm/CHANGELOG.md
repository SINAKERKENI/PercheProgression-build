# Changelog

## 15.0.5

### Caméra Pixel distante — démarrage et configuration
- Le démarrage d’enregistrement réutilise la session CameraX déjà liée `Preview + VideoCapture` ; `recordStart` ne rebinde plus implicitement la caméra.
- Les opérations caméra sont sérialisées par des états explicites `READY`, `RECONFIGURING`, `STARTING_RECORDING`, `RECORDING`, `FINALIZING` et `ERROR`.
- L’ACK d’enregistrement n’est envoyé qu’après `VideoRecordEvent.Start`; un délai borné récupère proprement un démarrage qui ne se confirme pas.
- Les exceptions `prepareRecording`, `PendingRecording.start` et callbacks CameraX sont capturées et conservées comme diagnostic sans laisser un échec récupérable tuer le processus.
- Quand le microphone est désactivé, `withAudioEnabled()` n’est jamais appelé.
- Les changements de caméra/configuration demandés depuis l’iPad sont transactionnels : le Pixel rebinde d’abord, confirme sa configuration active, puis l’iPad met à jour son sélecteur. En cas d’échec, la configuration précédente reste active.
- Le compagnon conserve un journal caméra privé et affiche au prochain lancement le dernier incident avec une action « Copier le diagnostic ».
- Version iOS 15.0.5 (build 38), compagnon Android 15.0.5 (`versionCode 150005`).

## 15.0.4

### Caméra Pixel distante
- Ajout d’un aperçu CameraX réel via `PreviewView`, actif dès que la permission caméra est accordée.
- `Preview` et `VideoCapture` partagent la même liaison CameraX et la même caméra/configuration.
- Caméra arrière principale, 1280×720, 30 i/s, microphone désactivé et stabilisation désactivée privilégiés au démarrage.
- Affichage Pixel des états d’ouverture, aperçu actif, liaison CameraX, VideoCapture, configuration, durée d’enregistrement et version `15.0.4 (150004)`.
- `STATUS` expose `cameraReady`, `previewActive` et la configuration liée ; l’iPad désactive Enregistrer tant que la caméra Pixel n’est pas prête.
- Le microphone n’est demandé qu’à l’activation de l’audio.
- Le cycle v15.0.3 finalisation/réconciliation/transfert reste inchangé.

## 15.0.3

### Caméra Pixel distante — cycle complet
- Les téléchargements `.partial` ne déterminent plus l’extension du média durable : l’extension provient du nom de fichier du manifeste distant et est limitée à MP4/MOV/M4V.
- Un import distant n’est persisté comme `VideoClipRecord` qu’après validation réelle AVFoundation (durée finie et positive, piste vidéo et géométrie lisibles).
- Migration non destructive des anciennes vidéos Pixel stockées en `source.partial` : copie au bon suffixe, contrôle SHA-256, validation AVFoundation, mise à jour SwiftData, puis suppression de l’ancienne copie seulement après succès.
- Stop iPad, Stop Pixel et finalisation CameraX convergent vers le même pipeline de finalisation et un manifeste persistant.
- STATUS expose la dernière vidéo finalisée non acquittée ; l’iPad réconcilie une réponse STOP manquée ou un Stop local et reprend automatiquement le transfert.
- Le transfert reste reprenable/idempotent par `remoteRecordingID` et la copie maître Pixel n’est jamais supprimée automatiquement.
- L’état d’erreur CameraX est récupérable à l’arrêt ; le Pixel affiche la dernière erreur et propose « Réinitialiser la caméra » sans supprimer les vidéos/manifeste.
- Version iOS 15.0.3 (build 36), compagnon Android 15.0.3 (`versionCode 150003`).

## 15.0.0

### Progression & FFA
- Suppression du radar de performance arbitraire et de son flux d’édition ; `PerformanceDimensionRecord` reste uniquement pour la compatibilité des stores existants.
- Ajout de `OfficialPerformanceRecord` pour conserver les performances officielles séparément des tentatives d’entraînement.
- Association explicite à un athlète FFA, synchronisation, cache local, historique indoor/outdoor, déduplication et mise à jour des résultats corrigés.
- Progression des records officiels calculée chronologiquement à partir des seules performances de perche importées ; le record d’entraînement reste distinct.
- Correction des filtres de `AnalyticsEngine.cumulativePRPoints`.

### Recommandation de perche
- Nouveau moteur candidat-par-candidat `pole-decision-v15.0` : rester, monter, descendre ou changer latéralement.
- Utilisation de l’historique athlète, diagnostics, prise, protocole de vitesse, longueur d’élan, qualité technique et caractéristiques réelles des perches.
- Comparaison de flex limitée aux familles fabricant/modèle compatibles ; transition inter-familles signalée avec confiance réduite.
- `progressionOrder` n’est plus un sélecteur sportif et ne sert qu’au départage final.
- Acceptation, refus ou ignorance d’une recommandation persistés dans SwiftData.

### Analyse vidéo
- `PerspectiveAwareSpeedEngine` devient la source quantitative des vitesses métriques calibrées.
- Homographie fixe ou dynamique, positions au sol issues en priorité des appuis/chevilles, PTS vidéo réels et rejet des géométries non fiables.
- Diagnostics de qualité inspectables : calibration, stabilité/nombre d’ancrages, continuité d’homographie, suivi athlète, confiance du point au sol, couverture trajectoire, outliers et couverture PTS.
- Les anciens modes anthropométriques/bassin restent consultables mais ne peuvent plus enregistrer silencieusement une vitesse métrique calibrée v15.

### Comparaison vidéo & plein écran
- Zoom/panoramique indépendants des vidéos principale et de référence.
- Pas image de la référence basé sur ses propres PTS, y compris lorsque les cadences diffèrent.
- Timeline de précision persistante en plein écran ; le chrome supérieur peut se masquer sans faire disparaître la timeline.
- Arbitrage : gestes à un doigt pour les outils d’annotation, gestes à deux doigts pour le viewport.
- Manipulation directe de la superposition de référence avec transformation dédiée.

### Caméra Pixel distante
- Projet Android `PixelCameraCompanion/` avec CameraX et découverte locale.
- Appairage explicite, canal de contrôle authentifié et transitions d’état acquittées.
- Enregistrement maître sur le Pixel, finalisation avant transfert, reprise HTTP Range, contrôle de taille et SHA-256.
- Import uniquement après vérification d’intégrité dans `VideoAssetStore`, avec prévention des doublons de `remoteRecordingID`.

### Harada
- Huit piliers spécifiques à la perche avec actions concrètes et non artificiellement remplies.
- Édition, type, récurrence, cible, archivage, réordonnancement et focus « En ce moment » persistés.
- Les feuilles de route existantes ne sont pas réensemencées lors d’une mise à jour.

### Migration
- Bundle identifier conservé : `com.tasnim.vaultroadmap.ipad`.
- Aucune suppression/recréation automatique du store SwiftData.
- Les anciens profils, séances, tentatives, perches, vidéos, annotations, mesures et personnalisations restent dans le même store persistant.
