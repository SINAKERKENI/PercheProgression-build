import Combine
import CryptoKit
import Foundation
import Network
#if canImport(Darwin)
import Darwin
#endif

private enum BonjourDiscoveryEvent: Sendable {
  case resolved(RemoteCameraEndpoint)
  case removed(name: String)
}

enum RemoteCameraSockaddrParser {
  static func numericIPAddress(from data: Data) -> RemoteCameraResolvedAddress? {
    #if canImport(Darwin)
    return data.withUnsafeBytes { rawBuffer in
      guard let baseAddress = rawBuffer.baseAddress,
            data.count >= MemoryLayout<sockaddr>.size
      else { return nil }

      let socketAddress = baseAddress.assumingMemoryBound(to: sockaddr.self)
      let family = Int32(socketAddress.pointee.sa_family)
      let addressFamily: RemoteCameraResolvedAddress.Family
      switch family {
      case AF_INET:
        addressFamily = .ipv4
      case AF_INET6:
        addressFamily = .ipv6
      default:
        return nil
      }

      var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
      let result = getnameinfo(
        socketAddress,
        socklen_t(data.count),
        &host,
        socklen_t(host.count),
        nil,
        0,
        NI_NUMERICHOST
      )
      guard result == 0 else { return nil }

      let value = String(cString: host)
      guard !value.isEmpty else { return nil }
      return RemoteCameraResolvedAddress(family: addressFamily, address: value)
    }
    #else
    return nil
    #endif
  }
}

/// Foundation owns the NetService callback contract. This worker intentionally has no
/// global-actor isolation; it keeps NetService objects on their callback/run-loop side
/// and emits only immutable, Sendable endpoint values to the MainActor observable model.
private final class BonjourCameraDiscoveryWorker: NSObject, NetServiceBrowserDelegate, NetServiceDelegate {
  var onEvent: (@Sendable (BonjourDiscoveryEvent) -> Void)?

  private let browser = NetServiceBrowser()
  private var services: [NetService] = []

  override init() {
    super.init()
    browser.delegate = self
  }

  func start() {
    stop()
    browser.searchForServices(ofType: "_perche-camera._tcp.", inDomain: "local.")
  }

  func stop() {
    browser.stop()
    services.forEach { $0.stop() }
    services.removeAll()
  }

  func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
    guard !services.contains(where: { $0 === service }) else { return }
    services.append(service)
    service.delegate = self
    service.resolve(withTimeout: 5)
  }

  func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool) {
    services.removeAll { $0 === service }
    onEvent?(.removed(name: service.name))
  }

  func netServiceDidResolveAddress(_ sender: NetService) {
    guard sender.port > 0 else { return }

    let numericAddresses = sender.addresses?.compactMap(RemoteCameraSockaddrParser.numericIPAddress(from:)) ?? []
    let fallbackHost = sender.hostName?.trimmingCharacters(in: CharacterSet(charactersIn: "."))
    guard let host = RemoteCameraEndpointSelection.preferredHost(
      numericAddresses: numericAddresses,
      fallbackHost: fallbackHost
    ) else { return }

    var transferPort = sender.port + 1
    var deviceID = sender.name
    if let txt = sender.txtRecordData() {
      let dictionary = NetService.dictionary(fromTXTRecord: txt)
      if let data = dictionary["transferPort"],
         let string = String(data: data, encoding: .utf8),
         let parsed = Int(string), parsed > 0
      {
        transferPort = parsed
      }
      if let data = dictionary["deviceID"],
         let string = String(data: data, encoding: .utf8),
         !string.isEmpty
      {
        deviceID = string
      }
    }

    onEvent?(.resolved(RemoteCameraEndpoint(
      name: sender.name,
      host: host,
      controlPort: sender.port,
      transferPort: transferPort,
      deviceID: deviceID
    )))
  }


}

@MainActor
final class BonjourCameraDiscovery: ObservableObject {
  @Published private(set) var endpoints: [RemoteCameraEndpoint] = []

  private let worker: BonjourCameraDiscoveryWorker

  init() {
    let worker = BonjourCameraDiscoveryWorker()
    self.worker = worker
    worker.onEvent = { [weak self] event in
      Task { @MainActor in
        self?.apply(event)
      }
    }
  }

  func start() { worker.start() }
  func stop() { worker.stop() }

  private func apply(_ event: BonjourDiscoveryEvent) {
    switch event {
    case .resolved(let endpoint):
      endpoints.removeAll { $0.deviceID == endpoint.deviceID || $0.name == endpoint.name }
      endpoints.append(endpoint)
      endpoints.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    case .removed(let name):
      endpoints.removeAll { $0.name == name }
    }
  }
}

private enum PixelConnectionEvent: Sendable {
  case ready
  case failed(String)
  case cancelled
}

actor PixelControlTransport {
  private var connection: NWConnection?
  private var receiveBuffer = Data()
  private var pending: [UUID: CheckedContinuation<RemoteControlResponse, Error>] = [:]
  private var requestTimeouts: [UUID: Task<Void, Never>] = [:]
  private var connectContinuation: CheckedContinuation<Void, Error>?
  private var connectAttemptID: UUID?
  private var activeEndpoint: RemoteCameraEndpoint?
  private let queue = DispatchQueue(label: "PercheProgression.PixelControl")

  func connect(to endpoint: RemoteCameraEndpoint) async throws {
    close()
    guard let port = NWEndpoint.Port(rawValue: UInt16(endpoint.controlPort)) else {
      throw RemoteCameraError.connectionFailed(host: endpoint.host, port: endpoint.controlPort, detail: "Port de contrôle invalide.")
    }

    let host = NWEndpoint.Host(endpoint.host)
    let newConnection = NWConnection(host: host, port: port, using: .tcp)
    let attemptID = UUID()
    connection = newConnection
    activeEndpoint = endpoint
    connectAttemptID = attemptID

    try await withTaskCancellationHandler {
      try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
        connectContinuation = continuation
        newConnection.stateUpdateHandler = { [weak self] state in
          let event: PixelConnectionEvent?
          switch state {
          case .ready:
            event = .ready
          case .failed(let error):
            event = .failed(String(describing: error))
          case .cancelled:
            event = .cancelled
          default:
            event = nil
          }
          guard let event else { return }
          Task { await self?.handleConnectionEvent(event, attemptID: attemptID, endpoint: endpoint) }
        }
        newConnection.start(queue: queue)
      }
    } onCancel: {
      Task { await self.cancelConnect(attemptID: attemptID, endpoint: endpoint) }
    }

    receiveNext()
  }

  func close() {
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
    activeEndpoint = nil

    if let continuation = connectContinuation {
      connectContinuation = nil
      connectAttemptID = nil
      continuation.resume(throwing: RemoteCameraError.notConnected)
    } else {
      connectAttemptID = nil
    }

    requestTimeouts.values.forEach { $0.cancel() }
    requestTimeouts.removeAll()
    let continuations = pending.values
    pending.removeAll()
    continuations.forEach { $0.resume(throwing: RemoteCameraError.notConnected) }
  }

  func request(
    _ request: RemoteControlRequest,
    timeoutSeconds: Double = 8,
    operationName: String? = nil
  ) async throws -> RemoteControlResponse {
    guard let connection else { throw RemoteCameraError.notConnected }
    let payload = try JSONEncoder().encode(request) + Data([0x0A])
    let operation = operationName ?? request.type

    return try await withTaskCancellationHandler {
      try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<RemoteControlResponse, Error>) in
        pending[request.id] = continuation
        let nanos = UInt64(max(timeoutSeconds, 0.25) * 1_000_000_000)
        requestTimeouts[request.id] = Task { [weak self] in
          try? await Task.sleep(nanoseconds: nanos)
          guard !Task.isCancelled else { return }
          await self?.timeout(requestID: request.id, operation: operation)
        }
        connection.send(content: payload, completion: .contentProcessed { [weak self] error in
          guard let error else { return }
          let detail = String(describing: error)
          Task { await self?.fail(requestID: request.id, error: RemoteCameraError.controlChannelFailed(detail)) }
        })
      }
    } onCancel: {
      Task { await self.cancelRequest(requestID: request.id) }
    }
  }

  private func handleConnectionEvent(_ event: PixelConnectionEvent, attemptID: UUID, endpoint: RemoteCameraEndpoint) {
    guard connectAttemptID == attemptID else {
      if case .failed(let detail) = event, activeEndpoint == endpoint {
        failAll(RemoteCameraError.connectionFailed(host: endpoint.host, port: endpoint.controlPort, detail: detail))
      } else if case .cancelled = event, activeEndpoint == endpoint {
        failAll(RemoteCameraError.connectionCancelled(host: endpoint.host, port: endpoint.controlPort))
      }
      return
    }

    switch event {
    case .ready:
      finishConnect(attemptID: attemptID, result: .success(()))
    case .failed(let detail):
      finishConnect(
        attemptID: attemptID,
        result: .failure(RemoteCameraError.connectionFailed(host: endpoint.host, port: endpoint.controlPort, detail: detail))
      )
      connection?.cancel()
      connection = nil
      activeEndpoint = nil
    case .cancelled:
      finishConnect(
        attemptID: attemptID,
        result: .failure(RemoteCameraError.connectionCancelled(host: endpoint.host, port: endpoint.controlPort))
      )
      connection = nil
      activeEndpoint = nil
    }
  }

  private func finishConnect(attemptID: UUID, result: Result<Void, Error>) {
    guard connectAttemptID == attemptID, let continuation = connectContinuation else { return }
    connectContinuation = nil
    connectAttemptID = nil
    continuation.resume(with: result)
  }

  private func cancelConnect(attemptID: UUID, endpoint: RemoteCameraEndpoint) {
    guard connectAttemptID == attemptID else { return }
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
    activeEndpoint = nil
    finishConnect(
      attemptID: attemptID,
      result: .failure(RemoteCameraError.connectionCancelled(host: endpoint.host, port: endpoint.controlPort))
    )
  }

  private func timeout(requestID: UUID, operation: String) {
    guard let continuation = pending.removeValue(forKey: requestID) else { return }
    requestTimeouts.removeValue(forKey: requestID)?.cancel()
    continuation.resume(throwing: RemoteCameraError.requestTimedOut(operation))
  }

  private func cancelRequest(requestID: UUID) {
    requestTimeouts.removeValue(forKey: requestID)?.cancel()
    pending.removeValue(forKey: requestID)?.resume(throwing: CancellationError())
  }

  private func fail(requestID: UUID, error: Error) {
    requestTimeouts.removeValue(forKey: requestID)?.cancel()
    pending.removeValue(forKey: requestID)?.resume(throwing: error)
  }

  private func receiveNext() {
    guard let connection else { return }
    connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, complete, error in
      let received = data
      let failureDetail = error.map { String(describing: $0) }
      Task {
        guard let self else { return }
        if let received { await self.ingest(received) }
        if let failureDetail {
          await self.failAll(RemoteCameraError.controlChannelFailed(failureDetail))
          return
        }
        if complete {
          await self.failAll(RemoteCameraError.notConnected)
          return
        }
        await self.receiveNext()
      }
    }
  }

  private func ingest(_ data: Data) {
    receiveBuffer.append(data)
    while let newline = receiveBuffer.firstIndex(of: 0x0A) {
      let line = receiveBuffer.prefix(upTo: newline)
      receiveBuffer.removeSubrange(...newline)
      guard !line.isEmpty,
            let response = try? JSONDecoder().decode(RemoteControlResponse.self, from: Data(line)),
            let id = response.id
      else { continue }
      requestTimeouts.removeValue(forKey: id)?.cancel()
      pending.removeValue(forKey: id)?.resume(returning: response)
    }
  }

  private func failAll(_ error: Error) {
    requestTimeouts.values.forEach { $0.cancel() }
    requestTimeouts.removeAll()
    let continuations = pending.values
    pending.removeAll()
    continuations.forEach { $0.resume(throwing: error) }
    connection?.stateUpdateHandler = nil
    connection?.cancel()
    connection = nil
    activeEndpoint = nil
  }
}

actor RemoteVideoTransferService {
  private let stagingRootOverride: URL?
  private let session: URLSession

  init(stagingRootOverride: URL? = nil, session: URLSession = .shared) {
    self.stagingRootOverride = stagingRootOverride
    self.session = session
  }

  private func stagingDirectory() throws -> URL {
    if let stagingRootOverride {
      try FileManager.default.createDirectory(at: stagingRootOverride, withIntermediateDirectories: true)
      return stagingRootOverride
    }
    let support = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let directory = support.appendingPathComponent("PercheProgression/RemoteTransfers", isDirectory: true)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    return directory
  }

  func transfer(manifest: RemoteRecordingManifest, endpoint: RemoteCameraEndpoint, token: String) async throws -> ImportedVideoAsset {
    let preferredExtension: String
    do {
      preferredExtension = try VideoAssetStore.preferredVideoExtension(fromRemoteFilename: manifest.filename)
    } catch {
      throw RemoteCameraError.invalidRemoteFilename(manifest.filename)
    }

    let safeID = manifest.recordingID.replacingOccurrences(of: "/", with: "_")
    let partial = try stagingDirectory().appendingPathComponent("\(safeID).partial")
    var existingSize = (try? partial.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
    if existingSize > manifest.sizeBytes {
      try? FileManager.default.removeItem(at: partial)
      existingSize = 0
    }
    var offset = RemoteTransferResumePolicy.resumeOffset(existingBytes: existingSize, expectedBytes: manifest.sizeBytes)

    if offset < manifest.sizeBytes {
      let host = endpoint.host.hasSuffix(".") ? String(endpoint.host.dropLast()) : endpoint.host
      var components = URLComponents()
      components.scheme = "http"
      components.host = host
      components.port = endpoint.transferPort
      components.path = manifest.transferPath.hasPrefix("/") ? manifest.transferPath : "/\(manifest.transferPath)"
      guard let url = components.url else { throw RemoteCameraError.invalidTransferResponse }
      var request = URLRequest(url: url)
      request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
      if offset > 0 { request.setValue("bytes=\(offset)-", forHTTPHeaderField: "Range") }
      let (downloadURL, response) = try await session.download(for: request)
      guard let http = response as? HTTPURLResponse else { throw RemoteCameraError.invalidTransferResponse }
      if offset > 0, http.statusCode == 200 {
        try? FileManager.default.removeItem(at: partial)
        offset = 0
      } else if ![200, 206].contains(http.statusCode) {
        throw RemoteCameraError.invalidTransferResponse
      }
      try appendFile(downloadURL, to: partial, truncate: offset == 0)
    }

    let actualSize = (try? partial.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
    guard actualSize == manifest.sizeBytes else {
      throw RemoteCameraError.incompleteTransfer(expected: manifest.sizeBytes, actual: actualSize)
    }
    guard try sha256Streaming(partial).caseInsensitiveCompare(manifest.sha256) == .orderedSame else {
      throw RemoteCameraError.checksumMismatch
    }

    var imported: ImportedVideoAsset?
    do {
      let candidate = try await VideoAssetStore.shared.importVideo(
        from: partial,
        preferredFileExtension: preferredExtension
      )
      imported = candidate
      guard candidate.sha256?.caseInsensitiveCompare(manifest.sha256) == .orderedSame else {
        throw RemoteCameraError.checksumMismatch
      }
      _ = try await VideoAssetStore.shared.validatePlayableVideo(at: candidate.url)
      try? FileManager.default.removeItem(at: partial)
      return candidate
    } catch {
      if let imported {
        try? await VideoAssetStore.shared.removeVideo(storageKey: imported.storageKey)
      }
      // Keep the staging .partial intact for retry/recovery. The Pixel master is also retained.
      throw error
    }
  }

  private func appendFile(_ source: URL, to destination: URL, truncate: Bool) throws {
    if truncate || !FileManager.default.fileExists(atPath: destination.path) {
      if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
      FileManager.default.createFile(atPath: destination.path, contents: nil)
    }
    let input = try FileHandle(forReadingFrom: source)
    let output = try FileHandle(forWritingTo: destination)
    defer { try? input.close(); try? output.close() }
    try output.seekToEnd()
    while true {
      let data = try input.read(upToCount: 1_048_576) ?? Data()
      if data.isEmpty { break }
      try output.write(contentsOf: data)
    }
  }

  private func sha256Streaming(_ url: URL) throws -> String {
    let handle = try FileHandle(forReadingFrom: url)
    defer { try? handle.close() }
    var hasher = SHA256()
    while true {
      let data = try handle.read(upToCount: 1_048_576) ?? Data()
      if data.isEmpty { break }
      hasher.update(data: data)
    }
    return hasher.finalize().map { String(format: "%02x", $0) }.joined()
  }
}

@MainActor
final class PixelRemoteCameraController: ObservableObject {
  @Published private(set) var state: RemoteCameraState = .disconnected
  @Published private(set) var configurations: [RemoteCameraConfiguration] = []
  @Published private(set) var selectedConfigurationID: String?
  @Published private(set) var stabilizationEnabled = false
  @Published private(set) var audioEnabled = false
  @Published private(set) var isConfiguring = false
  @Published private(set) var isStartingRecording = false
  @Published private(set) var cameraReady = false
  @Published private(set) var previewActive = false
  @Published private(set) var statusMessage = ""
  @Published private(set) var recordingStartedAt: Date?
  @Published private(set) var pendingManifest: RemoteRecordingManifest?

  let discovery = BonjourCameraDiscovery()
  private let control = PixelControlTransport()
  private let transfer = RemoteVideoTransferService()
  private var endpoint: RemoteCameraEndpoint?
  private var token: String?
  private let clientID = UUID().uuidString
  private var recordingMonitorTask: Task<Void, Never>?

  func startDiscovery() { discovery.start() }
  func stopDiscovery() { discovery.stop() }

  func pair(endpoint: RemoteCameraEndpoint, code: String) async {
    recordingMonitorTask?.cancel()
    pendingManifest = nil
    state = .connecting
    statusMessage = "Connexion TCP au Pixel · \(endpoint.host):\(endpoint.controlPort)…"
    do {
      try await control.connect(to: endpoint)
      statusMessage = "Connexion TCP établie."
      await Task.yield()

      statusMessage = "Connexion TCP établie · envoi du code d’appairage…"
      let response = try await control.request(
        RemoteControlRequest(type: "pair", pairingCode: code, clientID: clientID),
        operationName: "appairage"
      )
      guard response.ok, let token = response.token else {
        throw RemoteCameraError.rejected(response.message ?? "Appairage refusé.")
      }

      self.endpoint = endpoint
      self.token = token
      state = response.state ?? .ready
      statusMessage = "Appairage confirmé · \(endpoint.name)"
      await refreshStatus()
      if pendingManifest == nil, state == .ready {
        statusMessage = cameraReady
          ? "Pixel appairé · Caméra prête"
          : "Pixel appairé · Caméra non prête"
      }
    } catch {
      state = .error
      statusMessage = error.localizedDescription
    }
  }

  func refreshStatus() async {
    guard token != nil else { return }
    do {
      let response = try await requestStatus()
      applyStatusResponse(response, updateUserMessage: true)
    } catch {
      state = .disconnected
      statusMessage = "Connexion perdue. Tout enregistrement finalisé reste conservé sur le Pixel et sera récupéré après reconnexion."
    }
  }

  var configurationControlsEnabled: Bool {
    !isConfiguring && (state == .ready || state == .imported)
  }

  func requestConfigurationChange(
    configurationID requestedID: String? = nil,
    stabilization requestedStabilization: Bool? = nil,
    audio requestedAudio: Bool? = nil
  ) async {
    guard let token, configurationControlsEnabled else {
      if state == .recording || state == .stopping {
        statusMessage = "Arrêtez l’enregistrement avant de changer de caméra."
      }
      return
    }
    guard let targetID = requestedID ?? selectedConfigurationID,
          var config = configurations.first(where: { $0.id == targetID })
    else { return }

    let confirmedStabilization = requestedStabilization ?? stabilizationEnabled
    let confirmedAudio = requestedAudio ?? audioEnabled
    config.stabilizationEnabled = config.stabilizationSupported && confirmedStabilization
    config.audioEnabled = confirmedAudio

    isConfiguring = true
    cameraReady = false
    statusMessage = "Configuration caméra sur le Pixel…"
    defer { isConfiguring = false }

    do {
      let response = try await control.request(
        RemoteControlRequest(type: "configure", token: token, config: config),
        timeoutSeconds: 15,
        operationName: "configuration caméra"
      )
      guard response.ok else {
        throw RemoteCameraError.rejected(response.message ?? "Le Pixel a refusé la configuration caméra.")
      }

      applyConfirmedConfiguration(response, requested: config)
      if let ready = response.cameraReady { cameraReady = ready }
      if let active = response.previewActive { previewActive = active }
      await waitForCameraReadyAfterConfiguration(expectedConfigurationID: selectedConfigurationID)
      statusMessage = cameraReady
        ? "Pixel connecté · Caméra prête"
        : "Configuration appliquée · attente de l’aperçu Pixel…"
    } catch {
      let failure = error.localizedDescription
      do {
        let status = try await requestStatus()
        applyStatusResponse(status, updateUserMessage: false)
      } catch {
        // Keep the original configuration failure as the user-facing diagnosis.
      }
      statusMessage = "Configuration non appliquée : \(failure)"
    }
  }

  func startRecording() async {
    guard let token else {
      state = .error
      statusMessage = RemoteCameraError.notPaired.localizedDescription
      return
    }
    if pendingManifest != nil {
      state = .ready
      statusMessage = "Une vidéo finalisée attend encore son transfert. Terminez sa récupération avant un nouvel enregistrement."
      return
    }
    guard !isConfiguring else {
      statusMessage = "Configuration caméra en cours sur le Pixel…"
      return
    }
    guard cameraReady else {
      state = .ready
      statusMessage = "Pixel connecté · Caméra non prête. Vérifiez l’aperçu sur le téléphone."
      return
    }
    guard !isStartingRecording else { return }
    isStartingRecording = true
    statusMessage = "Démarrage de l’enregistrement sur le Pixel…"
    defer { isStartingRecording = false }

    var config = configurations.first { $0.id == selectedConfigurationID }
    if var updatedConfig = config {
      updatedConfig.stabilizationEnabled = updatedConfig.stabilizationSupported && stabilizationEnabled
      updatedConfig.audioEnabled = audioEnabled
      config = updatedConfig
    }
    do {
      let response = try await control.request(
        RemoteControlRequest(type: "recordStart", token: token, config: config),
        timeoutSeconds: 15,
        operationName: "démarrage de l’enregistrement"
      )
      guard response.ok, response.state == .recording else {
        throw RemoteCameraError.rejected(response.message ?? "Le Pixel n’a pas confirmé le démarrage.")
      }
      state = .recording
      recordingStartedAt = .now
      pendingManifest = nil
      statusMessage = "Enregistrement confirmé par le Pixel."
      startRecordingMonitor()
    } catch {
      let failure = error.localizedDescription
      do {
        let status = try await requestStatus()
        applyStatusResponse(status, updateUserMessage: false)
      } catch {
        state = .error
      }
      statusMessage = failure
    }
  }

  func stopRecording() async {
    guard let token else {
      state = .error
      statusMessage = RemoteCameraError.notPaired.localizedDescription
      return
    }
    recordingMonitorTask?.cancel()
    recordingMonitorTask = nil
    state = .stopping
    statusMessage = "Finalisation sur le Pixel…"

    do {
      let response = try await control.request(
        RemoteControlRequest(type: "recordStop", token: token),
        timeoutSeconds: 8,
        operationName: "finalisation"
      )
      if let manifest = response.manifest {
        adoptFinalizedManifest(manifest)
        return
      }
      applyStatusResponse(response, updateUserMessage: false)
    } catch {
      // A delayed/missed STOP response is not treated as data loss. STATUS is authoritative.
    }

    statusMessage = "Vérification de l’enregistrement sur le Pixel…"
    await reconcileFinalization()
  }

  func importPending(existingRemoteIDs: Set<String>) async throws -> (ImportedVideoAsset, RemoteRecordingManifest, RemoteCameraEndpoint) {
    guard let manifest = pendingManifest, let endpoint, let token else { throw RemoteCameraError.notConnected }
    guard RemoteRecordingIdentity.shouldImport(recordingID: manifest.recordingID, existingRemoteIDs: existingRemoteIDs) else {
      throw RemoteCameraError.duplicateRecording
    }
    state = .transferring
    statusMessage = "Transfert depuis le Pixel…"
    do {
      let asset = try await transfer.transfer(manifest: manifest, endpoint: endpoint, token: token)
      // Do not mark imported until the SwiftData VideoClipRecord is durably saved.
      state = .ready
      statusMessage = "Fichier transféré et validé · enregistrement local en cours…"
      return (asset, manifest, endpoint)
    } catch {
      state = .error
      statusMessage = error.localizedDescription
      throw error
    }
  }

  func confirmImported(recordingID: String) async {
    guard let token else { return }
    do {
      let response = try await control.request(
        RemoteControlRequest(type: "transferComplete", token: token, recordingID: recordingID),
        timeoutSeconds: 5,
        operationName: "confirmation d’import"
      )
      guard response.ok else { throw RemoteCameraError.rejected(response.message ?? "Confirmation distante refusée.") }
      if pendingManifest?.recordingID == recordingID { pendingManifest = nil }
      state = .imported
      statusMessage = "Vidéo transférée, validée et enregistrée sur l’iPad."
      // STATUS may reveal an older finalized recording that was never acknowledged by an
      // earlier app version. Import acknowledgement never deletes the Pixel master file.
      await refreshStatus()
    } catch {
      // The local validated clip is already durable. Keep the manifest visible so a later STATUS
      // can be acknowledged without creating a duplicate clip.
      state = .ready
      statusMessage = "Vidéo locale validée. Confirmation au Pixel différée ; aucun fichier n’a été supprimé."
    }
  }

  private func applyConfirmedConfiguration(
    _ response: RemoteControlResponse,
    requested: RemoteCameraConfiguration
  ) {
    if let confirmed = response.config {
      if let index = configurations.firstIndex(where: { $0.id == confirmed.id }) {
        configurations[index] = confirmed
      }
    }
    let activeID = response.activeConfigurationID
      ?? response.selectedConfigurationID
      ?? response.config?.id
      ?? requested.id
    selectedConfigurationID = activeID
    let confirmed = response.config ?? configurations.first(where: { $0.id == activeID }) ?? requested
    stabilizationEnabled = confirmed.stabilizationEnabled
    audioEnabled = confirmed.audioEnabled
  }

  private func waitForCameraReadyAfterConfiguration(expectedConfigurationID: String?) async {
    for _ in 0..<20 {
      guard !Task.isCancelled else { return }
      if cameraReady, selectedConfigurationID == expectedConfigurationID { return }
      try? await Task.sleep(nanoseconds: 250_000_000)
      guard let response = try? await requestStatus() else { continue }
      applyStatusResponse(response, updateUserMessage: false)
      if let activeID = response.activeConfigurationID ?? response.selectedConfigurationID,
         let expectedConfigurationID, activeID != expectedConfigurationID {
        return
      }
    }
  }

  private func requestStatus() async throws -> RemoteControlResponse {
    guard let token else { throw RemoteCameraError.notPaired }
    let response = try await control.request(
      RemoteControlRequest(type: "status", token: token),
      timeoutSeconds: 4,
      operationName: "synchronisation d’état"
    )
    guard response.ok else { throw RemoteCameraError.rejected(response.message ?? "État distant indisponible.") }
    return response
  }

  private func applyStatusResponse(_ response: RemoteControlResponse, updateUserMessage: Bool) {
    if let configs = response.configs {
      configurations = configs
      if let remoteSelection = response.activeConfigurationID ?? response.selectedConfigurationID,
         configs.contains(where: { $0.id == remoteSelection }) {
        selectedConfigurationID = remoteSelection
      } else if selectedConfigurationID == nil {
        selectedConfigurationID = configs.first?.id
      }
      if let selected = configs.first(where: { $0.id == selectedConfigurationID }) {
        stabilizationEnabled = selected.stabilizationEnabled
        audioEnabled = selected.audioEnabled
      }
    }
    if let ready = response.cameraReady { cameraReady = ready }
    else if response.state == .ready { cameraReady = true } // compatibility with pre-v15.0.4 companion
    if let active = response.previewActive { previewActive = active }

    pendingManifest = response.manifest
    let remoteState = response.state ?? state
    if let manifest = response.manifest {
      recordingStartedAt = nil
      if remoteState == .error {
        state = .ready
        if updateUserMessage {
          statusMessage = "Le Pixel signale une erreur, mais la vidéo \(manifest.filename) est finalisée et récupérable."
        }
      } else if remoteState != .recording && remoteState != .stopping {
        state = .ready
        if updateUserMessage {
          statusMessage = "Une vidéo finalisée est disponible sur le Pixel."
        }
      } else {
        state = remoteState
      }
      return
    }

    state = remoteState
    if remoteState != .recording { recordingStartedAt = nil }
    if updateUserMessage, remoteState == .stopping {
      statusMessage = "Finalisation sur le Pixel…"
    } else if updateUserMessage, remoteState == .ready, response.manifest == nil {
      statusMessage = cameraReady ? "Pixel connecté · Caméra prête" : "Pixel connecté · Caméra non prête"
    }
  }

  private func adoptFinalizedManifest(_ manifest: RemoteRecordingManifest) {
    pendingManifest = manifest
    recordingStartedAt = nil
    state = .ready
    statusMessage = "Vidéo finalisée sur le Pixel · transfert…"
  }

  private func startRecordingMonitor() {
    recordingMonitorTask?.cancel()
    recordingMonitorTask = Task { [weak self] in
      while !Task.isCancelled {
        try? await Task.sleep(nanoseconds: 1_000_000_000)
        guard !Task.isCancelled, let self else { return }
        guard self.state == .recording || self.state == .stopping else { return }
        do {
          let response = try await self.requestStatus()
          if let manifest = response.manifest {
            self.adoptFinalizedManifest(manifest)
            return
          }
          if response.state == .stopping || response.state == .ready {
            self.state = .stopping
            self.statusMessage = "Finalisation sur le Pixel…"
            await self.reconcileFinalization()
            return
          }
        } catch {
          // A transient STATUS miss while CameraX records must not poison the session.
          continue
        }
      }
    }
  }

  private func reconcileFinalization() async {
    for attempt in 0..<10 {
      if Task.isCancelled { return }
      if attempt > 0 {
        try? await Task.sleep(nanoseconds: 750_000_000)
      }
      do {
        let response = try await requestStatus()
        if let manifest = response.manifest {
          adoptFinalizedManifest(manifest)
          return
        }

        switch response.state {
        case .recording:
          state = .recording
          statusMessage = "Le Pixel enregistre encore · nouvelle vérification…"
        case .stopping:
          state = .stopping
          statusMessage = "Finalisation sur le Pixel…"
        case .error:
          state = .error
          statusMessage = "Le Pixel signale une erreur et aucune vidéo finalisée n’est encore disponible. Utilisez « Réinitialiser la caméra » sur le Pixel puis resynchronisez."
          return
        case .ready:
          state = .stopping
          statusMessage = "Pixel prêt · recherche de la vidéo finalisée…"
        default:
          state = response.state ?? .stopping
        }
      } catch {
        if attempt == 9 {
          state = .disconnected
          statusMessage = "Impossible de confirmer la finalisation. Reconnectez le Pixel : STATUS récupérera toute vidéo finalisée conservée sur le téléphone."
          return
        }
      }
    }

    state = .error
    statusMessage = RemoteCameraError.finalizedRecordingUnavailable.localizedDescription
  }
}
