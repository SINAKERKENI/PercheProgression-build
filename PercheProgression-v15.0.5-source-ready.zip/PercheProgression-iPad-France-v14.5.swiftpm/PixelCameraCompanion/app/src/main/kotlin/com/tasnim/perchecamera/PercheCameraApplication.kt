package com.tasnim.perchecamera

import android.app.Application

class PercheCameraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CameraDiagnosticStore.installCrashHandler(this)
    }
}
