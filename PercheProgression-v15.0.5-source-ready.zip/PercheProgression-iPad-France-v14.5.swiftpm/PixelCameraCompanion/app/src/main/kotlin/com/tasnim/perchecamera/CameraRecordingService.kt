package com.tasnim.perchecamera

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.DynamicRange
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.SessionConfig
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.HighSpeedVideoSessionConfig
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.CameraOperationCoordinator
import com.tasnim.perchecamera.protocol.CameraOperationState
import com.tasnim.perchecamera.protocol.RecordingManifest
import com.tasnim.perchecamera.protocol.RecordingStartPolicy
import com.tasnim.perchecamera.protocol.StopOrigin
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.time.Instant
import java.util.Properties
import java.util.UUID
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraRecordingService : LifecycleService() {
    companion object {
        private const val TAG = "PercheCamera"
        private const val START_EVENT_TIMEOUT_MS = 8_000L
    }
    data class InternalConfig(val public: CameraConfiguration, val cameraId: String, val quality: Quality, val highSpeed: Boolean)

    data class CameraDiagnostics(
        val providerReady: Boolean,
        val cameraBound: Boolean,
        val previewSurfaceAttached: Boolean,
        val previewActive: Boolean,
        val videoCaptureReady: Boolean,
        val bindingInProgress: Boolean,
        val operationState: CameraOperationState,
        val foregroundServiceReady: Boolean,
        val selectedConfiguration: CameraConfiguration?,
        val bindingError: String?,
    )

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val lifecycleLock = Any()
    private val cameraOperations = CameraOperationCoordinator()
    @Volatile private var provider: ProcessCameraProvider? = null
    @Volatile private var activeRecording: Recording? = null
    @Volatile private var activeFile: File? = null
    @Volatile private var activeConfig: InternalConfig? = null
    @Volatile private var finalizationInProgress: Boolean = false
    @Volatile private var selectedConfig: InternalConfig? = null
    @Volatile private var defaultBackCameraID: String? = null
    @Volatile private var boundConfig: InternalConfig? = null
    @Volatile private var boundPreview: Preview? = null
    @Volatile private var boundVideoCapture: VideoCapture<Recorder>? = null
    @Volatile private var boundRecorder: Recorder? = null
    @Volatile private var cameraBound: Boolean = false
    @Volatile private var cameraBindingInProgress: Boolean = false
    @Volatile private var previewSurfaceAttached: Boolean = false
    @Volatile private var previewStreaming: Boolean = false
    @Volatile private var cameraBindingError: String? = null
    @Volatile private var foregroundServiceReady: Boolean = false
    @Volatile private var recordingStartNanos: Long = 0
    private var previewSurfaceProvider: Preview.SurfaceProvider? = null
    private var startTimeoutRunnable: Runnable? = null
    private val stopWaiters = mutableListOf<CompletableFuture<RecordingManifest>>()
    private val configs = ConcurrentHashMap<String, InternalConfig>()
    private val manifests = ConcurrentHashMap<String, RecordingManifest>()
    private lateinit var localServer: LocalCameraServer

    override fun onCreate() {
        super.onCreate()
        CompanionRuntime.service = this
        CameraDiagnosticStore.event(this, "CameraRecordingService.onCreate")
        loadPersistedManifests()
        try {
            startForegroundNotification()
        } catch (t: Throwable) {
            val message = "Service caméra au premier plan impossible : ${t.message ?: t::class.java.simpleName}"
            cameraOperations.fatalError(message)
            CompanionRuntime.stateMachine.recordingFailed(message)
            CameraDiagnosticStore.event(this, message, t)
            Log.e(TAG, message, t)
        }
        LocalCameraServer(this).also { localServer = it; it.start() }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                rebuildConfigurations()
                val initial = preferredDefaultConfig()
                    ?: throw IllegalStateException("Aucune configuration caméra exploitable.")
                bindCameraUseCases(initial)
                cameraOperations.initialized(initial.public.id)
                CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
                CameraDiagnosticStore.event(this, "CameraX initialisé config=${initial.public.id} camera=${initial.cameraId}")
            } catch (t: Throwable) {
                val message = t.message ?: "CameraX n’a pas pu initialiser la caméra."
                cameraOperations.fatalError(message)
                CompanionRuntime.stateMachine.recordingFailed(message)
                CameraDiagnosticStore.event(this, "CameraX initialization failed", t)
                Log.e(TAG, "CameraX initialization failed", t)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        if (::localServer.isInitialized) localServer.stop()
        startTimeoutRunnable?.let(mainHandler::removeCallbacks)
        boundPreview?.setSurfaceProvider(null)
        runCatching { provider?.unbindAll() }
        cameraExecutor.shutdown()
        CompanionRuntime.service = null
        CameraDiagnosticStore.event(this, "CameraRecordingService.onDestroy")
        super.onDestroy()
    }

    fun configurations(): List<CameraConfiguration> {
        val selected = selectedConfig
        return configs.values
            .map { candidate -> if (candidate.public.id == selected?.public?.id) selected.public else candidate.public }
            .sortedWith(
                compareBy<CameraConfiguration>(
                    { if (it.id == preferredDefaultConfig()?.public?.id) 0 else 1 },
                    { if (it.lensLabel.startsWith("Arrière")) 0 else 1 },
                    { if (it.width == 1280 && it.height == 720) 0 else 1 },
                    { if (it.fps == 30) 0 else 1 },
                    { it.lensLabel },
                    { it.width },
                    { it.fps },
                ),
            )
    }

    fun selectedConfiguration(): CameraConfiguration? = boundConfig?.public ?: selectedConfig?.public

    fun activeConfigurationID(): String? = boundConfig?.public?.id

    fun cameraOperationState(): CameraOperationState = cameraOperations.state

    fun lastErrorMessage(): String? = cameraOperations.lastErrorMessage ?: CompanionRuntime.stateMachine.lastErrorMessage

    fun isFinalizing(): Boolean = finalizationInProgress || cameraOperations.state == CameraOperationState.FINALIZING

    fun cameraDiagnostics(): CameraDiagnostics = CameraDiagnostics(
        providerReady = provider != null,
        cameraBound = cameraBound,
        previewSurfaceAttached = previewSurfaceAttached,
        previewActive = previewStreaming,
        videoCaptureReady = boundVideoCapture != null && boundRecorder != null,
        bindingInProgress = cameraBindingInProgress,
        operationState = cameraOperations.state,
        foregroundServiceReady = foregroundServiceReady,
        selectedConfiguration = boundConfig?.public ?: selectedConfig?.public,
        bindingError = cameraBindingError,
    )

    fun cameraReady(): Boolean {
        if (!foregroundServiceReady || provider == null || !cameraBound || boundVideoCapture == null || boundRecorder == null || cameraBindingInProgress) return false
        if (cameraOperations.state == CameraOperationState.INITIALIZING ||
            cameraOperations.state == CameraOperationState.RECONFIGURING ||
            cameraOperations.state == CameraOperationState.ERROR) return false
        // While the Pixel UI is visibly asking for a preview, READY means frames are genuinely streaming.
        // When the Activity is backgrounded and the surface is detached, VideoCapture remains valid for remote recording.
        return !previewSurfaceAttached || previewStreaming
    }

    fun previewActive(): Boolean = previewStreaming

    fun recordingElapsedSeconds(): Long? {
        if (activeRecording == null || recordingStartNanos <= 0L) return null
        return ((System.nanoTime() - recordingStartNanos).coerceAtLeast(0L) / 1_000_000_000L)
    }

    fun attachPreviewSurface(surfaceProvider: Preview.SurfaceProvider) {
        ContextCompat.getMainExecutor(this).execute {
            previewSurfaceProvider = surfaceProvider
            previewSurfaceAttached = true
            previewStreaming = false
            boundPreview?.setSurfaceProvider(surfaceProvider)
            if (!cameraBound && !cameraBindingInProgress) {
                val config = selectedConfig ?: preferredDefaultConfig()
                if (config != null) runCatching { bindCameraUseCases(config) }
            }
            CameraDiagnosticStore.event(this, "Preview surface attached cameraBound=$cameraBound")
            Log.i(TAG, "Preview surface attached cameraBound=$cameraBound")
        }
    }

    fun detachPreviewSurface() {
        ContextCompat.getMainExecutor(this).execute {
            previewSurfaceProvider = null
            previewSurfaceAttached = false
            previewStreaming = false
            boundPreview?.setSurfaceProvider(null)
            CameraDiagnosticStore.event(this, "Preview surface detached VideoCaptureBound=$cameraBound")
            Log.i(TAG, "Preview surface detached; VideoCapture remains bound=$cameraBound")
        }
    }

    fun setPreviewStreaming(active: Boolean) {
        previewStreaming = active
        if (active) {
            cameraBindingError = null
            recoverIfIdle()
            CameraDiagnosticStore.event(this, "Preview stream active")
            Log.i(TAG, "Preview stream active")
        } else {
            Log.i(TAG, "Preview stream inactive")
        }
    }

    fun reportPreviewFailure(message: String) {
        ContextCompat.getMainExecutor(this).execute {
            if (!previewSurfaceAttached || previewStreaming || activeRecording != null || finalizationInProgress) return@execute
            cameraBindingError = message
            cameraOperations.fatalError(message)
            CompanionRuntime.stateMachine.recordingFailed(message)
            CameraDiagnosticStore.event(this, "preview failure: $message")
            Log.e(TAG, message)
        }
    }

    fun configureCamera(requested: CameraConfiguration): CompletableFuture<CameraConfiguration> {
        val result = CompletableFuture<CameraConfiguration>()
        ContextCompat.getMainExecutor(this).execute {
            val previous = boundConfig
            try {
                if (activeRecording != null || finalizationInProgress) {
                    throw IllegalStateException("Arrêtez l’enregistrement avant de changer de caméra.")
                }
                val effective = effectiveConfig(requested)
                if (!cameraOperations.beginReconfiguration(effective.public.id)) {
                    throw IllegalStateException("La caméra est occupée (${cameraOperations.state.name.lowercase()}). Réessayez lorsque le Pixel est prêt.")
                }
                CameraDiagnosticStore.event(
                    this,
                    "configure begin requested=${effective.public.id} camera=${effective.cameraId} previous=${previous?.public?.id ?: "none"}",
                )

                if (previous != null && sameCaptureBinding(previous, effective) && cameraBound) {
                    // Audio does not require a camera rebind; keep the proven Preview + VideoCapture session.
                    selectedConfig = effective
                    boundConfig = effective
                } else {
                    bindCameraUseCases(effective)
                }

                cameraOperations.reconfigurationSucceeded(effective.public.id)
                CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
                cameraBindingError = null
                CameraDiagnosticStore.event(this, "configure success active=${effective.public.id} camera=${effective.cameraId}")
                result.complete(effective.public)
            } catch (t: Throwable) {
                val message = t.message ?: "Configuration caméra impossible."
                var rollbackRecovered = false
                if (cameraOperations.state == CameraOperationState.RECONFIGURING && previous != null) {
                    rollbackRecovered = runCatching {
                        bindCameraUseCases(previous)
                        selectedConfig = previous
                        boundConfig = previous
                        true
                    }.getOrElse { rollbackError ->
                        CameraDiagnosticStore.event(this, "configure rollback failed", rollbackError)
                        false
                    }
                } else if (cameraOperations.state != CameraOperationState.RECONFIGURING) {
                    rollbackRecovered = captureBindingReady()
                }

                if (cameraOperations.state == CameraOperationState.RECONFIGURING) {
                    cameraOperations.reconfigurationFailed(message, rollbackRecovered)
                }
                cameraBindingError = if (rollbackRecovered) null else message
                if (rollbackRecovered) {
                    CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
                } else {
                    CompanionRuntime.stateMachine.recordingFailed(message)
                }
                CameraDiagnosticStore.event(this, "configure failed recovered=$rollbackRecovered", t)
                Log.e(TAG, "Camera configuration failed recovered=$rollbackRecovered", t)
                result.completeExceptionally(t)
            }
        }
        return result
    }

    fun startRemoteRecording(requested: CameraConfiguration?): CompletableFuture<Long> {
        val result = CompletableFuture<Long>()
        ContextCompat.getMainExecutor(this).execute {
            try {
                if (!recoverIfIdle()) throw IllegalStateException("Caméra Pixel non prête.")
                if (latestPendingManifest() != null) {
                    throw IllegalStateException("Une vidéo finalisée attend encore son transfert vers l’iPad.")
                }
                if (activeRecording != null || finalizationInProgress || cameraBindingInProgress) {
                    throw IllegalStateException("Un enregistrement, une finalisation ou un changement de caméra est déjà en cours.")
                }
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    throw SecurityException("Autorisation caméra refusée.")
                }
                if (!foregroundServiceReady) {
                    throw IllegalStateException("Service caméra au premier plan non prêt.")
                }

                val bound = boundConfig ?: throw IllegalStateException("Aucune configuration CameraX n’est liée.")
                val requestedEffective = requested?.let(::effectiveConfig)
                if (requestedEffective != null && !sameActiveConfiguration(bound, requestedEffective)) {
                    throw IllegalStateException(
                        "La configuration demandée n’est pas encore active sur le Pixel. Configurez la caméra puis attendez Caméra prête.",
                    )
                }
                val config = bound
                if (!captureBindingReady()) throw IllegalStateException("Caméra Pixel non prête.")
                if (!cameraOperations.beginRecordingStart(config.public.id)) {
                    throw IllegalStateException("La caméra ne peut pas démarrer un enregistrement depuis l’état ${cameraOperations.state.name.lowercase()}.")
                }

                CameraDiagnosticStore.event(this, recordingStartSnapshot("recordStart received", config))
                startBoundRecording(config, result)
            } catch (t: Throwable) {
                handleSynchronousRecordStartFailure(t, result)
            }
        }
        return result
    }

    fun stopRemoteRecording(): CompletableFuture<RecordingManifest> = requestStop(StopOrigin.IPAD)

    fun requestStopFromPixel(): CompletableFuture<RecordingManifest> = requestStop(StopOrigin.PIXEL)

    private fun requestStop(origin: StopOrigin): CompletableFuture<RecordingManifest> {
        val future = CompletableFuture<RecordingManifest>()
        ContextCompat.getMainExecutor(this).execute {
            var recordingToStop: Recording? = null
            synchronized(lifecycleLock) {
                val recording = activeRecording
                if (recording == null) {
                    if (finalizationInProgress || cameraOperations.state == CameraOperationState.FINALIZING) {
                        // CameraX has emitted Finalize and the manifest/SHA is still being built.
                        stopWaiters += future
                    } else {
                        val pending = latestPendingManifest()
                        if (pending != null) future.complete(pending)
                        else future.completeExceptionally(IllegalStateException("Aucun enregistrement en cours ou finalisé en attente."))
                    }
                    return@execute
                }

                stopWaiters += future
                try {
                    if (!cameraOperations.beginFinalization()) {
                        throw IllegalStateException("Arrêt impossible depuis l’état ${cameraOperations.state.name.lowercase()}.")
                    }
                    CompanionRuntime.stateMachine.stopRequested(origin)
                    CameraDiagnosticStore.event(this, "recordStop origin=$origin state=${cameraOperations.state}")
                    Log.i(TAG, "Stop requested origin=$origin finalizing=$finalizationInProgress")
                    if (!finalizationInProgress) {
                        finalizationInProgress = true
                        recordingToStop = recording
                    }
                } catch (t: Throwable) {
                    stopWaiters.remove(future)
                    future.completeExceptionally(t)
                    return@execute
                }
            }

            if (recordingToStop != null) {
                try {
                    recordingToStop?.stop()
                } catch (t: Throwable) {
                    synchronized(lifecycleLock) { finalizationInProgress = false }
                    val message = t.message ?: "Impossible d’arrêter l’enregistrement."
                    cameraOperations.finalizationFailed(message, cameraStillUsable = captureBindingReady())
                    CompanionRuntime.stateMachine.recordingFailed(message)
                    if (captureBindingReady()) CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
                    CameraDiagnosticStore.event(this, "recordStop failed", t)
                    completeStopWaiters(exception = t)
                }
            }
        }
        return future
    }

    private fun startBoundRecording(config: InternalConfig, startFuture: CompletableFuture<Long>) {
        requireMainThread("recordStart")
        val recorder = requireNotNull(boundRecorder) { "Recorder CameraX indisponible." }
        require(boundVideoCapture != null && cameraBound) { "VideoCapture CameraX n’est pas lié." }
        require(foregroundServiceReady) { "Service caméra au premier plan non prêt." }

        val recordings = File(filesDir, "recordings").apply { mkdirs() }
        val id = UUID.randomUUID().toString()
        val file = File(recordings, "$id.mp4")
        val createdAt = Instant.now().toString()
        val microphoneGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (config.public.audioEnabled && !microphoneGranted) {
            throw SecurityException("Microphone demandé mais autorisation audio absente.")
        }

        CameraDiagnosticStore.event(this, recordingStartSnapshot("configuration validated", config))
        CameraDiagnosticStore.event(this, "prepareRecording begin file=${file.name}")
        var pending: PendingRecording = recorder.prepareRecording(this, FileOutputOptions.Builder(file).build())
        CameraDiagnosticStore.event(this, "prepareRecording success")

        if (RecordingStartPolicy.shouldEnableAudio(config.public.audioEnabled, microphoneGranted)) {
            CameraDiagnosticStore.event(this, "audio enable begin")
            updateForegroundServiceTypes(includeMicrophone = true)
            pending = pending.withAudioEnabled()
            CameraDiagnosticStore.event(this, "audio enable success")
        } else {
            CameraDiagnosticStore.event(this, "audio disabled; withAudioEnabled not called")
        }

        synchronized(lifecycleLock) {
            activeFile = file
            activeConfig = config
            finalizationInProgress = false
        }

        try {
            CameraDiagnosticStore.event(this, "PendingRecording.start begin")
            val recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                try {
                    when (event) {
                        is VideoRecordEvent.Start -> handleVideoRecordStart(config, startFuture)
                        is VideoRecordEvent.Finalize -> cameraExecutor.execute {
                            try {
                                finalizeRecording(event, id, file, config, createdAt, startFuture)
                            } catch (t: Throwable) {
                                handleUnexpectedCameraCallbackFailure("Finalize callback", t, startFuture)
                            }
                        }
                    }
                } catch (t: Throwable) {
                    handleUnexpectedCameraCallbackFailure(event::class.java.simpleName, t, startFuture)
                }
            }
            synchronized(lifecycleLock) { activeRecording = recording }
            scheduleStartEventTimeout(startFuture)
        } catch (t: Throwable) {
            synchronized(lifecycleLock) {
                activeRecording = null
                activeFile = null
                activeConfig = null
            }
            CameraDiagnosticStore.event(this, "PendingRecording.start threw", t)
            throw t
        }
    }

    private fun handleVideoRecordStart(config: InternalConfig, startFuture: CompletableFuture<Long>) {
        cancelStartEventTimeout()
        cameraOperations.recordingStarted()
        CompanionRuntime.stateMachine.recordingStarted()
        recordingStartNanos = System.nanoTime()
        startFuture.complete(recordingStartNanos)
        CameraDiagnosticStore.event(this, recordingStartSnapshot("VideoRecordEvent.Start", config))
        Log.i(TAG, "VideoRecordEvent.Start config=${config.public.id} previewActive=$previewStreaming")
    }

    private fun scheduleStartEventTimeout(startFuture: CompletableFuture<Long>) {
        cancelStartEventTimeout()
        val timeout = Runnable {
            if (startFuture.isDone || cameraOperations.state != CameraOperationState.STARTING_RECORDING) return@Runnable
            val message = "CameraX n’a pas confirmé VideoRecordEvent.Start dans le délai prévu."
            val error = IllegalStateException(message)
            CameraDiagnosticStore.event(this, "recordStart timeout", error)
            Log.e(TAG, message)
            startFuture.completeExceptionally(error)
            val recording = synchronized(lifecycleLock) { activeRecording }
            if (recording != null) {
                cameraOperations.beginFinalization()
                synchronized(lifecycleLock) { finalizationInProgress = true }
                runCatching { recording.stop() }.onFailure { stopError ->
                    synchronized(lifecycleLock) { finalizationInProgress = false }
                    markRecordingStartFailure(message, stopError)
                }
            } else {
                markRecordingStartFailure(message, error)
            }
        }
        startTimeoutRunnable = timeout
        mainHandler.postDelayed(timeout, START_EVENT_TIMEOUT_MS)
    }

    private fun cancelStartEventTimeout() {
        startTimeoutRunnable?.let(mainHandler::removeCallbacks)
        startTimeoutRunnable = null
    }

    private fun handleUnexpectedCameraCallbackFailure(phase: String, throwable: Throwable, startFuture: CompletableFuture<Long>) {
        ContextCompat.getMainExecutor(this).execute {
            val message = "Échec CameraX pendant $phase : ${throwable.message ?: throwable::class.java.simpleName}"
            CameraDiagnosticStore.event(this, message, throwable)
            Log.e(TAG, message, throwable)
            if (!startFuture.isDone) startFuture.completeExceptionally(throwable)
            val recording = synchronized(lifecycleLock) { activeRecording }
            if (recording != null) {
                cameraOperations.beginFinalization()
                synchronized(lifecycleLock) { finalizationInProgress = true }
                runCatching { recording.stop() }
                    .onFailure { markRecordingStartFailure(message, it) }
            } else {
                markRecordingStartFailure(message, throwable)
            }
        }
    }

    private fun finalizeRecording(
        event: VideoRecordEvent.Finalize,
        id: String,
        file: File,
        config: InternalConfig,
        createdAtISO8601: String,
        startFuture: CompletableFuture<Long>,
    ) {
        cancelStartEventTimeout()
        cameraOperations.beginFinalization()
        synchronized(lifecycleLock) {
            finalizationInProgress = true
            activeRecording = null
            activeFile = null
            activeConfig = null
        }
        if (config.public.audioEnabled) {
            mainHandler.post {
                runCatching { updateForegroundServiceTypes(includeMicrophone = false) }
                    .onFailure { CameraDiagnosticStore.event(this, "foreground camera-only restore failed", it) }
            }
        }
        CameraDiagnosticStore.event(
            this,
            "VideoRecordEvent.Finalize id=${id.take(8)} error=${event.error} hasError=${event.hasError()} bytes=${file.takeIf(File::exists)?.length() ?: 0}",
        )

        if (event.hasError() || !file.isFile || file.length() <= 0) {
            val message = "CameraX Finalize a signalé l’erreur ${event.error}. Le fichier Pixel est conservé s’il existe."
            val error = IllegalStateException(message)
            val usable = captureBindingReady()
            cameraOperations.finalizationFailed(message, cameraStillUsable = usable)
            CompanionRuntime.stateMachine.recordingFailed(message)
            if (usable) CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
            CameraDiagnosticStore.event(this, message, error)
            Log.e(TAG, message)
            if (!startFuture.isDone) startFuture.completeExceptionally(error)
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(exception = error)
            return
        }

        try {
            val metadata = readMetadata(file)
            require(metadata.first.isFinite() && metadata.first > 0) { "Durée vidéo invalide après finalisation." }
            require(metadata.second.first > 0 && metadata.second.second > 0) { "Dimensions vidéo invalides après finalisation." }
            val finalizedAt = Instant.now().toString()
            val manifest = RecordingManifest(
                recordingID = id,
                filename = file.name,
                sizeBytes = file.length(),
                sha256 = sha256(file),
                createdAtISO8601 = createdAtISO8601,
                durationSeconds = metadata.first,
                width = metadata.second.first,
                height = metadata.second.second,
                nominalFPS = config.public.fps.toDouble(),
                lensLabel = config.public.lensLabel,
                orientation = if (metadata.second.first >= metadata.second.second) "landscape" else "portrait",
                transferPath = "/recordings/$id",
                finalizedAtISO8601 = finalizedAt,
                transferState = "pending",
            )
            manifests[manifest.recordingID] = manifest
            persistManifest(manifest)
            CameraDiagnosticStore.event(
                this,
                "recording finalized id=${manifest.recordingID.take(8)} bytes=${manifest.sizeBytes} duration=${manifest.durationSeconds}",
            )
            Log.i(TAG, "Recording finalized id=${manifest.recordingID.take(8)}… bytes=${manifest.sizeBytes} duration=${manifest.durationSeconds}")

            cameraOperations.recordingFinalized()
            when (CompanionRuntime.stateMachine.state) {
                com.tasnim.perchecamera.protocol.CameraState.RECORDING -> {
                    CompanionRuntime.stateMachine.stopRequested(StopOrigin.SYSTEM)
                    CompanionRuntime.stateMachine.recordingFinalized(manifest)
                }
                com.tasnim.perchecamera.protocol.CameraState.STOPPING -> CompanionRuntime.stateMachine.recordingFinalized(manifest)
                else -> CompanionRuntime.stateMachine.restoreFinalizedManifest(manifest)
            }
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(manifest = manifest)
        } catch (t: Throwable) {
            val message = t.message ?: "Impossible de finaliser les métadonnées de la vidéo."
            val usable = captureBindingReady()
            cameraOperations.finalizationFailed(message, cameraStillUsable = usable)
            CompanionRuntime.stateMachine.recordingFailed(message)
            if (usable) CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
            CameraDiagnosticStore.event(this, "recording finalization metadata failed", t)
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(exception = t)
        }
    }

    private fun completeStopWaiters(manifest: RecordingManifest? = null, exception: Throwable? = null) {
        val waiters = synchronized(lifecycleLock) {
            val copy = stopWaiters.toList()
            stopWaiters.clear()
            copy
        }
        for (waiter in waiters) {
            if (manifest != null) waiter.complete(manifest)
            else waiter.completeExceptionally(exception ?: IllegalStateException("Finalisation interrompue."))
        }
    }

    private fun effectiveConfig(requested: CameraConfiguration): InternalConfig {
        val base = configs[requested.id]
            ?: throw IllegalArgumentException("Configuration caméra inconnue : ${requested.id}")
        val stabilization = requested.stabilizationEnabled && base.public.stabilizationSupported
        return base.copy(
            public = base.public.copy(
                stabilizationEnabled = stabilization,
                audioEnabled = requested.audioEnabled,
            ),
        )
    }

    private fun sameCaptureBinding(lhs: InternalConfig, rhs: InternalConfig): Boolean =
        lhs.cameraId == rhs.cameraId &&
            lhs.public.id == rhs.public.id &&
            lhs.public.stabilizationEnabled == rhs.public.stabilizationEnabled

    private fun sameActiveConfiguration(lhs: InternalConfig, rhs: InternalConfig): Boolean =
        sameCaptureBinding(lhs, rhs) && lhs.public.audioEnabled == rhs.public.audioEnabled

    private fun recordingStartSnapshot(step: String, config: InternalConfig): String =
        "$step state=${cameraOperations.state} config=${config.public.id} cameraID=${config.cameraId} " +
            "lens=${config.public.lensLabel} resolution=${config.public.width}x${config.public.height} " +
            "fps=${config.public.fps} audio=${config.public.audioEnabled} stabilization=${config.public.stabilizationEnabled} " +
            "cameraBound=$cameraBound previewActive=$previewStreaming videoCaptureReady=${boundVideoCapture != null && boundRecorder != null} " +
            "foregroundReady=$foregroundServiceReady"

    private fun handleSynchronousRecordStartFailure(t: Throwable, result: CompletableFuture<Long>) {
        val message = "Impossible de démarrer l’enregistrement : ${t.message ?: t::class.java.simpleName}"
        CameraDiagnosticStore.event(this, "recordStart synchronous failure", t)
        Log.e(TAG, message, t)
        if (cameraOperations.state == CameraOperationState.STARTING_RECORDING) {
            markRecordingStartFailure(message, t)
        }
        result.completeExceptionally(IllegalStateException(message, t))
    }

    private fun markRecordingStartFailure(message: String, throwable: Throwable) {
        cancelStartEventTimeout()
        val cameraUsable = captureBindingReady()
        val safelyIdle = cameraUsable && activeRecording == null && !finalizationInProgress
        cameraOperations.recordingStartFailed(message, cameraStillUsable = safelyIdle)
        CompanionRuntime.stateMachine.recordingFailed(message)
        if (safelyIdle) CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
        CameraDiagnosticStore.event(this, "recordStart recoverable=$safelyIdle cameraUsable=$cameraUsable", throwable)
    }

    private fun requireMainThread(operation: String) {
        check(Looper.myLooper() == Looper.getMainLooper()) { "$operation doit s’exécuter sur le thread principal Android." }
    }

    private fun preferredDefaultConfig(): InternalConfig? {
        val values = configs.values.toList()
        val backID = defaultBackCameraID
        return values.firstOrNull { candidate ->
            candidate.cameraId == backID && candidate.quality == Quality.HD && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.cameraId == backID && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.public.lensLabel.startsWith("Arrière") && candidate.quality == Quality.HD && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.public.lensLabel.startsWith("Arrière") && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull()
    }

    private fun captureBindingReady(): Boolean =
        provider != null && cameraBound && boundVideoCapture != null && boundRecorder != null && !cameraBindingInProgress

    private fun bindCameraUseCases(config: InternalConfig) {
        requireMainThread("bindCameraUseCases")
        val provider = requireNotNull(provider) { "CameraX n’est pas initialisé." }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            throw SecurityException("Autorisation caméra refusée.")
        }

        cameraBindingInProgress = true
        cameraBindingError = null
        previewStreaming = false
        CameraDiagnosticStore.event(
            this,
            "bind begin config=${config.public.id} camera=${config.cameraId} lens=${config.public.lensLabel} " +
                "resolution=${config.public.width}x${config.public.height} fps=${config.public.fps} " +
                "stabilization=${config.public.stabilizationEnabled} previewSurface=${previewSurfaceProvider != null}",
        )
        Log.i(TAG, "Binding CameraX config=${config.public.id} camera=${config.cameraId} fps=${config.public.fps}")

        try {
            provider.unbindAll()
            cameraBound = false
            boundPreview = null
            boundVideoCapture = null
            boundRecorder = null

            val selector = CameraSelector.Builder().addCameraFilter { infos ->
                infos.filter { Camera2CameraInfo.from(it).cameraId == config.cameraId }
            }.build()

            val stabilizationEnabled = config.public.stabilizationEnabled && config.public.stabilizationSupported
            val preview = Preview.Builder()
                .setPreviewStabilizationEnabled(stabilizationEnabled)
                .build()
            previewSurfaceProvider?.let(preview::setSurfaceProvider)

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(config.quality))
                .build()
            val videoCapture = VideoCapture.Builder(recorder)
                .setVideoStabilizationEnabled(stabilizationEnabled)
                .build()
            val fpsRange = Range(config.public.fps, config.public.fps)

            if (config.highSpeed) {
                val session = HighSpeedVideoSessionConfig.Builder(videoCapture)
                    .setPreview(preview)
                    .setFrameRateRange(fpsRange)
                    .setSlowMotionEnabled(false)
                    .build()
                provider.bindToLifecycle(this, selector, session)
            } else {
                val session = SessionConfig.Builder(preview, videoCapture)
                    .setFrameRateRange(fpsRange)
                    .build()
                val info = provider.getCameraInfo(selector)
                require(info.getSupportedFrameRateRanges(session).any { it.contains(config.public.fps) }) {
                    "Cadence ${config.public.fps} i/s non prise en charge avec l’aperçu et VideoCapture."
                }
                provider.bindToLifecycle(this, selector, session)
            }

            selectedConfig = config
            boundConfig = config
            boundPreview = preview
            boundVideoCapture = videoCapture
            boundRecorder = recorder
            cameraBound = true
            cameraBindingError = null
            CameraDiagnosticStore.event(this, "bind success camera=${config.cameraId} Preview=true VideoCapture=true")
            Log.i(TAG, "CameraX bound camera=${config.cameraId} preview=${previewSurfaceProvider != null} videoCapture=true")
        } catch (t: Throwable) {
            cameraBound = false
            boundConfig = null
            boundPreview = null
            boundVideoCapture = null
            boundRecorder = null
            cameraBindingError = t.message ?: "Impossible d’ouvrir la caméra Pixel."
            CameraDiagnosticStore.event(this, "CameraX bind failed config=${config.public.id}", t)
            Log.e(TAG, "CameraX bind failed", t)
            throw t
        } finally {
            cameraBindingInProgress = false
        }
    }

    fun recoverIfIdle(): Boolean {
        val operationActive = activeRecording != null || finalizationInProgress || cameraBindingInProgress ||
            cameraOperations.state == CameraOperationState.RECONFIGURING ||
            cameraOperations.state == CameraOperationState.STARTING_RECORDING ||
            cameraOperations.state == CameraOperationState.FINALIZING
        val bindingUsable = captureBindingReady() && (!previewSurfaceAttached || previewStreaming) && foregroundServiceReady
        val operationReady = cameraOperations.recoverIfIdle(operationActive = operationActive, cameraUsable = bindingUsable)
        val remoteReady = CompanionRuntime.stateMachine.recoverIfIdle(operationActive = operationActive || !bindingUsable)
        return operationReady && remoteReady && bindingUsable
    }

    fun resetCamera(): CompletableFuture<Boolean> {
        val future = CompletableFuture<Boolean>()
        ContextCompat.getMainExecutor(this).execute {
            if (activeRecording != null || finalizationInProgress || cameraOperations.state == CameraOperationState.STARTING_RECORDING) {
                future.complete(false)
                return@execute
            }
            try {
                val previousID = boundConfig?.public?.id ?: selectedConfig?.public?.id
                CameraDiagnosticStore.event(this, "camera reset requested previous=$previousID")
                provider?.unbindAll()
                cameraBound = false
                boundPreview = null
                boundVideoCapture = null
                boundRecorder = null
                rebuildConfigurations()
                val next = previousID?.let(configs::get) ?: preferredDefaultConfig()
                    ?: throw IllegalStateException("Aucune configuration caméra exploitable après réinitialisation.")
                bindCameraUseCases(next)
                cameraOperations.initialized(next.public.id)
                CompanionRuntime.stateMachine.recoverIfIdle(operationActive = false)
                cameraBindingError = null
                CameraDiagnosticStore.event(this, "camera reset success active=${next.public.id}")
                future.complete(cameraReady())
            } catch (t: Throwable) {
                val message = t.message ?: "Réinitialisation CameraX impossible."
                cameraBindingError = message
                cameraOperations.fatalError(message)
                CompanionRuntime.stateMachine.recordingFailed(message)
                CameraDiagnosticStore.event(this, "camera reset failed", t)
                future.complete(false)
            }
        }
        return future
    }

    private fun rebuildConfigurations() {
        val provider = provider ?: return
        val next = mutableMapOf<String, InternalConfig>()
        defaultBackCameraID = runCatching {
            Camera2CameraInfo.from(provider.getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)).cameraId
        }.getOrNull()
        val defaultFrontCameraID = runCatching {
            Camera2CameraInfo.from(provider.getCameraInfo(CameraSelector.DEFAULT_FRONT_CAMERA)).cameraId
        }.getOrNull()

        val infos = provider.availableCameraInfos.sortedBy { Camera2CameraInfo.from(it).cameraId }
        val rearSecondaryIDs = infos.filter { it.lensFacing == CameraSelector.LENS_FACING_BACK }
            .map { Camera2CameraInfo.from(it).cameraId }
            .filter { it != defaultBackCameraID }
        val frontSecondaryIDs = infos.filter { it.lensFacing == CameraSelector.LENS_FACING_FRONT }
            .map { Camera2CameraInfo.from(it).cameraId }
            .filter { it != defaultFrontCameraID }

        for (info in infos) {
            val camera2 = Camera2CameraInfo.from(info)
            val id = camera2.cameraId
            val facing = info.lensFacing
            val label = when {
                facing == CameraSelector.LENS_FACING_BACK && id == defaultBackCameraID -> "Arrière — principale"
                facing == CameraSelector.LENS_FACING_BACK -> {
                    val index = rearSecondaryIDs.indexOf(id).takeIf { it >= 0 }?.plus(1) ?: 1
                    "Arrière — objectif secondaire $index"
                }
                facing == CameraSelector.LENS_FACING_FRONT && id == defaultFrontCameraID -> "Avant — principale"
                facing == CameraSelector.LENS_FACING_FRONT -> {
                    val index = frontSecondaryIDs.indexOf(id).takeIf { it >= 0 }?.plus(1) ?: 1
                    "Avant — objectif secondaire $index"
                }
                else -> "Caméra externe"
            }

            val capabilities = Recorder.getVideoCapabilities(info)
            for (quality in capabilities.getSupportedQualities(DynamicRange.SDR)) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                val preview = Preview.Builder().build()
                val probe = SessionConfig.Builder(preview, capture).build()
                val supportedRanges = info.getSupportedFrameRateRanges(probe)
                for (fps in listOf(30, 60)) if (supportedRanges.any { it.contains(fps) }) {
                    val stabilization = capabilities.isStabilizationSupported() && fps <= 30 && w <= 1920 && h <= 1080
                    val public = CameraConfiguration(
                        id = "$id|${qualityName(quality)}|$fps",
                        lensLabel = label,
                        width = w,
                        height = h,
                        fps = fps,
                        stabilizationSupported = stabilization,
                        stabilizationEnabled = false,
                        audioEnabled = false,
                    )
                    next[public.id] = InternalConfig(public, id, quality, false)
                }
            }

            val highCaps = Recorder.getHighSpeedVideoCapabilities(info)
            for (quality in highCaps?.getSupportedQualities(DynamicRange.SDR).orEmpty()) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                val preview = Preview.Builder().build()
                for (fps in listOf(120, 240)) {
                    try {
                        val probe = HighSpeedVideoSessionConfig.Builder(capture)
                            .setPreview(preview)
                            .setFrameRateRange(Range(fps, fps))
                            .setSlowMotionEnabled(false)
                            .build()
                        if (info.getSupportedFrameRateRanges(probe).any { it.contains(fps) }) {
                            val public = CameraConfiguration(
                                id = "$id|${qualityName(quality)}|$fps",
                                lensLabel = label,
                                width = w,
                                height = h,
                                fps = fps,
                                stabilizationSupported = false,
                                stabilizationEnabled = false,
                                audioEnabled = false,
                            )
                            next[public.id] = InternalConfig(public, id, quality, true)
                        }
                    } catch (_: IllegalArgumentException) { /* unsupported combination: do not expose */ }
                }
            }
        }
        configs.clear()
        configs.putAll(next)
        Log.i(TAG, "Camera configurations rebuilt count=${next.size} defaultBack=${defaultBackCameraID ?: "none"}")
    }

    private fun qualityName(q: Quality) = when (q) {
        Quality.UHD -> "UHD"; Quality.FHD -> "FHD"; Quality.HD -> "HD"; Quality.SD -> "SD"; else -> q.toString()
    }

    private fun qualityResolution(q: Quality): Pair<Int, Int>? = when (q) {
        Quality.UHD -> 3840 to 2160; Quality.FHD -> 1920 to 1080; Quality.HD -> 1280 to 720; Quality.SD -> 720 to 480; else -> null
    }

    private fun readMetadata(file: File): Pair<Double, Pair<Int, Int>> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val duration = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
            val width = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            duration to (width to height)
        } finally {
            r.release()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun networkDiagnostics(): LocalCameraServer.Diagnostics? =
        if (::localServer.isInitialized) localServer.diagnostics() else null

    fun latestManifest(): RecordingManifest? = latestPendingManifest()

    fun manifest(recordingID: String): RecordingManifest? = manifests[recordingID]

    fun finalizedFile(recordingID: String): File? {
        val manifest = manifests[recordingID] ?: return null
        val file = File(filesDir, "recordings/${manifest.filename}")
        return file.takeIf(File::isFile)
    }

    fun markTransferStarted(recordingID: String) {
        recoverIfIdle()
        updateTransferState(recordingID, "transferring")
        CompanionRuntime.stateMachine.transferStarted()
    }

    fun markTransferServed(recordingID: String) {
        updateTransferState(recordingID, "served")
        CompanionRuntime.stateMachine.transferFinished()
    }

    fun markTransferInterrupted(recordingID: String) {
        updateTransferState(recordingID, "pending")
        CompanionRuntime.stateMachine.transferFinished()
    }

    fun markImported(recordingID: String): Boolean {
        val manifest = manifests[recordingID] ?: return false
        val updated = manifest.copy(transferState = "imported")
        manifests[recordingID] = updated
        persistManifest(updated)
        CompanionRuntime.stateMachine.clearFinalizedManifest(recordingID)
        CompanionRuntime.stateMachine.transferFinished()
        return true
    }

    private fun updateTransferState(recordingID: String, state: String) {
        val manifest = manifests[recordingID] ?: return
        val updated = manifest.copy(transferState = state)
        manifests[recordingID] = updated
        persistManifest(updated)
    }

    private fun latestPendingManifest(): RecordingManifest? = manifests.values
        .asSequence()
        .filter { it.transferState != "imported" }
        .maxByOrNull { it.finalizedAtISO8601 ?: it.createdAtISO8601 }

    private fun persistManifest(manifest: RecordingManifest) {
        val dir = File(filesDir, "recordings").apply { mkdirs() }
        val props = Properties().apply {
            setProperty("recordingID", manifest.recordingID)
            setProperty("filename", manifest.filename)
            setProperty("sizeBytes", manifest.sizeBytes.toString())
            setProperty("sha256", manifest.sha256)
            setProperty("createdAtISO8601", manifest.createdAtISO8601)
            setProperty("durationSeconds", manifest.durationSeconds.toString())
            setProperty("width", manifest.width.toString())
            setProperty("height", manifest.height.toString())
            setProperty("nominalFPS", manifest.nominalFPS.toString())
            setProperty("lensLabel", manifest.lensLabel)
            setProperty("orientation", manifest.orientation)
            setProperty("transferPath", manifest.transferPath)
            setProperty("finalizedAtISO8601", manifest.finalizedAtISO8601 ?: manifest.createdAtISO8601)
            setProperty("transferState", manifest.transferState)
        }
        File(dir, "${manifest.recordingID}.manifest").outputStream().use {
            props.store(it, "Perche Camera Companion recording")
        }
    }

    private fun loadPersistedManifests() {
        val dir = File(filesDir, "recordings")
        if (!dir.isDirectory) return
        val loaded = dir.listFiles { file -> file.extension == "manifest" }.orEmpty().mapNotNull { file ->
            try {
                val p = Properties().also { props -> file.inputStream().use(props::load) }
                RecordingManifest(
                    recordingID = p.getProperty("recordingID"),
                    filename = p.getProperty("filename"),
                    sizeBytes = p.getProperty("sizeBytes").toLong(),
                    sha256 = p.getProperty("sha256"),
                    createdAtISO8601 = p.getProperty("createdAtISO8601"),
                    durationSeconds = p.getProperty("durationSeconds").toDouble(),
                    width = p.getProperty("width").toInt(),
                    height = p.getProperty("height").toInt(),
                    nominalFPS = p.getProperty("nominalFPS").toDouble(),
                    lensLabel = p.getProperty("lensLabel"),
                    orientation = p.getProperty("orientation"),
                    transferPath = p.getProperty("transferPath"),
                    finalizedAtISO8601 = p.getProperty("finalizedAtISO8601") ?: p.getProperty("createdAtISO8601"),
                    transferState = p.getProperty("transferState") ?: "pending",
                ).takeIf { File(dir, it.filename).isFile }
            } catch (_: Throwable) {
                null
            }
        }
        loaded.forEach { manifests[it.recordingID] = it }
        loaded.filter { it.transferState != "imported" }
            .maxByOrNull { it.finalizedAtISO8601 ?: it.createdAtISO8601 }
            ?.let(CompanionRuntime.stateMachine::restoreFinalizedManifest)
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val channelId = "remote_camera"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Caméra distante", NotificationManager.IMPORTANCE_LOW))
        }
        updateForegroundServiceTypes(includeMicrophone = false)
        foregroundServiceReady = true
        CameraDiagnosticStore.event(this, "foreground service ready type=camera")
    }

    private fun updateForegroundServiceTypes(includeMicrophone: Boolean) {
        val channelId = "remote_camera"
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Perche Camera Companion")
            .setContentText(if (activeRecording != null) "Enregistrement caméra distant" else "Caméra distante disponible sur le réseau local")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()

        var serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (includeMicrophone && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            serviceTypes = serviceTypes or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        ServiceCompat.startForeground(this, 1500, notification, serviceTypes)
        foregroundServiceReady = true
    }
}
