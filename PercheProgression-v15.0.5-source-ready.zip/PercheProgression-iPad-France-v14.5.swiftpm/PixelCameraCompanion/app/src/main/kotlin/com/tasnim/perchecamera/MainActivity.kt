package com.tasnim.perchecamera

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.CameraOperationState
import com.tasnim.perchecamera.protocol.CameraState

class MainActivity : ComponentActivity() {
    companion object {
        private const val TAG = "PercheCamera"
        private const val CAMERA_PERMISSION_REQUEST = 1001
        private const val AUDIO_PERMISSION_REQUEST = 1002
        private const val PREVIEW_START_TIMEOUT_MS = 10_000L
    }

    private lateinit var previewView: PreviewView
    private lateinit var versionView: TextView
    private lateinit var cameraPhaseView: TextView
    private lateinit var cameraReadinessView: TextView
    private lateinit var pinView: TextView
    private lateinit var stateView: TextView
    private lateinit var networkView: TextView
    private lateinit var ipadView: TextView
    private lateinit var pendingView: TextView
    private lateinit var errorView: TextView
    private lateinit var crashView: TextView
    private lateinit var copyCrashButton: Button
    private lateinit var recordingDurationView: TextView
    private lateinit var configDetailsView: TextView
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button
    private lateinit var requestCameraPermissionButton: Button
    private lateinit var cameraSpinner: Spinner
    private lateinit var resolutionSpinner: Spinner
    private lateinit var fpsSpinner: Spinner
    private lateinit var audioSwitch: Switch
    private lateinit var stabilizationSwitch: Switch

    private val handler = Handler(Looper.getMainLooper())
    private var attachedService: CameraRecordingService? = null
    private var previewAttachStartedAtMs: Long? = null
    private var previewFailureReportedForAttachment = false
    private var availableConfigs: List<CameraConfiguration> = emptyList()
    private var controlsFingerprint: String? = null
    private var suppressControlCallbacks = false
    private var pendingAudioEnable = false

    private val refresh = object : Runnable {
        override fun run() {
            val service = CompanionRuntime.service
            if (service != null) ensurePreviewAttached(service)

            val state = CompanionRuntime.stateMachine.state
            val diagnostics = service?.cameraDiagnostics()
            pinView.text = "Code d’appairage : ${CompanionRuntime.pairing.currentCode()}"

            val operationState = service?.cameraOperationState()
            stateView.text = "État : ${cameraStateLabel(operationState, state)}"

            cameraPhaseView.text = when {
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ->
                    "Autorisez l’accès à la caméra pour afficher l’aperçu et filmer."
                diagnostics == null || !diagnostics.providerReady -> "Initialisation caméra…"
                diagnostics.bindingInProgress || !diagnostics.cameraBound -> "Ouverture caméra…"
                diagnostics.previewSurfaceAttached && !diagnostics.previewActive -> "Ouverture caméra…"
                diagnostics.previewActive -> "Aperçu actif · Prêt"
                else -> "Caméra liée · aperçu suspendu"
            }

            cameraReadinessView.text = if (diagnostics == null) {
                "Caméra liée : non\nAperçu : inactif\nVideoCapture : non prêt"
            } else {
                "Caméra liée : ${yesNo(diagnostics.cameraBound)}\n" +
                    "Aperçu : ${if (diagnostics.previewActive) "actif" else "inactif"}\n" +
                    "VideoCapture : ${if (diagnostics.videoCaptureReady) "prêt" else "non prêt"}"
            }

            if (diagnostics != null) {
                refreshConfigurationControls(service, diagnostics.selectedConfiguration)
                maybeReportPreviewTimeout(service, diagnostics)
            }

            val network = service?.networkDiagnostics()
            networkView.text = if (network == null) {
                "Réseau : initialisation…"
            } else {
                "Réseau : ${network.ipv4Address ?: "adresse IPv4 indisponible"}\n" +
                    "Contrôle : ${network.controlPort}\n" +
                    "Transfert : ${network.transferPort}"
            }
            ipadView.text = if (network?.controlConnected == true) "iPad : connecté" else "iPad : en attente"

            val pending = service?.latestManifest()
            pendingView.text = if (pending == null) {
                "Vidéo en attente : aucune"
            } else {
                "Vidéo en attente de transfert · ${pending.durationSeconds.formatOneDecimal()} s · ${pending.transferState}"
            }

            val lastError = diagnostics?.bindingError ?: service?.lastErrorMessage()
            errorView.visibility = if (lastError.isNullOrBlank()) View.GONE else View.VISIBLE
            errorView.text = if (lastError.isNullOrBlank()) "" else "Dernière erreur :\n$lastError"

            val crashSummary = CameraDiagnosticStore.lastCrashSummary(this@MainActivity)
            crashView.visibility = if (crashSummary.isNullOrBlank()) View.GONE else View.VISIBLE
            copyCrashButton.visibility = crashView.visibility
            crashView.text = if (crashSummary.isNullOrBlank()) "" else "Dernier incident :\n$crashSummary"

            recordingDurationView.visibility = if (state == CameraState.RECORDING) View.VISIBLE else View.GONE
            recordingDurationView.text = service?.recordingElapsedSeconds()?.let { "Enregistrement · ${it}s" } ?: ""

            stopButton.visibility = if (state == CameraState.RECORDING || state == CameraState.STOPPING) View.VISIBLE else View.GONE
            stopButton.isEnabled = state == CameraState.RECORDING
            stopButton.text = if (state == CameraState.STOPPING) "Finalisation…" else "Arrêter l’enregistrement"

            resetButton.visibility = if (state == CameraState.ERROR) View.VISIBLE else View.GONE
            requestCameraPermissionButton.visibility =
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) View.GONE else View.VISIBLE

            handler.postDelayed(this, 350)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(TextView(this).apply {
            text = "Perche Camera Companion"
            textSize = 28f
        })
        versionView = TextView(this).apply {
            text = "Version 15.0.5 (150005)"
            textSize = 14f
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(versionView)

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            contentDescription = "Aperçu caméra Pixel"
        }
        root.addView(
            previewView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)).apply {
                bottomMargin = dp(12)
            },
        )

        cameraPhaseView = TextView(this).apply { textSize = 19f; setPadding(0, 0, 0, dp(8)) }
        cameraReadinessView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(16)) }
        root.addView(cameraPhaseView)
        root.addView(cameraReadinessView)

        requestCameraPermissionButton = Button(this).apply {
            text = "Autoriser la caméra"
            visibility = View.GONE
            setOnClickListener { requestCameraPermission() }
        }
        root.addView(requestCameraPermissionButton)

        addSectionTitle(root, "Caméra")
        cameraSpinner = Spinner(this)
        root.addView(cameraSpinner, fullWidthParams())

        addSectionTitle(root, "Résolution")
        resolutionSpinner = Spinner(this)
        root.addView(resolutionSpinner, fullWidthParams())

        addSectionTitle(root, "Fréquence")
        fpsSpinner = Spinner(this)
        root.addView(fpsSpinner, fullWidthParams())

        audioSwitch = Switch(this).apply {
            text = "Microphone"
            isChecked = false
            setPadding(0, dp(8), 0, dp(4))
        }
        stabilizationSwitch = Switch(this).apply {
            text = "Stabilisation vidéo"
            isChecked = false
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(audioSwitch, fullWidthParams())
        root.addView(stabilizationSwitch, fullWidthParams())

        configDetailsView = TextView(this).apply {
            textSize = 13f
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(configDetailsView)

        pinView = TextView(this).apply { textSize = 24f; setPadding(0, dp(18), 0, dp(12)) }
        stateView = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, dp(10)) }
        networkView = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, dp(10)) }
        ipadView = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, dp(10)) }
        pendingView = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(10)) }
        recordingDurationView = TextView(this).apply { textSize = 24f; visibility = View.GONE; setPadding(0, dp(8), 0, dp(8)) }
        errorView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(12)) }
        crashView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(8)); visibility = View.GONE }
        copyCrashButton = Button(this).apply {
            text = "Copier le diagnostic"
            visibility = View.GONE
            setOnClickListener {
                val text = CameraDiagnosticStore.crashDiagnosticText(this@MainActivity) ?: return@setOnClickListener
                val clipboard = getSystemService(ClipboardManager::class.java)
                clipboard.setPrimaryClip(ClipData.newPlainText("Perche Camera diagnostic", text))
            }
        }
        stopButton = Button(this).apply {
            text = "Arrêter l’enregistrement"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.requestStopFromPixel()?.whenComplete { _, error ->
                    if (error != null) runOnUiThread {
                        errorView.visibility = View.VISIBLE
                        errorView.text = "Dernière erreur :\n${error.message ?: "Finalisation impossible."}"
                    }
                }
            }
        }
        resetButton = Button(this).apply {
            text = "Réinitialiser la caméra"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.resetCamera()?.whenComplete { _, _ ->
                    runOnUiThread {
                        isEnabled = true
                        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
                        previewFailureReportedForAttachment = false
                    }
                }
            }
        }

        root.addView(pinView)
        root.addView(stateView)
        root.addView(networkView)
        root.addView(ipadView)
        root.addView(pendingView)
        root.addView(recordingDurationView)
        root.addView(errorView)
        root.addView(crashView)
        root.addView(copyCrashButton)
        root.addView(stopButton)
        root.addView(resetButton)
        root.addView(TextView(this).apply {
            text = "Le fichier maître reste conservé sur ce Pixel après finalisation et transfert. Aucun cloud n’est requis."
            textSize = 16f
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(scroll)
        bindControlListeners()
        previewView.previewStreamState.observe(this) { streamState ->
            val active = streamState == PreviewView.StreamState.STREAMING
            CompanionRuntime.service?.setPreviewStreaming(active)
            if (active) {
                previewAttachStartedAtMs = null
                previewFailureReportedForAttachment = false
                Log.i(TAG, "PreviewView reports STREAMING")
            } else {
                Log.i(TAG, "PreviewView reports IDLE")
            }
        }
        requestPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        attachedService?.detachPreviewSurface()
        attachedService = null
        previewAttachStartedAtMs = null
        previewFailureReportedForAttachment = false
        super.onPause()
    }

    private fun requestPermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraService()
            return
        }
        requestCameraPermission()
    }

    private fun requestCameraPermission() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 37) permissions += "android.permission.ACCESS_LOCAL_NETWORK"
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), CAMERA_PERMISSION_REQUEST)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CAMERA_PERMISSION_REQUEST -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "Camera permission granted")
                    startCameraService()
                } else {
                    Log.w(TAG, "Camera permission denied")
                    cameraPhaseView.text = "Autorisez l’accès à la caméra pour afficher l’aperçu et filmer."
                }
            }
            AUDIO_PERMISSION_REQUEST -> {
                val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                suppressControlCallbacks = true
                audioSwitch.isChecked = granted && pendingAudioEnable
                suppressControlCallbacks = false
                pendingAudioEnable = false
                applyControlSelection()
                if (!granted) {
                    errorView.visibility = View.VISIBLE
                    errorView.text = "Dernière erreur :\nMicrophone refusé. L’enregistrement vidéo reste disponible sans audio."
                }
            }
        }
    }

    private fun startCameraService() {
        val intent = Intent(this, CameraRecordingService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun ensurePreviewAttached(service: CameraRecordingService) {
        if (attachedService === service) return
        attachedService?.detachPreviewSurface()
        attachedService = service
        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
        previewFailureReportedForAttachment = false
        service.attachPreviewSurface(previewView.surfaceProvider)
        Log.i(TAG, "Preview surface attached to CameraRecordingService")
    }

    private fun maybeReportPreviewTimeout(service: CameraRecordingService, diagnostics: CameraRecordingService.CameraDiagnostics) {
        if (diagnostics.previewActive) {
            previewAttachStartedAtMs = null
            previewFailureReportedForAttachment = false
            return
        }
        val started = previewAttachStartedAtMs ?: return
        if (!diagnostics.previewSurfaceAttached || !diagnostics.cameraBound || diagnostics.bindingInProgress) return
        if (CompanionRuntime.stateMachine.state == CameraState.RECORDING || CompanionRuntime.stateMachine.state == CameraState.STOPPING) return
        if (!previewFailureReportedForAttachment && SystemClock.elapsedRealtime() - started >= PREVIEW_START_TIMEOUT_MS) {
            previewFailureReportedForAttachment = true
            service.reportPreviewFailure("L’aperçu CameraX n’a produit aucune image après 10 secondes.")
        }
    }

    private fun bindControlListeners() {
        cameraSpinner.onItemSelectedListener = selectionListener { onCameraChanged() }
        resolutionSpinner.onItemSelectedListener = selectionListener { onResolutionChanged() }
        fpsSpinner.onItemSelectedListener = selectionListener { applyControlSelection() }

        audioSwitch.setOnCheckedChangeListener { _, checked ->
            if (suppressControlCallbacks) return@setOnCheckedChangeListener
            if (checked && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingAudioEnable = true
                suppressControlCallbacks = true
                audioSwitch.isChecked = false
                suppressControlCallbacks = false
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            } else {
                applyControlSelection()
            }
        }
        stabilizationSwitch.setOnCheckedChangeListener { _, _ ->
            if (!suppressControlCallbacks) applyControlSelection()
        }
    }

    private fun selectionListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (!suppressControlCallbacks) action()
        }
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
    }

    private fun refreshConfigurationControls(service: CameraRecordingService, selected: CameraConfiguration?) {
        val configs = service.configurations()
        if (configs.isEmpty()) return
        val current = selected ?: configs.first()
        val fingerprint = buildString {
            append(configs.joinToString("|") { it.id })
            append('#').append(current.id)
            append('#').append(current.audioEnabled)
            append('#').append(current.stabilizationEnabled)
        }
        if (fingerprint == controlsFingerprint) return
        availableConfigs = configs
        controlsFingerprint = fingerprint
        syncControlsFrom(current)
    }

    private fun syncControlsFrom(config: CameraConfiguration) {
        suppressControlCallbacks = true
        try {
            val cameraNames = availableConfigs.map { it.lensLabel }.distinct()
            setSpinner(cameraSpinner, cameraNames, config.lensLabel)

            val resolutions = availableConfigs
                .filter { it.lensLabel == config.lensLabel }
                .map { "${it.width} × ${it.height}" }
                .distinct()
            setSpinner(resolutionSpinner, resolutions, "${config.width} × ${config.height}")

            val fpsValues = availableConfigs
                .filter { it.lensLabel == config.lensLabel && it.width == config.width && it.height == config.height }
                .map { "${it.fps} i/s" }
                .distinct()
            setSpinner(fpsSpinner, fpsValues, "${config.fps} i/s")

            audioSwitch.isChecked = config.audioEnabled
            stabilizationSwitch.isChecked = config.stabilizationEnabled
            stabilizationSwitch.isEnabled = config.stabilizationSupported
            configDetailsView.text = "Détails techniques · ID caméra ${config.id.substringBefore('|')} · configuration ${config.id}"
        } finally {
            suppressControlCallbacks = false
        }
    }

    private fun onCameraChanged() {
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val candidates = availableConfigs.filter { it.lensLabel == lens }
        if (candidates.isEmpty()) return
        val preferred = candidates.firstOrNull { it.width == 1280 && it.height == 720 && it.fps == 30 }
            ?: candidates.firstOrNull { it.fps == 30 }
            ?: candidates.first()
        syncControlsFrom(preferred.copy(audioEnabled = audioSwitch.isChecked, stabilizationEnabled = false))
        applyControlSelection()
    }

    private fun onResolutionChanged() {
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val resolution = resolutionSpinner.selectedItem?.toString() ?: return
        val (width, height) = parseResolution(resolution) ?: return
        val candidates = availableConfigs.filter { it.lensLabel == lens && it.width == width && it.height == height }
        if (candidates.isEmpty()) return
        val preferred = candidates.firstOrNull { it.fps == 30 } ?: candidates.first()
        suppressControlCallbacks = true
        try {
            setSpinner(fpsSpinner, candidates.map { "${it.fps} i/s" }.distinct(), "${preferred.fps} i/s")
            stabilizationSwitch.isEnabled = preferred.stabilizationSupported
            if (!preferred.stabilizationSupported) stabilizationSwitch.isChecked = false
        } finally {
            suppressControlCallbacks = false
        }
        applyControlSelection()
    }

    private fun applyControlSelection() {
        val service = CompanionRuntime.service ?: return
        if (availableConfigs.isEmpty()) return
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val resolution = resolutionSpinner.selectedItem?.toString() ?: return
        val (width, height) = parseResolution(resolution) ?: return
        val fps = fpsSpinner.selectedItem?.toString()?.substringBefore(' ')?.toIntOrNull() ?: return
        val base = availableConfigs.firstOrNull {
            it.lensLabel == lens && it.width == width && it.height == height && it.fps == fps
        } ?: return
        val requested = base.copy(
            audioEnabled = audioSwitch.isChecked,
            stabilizationEnabled = stabilizationSwitch.isChecked && base.stabilizationSupported,
        )
        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
        previewFailureReportedForAttachment = false
        service.configureCamera(requested).whenComplete { _, error ->
            if (error != null) runOnUiThread {
                errorView.visibility = View.VISIBLE
                errorView.text = "Dernière erreur :\n${error.message ?: "Configuration caméra impossible."}"
            }
        }
    }

    private fun setSpinner(spinner: Spinner, values: List<String>, selected: String) {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, values).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val index = values.indexOf(selected).takeIf { it >= 0 } ?: 0
        spinner.setSelection(index, false)
    }

    private fun parseResolution(value: String): Pair<Int, Int>? {
        val parts = value.replace(" ", "").split('×')
        if (parts.size != 2) return null
        val width = parts[0].toIntOrNull() ?: return null
        val height = parts[1].toIntOrNull() ?: return null
        return width to height
    }

    private fun addSectionTitle(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setPadding(0, dp(8), 0, dp(2))
        }, fullWidthParams())
    }

    private fun fullWidthParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun cameraStateLabel(operation: CameraOperationState?, remote: CameraState): String = when (operation) {
        CameraOperationState.INITIALIZING -> "initialisation caméra…"
        CameraOperationState.RECONFIGURING -> "reconfiguration caméra…"
        CameraOperationState.STARTING_RECORDING -> "démarrage enregistrement…"
        CameraOperationState.RECORDING -> "enregistrement"
        CameraOperationState.FINALIZING -> "finalisation…"
        CameraOperationState.ERROR -> "erreur"
        CameraOperationState.READY -> when (remote) {
            CameraState.TRANSFERRING -> "transfert…"
            CameraState.ERROR -> "erreur"
            else -> "prêt"
        }
        null -> when (remote) {
            CameraState.STOPPING -> "finalisation…"
            CameraState.ERROR -> "erreur"
            else -> remote.name.lowercase()
        }
    }

    private fun yesNo(value: Boolean) = if (value) "oui" else "non"

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun Double.formatOneDecimal(): String = String.format(java.util.Locale.FRANCE, "%.1f", this)
}
