package com.tasnim.perchecamera

import android.content.Context
import java.io.File
import java.time.Instant
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.system.exitProcess

/** Lightweight process-private diagnostics for field camera failures without ADB/logcat. */
object CameraDiagnosticStore {
    private const val LOG_DIRECTORY = "diagnostics"
    private const val EVENT_FILE = "camera-events.log"
    private const val CRASH_FILE = "last-camera-crash.log"
    private const val MAX_EVENT_BYTES = 512 * 1024L
    private val installed = AtomicBoolean(false)

    @Synchronized
    fun event(context: Context, message: String, throwable: Throwable? = null) {
        runCatching {
            val dir = File(context.filesDir, LOG_DIRECTORY).apply { mkdirs() }
            val file = File(dir, EVENT_FILE)
            if (file.length() > MAX_EVENT_BYTES) {
                val rotated = File(dir, "$EVENT_FILE.previous")
                if (rotated.exists()) rotated.delete()
                file.renameTo(rotated)
            }
            file.appendText(buildDiagnosticLine(message, throwable))
        }
    }

    fun installCrashHandler(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val dir = File(appContext.filesDir, LOG_DIRECTORY).apply { mkdirs() }
                File(dir, CRASH_FILE).writeText(
                    buildString {
                        append(Instant.now()).append('\n')
                        append("thread=").append(thread.name).append('\n')
                        append("exception=").append(throwable::class.java.name).append('\n')
                        append("message=").append(throwable.message ?: "(aucun message)").append('\n')
                        append('\n')
                        append(throwable.stackTraceToString())
                    },
                )
                event(appContext, "UNCAUGHT ${throwable::class.java.name}: ${throwable.message ?: "(aucun message)"}")
            }
            if (previous != null) previous.uncaughtException(thread, throwable) else exitProcess(10)
        }
    }

    fun lastCrashSummary(context: Context): String? = runCatching {
        val file = File(File(context.filesDir, LOG_DIRECTORY), CRASH_FILE)
        if (!file.isFile) return@runCatching null
        val lines = file.readLines()
        val exception = lines.firstOrNull { it.startsWith("exception=") }?.substringAfter('=')
        val message = lines.firstOrNull { it.startsWith("message=") }?.substringAfter('=')
        listOfNotNull(exception, message?.takeIf { it.isNotBlank() }).joinToString("\n").ifBlank { null }
    }.getOrNull()

    fun crashDiagnosticText(context: Context): String? = runCatching {
        val dir = File(context.filesDir, LOG_DIRECTORY)
        val crash = File(dir, CRASH_FILE).takeIf(File::isFile)?.readText() ?: return@runCatching null
        val events = File(dir, EVENT_FILE).takeIf(File::isFile)?.readText().orEmpty()
        buildString {
            append("=== Dernier crash caméra ===\n")
            append(crash)
            if (events.isNotBlank()) {
                append("\n\n=== Journal caméra récent ===\n")
                append(events.takeLast(64 * 1024))
            }
        }
    }.getOrNull()

    private fun buildDiagnosticLine(message: String, throwable: Throwable?): String = buildString {
        append(Instant.now())
        append(" thread=").append(Thread.currentThread().name)
        append(" ").append(message)
        if (throwable != null) {
            append(" exception=").append(throwable::class.java.name)
            append(" message=").append(throwable.message ?: "(aucun message)")
        }
        append('\n')
        if (throwable != null) append(throwable.stackTraceToString()).append('\n')
    }
}
