package com.tasnim.perchecamera.protocol

import org.junit.Assert.*
import org.junit.Test

class CameraOperationCoordinatorTest {
    private fun ready(id: String = "rear|HD|30") = CameraOperationCoordinator().also { it.initialized(id) }

    @Test
    fun readyRecordStartTransitionsThroughStartingToRecording() {
        val state = ready()
        assertTrue(state.beginRecordingStart("rear|HD|30"))
        assertEquals(CameraOperationState.STARTING_RECORDING, state.state)
        state.recordingStarted()
        assertEquals(CameraOperationState.RECORDING, state.state)
    }

    @Test
    fun prepareRecordingFailureIsRecoverableWithoutProcessDeath() {
        val state = ready()
        assertTrue(state.beginRecordingStart("rear|HD|30"))
        state.recordingStartFailed("prepareRecording failed", cameraStillUsable = true)
        assertEquals(CameraOperationState.READY, state.state)
        assertEquals("prepareRecording failed", state.lastErrorMessage)
    }

    @Test
    fun startFailureIsRecoverableWithoutProcessDeath() {
        val state = ready()
        assertTrue(state.beginRecordingStart("rear|HD|30"))
        state.recordingStartFailed("start failed", cameraStillUsable = true)
        assertEquals(CameraOperationState.READY, state.state)
    }

    @Test
    fun startEventTimeoutRecoversWhenCameraBindingSurvives() {
        val state = ready()
        assertTrue(state.beginRecordingStart("rear|HD|30"))
        state.recordingStartFailed("timeout", cameraStillUsable = true)
        assertEquals(CameraOperationState.READY, state.state)
    }

    @Test
    fun configurationChangeCommitsOnlyAfterSuccessfulRebind() {
        val state = ready("rear")
        assertTrue(state.beginReconfiguration("front"))
        assertEquals("rear", state.activeConfigurationID)
        state.reconfigurationSucceeded("front")
        assertEquals(CameraOperationState.READY, state.state)
        assertEquals("front", state.activeConfigurationID)
    }

    @Test
    fun failedConfigurationChangePreservesPreviousConfiguration() {
        val state = ready("rear")
        assertTrue(state.beginReconfiguration("front"))
        state.reconfigurationFailed("front unavailable", previousBindingRecovered = true)
        assertEquals(CameraOperationState.READY, state.state)
        assertEquals("rear", state.activeConfigurationID)
    }

    @Test
    fun configurationAndRecordStartAreSerialized() {
        val state = ready("rear")
        assertTrue(state.beginReconfiguration("front"))
        assertFalse(state.beginRecordingStart("rear"))
        state.reconfigurationSucceeded("front")
        assertTrue(state.beginRecordingStart("front"))
    }

    @Test
    fun duplicateRecordStartIsRejected() {
        val state = ready()
        assertTrue(state.beginRecordingStart("rear|HD|30"))
        assertFalse(state.beginRecordingStart("rear|HD|30"))
    }

    @Test
    fun cameraChangeWhileRecordingIsRejected() {
        val state = ready("rear")
        assertTrue(state.beginRecordingStart("rear"))
        state.recordingStarted()
        assertFalse(state.beginReconfiguration("front"))
    }

    @Test
    fun microphoneOffNeverEnablesAudio() {
        assertFalse(RecordingStartPolicy.shouldEnableAudio(audioRequested = false, microphonePermissionGranted = true))
        assertFalse(RecordingStartPolicy.shouldEnableAudio(audioRequested = false, microphonePermissionGranted = false))
        assertTrue(RecordingStartPolicy.shouldEnableAudio(audioRequested = true, microphonePermissionGranted = true))
    }
}
