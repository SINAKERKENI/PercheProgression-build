package com.tasnim.perchecamera.protocol

fun sampleManifest(id: String = "r1") = RecordingManifest(
    id,
    "$id.mp4",
    3,
    "abc",
    "2026-09-12T12:00:00Z",
    1.0,
    1920,
    1080,
    60.0,
    "1×",
    "landscape",
    "/recordings/$id",
    "2026-09-12T12:00:01Z",
    "pending",
)

fun main() {
    var now = 1_000L
    val auth = PairingAuthority { now }
    val code = auth.currentCode()
    check(auth.pair("000000", "ipad") == null)
    val token = checkNotNull(auth.pair(code, "ipad"))
    check(auth.isAuthorized(token))
    check(!auth.isAuthorized("bad"))

    val state = RemoteCameraStateMachine()
    state.recordingStarted()
    check(state.state == CameraState.RECORDING)
    state.stopRequested(StopOrigin.IPAD)
    val manifest = sampleManifest()
    state.recordingFinalized(manifest)
    check(state.state == CameraState.READY)
    check(state.finalizedManifest == manifest)

    state.recordingStarted()
    state.stopRequested(StopOrigin.PIXEL)
    state.recordingFinalized(sampleManifest("r2"))
    check(state.state == CameraState.READY)

    val operations = CameraOperationCoordinator()
    operations.initialized("rear")
    check(operations.beginReconfiguration("front"))
    check(!operations.beginRecordingStart("rear"))
    operations.reconfigurationSucceeded("front")
    check(operations.beginRecordingStart("front"))
    check(operations.state == CameraOperationState.STARTING_RECORDING)
    operations.recordingStarted()
    check(operations.state == CameraOperationState.RECORDING)
    check(!operations.beginReconfiguration("rear"))
    check(operations.beginFinalization())
    operations.recordingFinalized()
    check(operations.state == CameraOperationState.READY)
    check(!RecordingStartPolicy.shouldEnableAudio(audioRequested = false, microphonePermissionGranted = true))

    now += 13 * 60 * 60_000L
    check(!auth.isAuthorized(token))
    println("ProtocolSelfTest: PASS")
}
