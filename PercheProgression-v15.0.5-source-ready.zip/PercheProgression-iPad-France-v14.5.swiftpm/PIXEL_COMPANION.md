# Pixel Camera Companion

## Prérequis

- iPad avec Perche Progression v15 ;
- téléphone Android/Pixel avec `PixelCameraCompanion/` ;
- réseau local utilisable par les deux appareils ;
- autorisation caméra (et microphone si l’audio est activé) sur Android ;
- autorisation réseau local/Bonjour sur iPadOS.

## Appairage

Le service Android est découvrable sur le LAN, mais la découverte n’autorise aucune commande. L’iPad ouvre le canal de contrôle puis envoie un code d’appairage explicite. Le compagnon retourne un jeton de session seulement après validation ; les commandes suivantes portent ce jeton. Les jetons temporaires ne doivent pas être placés dans le code source ni dans les logs de production.

## Enregistrement

1. L’iPad interroge les configurations réellement annoncées par le compagnon.
2. `recordStart` est envoyé avec la configuration choisie.
3. L’iPad n’affiche `recording` qu’après l’ACK Android correspondant.
4. Au STOP, Android arrête CameraX et attend son événement de finalisation.
5. La réponse de STOP contient alors le manifeste du fichier finalisé : identifiant, taille, SHA-256, métadonnées et chemin de transfert.

Le maître reste enregistré localement sur le téléphone jusqu’à ce qu’un transfert fiable ait eu lieu ; une perte réseau ne doit donc pas perdre un enregistrement déjà finalisé.

## Transfert et import

Le transfert local HTTP accepte la reprise par `Range`. L’iPad conserve un fichier de staging `<recordingID>.partial`, reprend à sa taille existante, vérifie la taille finale puis calcule le SHA-256 en flux. `VideoAssetStore` n’est alimenté qu’après cette vérification, puis le hash du fichier importé est contrôlé une seconde fois. En cas d’échec de checksum, l’asset importé est supprimé et le fichier corrompu n’est pas enregistré comme succès.

`remoteRecordingID` empêche un second import du même enregistrement.

## Récupération

- Perte réseau pendant un enregistrement : le téléphone continue à protéger son maître local ; l’iPad ne suppose pas que STOP a réussi sans ACK.
- Perte après STOP : le manifeste finalisé peut être récupéré via l’état distant après reconnexion.
- Perte pendant le transfert : le `.partial` permet une reprise HTTP Range.
- Fichier partiel plus grand que le manifeste ou réponse incompatible : le staging est réinitialisé plutôt que validé.

## Aperçu

Le compagnon affiche un aperçu CameraX **local sur le Pixel** via `PreviewView`. Le streaming live vers l’iPad/WebRTC n’est pas inclus.

## Correctif cycle v15.0.4

Le manifeste n’est plus seulement une réponse à `recordStop`. `VideoRecordEvent.Finalize` crée et persiste systématiquement le manifeste, quelle que soit l’origine de l’arrêt (`IPAD`, `PIXEL` ou finalisation système). `STATUS` expose la dernière vidéo finalisée qui n’a pas encore été acquittée par l’iPad.

L’iPad traite `STATUS` comme l’état autoritatif : si la réponse directe à STOP manque ou tarde, il interroge le Pixel et bascule vers le transfert dès qu’un manifeste finalisé apparaît. Un Stop local sur le Pixel suit exactement ce même chemin.

Le transfert garde le fichier maître dans `filesDir/recordings/`. Le serveur HTTP Range marque seulement l’état du transfert (`pending`, `transferring`, `served`, `imported`) ; aucune de ces transitions ne supprime le MP4. `transferComplete` signifie uniquement que l’iPad a validé et persisté sa copie.

Côté iPad, le suffixe `.partial` est uniquement un suffixe de staging. Le média durable reçoit l’extension MP4/MOV/M4V déclarée par le manifeste et doit être ouvert avec succès par AVFoundation avant création du `VideoClipRecord`.

## Aperçu local v15.0.4

Le compagnon lie un `Preview` CameraX et le `VideoCapture` dans la même session. Quand l’activité est visible, `PreviewView` fournit la surface et `previewActive` ne devient vrai qu’après l’état `STREAMING`. La configuration initiale privilégie la caméra arrière principale en HD 1280×720 à 30 i/s, audio et stabilisation désactivés. Si l’activité quitte l’écran, la surface d’aperçu est détachée sans détruire le `VideoCapture` du service premier plan.

## Démarrage et configuration v15.0.5

`CameraRecordingService` reste l’unique propriétaire de la session CameraX. En état READY, `Preview` et `VideoCapture` sont déjà liés à la même caméra ; l’activité ne fournit que la surface `PreviewView`. `recordStart` utilise ce `VideoCapture` existant et ne fait pas `unbindAll()`/rebind avant `PendingRecording.start`.

Le démarrage est acquitté uniquement après `VideoRecordEvent.Start`. Les étapes `prepareRecording`, audio et `start()` sont journalisées dans le stockage privé du compagnon, les exceptions récupérables sont renvoyées à l’iPad sans interrompre volontairement le serveur de contrôle, et un timeout borné empêche `STARTING_RECORDING` de rester bloqué. Avec microphone OFF, `withAudioEnabled()` n’est pas appelé.

Une configuration choisie sur l’iPad est une commande distante transactionnelle : Android passe en `RECONFIGURING`, rebinde `Preview + VideoCapture`, puis renvoie l’identifiant réellement actif. L’iPad ne change son sélecteur qu’après cet ACK/STATUS. Un changement de caméra est refusé pendant un enregistrement/finalisation et une reconfiguration échouée restaure la configuration précédente lorsqu’elle reste exploitable.

Le compagnon écrit `camera-events.log` et `last-camera-crash.log` dans son stockage privé, sans jeton d’authentification. Au lancement, « Dernier incident » et « Copier le diagnostic » permettent de récupérer l’exception exacte si un crash inattendu subsiste.
