# Validation v15.0.5

| Zone | Validation effectuée | Résultat | Limite restante |
|---|---|---|---|
| Matériel v15.0.4 | Aperçu CameraX local + indicateur caméra Android + caméra arrière | **Confirmé sur Pixel réel** | aucune pour l’ouverture initiale/aperçu |
| Matériel v15.0.4 | Bonjour/NSD, appairage, `cameraReady`, `previewActive` | **Confirmé iPad + Pixel réels** | aucune pour ces étapes |
| Matériel v15.0.4 | `recordStart` | **Échec physique : processus Pixel se ferme au démarrage** | correctif v15.0.5 à revalider sur matériel |
| Matériel v15.0.4 | changement de caméra depuis l’iPad | **Échec physique : UI/configuration réelle peuvent diverger** | transaction distante v15.0.5 à revalider |
| Android protocole pur | `ProtocolSelfTest` avec coordinateur d’opérations caméra | **PASS** | ne remplace pas CameraX |
| Android tests v15.0.5 | 10 tests JUnit : start, erreurs, timeout, config transactionnelle, races, audio OFF | **Ajoutés** | exécution Gradle GitHub **PENDING** |
| Android CameraX v15.0.5 | `recordStart` utilise le `VideoCapture` déjà lié; callbacks/start protégés; timeout borné | **Implémenté en source** | build GitHub + test Pixel **PENDING** |
| Diagnostic Android | journal privé + dernier crash + copie du diagnostic | **Implémenté en source** | crash réel à observer seulement si le défaut persiste |
| iPad config distante | sélection confirmée uniquement après ACK/STATUS Android | **Implémenté en source** | test matériel Rear → Front → Rear **PENDING** |
| Swift | parse AppModule + Tests | **82/82 PASS** | ce n’est pas un build Xcode complet |
| Swift protocole distant | `RemoteCameraProtocol.swift` type-check | **PASS** | build Xcode complet non exécuté ici |
| GitHub CI | build `gradle clean :app:assembleDebug` sans réécriture production | **Préparé** | exécution **PENDING** |

## Gate matériel v15.0.5

1. Aperçu actif et indicateur caméra vert.
2. Depuis l’iPad : arrière → avant → arrière, avec changement visible du Preview Pixel et ACK de la configuration active.
3. Configuration de base : arrière principale, 1280×720, 30 i/s, micro OFF, stabilisation OFF.
4. `Enregistrer` : le Pixel reste ouvert, passe `STARTING_RECORDING` puis reçoit `VideoRecordEvent.Start` et devient `RECORDING`.
5. Stop → Finalize → transfert → lecture iPad.
6. Nouvel enregistrement sans redémarrage.
