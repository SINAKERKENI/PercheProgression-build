# Validation v15.0.7 — UX vidéo ciblée

## Périmètre

Cette passe ne modifie que l’expérience Analyse vidéo demandée : lecture/pause au toucher, export et renommage de la vidéothèque, raccourci de capture Pixel sans perturber l’analyse active, et fiabilisation des gestes de timeline/viewport.

## Vérifications exécutées dans cet environnement

- Parsing Swift : 85/85 fichiers `AppModule` + `Tests`.
- `VideoClipNaming` : type-check Swift réussi.
- Self-test `VideoClipNaming` : conservation de l’extension, suppression d’une extension média saisie en double, refus des chemins — PASS.
- `ProtocolSelfTest` Kotlin : PASS.
- Workflow GitHub v15.0.7 : parsing YAML réussi.
- Vérifications statiques ciblées : PASS (`floatingPlaybackButton`, capture rapide Pixel, export, renommage, hôte de gestes, surface timeline plein cadre, suppression du `DragGesture(minimumDistance: 0)`).

## Validation matérielle encore requise

Un iPad réel doit confirmer :

1. toucher la vidéo → contrôle central lecture/pause visible et utilisable ;
2. zoom/pan à deux doigts sur la vidéo principale et la référence ;
3. glisser/pincer la timeline sans que le ScrollView de la page vole le geste ;
4. export vers Fichiers/partage avec le nom choisi ;
5. renommage persistant après relance ;
6. capture rapide Pixel pendant l’analyse d’une autre vidéo, sans remplacement automatique de l’espace de travail courant ;
7. import de la nouvelle capture dans la vidéothèque une fois finalisée.

Aucun succès matériel n’est revendiqué avant ces tests.
