import SwiftUI
import UIKit

/// Installs two-finger viewport gestures on the surrounding video container rather than
/// placing a hit-testing view over the annotations. One-finger touches therefore continue
/// to reach PencilKit / annotation tools, while a recognized multi-touch gesture cancels
/// the in-progress one-finger delivery so an accidental annotation is not committed.
struct VideoGestureLayer: UIViewRepresentable {
  var onPan: (CGSize) -> Void
  var onScale: (CGFloat) -> Void
  var onRotation: (CGFloat) -> Void
  var onInteractionChanged: (Bool) -> Void = { _ in }
  var isEnabled = true

  func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

  func makeUIView(context: Context) -> GestureAttachmentView {
    let view = GestureAttachmentView()
    view.backgroundColor = .clear
    view.isUserInteractionEnabled = false
    view.onSuperviewChanged = { [weak coordinator = context.coordinator] host in
      coordinator?.attach(to: host)
    }
    return view
  }

  func updateUIView(_ uiView: GestureAttachmentView, context: Context) {
    context.coordinator.parent = self
    context.coordinator.setEnabled(isEnabled)
    if context.coordinator.host == nil {
      context.coordinator.attach(to: uiView.superview)
    }
  }

  static func dismantleUIView(_ uiView: GestureAttachmentView, coordinator: Coordinator) {
    coordinator.detach()
  }

  final class GestureAttachmentView: UIView {
    var onSuperviewChanged: ((UIView?) -> Void)?

    override func didMoveToSuperview() {
      super.didMoveToSuperview()
      notifyHostAfterLayout()
    }

    override func layoutSubviews() {
      super.layoutSubviews()
      notifyHostAfterLayout()
    }

    private func notifyHostAfterLayout() {
      // SwiftUI can finish building/sizing the surrounding container after either callback.
      // Re-resolving is cheap because the coordinator ignores an unchanged host.
      DispatchQueue.main.async { [weak self] in
        guard let self else { return }
        self.onSuperviewChanged?(self.superview)
      }
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool { false }
  }

  final class Coordinator: NSObject, UIGestureRecognizerDelegate {
    var parent: VideoGestureLayer
    weak var host: UIView?
    private var pan: UIPanGestureRecognizer?
    private var pinch: UIPinchGestureRecognizer?
    private var rotation: UIRotationGestureRecognizer?
    private var activeRecognizers: Set<ObjectIdentifier> = []
    private var pendingRotation: CGFloat = 0

    init(parent: VideoGestureLayer) { self.parent = parent }

    func attach(to newHost: UIView?) {
      guard let candidate = newHost else { return }
      let newHost = preferredViewportHost(startingAt: candidate)
      guard newHost !== host else {
        setEnabled(parent.isEnabled)
        return
      }
      detach()
      host = newHost
      newHost.isUserInteractionEnabled = true
      newHost.isMultipleTouchEnabled = true

      let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
      pan.minimumNumberOfTouches = 2
      pan.maximumNumberOfTouches = 2
      pan.cancelsTouchesInView = true

      let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
      pinch.cancelsTouchesInView = true

      let rotation = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation(_:)))
      rotation.cancelsTouchesInView = true

      for recognizer in [pan, pinch, rotation] {
        recognizer.delegate = self
        newHost.addGestureRecognizer(recognizer)
      }
      self.pan = pan
      self.pinch = pinch
      self.rotation = rotation
      setEnabled(parent.isEnabled)
    }

    private func preferredViewportHost(startingAt candidate: UIView) -> UIView {
      // SwiftUI may wrap UIViewRepresentable in one or more zero-sized hosting views.
      // Attaching to such a wrapper makes UIKit recognizers appear installed while they
      // never receive the video touches. Walk upward only until the first substantial,
      // non-scroll container so primary/reference surfaces remain independent.
      var current: UIView? = candidate
      while let view = current {
        if !(view is UIScrollView), view.bounds.width >= 120, view.bounds.height >= 120 {
          return view
        }
        current = view.superview
      }
      return candidate
    }

    func detach() {
      if let host {
        [pan, pinch, rotation].compactMap { $0 }.forEach(host.removeGestureRecognizer)
      }
      pan = nil
      pinch = nil
      rotation = nil
      pendingRotation = 0
      activeRecognizers.removeAll()
      host = nil
    }

    func setEnabled(_ enabled: Bool) {
      pan?.isEnabled = enabled
      pinch?.isEnabled = enabled
      rotation?.isEnabled = enabled
      if !enabled, !activeRecognizers.isEmpty {
        activeRecognizers.removeAll()
        parent.onInteractionChanged(false)
      }
    }

    func gestureRecognizer(
      _ gestureRecognizer: UIGestureRecognizer,
      shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
    ) -> Bool { true }

    private func updateInteraction(_ recognizer: UIGestureRecognizer) {
      let id = ObjectIdentifier(recognizer)
      switch recognizer.state {
      case .began:
        let wasEmpty = activeRecognizers.isEmpty
        activeRecognizers.insert(id)
        if wasEmpty { parent.onInteractionChanged(true) }
      case .ended, .cancelled, .failed:
        activeRecognizers.remove(id)
        if activeRecognizers.isEmpty { parent.onInteractionChanged(false) }
      default:
        break
      }
    }

    @objc private func handlePan(_ recognizer: UIPanGestureRecognizer) {
      updateInteraction(recognizer)
      guard recognizer.state == .changed else { return }
      let t = recognizer.translation(in: recognizer.view)
      parent.onPan(CGSize(width: t.x, height: t.y))
      recognizer.setTranslation(.zero, in: recognizer.view)
    }

    @objc private func handlePinch(_ recognizer: UIPinchGestureRecognizer) {
      updateInteraction(recognizer)
      guard recognizer.state == .changed else { return }
      parent.onScale(recognizer.scale)
      recognizer.scale = 1
    }

    @objc private func handleRotation(_ recognizer: UIRotationGestureRecognizer) {
      updateInteraction(recognizer)
      if recognizer.state == .began { pendingRotation = 0 }
      guard recognizer.state == .changed else { return }
      pendingRotation += recognizer.rotation
      recognizer.rotation = 0
      // Ignore tiny involuntary twists while pinching/panning. Once the threshold is
      // crossed, apply the accumulated rotation and continue smoothly.
      guard abs(pendingRotation) >= 0.015 else { return }
      parent.onRotation(pendingRotation)
      pendingRotation = 0
    }
  }
}
