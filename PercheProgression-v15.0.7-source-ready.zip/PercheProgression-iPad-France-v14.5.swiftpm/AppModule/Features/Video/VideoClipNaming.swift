import Foundation

enum VideoClipNaming {
  private static let mediaExtensions: Set<String> = ["mp4", "mov", "m4v"]

  static func displayName(for filename: String) -> String {
    let trimmed = filename.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { return "Vidéo sans nom" }
    let url = URL(fileURLWithPath: trimmed)
    let ext = url.pathExtension.lowercased()
    guard mediaExtensions.contains(ext) else { return trimmed }
    let base = url.deletingPathExtension().lastPathComponent
    return base.isEmpty ? trimmed : base
  }

  static func renamedFilename(requestedName: String, preservingExtensionOf currentFilename: String) -> String? {
    var name = requestedName.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !name.isEmpty, !name.contains("/"), !name.contains("\\") else { return nil }

    let requestedURL = URL(fileURLWithPath: name)
    if mediaExtensions.contains(requestedURL.pathExtension.lowercased()) {
      name = requestedURL.deletingPathExtension().lastPathComponent
    }
    guard !name.isEmpty else { return nil }

    let currentExtension = URL(fileURLWithPath: currentFilename).pathExtension
    return currentExtension.isEmpty ? name : "\(name).\(currentExtension)"
  }
}
