# v15.0.7 — Correctifs ciblés Analyse vidéo

## Interaction vidéo
- Un toucher sur la vidéo révèle un bouton central lecture/pause.
- Le `DragGesture(minimumDistance: 0)` utilisé seulement pour afficher le chrome a été retiré afin de ne plus concurrencer le multi-touch.
- Les recognizers UIKit de zoom/pan/rotation sont attachés au premier conteneur vidéo réellement dimensionné et réévalués après layout.
- Les surfaces de gestes sont explicitement plein cadre dans la vue principale, la référence et le plein écran.

## Timeline
- La surface UIKit de scrub/pinch remplit toute la timeline.
- Le pan de timeline est prioritaire sur le ScrollView parent quand le geste démarre sur la bande.

## Vidéothèque
- Export/téléchargement via feuille système, avec une copie temporaire portant le nom utilisateur.
- Renommage en touchant le nom ; l’extension vidéo réelle est conservée et aucun média n’est déplacé/réencodé.

## Capture Pixel rapide
- Bouton `Filmer Pixel` rapproché des contrôles d’import.
- Une capture rapide peut continuer et s’importer dans la vidéothèque sans remplacer la vidéo actuellement analysée.

## Hors périmètre
Aucun changement FFA, moteur de recommandation de perches, Harada, moteur de vitesse, schéma SwiftData, protocole de transfert ou logique de progression.
