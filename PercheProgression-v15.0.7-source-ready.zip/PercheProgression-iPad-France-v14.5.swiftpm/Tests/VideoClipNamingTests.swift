import XCTest
@testable import AppModule

final class VideoClipNamingTests: XCTestCase {
  func testDisplayNameHidesMediaExtension() {
    XCTAssertEqual(VideoClipNaming.displayName(for: "saut-01.mp4"), "saut-01")
  }

  func testRenamePreservesOriginalMediaExtension() {
    XCTAssertEqual(
      VideoClipNaming.renamedFilename(requestedName: "Essai 4", preservingExtensionOf: "source.mp4"),
      "Essai 4.mp4"
    )
  }

  func testRenameDoesNotDuplicateMediaExtension() {
    XCTAssertEqual(
      VideoClipNaming.renamedFilename(requestedName: "Essai 4.MP4", preservingExtensionOf: "source.mp4"),
      "Essai 4.mp4"
    )
    XCTAssertEqual(
      VideoClipNaming.renamedFilename(requestedName: "Essai 5.mov", preservingExtensionOf: "source.mp4"),
      "Essai 5.mp4"
    )
  }

  func testRenameRejectsPathLikeNames() {
    XCTAssertNil(VideoClipNaming.renamedFilename(requestedName: "../video", preservingExtensionOf: "source.mov"))
    XCTAssertNil(VideoClipNaming.renamedFilename(requestedName: "folder/video", preservingExtensionOf: "source.mov"))
  }
}
