package com.tasnim.perchecamera

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.CameraOperationState
import com.tasnim.perchecamera.protocol.CameraState

class MainActivity : ComponentActivity() {
    companion object {
        private const val TAG = "PercheCamera"
        private const val CAMERA_PERMISSION_REQUEST = 1001
        private const val PREVIEW_START_TIMEOUT_MS = 10_000L
    }

    private lateinit var previewView: PreviewView
    private lateinit var versionView: TextView
    private lateinit var cameraPhaseView: TextView
    private lateinit var cameraReadinessView: TextView
    private lateinit var pinView: TextView
    private lateinit var stateView: TextView
    private lateinit var networkView: TextView
    private lateinit var ipadView: TextView
    private lateinit var pendingView: TextView
    private lateinit var errorView: TextView
    private lateinit var crashView: TextView
    private lateinit var copyCrashButton: Button
    private lateinit var recordingDurationView: TextView
    private lateinit var configDetailsView: TextView
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button
    private lateinit var requestCameraPermissionButton: Button
    private lateinit var cameraSpinner: Spinner
    private lateinit var resolutionSpinner: Spinner
    private lateinit var fpsSpinner: Spinner

    private val handler = Handler(Looper.getMainLooper())
    private var attachedService: CameraRecordingService? = null
    private var previewAttachStartedAtMs: Long? = null
    private var previewFailureReportedForAttachment = false
    private var availableConfigs: List<CameraConfiguration> = emptyList()
    private var controlsFingerprint: String? = null
    private var suppressControlCallbacks = false

    private val refresh = object : Runnable {
        override fun run() {
            val service = CompanionRuntime.service
            if (service != null) ensurePreviewAttached(service)

            val state = CompanionRuntime.stateMachine.state
            val diagnostics = service?.cameraDiagnostics()
            pinView.text = "Code d’appairage : ${CompanionRuntime.pairing.currentCode()}"

            val operationState = service?.cameraOperationState()
            stateView.text = "État : ${cameraStateLabel(operationState, state)}"

            cameraPhaseView.text = when {
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ->
                    "Autorisez l’accès à la caméra pour afficher l’aperçu et filmer."
                diagnostics == null || !diagnostics.providerReady -> "Initialisation caméra…"
                diagnostics.bindingInProgress || !diagnostics.cameraBound -> "Ouverture caméra…"
                diagnostics.previewSurfaceAttached && !diagnostics.previewActive -> "Ouverture caméra…"
                diagnostics.previewActive -> "Aperçu actif · Prêt"
                else -> "Caméra liée · aperçu suspendu"
            }

            cameraReadinessView.text = if (diagnostics == null) {
                "Caméra liée : non\nAperçu : inactif\nVideoCapture : non prêt"
            } else {
                "Caméra liée : ${yesNo(diagnostics.cameraBound)}\n" +
                    "Aperçu : ${if (diagnostics.previewActive) "actif" else "inactif"}\n" +
                    "VideoCapture : ${if (diagnostics.videoCaptureReady) "prêt" else "non prêt"}"
            }

            if (diagnostics != null) {
                refreshConfigurationControls(service, diagnostics.selectedConfiguration)
                maybeReportPreviewTimeout(service, diagnostics)
            }

            val network = service?.networkDiagnostics()
            networkView.text = if (network == null) {
                "Réseau : initialisation…"
            } else {
                "Réseau : ${network.ipv4Address ?: "adresse IPv4 indisponible"}\n" +
                    "Contrôle : ${network.controlPort}\n" +
                    "Transfert : ${network.transferPort}"
            }
            ipadView.text = if (network?.controlConnected == true) "iPad : connecté" else "iPad : en attente"

            val pending = service?.latestManifest()
            pendingView.text = if (pending == null) {
                "Vidéo en attente : aucune"
            } else {
                "Vidéo en attente de transfert · ${pending.durationSeconds.formatOneDecimal()} s · ${pending.transferState}"
            }

            val lastError = diagnostics?.bindingError ?: service?.lastErrorMessage()
            errorView.visibility = if (lastError.isNullOrBlank()) View.GONE else View.VISIBLE
            errorView.text = if (lastError.isNullOrBlank()) "" else "Dernière erreur :\n$lastError"

            val crashSummary = CameraDiagnosticStore.lastCrashSummary(this@MainActivity)
            crashView.visibility = if (crashSummary.isNullOrBlank()) View.GONE else View.VISIBLE
            copyCrashButton.visibility = crashView.visibility
            crashView.text = if (crashSummary.isNullOrBlank()) "" else "Dernier incident :\n$crashSummary"

            recordingDurationView.visibility = if (state == CameraState.RECORDING) View.VISIBLE else View.GONE
            recordingDurationView.text = service?.recordingElapsedSeconds()?.let { "Enregistrement · ${it}s" } ?: ""

            stopButton.visibility = if (state == CameraState.RECORDING || state == CameraState.STOPPING) View.VISIBLE else View.GONE
            stopButton.isEnabled = state == CameraState.RECORDING
            stopButton.text = if (state == CameraState.STOPPING) "Finalisation…" else "Arrêter l’enregistrement"

            resetButton.visibility = if (state == CameraState.ERROR) View.VISIBLE else View.GONE
            requestCameraPermissionButton.visibility =
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) View.GONE else View.VISIBLE

            val keepAwake = state == CameraState.RECORDING || state == CameraState.STOPPING
            if (keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            val refreshDelayMs = if (keepAwake || operationState == CameraOperationState.STARTING_RECORDING || operationState == CameraOperationState.RECONFIGURING) 250L else 1_000L
            handler.postDelayed(this, refreshDelayMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

        val titleView = TextView(this).apply {
            text = "Perche Camera Companion"
            textSize = if (landscape) 24f else 28f
        }
        versionView = TextView(this).apply {
            text = "Version 15.0.7 (150007)"
            textSize = 14f
            setPadding(0, dp(4), 0, dp(10))
        }

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            contentDescription = "Aperçu caméra Pixel"
        }

        cameraPhaseView = TextView(this).apply { textSize = 19f; setPadding(0, dp(8), 0, dp(6)) }
        cameraReadinessView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(10)) }
        requestCameraPermissionButton = Button(this).apply {
            text = "Autoriser la caméra"
            visibility = View.GONE
            setOnClickListener { requestCameraPermission() }
        }

        cameraSpinner = Spinner(this)
        resolutionSpinner = Spinner(this)
        fpsSpinner = Spinner(this)
        configDetailsView = TextView(this).apply {
            textSize = 13f
            setPadding(0, 0, 0, dp(14))
        }

        pinView = TextView(this).apply { textSize = 22f; setPadding(0, dp(12), 0, dp(10)) }
        stateView = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, dp(8)) }
        networkView = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(8)) }
        ipadView = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(8)) }
        pendingView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(8)) }
        recordingDurationView = TextView(this).apply { textSize = 22f; visibility = View.GONE; setPadding(0, dp(8), 0, dp(8)) }
        errorView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(10)) }
        crashView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(8)); visibility = View.GONE }
        copyCrashButton = Button(this).apply {
            text = "Copier le diagnostic"
            visibility = View.GONE
            setOnClickListener {
                val text = CameraDiagnosticStore.crashDiagnosticText(this@MainActivity) ?: return@setOnClickListener
                val clipboard = getSystemService(ClipboardManager::class.java)
                clipboard.setPrimaryClip(ClipData.newPlainText("Perche Camera diagnostic", text))
            }
        }
        stopButton = Button(this).apply {
            text = "Arrêter l’enregistrement"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.requestStopFromPixel()?.whenComplete { _, error ->
                    if (error != null) runOnUiThread {
                        errorView.visibility = View.VISIBLE
                        errorView.text = "Dernière erreur :\n${error.message ?: "Finalisation impossible."}"
                    }
                }
            }
        }
        resetButton = Button(this).apply {
            text = "Réinitialiser la caméra"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.resetCamera()?.whenComplete { _, _ ->
                    runOnUiThread {
                        isEnabled = true
                        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
                        previewFailureReportedForAttachment = false
                    }
                }
            }
        }

        val previewColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            addView(titleView, fullWidthParams())
            addView(versionView, fullWidthParams())
            addView(
                previewView,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (landscape) 0 else dp(250)).apply {
                    if (landscape) weight = 1f
                    bottomMargin = dp(8)
                },
            )
            addView(cameraPhaseView, fullWidthParams())
            addView(cameraReadinessView, fullWidthParams())
            addView(requestCameraPermissionButton, fullWidthParams())
        }

        val controlsColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(20))
        }
        addSectionTitle(controlsColumn, "Caméra")
        controlsColumn.addView(cameraSpinner, fullWidthParams())
        addSectionTitle(controlsColumn, "Résolution")
        controlsColumn.addView(resolutionSpinner, fullWidthParams())
        addSectionTitle(controlsColumn, "Fréquence")
        controlsColumn.addView(fpsSpinner, fullWidthParams())
        controlsColumn.addView(configDetailsView, fullWidthParams())
        controlsColumn.addView(pinView)
        controlsColumn.addView(stateView)
        controlsColumn.addView(networkView)
        controlsColumn.addView(ipadView)
        controlsColumn.addView(pendingView)
        controlsColumn.addView(recordingDurationView)
        controlsColumn.addView(errorView)
        controlsColumn.addView(crashView)
        controlsColumn.addView(copyCrashButton)
        controlsColumn.addView(stopButton)
        controlsColumn.addView(resetButton)
        controlsColumn.addView(TextView(this).apply {
            text = "Le fichier maître reste conservé sur ce Pixel après finalisation et transfert. Aucun cloud n’est requis."
            textSize = 14f
            setPadding(0, dp(14), 0, 0)
        })

        if (landscape) {
            val controlsScroll = ScrollView(this).apply { addView(controlsColumn) }
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(previewColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.35f))
                addView(controlsScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            setContentView(root)
        } else {
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(previewColumn, fullWidthParams())
                addView(controlsColumn, fullWidthParams())
            }
            val scroll = ScrollView(this).apply { addView(content) }
            setContentView(scroll)
        }

        bindControlListeners()
        previewView.previewStreamState.observe(this) { streamState ->
            val active = streamState == PreviewView.StreamState.STREAMING
            CompanionRuntime.service?.setPreviewStreaming(active)
            if (active) {
                previewAttachStartedAtMs = null
                previewFailureReportedForAttachment = false
                Log.i(TAG, "PreviewView reports STREAMING")
            } else {
                Log.i(TAG, "PreviewView reports IDLE")
            }
        }
        requestPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        CompanionRuntime.service?.let { service ->
            previewView.display?.rotation?.let(service::updateTargetRotation)
        }
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        attachedService?.detachPreviewSurface()
        attachedService?.releaseCameraIfIdleAndUnpaired()
        attachedService = null
        previewAttachStartedAtMs = null
        previewFailureReportedForAttachment = false
        super.onPause()
    }

    private fun requestPermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraService()
            return
        }
        requestCameraPermission()
    }

    private fun requestCameraPermission() {
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 37) permissions += "android.permission.ACCESS_LOCAL_NETWORK"
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), CAMERA_PERMISSION_REQUEST)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CAMERA_PERMISSION_REQUEST -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "Camera permission granted")
                    startCameraService()
                } else {
                    Log.w(TAG, "Camera permission denied")
                    cameraPhaseView.text = "Autorisez l’accès à la caméra pour afficher l’aperçu et filmer."
                }
            }
        }
    }

    private fun startCameraService() {
        val intent = Intent(this, CameraRecordingService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun ensurePreviewAttached(service: CameraRecordingService) {
        if (attachedService === service) return
        attachedService?.detachPreviewSurface()
        attachedService = service
        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
        previewFailureReportedForAttachment = false
        service.attachPreviewSurface(previewView.surfaceProvider)
        previewView.display?.rotation?.let(service::updateTargetRotation)
        Log.i(TAG, "Preview surface attached to CameraRecordingService")
    }

    private fun maybeReportPreviewTimeout(service: CameraRecordingService, diagnostics: CameraRecordingService.CameraDiagnostics) {
        if (diagnostics.previewActive) {
            previewAttachStartedAtMs = null
            previewFailureReportedForAttachment = false
            return
        }
        val started = previewAttachStartedAtMs ?: return
        if (!diagnostics.previewSurfaceAttached || !diagnostics.cameraBound || diagnostics.bindingInProgress) return
        if (CompanionRuntime.stateMachine.state == CameraState.RECORDING || CompanionRuntime.stateMachine.state == CameraState.STOPPING) return
        if (!previewFailureReportedForAttachment && SystemClock.elapsedRealtime() - started >= PREVIEW_START_TIMEOUT_MS) {
            previewFailureReportedForAttachment = true
            service.reportPreviewFailure("L’aperçu CameraX n’a produit aucune image après 10 secondes.")
        }
    }

    private fun bindControlListeners() {
        cameraSpinner.onItemSelectedListener = selectionListener { onCameraChanged() }
        resolutionSpinner.onItemSelectedListener = selectionListener { onResolutionChanged() }
        fpsSpinner.onItemSelectedListener = selectionListener { applyControlSelection() }
    }

    private fun selectionListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (!suppressControlCallbacks) action()
        }
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
    }

    private fun refreshConfigurationControls(service: CameraRecordingService, selected: CameraConfiguration?) {
        val configs = service.configurations()
        if (configs.isEmpty()) return
        val current = selected ?: configs.first()
        val fingerprint = buildString {
            append(configs.joinToString("|") { it.id })
            append('#').append(current.id)
        }
        if (fingerprint == controlsFingerprint) return
        availableConfigs = configs
        controlsFingerprint = fingerprint
        syncControlsFrom(current)
    }

    private fun syncControlsFrom(config: CameraConfiguration) {
        suppressControlCallbacks = true
        try {
            val cameraNames = availableConfigs.map { it.lensLabel }.distinct()
            setSpinner(cameraSpinner, cameraNames, config.lensLabel)

            val resolutions = availableConfigs
                .filter { it.lensLabel == config.lensLabel }
                .map { "${it.width} × ${it.height}" }
                .distinct()
            setSpinner(resolutionSpinner, resolutions, "${config.width} × ${config.height}")

            val fpsValues = availableConfigs
                .filter { it.lensLabel == config.lensLabel && it.width == config.width && it.height == config.height }
                .map { "${it.fps} i/s" }
                .distinct()
            setSpinner(fpsSpinner, fpsValues, "${config.fps} i/s")

            configDetailsView.text = "Détails techniques · ID caméra ${config.id.substringBefore('|')} · configuration ${config.id}"
        } finally {
            suppressControlCallbacks = false
        }
    }

    private fun onCameraChanged() {
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val candidates = availableConfigs.filter { it.lensLabel == lens }
        if (candidates.isEmpty()) return
        val preferred = candidates.firstOrNull { it.width == 1280 && it.height == 720 && it.fps == 30 }
            ?: candidates.firstOrNull { it.fps == 30 }
            ?: candidates.first()
        syncControlsFrom(preferred.copy(audioEnabled = false, stabilizationEnabled = false))
        applyControlSelection()
    }

    private fun onResolutionChanged() {
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val resolution = resolutionSpinner.selectedItem?.toString() ?: return
        val (width, height) = parseResolution(resolution) ?: return
        val candidates = availableConfigs.filter { it.lensLabel == lens && it.width == width && it.height == height }
        if (candidates.isEmpty()) return
        val preferred = candidates.firstOrNull { it.fps == 30 } ?: candidates.first()
        suppressControlCallbacks = true
        try {
            setSpinner(fpsSpinner, candidates.map { "${it.fps} i/s" }.distinct(), "${preferred.fps} i/s")
        } finally {
            suppressControlCallbacks = false
        }
        applyControlSelection()
    }

    private fun applyControlSelection() {
        val service = CompanionRuntime.service ?: return
        if (availableConfigs.isEmpty()) return
        val lens = cameraSpinner.selectedItem?.toString() ?: return
        val resolution = resolutionSpinner.selectedItem?.toString() ?: return
        val (width, height) = parseResolution(resolution) ?: return
        val fps = fpsSpinner.selectedItem?.toString()?.substringBefore(' ')?.toIntOrNull() ?: return
        val base = availableConfigs.firstOrNull {
            it.lensLabel == lens && it.width == width && it.height == height && it.fps == fps
        } ?: return
        val requested = base.copy(
            audioEnabled = false,
            stabilizationEnabled = false,
        )
        previewAttachStartedAtMs = SystemClock.elapsedRealtime()
        previewFailureReportedForAttachment = false
        service.configureCamera(requested).whenComplete { _, error ->
            if (error != null) runOnUiThread {
                errorView.visibility = View.VISIBLE
                errorView.text = "Dernière erreur :\n${error.message ?: "Configuration caméra impossible."}"
            }
        }
    }

    private fun setSpinner(spinner: Spinner, values: List<String>, selected: String) {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, values).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val index = values.indexOf(selected).takeIf { it >= 0 } ?: 0
        spinner.setSelection(index, false)
    }

    private fun parseResolution(value: String): Pair<Int, Int>? {
        val parts = value.replace(" ", "").split('×')
        if (parts.size != 2) return null
        val width = parts[0].toIntOrNull() ?: return null
        val height = parts[1].toIntOrNull() ?: return null
        return width to height
    }

    private fun addSectionTitle(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setPadding(0, dp(8), 0, dp(2))
        }, fullWidthParams())
    }

    private fun fullWidthParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun cameraStateLabel(operation: CameraOperationState?, remote: CameraState): String = when (operation) {
        CameraOperationState.INITIALIZING -> "initialisation caméra…"
        CameraOperationState.RECONFIGURING -> "reconfiguration caméra…"
        CameraOperationState.STARTING_RECORDING -> "démarrage enregistrement…"
        CameraOperationState.RECORDING -> "enregistrement"
        CameraOperationState.FINALIZING -> "finalisation…"
        CameraOperationState.ERROR -> "erreur"
        CameraOperationState.READY -> when (remote) {
            CameraState.TRANSFERRING -> "transfert…"
            CameraState.ERROR -> "erreur"
            else -> "prêt"
        }
        null -> when (remote) {
            CameraState.STOPPING -> "finalisation…"
            CameraState.ERROR -> "erreur"
            else -> remote.name.lowercase()
        }
    }

    private fun yesNo(value: Boolean) = if (value) "oui" else "non"

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun Double.formatOneDecimal(): String = String.format(java.util.Locale.FRANCE, "%.1f", this)
}
