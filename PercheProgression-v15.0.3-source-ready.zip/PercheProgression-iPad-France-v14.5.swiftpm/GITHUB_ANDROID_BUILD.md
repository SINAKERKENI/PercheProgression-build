# Build Android v15.0.3 avec GitHub Actions

1. Ouvrez le dépôt GitHub utilisé pour le build Android.
2. Supprimez/remplacez l’ancien ZIP de checkpoint.
3. Ajoutez `PercheProgression-v15.0.3-source-ready.zip` à la racine du dépôt puis validez le commit.
4. Remplacez aussi `.github/workflows/build-pixel-apk.yml` par la version fournie dans ce checkpoint si le dépôt GitHub contient encore une version antérieure du workflow.
5. Ouvrez **Actions** → **Build Perche Camera Companion** → **Run workflow**.
6. Le workflow vérifie les correctifs CameraX et le cycle v15.0.3 puis compile la source **sans la réécrire**.
7. Téléchargez l’artifact **PercheProgression-v15.0.3-Android-Build**.
8. Installez `PercheCameraCompanion-v15.0.3-debug.apk` sur le Pixel sans effacer les données de l’application existante si l’APK est compatible avec la signature installée.

Commande de build CI :

```text
gradle clean :app:assembleDebug --stacktrace --warning-mode all
```

Environnement attendu : Java 17, Gradle 9.6.0, Android API 37. Le workflow ne contient aucun `sed`, script Python ou autre étape qui corrige `CameraRecordingService.kt` avant compilation : le code production doit compiler tel qu’il est stocké.

> Important : ne désinstallez pas l’application Pixel actuelle tant qu’une vidéo maître importante y est conservée. Un changement de signature de l’APK debug peut empêcher une mise à jour directe ; dans ce cas récupérez d’abord les enregistrements existants.
