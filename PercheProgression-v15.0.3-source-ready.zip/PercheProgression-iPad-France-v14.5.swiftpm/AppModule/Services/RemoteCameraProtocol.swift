import Foundation

struct RemoteCameraResolvedAddress: Equatable, Sendable {
  enum Family: Equatable, Sendable { case ipv4, ipv6 }
  let family: Family
  let address: String
}

enum RemoteCameraEndpointSelection {
  static func preferredHost(
    numericAddresses: [RemoteCameraResolvedAddress],
    fallbackHost: String?
  ) -> String? {
    if let ipv4 = numericAddresses.first(where: { $0.family == .ipv4 && !$0.address.isEmpty }) {
      return ipv4.address
    }
    if let ipv6 = numericAddresses.first(where: { $0.family == .ipv6 && !$0.address.isEmpty }) {
      return ipv6.address
    }
    let fallback = fallbackHost?.trimmingCharacters(in: .whitespacesAndNewlines)
    return (fallback?.isEmpty == false) ? fallback : nil
  }
}

struct RemoteCameraEndpoint: Identifiable, Equatable, Sendable {
  var id: String { "\(host):\(controlPort)" }
  let name: String
  let host: String
  let controlPort: Int
  let transferPort: Int
  let deviceID: String
}

enum RemoteCameraState: String, Codable, Sendable {
  case disconnected, connecting, ready, recording, stopping, transferring, imported, error

  var title: String {
    switch self {
    case .disconnected: "Déconnecté"
    case .connecting: "Connexion…"
    case .ready: "Prêt"
    case .recording: "Enregistrement"
    case .stopping: "Finalisation…"
    case .transferring: "Transfert…"
    case .imported: "Importé"
    case .error: "Erreur"
    }
  }
}

struct RemoteCameraConfiguration: Codable, Identifiable, Hashable, Sendable {
  let id: String
  let lensLabel: String
  let width: Int
  let height: Int
  let fps: Int
  let stabilizationSupported: Bool
  var stabilizationEnabled: Bool
  var audioEnabled: Bool

  var displayName: String { "\(lensLabel) · \(width)×\(height) · \(fps) i/s" }
}

struct RemoteRecordingManifest: Codable, Equatable, Sendable {
  let recordingID: String
  let filename: String
  let sizeBytes: Int64
  let sha256: String
  let createdAtISO8601: String
  let durationSeconds: Double
  let width: Int
  let height: Int
  let nominalFPS: Double
  let lensLabel: String
  let orientation: String
  let transferPath: String
  /// Added in v15.0.3. Optional keeps compatibility with manifests produced by older companions.
  let finalizedAtISO8601: String?
  let transferState: String?

  var createdAt: Date? { ISO8601DateFormatter().date(from: createdAtISO8601) }
  var finalizedAt: Date? {
    guard let finalizedAtISO8601 else { return nil }
    return ISO8601DateFormatter().date(from: finalizedAtISO8601)
  }
}

struct RemoteControlRequest: Codable, Sendable {
  let id: UUID
  let type: String
  let token: String?
  let pairingCode: String?
  let clientID: String?
  let config: RemoteCameraConfiguration?
  let recordingID: String?

  init(
    type: String,
    token: String? = nil,
    pairingCode: String? = nil,
    clientID: String? = nil,
    config: RemoteCameraConfiguration? = nil,
    recordingID: String? = nil
  ) {
    self.id = UUID()
    self.type = type
    self.token = token
    self.pairingCode = pairingCode
    self.clientID = clientID
    self.config = config
    self.recordingID = recordingID
  }
}

struct RemoteControlResponse: Codable, Sendable {
  let id: UUID?
  let type: String
  let ok: Bool
  let token: String?
  let state: RemoteCameraState?
  let message: String?
  let configs: [RemoteCameraConfiguration]?
  let manifest: RemoteRecordingManifest?
  let recordingStartedAtMonotonicNanos: Int64?
}

enum RemoteRecordingIdentity {
  static func shouldImport(recordingID: String, existingRemoteIDs: Set<String>) -> Bool {
    !recordingID.isEmpty && !existingRemoteIDs.contains(recordingID)
  }
}

enum RemoteTransferResumePolicy {
  static func resumeOffset(existingBytes: Int64, expectedBytes: Int64) -> Int64 {
    guard expectedBytes > 0, existingBytes > 0, existingBytes <= expectedBytes else { return 0 }
    return existingBytes
  }
}

enum RemoteCameraError: LocalizedError {
  case notPaired
  case notConnected
  case invalidResponse
  case rejected(String)
  case checksumMismatch
  case invalidTransferResponse
  case incompleteTransfer(expected: Int64, actual: Int64)
  case duplicateRecording
  case connectionFailed(host: String, port: Int, detail: String?)
  case connectionCancelled(host: String, port: Int)
  case controlChannelFailed(String)
  case requestTimedOut(String)
  case invalidRemoteFilename(String)
  case finalizedRecordingUnavailable

  var errorDescription: String? {
    switch self {
    case .notPaired: "La caméra distante doit être appairée avant cette action."
    case .notConnected: "La caméra Pixel n’est pas connectée."
    case .invalidResponse: "La réponse de la caméra distante est invalide."
    case .rejected(let message): message
    case .checksumMismatch: "Le contrôle SHA-256 du fichier transféré a échoué. La vidéo corrompue n’a pas été importée."
    case .invalidTransferResponse: "Le serveur de transfert a renvoyé une réponse inattendue."
    case .incompleteTransfer(let expected, let actual): "Transfert incomplet (\(actual) octets reçus sur \(expected))."
    case .duplicateRecording: "Cet enregistrement distant a déjà été importé."
    case .connectionFailed(let host, let port, _): "Connexion TCP impossible vers \(host):\(port)."
    case .connectionCancelled(let host, let port): "Connexion TCP annulée vers \(host):\(port)."
    case .controlChannelFailed: "La liaison de contrôle avec le Pixel a été interrompue."
    case .requestTimedOut(let operation): "Le Pixel n’a pas répondu à temps pendant « \(operation) ». Vérification de son état en cours."
    case .invalidRemoteFilename(let filename): "Le nom de fichier distant « \(filename) » n’est pas un média vidéo accepté."
    case .finalizedRecordingUnavailable: "Le Pixel est revenu à l’état prêt sans fournir de vidéo finalisée. L’enregistrement reste conservé sur le téléphone s’il existe."
    }
  }
}
