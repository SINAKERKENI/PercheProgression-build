// swift-tools-version: 5.10

import PackageDescription
import AppleProductTypes

let package = Package(
  name: "PercheProgressionV14_5",
  platforms: [
    .iOS("18.0")
  ],
  products: [
    .iOSApplication(
      name: "Perche Progression",
      targets: ["AppModule"],
      bundleIdentifier: "com.tasnim.vaultroadmap.ipad",
      displayVersion: "15.0.3",
      bundleVersion: "36",
      appIcon: .asset("AppIcon"),
      accentColor: .asset("AccentColor"),
      supportedDeviceFamilies: [
        .pad
      ],
      supportedInterfaceOrientations: [
        .portrait,
        .landscapeRight,
        .landscapeLeft,
        .portraitUpsideDown(.when(deviceFamilies: [.pad]))
      ],
      additionalInfoPlistContentFilePath: "AppModule/Supporting/AppInfo.plist"
    )
  ],
  targets: [
    .executableTarget(
      name: "AppModule",
      path: "AppModule",
      exclude: [
        "Supporting/AppInfo.plist"
      ],
      resources: [
        .process("Resources")
      ]
    ),
    .testTarget(
      name: "AppModuleTests",
      dependencies: ["AppModule"],
      path: "Tests",
      resources: [
        .process("Fixtures")
      ]
    )
  ]
)
