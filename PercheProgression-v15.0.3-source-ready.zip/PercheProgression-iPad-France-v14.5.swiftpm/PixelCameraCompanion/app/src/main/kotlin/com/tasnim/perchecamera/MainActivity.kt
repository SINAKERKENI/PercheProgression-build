package com.tasnim.perchecamera

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.tasnim.perchecamera.protocol.CameraState

class MainActivity : Activity() {
    private lateinit var pinView: TextView
    private lateinit var stateView: TextView
    private lateinit var networkView: TextView
    private lateinit var ipadView: TextView
    private lateinit var pendingView: TextView
    private lateinit var errorView: TextView
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            val state = CompanionRuntime.stateMachine.state
            pinView.text = "Code d’appairage : ${CompanionRuntime.pairing.currentCode()}"
            stateView.text = when (state) {
                CameraState.STOPPING -> "État : finalisation…"
                else -> "État : ${state.name.lowercase()}"
            }
            val diagnostics = CompanionRuntime.service?.networkDiagnostics()
            networkView.text = if (diagnostics == null) {
                "Réseau : initialisation…"
            } else {
                "Réseau : ${diagnostics.ipv4Address ?: "adresse IPv4 indisponible"}\n" +
                    "Contrôle : ${diagnostics.controlPort}\n" +
                    "Transfert : ${diagnostics.transferPort}"
            }
            ipadView.text = if (diagnostics?.controlConnected == true) "iPad : connecté" else "iPad : en attente"

            val pending = CompanionRuntime.service?.latestManifest()
            pendingView.text = if (pending == null) {
                "Vidéo en attente : aucune"
            } else {
                "Vidéo en attente de transfert · ${pending.durationSeconds.formatOneDecimal()} s · ${pending.transferState}"
            }

            val lastError = CompanionRuntime.service?.lastErrorMessage()
            errorView.visibility = if (lastError.isNullOrBlank()) View.GONE else View.VISIBLE
            errorView.text = if (lastError.isNullOrBlank()) "" else "Dernière erreur :\n$lastError"

            stopButton.visibility = if (state == CameraState.RECORDING || state == CameraState.STOPPING) View.VISIBLE else View.GONE
            stopButton.isEnabled = state == CameraState.RECORDING
            stopButton.text = if (state == CameraState.STOPPING) "Finalisation…" else "Arrêter l’enregistrement"

            resetButton.visibility = if (state == CameraState.ERROR) View.VISIBLE else View.GONE
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 80, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Perche Camera Companion"
            textSize = 28f
        })
        pinView = TextView(this).apply { textSize = 24f; setPadding(0, 48, 0, 24) }
        stateView = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, 18) }
        networkView = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, 18) }
        ipadView = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, 18) }
        pendingView = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, 18) }
        errorView = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, 18) }
        stopButton = Button(this).apply {
            text = "Arrêter l’enregistrement"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.requestStopFromPixel()?.whenComplete { _, error ->
                    if (error != null) runOnUiThread {
                        errorView.visibility = View.VISIBLE
                        errorView.text = "Dernière erreur :\n${error.message ?: "Finalisation impossible."}"
                    }
                }
            }
        }
        resetButton = Button(this).apply {
            text = "Réinitialiser la caméra"
            visibility = View.GONE
            setOnClickListener {
                isEnabled = false
                CompanionRuntime.service?.resetCamera()?.whenComplete { _, _ ->
                    runOnUiThread { isEnabled = true }
                }
            }
        }

        root.addView(pinView)
        root.addView(stateView)
        root.addView(networkView)
        root.addView(ipadView)
        root.addView(pendingView)
        root.addView(errorView)
        root.addView(stopButton)
        root.addView(resetButton)
        root.addView(TextView(this).apply {
            text = "Le fichier maître reste conservé sur ce Pixel après finalisation et transfert. Aucun cloud n’est requis."
            textSize = 16f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
        requestPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 37) permissions += "android.permission.ACCESS_LOCAL_NETWORK"
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startCameraService()
        else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraService()
        } else {
            stateView.text = "Autorisation caméra requise. Ouvrez les réglages de l’application."
        }
    }

    private fun startCameraService() {
        val intent = Intent(this, CameraRecordingService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun Double.formatOneDecimal(): String = String.format(java.util.Locale.FRANCE, "%.1f", this)
}
