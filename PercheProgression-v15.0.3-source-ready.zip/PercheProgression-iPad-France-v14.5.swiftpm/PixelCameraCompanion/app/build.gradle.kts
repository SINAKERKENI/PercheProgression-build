plugins { id("com.android.application") }

android {
    namespace = "com.tasnim.perchecamera"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.tasnim.perchecamera"
        minSdk = 28
        targetSdk = 37
        versionCode = 150003
        versionName = "15.0.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(project(":protocol"))
    implementation("androidx.activity:activity-ktx:1.13.0")
    implementation("androidx.lifecycle:lifecycle-service:2.11.0")
    implementation("androidx.camera:camera-core:1.6.2")
    implementation("androidx.camera:camera-camera2:1.6.2")
    implementation("androidx.camera:camera-lifecycle:1.6.2")
    implementation("androidx.camera:camera-video:1.6.2")
}
