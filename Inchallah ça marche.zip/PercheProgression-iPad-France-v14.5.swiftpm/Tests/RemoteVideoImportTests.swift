import CryptoKit
import Foundation
import XCTest
@testable import AppModule

final class RemoteVideoImportTests: XCTestCase {
  private func temporaryDirectory() throws -> URL {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("PercheRemoteVideoTests-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func fixtureURL() throws -> URL {
    guard let url = Bundle.module.url(forResource: "valid-remote", withExtension: "mp4") else {
      throw XCTSkip("Fixture valid-remote.mp4 unavailable")
    }
    return url
  }

  private func sha256(_ url: URL) throws -> String {
    let data = try Data(contentsOf: url)
    return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
  }

  func testPartialImportedWithPreferredMP4BecomesMP4() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let source = root.appendingPathComponent("recording.partial")
    try FileManager.default.copyItem(at: try fixtureURL(), to: source)
    let store = VideoAssetStore(rootDirectoryOverride: root.appendingPathComponent("Media"))

    let imported = try await store.importVideo(from: source, preferredFileExtension: "mp4")
    XCTAssertEqual(imported.url.pathExtension, "mp4")
    XCTAssertTrue(imported.storageKey.hasSuffix("/source.mp4"))
    _ = try await store.validatePlayableVideo(at: imported.url)
  }

  func testInvalidPreferredExtensionIsRejected() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let source = root.appendingPathComponent("recording.partial")
    try Data([0, 1, 2]).write(to: source)
    let store = VideoAssetStore(rootDirectoryOverride: root.appendingPathComponent("Media"))

    do {
      _ = try await store.importVideo(from: source, preferredFileExtension: "../exe")
      XCTFail("Expected invalid extension to be rejected")
    } catch VideoStoreError.invalidMediaExtension {
      // expected
    }
  }

  func testNormalMP4ImportRemainsMP4() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let mp4 = root.appendingPathComponent("normal.mp4")
    try FileManager.default.copyItem(at: try fixtureURL(), to: mp4)
    let store = VideoAssetStore(rootDirectoryOverride: root.appendingPathComponent("Media"))

    XCTAssertEqual(try await store.importVideo(from: mp4).url.pathExtension, "mp4")
  }

  func testNormalMOVImportRemainsMOV() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let mov = root.appendingPathComponent("normal.mov")
    try FileManager.default.copyItem(at: try fixtureURL(), to: mov)
    let store = VideoAssetStore(rootDirectoryOverride: root.appendingPathComponent("Media"))

    XCTAssertEqual(try await store.importVideo(from: mov).url.pathExtension, "mov")
  }

  func testLegacyPartialRepairPreservesSHAAndLeavesOriginalUntilCommit() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let mediaRoot = root.appendingPathComponent("Media")
    let legacyDir = mediaRoot.appendingPathComponent("legacy", isDirectory: true)
    try FileManager.default.createDirectory(at: legacyDir, withIntermediateDirectories: true)
    let legacy = legacyDir.appendingPathComponent("source.partial")
    try FileManager.default.copyItem(at: try fixtureURL(), to: legacy)
    let expected = try sha256(legacy)
    let store = VideoAssetStore(rootDirectoryOverride: mediaRoot)

    let repaired = try await store.prepareLegacyRemoteRepair(
      storageKey: "legacy/source.partial",
      preferredFileExtension: "mp4",
      expectedSHA256: expected
    )

    XCTAssertEqual(repaired.sha256?.lowercased(), expected.lowercased())
    XCTAssertTrue(FileManager.default.fileExists(atPath: legacy.path), "Original .partial must survive until persistence commits")
    XCTAssertEqual(repaired.url.pathExtension, "mp4")
    _ = try await store.validatePlayableVideo(at: repaired.url)
  }

  func testRepairFailureNeverDeletesOriginalPartial() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let mediaRoot = root.appendingPathComponent("Media")
    let legacyDir = mediaRoot.appendingPathComponent("legacy", isDirectory: true)
    try FileManager.default.createDirectory(at: legacyDir, withIntermediateDirectories: true)
    let legacy = legacyDir.appendingPathComponent("source.partial")
    try Data("not a movie".utf8).write(to: legacy)
    let store = VideoAssetStore(rootDirectoryOverride: mediaRoot)

    do {
      _ = try await store.prepareLegacyRemoteRepair(
        storageKey: "legacy/source.partial",
        preferredFileExtension: "mp4",
        expectedSHA256: try sha256(legacy)
      )
      XCTFail("Unreadable media must not be accepted")
    } catch {
      XCTAssertTrue(FileManager.default.fileExists(atPath: legacy.path))
      XCTAssertEqual(try Data(contentsOf: legacy), Data("not a movie".utf8))
    }
  }

  func testUnreadableAssetIsRejectedBeforeClipPersistenceBoundary() async throws {
    let root = try temporaryDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let invalid = root.appendingPathComponent("invalid.mp4")
    try Data("invalid mp4".utf8).write(to: invalid)
    let store = VideoAssetStore(rootDirectoryOverride: root.appendingPathComponent("Media"))
    let imported = try await store.importVideo(from: invalid)

    do {
      _ = try await store.validatePlayableVideo(at: imported.url)
      XCTFail("Unreadable AVAsset must be rejected before a VideoClipRecord is inserted")
    } catch {
      XCTAssertTrue(FileManager.default.fileExists(atPath: imported.url.path))
    }
  }

  func testDuplicateRemoteRecordingIdentityDoesNotImportTwice() {
    let existing: Set<String> = ["remote-123"]
    XCTAssertFalse(RemoteRecordingIdentity.shouldImport(recordingID: "remote-123", existingRemoteIDs: existing))
    XCTAssertTrue(RemoteRecordingIdentity.shouldImport(recordingID: "remote-456", existingRemoteIDs: existing))
  }

  func testInterruptedTransferResumeOffset() {
    XCTAssertEqual(RemoteTransferResumePolicy.resumeOffset(existingBytes: 400, expectedBytes: 1_000), 400)
    XCTAssertEqual(RemoteTransferResumePolicy.resumeOffset(existingBytes: 1_100, expectedBytes: 1_000), 0)
    XCTAssertEqual(RemoteTransferResumePolicy.resumeOffset(existingBytes: 0, expectedBytes: 1_000), 0)
  }

  func testRemoteFilenameRejectsTraversalAndAcceptsMP4() throws {
    XCTAssertEqual(try VideoAssetStore.preferredVideoExtension(fromRemoteFilename: "abc.mp4"), "mp4")
    XCTAssertThrowsError(try VideoAssetStore.preferredVideoExtension(fromRemoteFilename: "../abc.mp4"))
    XCTAssertThrowsError(try VideoAssetStore.preferredVideoExtension(fromRemoteFilename: "abc.partial"))
  }
}
