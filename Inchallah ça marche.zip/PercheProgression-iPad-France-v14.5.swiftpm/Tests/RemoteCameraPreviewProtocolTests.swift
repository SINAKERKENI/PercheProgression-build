import XCTest
@testable import AppModule

final class RemoteCameraPreviewProtocolTests: XCTestCase {
  func testStatusDecodesCameraReadinessAndPreviewState() throws {
    let json = #"{"id":null,"type":"status","ok":true,"token":null,"state":"ready","message":null,"configs":null,"manifest":null,"recordingStartedAtMonotonicNanos":null,"cameraReady":true,"previewActive":true,"selectedConfigurationID":"0|HD|30"}"#
    let response = try JSONDecoder().decode(RemoteControlResponse.self, from: Data(json.utf8))
    XCTAssertEqual(response.cameraReady, true)
    XCTAssertEqual(response.previewActive, true)
    XCTAssertEqual(response.selectedConfigurationID, "0|HD|30")
  }

  func testOlderStatusWithoutPreviewFieldsRemainsDecodable() throws {
    let json = #"{"id":null,"type":"status","ok":true,"token":null,"state":"ready","message":null,"configs":null,"manifest":null,"recordingStartedAtMonotonicNanos":null}"#
    let response = try JSONDecoder().decode(RemoteControlResponse.self, from: Data(json.utf8))
    XCTAssertNil(response.cameraReady)
    XCTAssertNil(response.previewActive)
    XCTAssertNil(response.selectedConfigurationID)
  }
}
