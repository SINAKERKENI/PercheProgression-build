import XCTest
@testable import AppModule

final class RemoteCameraEndpointSelectionTests: XCTestCase {
  func testPrefersIPv4WhenIPv4AndIPv6AreAvailable() {
    let host = RemoteCameraEndpointSelection.preferredHost(
      numericAddresses: [
        .init(family: .ipv6, address: "fe80::1234%en0"),
        .init(family: .ipv4, address: "192.168.1.42")
      ],
      fallbackHost: "pixel.local"
    )
    XCTAssertEqual(host, "192.168.1.42")
  }

  func testUsesIPv6WhenItIsTheOnlyNumericAddress() {
    let host = RemoteCameraEndpointSelection.preferredHost(
      numericAddresses: [.init(family: .ipv6, address: "fe80::1234%en0")],
      fallbackHost: "pixel.local"
    )
    XCTAssertEqual(host, "fe80::1234%en0")
  }

  func testFallsBackToHostnameWhenNoNumericAddressExists() {
    let host = RemoteCameraEndpointSelection.preferredHost(
      numericAddresses: [],
      fallbackHost: "pixel.local"
    )
    XCTAssertEqual(host, "pixel.local")
  }

  func testInvalidSockaddrDataIsIgnored() {
    XCTAssertNil(RemoteCameraSockaddrParser.numericIPAddress(from: Data([0x01, 0x02, 0x03])))
  }

  func testEndpointRetainsControlAndTransferPorts() {
    let endpoint = RemoteCameraEndpoint(
      name: "Perche Pixel",
      host: "192.168.1.42",
      controlPort: 41837,
      transferPort: 46312,
      deviceID: "pixel-test"
    )
    XCTAssertEqual(endpoint.controlPort, 41837)
    XCTAssertEqual(endpoint.transferPort, 46312)
  }
}
