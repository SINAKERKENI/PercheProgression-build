import AVFoundation
import CryptoKit
import Foundation

enum VideoStoreError: LocalizedError {
  case missingFile
  case invalidStorageKey
  case invalidSource
  case invalidMediaExtension(String)
  case unreadableMedia(String)
  case checksumMismatch
  case legacyRepairNotApplicable

  var errorDescription: String? {
    switch self {
    case .missingFile:
      return "Le fichier vidéo associé à ce projet est introuvable."
    case .invalidStorageKey:
      return "La référence locale de cette vidéo est invalide."
    case .invalidSource:
      return "Le fichier sélectionné n’est pas une vidéo locale lisible. Téléchargez-le dans Fichiers puis réessayez."
    case .invalidMediaExtension(let value):
      return "Le format vidéo « \(value) » n’est pas accepté. Utilisez MP4, MOV ou M4V."
    case .unreadableMedia(let detail):
      return "La vidéo transférée ne peut pas être ouverte correctement : \(detail)"
    case .checksumMismatch:
      return "Le fichier vidéo local ne correspond plus à son empreinte SHA-256."
    case .legacyRepairNotApplicable:
      return "Cette vidéo ne nécessite pas la réparation du suffixe de transfert."
    }
  }
}

struct ImportedVideoAsset: Sendable {
  let storageKey: String
  let url: URL
  let sha256: String?
}

struct VideoMediaValidation: Sendable, Equatable {
  let durationSeconds: Double
  let nominalFrameRate: Double
  let width: Double
  let height: Double
}

actor VideoAssetStore {
  static let shared = VideoAssetStore()

  private static let allowedVideoExtensions: Set<String> = ["mp4", "mov", "m4v"]
  private let rootDirectoryOverride: URL?

  init(rootDirectoryOverride: URL? = nil) {
    self.rootDirectoryOverride = rootDirectoryOverride
  }

  private func rootDirectory() throws -> URL {
    let fm = FileManager.default
    if let override = rootDirectoryOverride {
      try fm.createDirectory(at: override, withIntermediateDirectories: true)
      return override
    }

    let support = try fm.url(
      for: .applicationSupportDirectory,
      in: .userDomainMask,
      appropriateFor: nil,
      create: true
    )
    let root = support
      .appendingPathComponent("PercheProgression", isDirectory: true)
      .appendingPathComponent("Media", isDirectory: true)
    try fm.createDirectory(at: root, withIntermediateDirectories: true)
    return root
  }

  static func sanitizedVideoExtension(_ rawValue: String?) -> String? {
    guard var value = rawValue?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(),
          !value.isEmpty
    else { return nil }
    while value.hasPrefix(".") { value.removeFirst() }
    guard allowedVideoExtensions.contains(value) else { return nil }
    return value
  }

  static func preferredVideoExtension(fromRemoteFilename filename: String) throws -> String {
    let trimmed = filename.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty,
          !trimmed.contains("/"),
          !trimmed.contains("\\"),
          URL(fileURLWithPath: trimmed).lastPathComponent == trimmed
    else {
      throw VideoStoreError.invalidSource
    }
    let rawExtension = URL(fileURLWithPath: trimmed).pathExtension
    guard let ext = sanitizedVideoExtension(rawExtension) else {
      throw VideoStoreError.invalidMediaExtension(rawExtension.isEmpty ? "sans extension" : rawExtension)
    }
    return ext
  }

  private static func destinationExtension(sourceURL: URL, preferredFileExtension: String?) throws -> String {
    if let preferredFileExtension {
      guard let ext = sanitizedVideoExtension(preferredFileExtension) else {
        throw VideoStoreError.invalidMediaExtension(preferredFileExtension)
      }
      return ext
    }

    let sourceExtension = sourceURL.pathExtension
    if sourceExtension.isEmpty {
      // Some Photos/document-provider temporary files have no suffix. MOV is the safest
      // Apple-native fallback; callers that know the media type should provide it explicitly.
      return "mov"
    }
    guard let ext = sanitizedVideoExtension(sourceExtension) else {
      throw VideoStoreError.invalidMediaExtension(sourceExtension)
    }
    return ext
  }

  func importVideo(
    from sourceURL: URL,
    preferredFileExtension: String? = nil
  ) throws -> ImportedVideoAsset {
    let projectID = UUID().uuidString
    let ext = try Self.destinationExtension(
      sourceURL: sourceURL,
      preferredFileExtension: preferredFileExtension
    )
    let storageKey = "\(projectID)/source.\(ext)"
    let destination = try rootDirectory().appendingPathComponent(storageKey)

    try FileManager.default.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if FileManager.default.fileExists(atPath: destination.path) {
      try FileManager.default.removeItem(at: destination)
    }
    try coordinatedCopy(from: sourceURL, to: destination)

    return ImportedVideoAsset(
      storageKey: storageKey,
      url: destination,
      sha256: sha256(of: destination)
    )
  }

  /// Validates the durable media bytes before a remote recording may become a VideoClipRecord.
  /// Loading duration, a video track and its geometry forces AVFoundation to parse the container
  /// rather than trusting the filename extension alone.
  func validatePlayableVideo(at url: URL) async throws -> VideoMediaValidation {
    let asset = AVURLAsset(url: url)
    do {
      let durationTime = try await asset.load(.duration)
      let duration = durationTime.seconds
      guard duration.isFinite, duration > 0 else {
        throw VideoStoreError.unreadableMedia("durée vidéo invalide")
      }

      let tracks = try await asset.loadTracks(withMediaType: .video)
      guard let track = tracks.first else {
        throw VideoStoreError.unreadableMedia("aucune piste vidéo")
      }

      let naturalSize = try await track.load(.naturalSize)
      let preferredTransform = try await track.load(.preferredTransform)
      let transformed = naturalSize.applying(preferredTransform)
      let width = abs(Double(transformed.width))
      let height = abs(Double(transformed.height))
      guard width > 0, height > 0 else {
        throw VideoStoreError.unreadableMedia("dimensions vidéo invalides")
      }

      let nominalFrameRate = Double(try await track.load(.nominalFrameRate))
      guard nominalFrameRate.isFinite, nominalFrameRate >= 0 else {
        throw VideoStoreError.unreadableMedia("cadence vidéo invalide")
      }

      return VideoMediaValidation(
        durationSeconds: duration,
        nominalFrameRate: nominalFrameRate,
        width: width,
        height: height
      )
    } catch let error as VideoStoreError {
      throw error
    } catch {
      throw VideoStoreError.unreadableMedia(error.localizedDescription)
    }
  }

  /// Creates and validates a correctly suffixed copy of a v15.0-v15.0.2 remote video that
  /// was accidentally persisted as `source.partial`. The original bytes are intentionally
  /// retained; the caller removes the old storage key only after model persistence succeeds.
  func prepareLegacyRemoteRepair(
    storageKey: String,
    preferredFileExtension: String,
    expectedSHA256: String?
  ) async throws -> ImportedVideoAsset {
    guard URL(fileURLWithPath: storageKey).pathExtension.lowercased() == "partial" else {
      throw VideoStoreError.legacyRepairNotApplicable
    }
    let originalURL = try resolve(storageKey)
    let originalSHA = sha256(of: originalURL)
    if let expectedSHA256, !expectedSHA256.isEmpty,
       originalSHA?.caseInsensitiveCompare(expectedSHA256) != .orderedSame
    {
      throw VideoStoreError.checksumMismatch
    }

    var repaired: ImportedVideoAsset?
    do {
      let candidate = try importVideo(
        from: originalURL,
        preferredFileExtension: preferredFileExtension
      )
      repaired = candidate

      guard let originalSHA,
            candidate.sha256?.caseInsensitiveCompare(originalSHA) == .orderedSame
      else {
        throw VideoStoreError.checksumMismatch
      }
      if let expectedSHA256, !expectedSHA256.isEmpty,
         candidate.sha256?.caseInsensitiveCompare(expectedSHA256) != .orderedSame
      {
        throw VideoStoreError.checksumMismatch
      }

      _ = try await validatePlayableVideo(at: candidate.url)
      return candidate
    } catch {
      if let repaired {
        try? removeVideo(storageKey: repaired.storageKey)
      }
      // Never touch the old .partial copy on a failed repair.
      throw error
    }
  }

  /// Reads document-provider and iCloud files through a coordinated access,
  /// then copies them into the app-owned media store while the security scope
  /// acquired by the view is still active.
  private func coordinatedCopy(from sourceURL: URL, to destination: URL) throws {
    let coordinator = NSFileCoordinator(filePresenter: nil)
    var coordinationError: NSError?
    var copyError: Error?

    coordinator.coordinate(
      readingItemAt: sourceURL,
      options: .withoutChanges,
      error: &coordinationError
    ) { coordinatedURL in
      do {
        let values = try coordinatedURL.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile != false else {
          throw VideoStoreError.invalidSource
        }
        if let fileSize = values.fileSize, fileSize == 0 {
          throw VideoStoreError.invalidSource
        }
        try FileManager.default.copyItem(at: coordinatedURL, to: destination)
      } catch {
        copyError = error
      }
    }

    if let copyError { throw copyError }
    if let coordinationError { throw coordinationError }
    guard FileManager.default.fileExists(atPath: destination.path) else {
      throw VideoStoreError.invalidSource
    }
  }

  func resolve(_ storageKey: String) throws -> URL {
    guard !storageKey.isEmpty, !storageKey.hasPrefix("/") else {
      throw VideoStoreError.invalidStorageKey
    }
    let root = try rootDirectory().standardizedFileURL
    let candidate = root.appendingPathComponent(storageKey).standardizedFileURL
    guard candidate.path.hasPrefix(root.path) else {
      throw VideoStoreError.invalidStorageKey
    }
    guard FileManager.default.fileExists(atPath: candidate.path) else {
      throw VideoStoreError.missingFile
    }
    return candidate
  }

  /// Migration douce des projets v10 : si l'ancien chemin absolu existe encore,
  /// le fichier est recopié dans le store stable v11 et une clé relative est retournée.
  func migrateLegacyAbsolutePath(_ path: String) throws -> ImportedVideoAsset {
    let url = URL(fileURLWithPath: path)
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw VideoStoreError.missingFile
    }
    return try importVideo(from: url)
  }

  func removeVideo(storageKey: String) throws {
    let url = try resolve(storageKey)
    let parent = url.deletingLastPathComponent()
    if FileManager.default.fileExists(atPath: parent.path) {
      try FileManager.default.removeItem(at: parent)
    }
  }

  func removeVideo(atLegacyURL url: URL) throws {
    guard FileManager.default.fileExists(atPath: url.path) else { return }
    try FileManager.default.removeItem(at: url)
  }

  func sha256(of url: URL) -> String? {
    guard let data = try? Data(contentsOf: url, options: .mappedIfSafe) else { return nil }
    return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
  }

  func matchesSHA256(url: URL, expected: String?) -> Bool {
    guard let expected, !expected.isEmpty, let actual = sha256(of: url) else { return true }
    return actual.caseInsensitiveCompare(expected) == .orderedSame
  }
}

// Alias temporaire pour ne pas casser les appels résiduels pendant la migration v10 → v11.
typealias VideoFileStore = VideoAssetStore
