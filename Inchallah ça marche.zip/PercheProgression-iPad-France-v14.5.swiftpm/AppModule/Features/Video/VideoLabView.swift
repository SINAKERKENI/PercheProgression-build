import AVKit
import Foundation
import PencilKit
import PhotosUI
import SwiftData
import SwiftUI
import UniformTypeIdentifiers
import UIKit

private enum VideoWorkspaceMode: String, CaseIterable, Identifiable {
  case playback = "Lecture"
  case compare = "Comparer"
  case measure = "Mesurer"
  case biomechanics = "Biomécanique"
  var id: String { rawValue }
}

private enum VideoFileImportRequest {
  case newVideo
  case relink(UUID)
}

private enum VideoFileImportError: LocalizedError {
  case emptySelection
  case missingRelinkTarget

  var errorDescription: String? {
    switch self {
    case .emptySelection:
      "Aucun fichier vidéo n’a été sélectionné."
    case .missingRelinkTarget:
      "Le projet vidéo à relier n’est plus disponible."
    }
  }
}

struct VideoLabView: View {
  @Environment(AppState.self) private var appState
  @Environment(\.modelContext) private var modelContext
  @Environment(PerformanceState.self) private var performanceStore
  @Query private var profiles: [AthleteProfile]
  @Query(sort: \VideoClipRecord.createdAt, order: .reverse) private var clips: [VideoClipRecord]
  @Query private var savedVectors: [VectorAnnotationRecord]
  @Query private var savedPhaseMarkers: [PhaseMarkerRecord]
  @Query(sort: \PhysicalMetricRecord.measuredAt) private var metrics: [PhysicalMetricRecord]

  @StateObject private var viewModel = VideoLabViewModel()
  @StateObject private var remoteCamera = PixelRemoteCameraController()
  @State private var selectedPhotoItem: PhotosPickerItem?
  @State private var showingFileImporter = false
  @State private var fileImportRequest: VideoFileImportRequest = .newVideo
  @State private var showingCamera = false
  @State private var currentClipID: UUID?
  @State private var comparisonClipID: UUID?
  @State private var importError: String?
  @State private var showingClearConfirmation = false
  @State private var clipPendingDeletion: VideoClipRecord?
  @State private var pencilCanvas: PKCanvasView?
  @State private var analysisAthleteHeightCM: Double = 0
  @State private var showAdvancedBoxMeasurement = false
  @State private var workspaceMode: VideoWorkspaceMode = .playback
  @State private var showFullScreen = false
  @State private var relinkClipID: UUID?
  @FocusState private var analysisHeightFieldFocused: Bool
  @State private var videoChromeVisible = false
  @State private var videoChromeHideWorkItem: DispatchWorkItem?
  @State private var overlayDirectManipulation = false

  private var athlete: AthleteProfile? { appState.athlete(in: profiles) }
  private var athleteClips: [VideoClipRecord] {
    guard let athleteID = athlete?.id else { return [] }
    return clips.filter { $0.athleteID == athleteID }
  }
  private var currentClip: VideoClipRecord? { athleteClips.first { $0.id == currentClipID } }
  private var comparisonClip: VideoClipRecord? { athleteClips.first { $0.id == comparisonClipID } }
  /// v15.0-v15.0.2 remote clips stored as `source.partial` are intentionally excluded until
  /// the non-destructive repair has produced and persisted a validated video container.
  private var successfullyImportedRemoteIDs: Set<String> {
    Set(athleteClips.compactMap { clip in
      guard !clip.remoteRecordingID.isEmpty,
            VideoAssetStore.sanitizedVideoExtension(URL(fileURLWithPath: clip.mediaStorageKey).pathExtension) != nil
      else { return nil }
      return clip.remoteRecordingID
    })
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: VaultSpacing.large) {
        HStack(alignment: .top) {
          VaultScreenHeader(
            title: "Analyse vidéo",
            subtitle:
              "Calibration dynamique pour caméra mobile, mesure depuis le butoir, comparaison, Apple Pencil et biomécanique.",
            symbol: "video.fill",
            tint: .vaultAnalysisAccent
          )
          Spacer()
          importControls
        }

        RemoteCameraPanel(
          controller: remoteCamera,
          discovery: remoteCamera.discovery,
          existingRemoteIDs: successfullyImportedRemoteIDs,
          onStopAndImport: stopRemoteRecordingAndImport,
          onRetryImport: importPendingRemoteRecording
        )

        if viewModel.loadedURL == nil {
          emptyVideoState
        } else {
          videoWorkspace
        }

        if appState.pendingVideoAttemptID != nil && appState.pendingVideoAthleteID == athlete?.id {
          Label(
            "La prochaine vidéo importée ou filmée sera automatiquement liée au saut sélectionné.",
            systemImage: "link.badge.plus"
          )
          .font(.subheadline.weight(.bold))
          .foregroundStyle(Color.vaultNavy)
          .padding(14)
          .frame(maxWidth: .infinity, alignment: .leading)
          .background(Color.vaultGold.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
        }

        if !athleteClips.isEmpty { clipLibrary }
      }
      .padding(VaultSpacing.large)
    }
    .vaultPage()
    .tint(.vaultAnalysisAccent)
    .onAppear { remoteCamera.startDiscovery() }
    .onDisappear { remoteCamera.stopDiscovery() }
    .fullScreenCover(isPresented: $showingCamera) {
      VideoCameraPicker(
        onCaptured: handleCameraCapture,
        onError: { error in
          importError = error.localizedDescription
          Haptics.error()
        }
      )
      .ignoresSafeArea()
    }
    .fullScreenCover(isPresented: $showFullScreen) {
      FullScreenVideoWorkspace(viewModel: viewModel)
    }
    .fileImporter(
      isPresented: $showingFileImporter,
      allowedContentTypes: [.movie, .video, .mpeg4Movie, .quickTimeMovie],
      allowsMultipleSelection: false
    ) { result in
      handleFileImport(result)
    }
    .onChange(of: selectedPhotoItem) { _, newValue in
      guard let newValue else { return }
      Task { await importPhotoItem(newValue) }
    }
    .onChange(of: remoteCamera.pendingManifest?.recordingID) { _, recordingID in
      guard let recordingID else { return }
      let existingIDs = successfullyImportedRemoteIDs
      if existingIDs.contains(recordingID) {
        Task { await remoteCamera.confirmImported(recordingID: recordingID) }
      } else if remoteCamera.state != .recording && remoteCamera.state != .transferring {
        importPendingRemoteRecording()
      }
    }
    .onAppear {
      if analysisAthleteHeightCM < 120, let height = athlete?.heightCM, height >= 120 {
        analysisAthleteHeightCM = height
      }
      if viewModel.loadedURL == nil {
        Task { @MainActor in
          await recoverLegacyRemoteClips()
          if let first = athleteClips.first { loadClip(first) }
        }
      }
    }
    .onChange(of: athlete?.heightCM) { _, newValue in
      if analysisAthleteHeightCM < 120, let newValue, newValue >= 120 {
        analysisAthleteHeightCM = newValue
      }
    }
    .onChange(of: athlete?.id) { _, athleteID in
      if appState.pendingVideoAthleteID != athleteID {
        appState.pendingVideoAttemptID = nil
        appState.pendingVideoAthleteID = nil
      }
      viewModel.teardown()
      currentClipID = nil
      comparisonClipID = nil
      Task { @MainActor in
        await recoverLegacyRemoteClips()
        if let first = athleteClips.first { loadClip(first) }
      }
    }
    .onChange(of: appState.destination) { _, destination in
      if destination != .video {
        appState.pendingVideoAttemptID = nil
        appState.pendingVideoAthleteID = nil
      }
    }
    .onDisappear {
      videoChromeHideWorkItem?.cancel()
      viewModel.teardown()
      if !showingCamera && !showFullScreen {
        appState.pendingVideoAttemptID = nil
        appState.pendingVideoAthleteID = nil
      }
    }
    .alert(
      "Échec de l’importation vidéo",
      isPresented: Binding(
        get: { importError != nil },
        set: { if !$0 { importError = nil } }
      )
    ) {
      Button("OK", role: .cancel) { importError = nil }
    } message: {
      Text(importError ?? "Erreur inconnue")
    }
    .alert("Vider l’analyse en cours ?", isPresented: $showingClearConfirmation) {
      Button("Tout effacer", role: .destructive) {
        pencilCanvas?.drawing = PKDrawing()
        viewModel.clearAnnotations()
      }
      Button("Annuler", role: .cancel) {}
    } message: {
      Text("Les vecteurs, l’étalonnage, le suivi, les phases et les dessins seront supprimés pour cette vidéo.")
    }
    .alert(
      "Retirer cette vidéo ?",
      isPresented: Binding(
        get: { clipPendingDeletion != nil },
        set: { if !$0 { clipPendingDeletion = nil } }
      )
    ) {
      Button("Retirer définitivement", role: .destructive) {
        guard let clip = clipPendingDeletion else { return }
        deleteClip(clip)
        clipPendingDeletion = nil
      }
      Button("Annuler", role: .cancel) { clipPendingDeletion = nil }
    } message: {
      Text("La vidéo et ses annotations locales seront supprimées de l’iPad. Cette action est irréversible.")
    }
  }

  private var importControls: some View {
    HStack(spacing: 10) {
      Button { showingCamera = true } label: {
        Label("Filmer", systemImage: "video.badge.plus")
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultAnalysisAccent)
      .disabled(!UIImagePickerController.isSourceTypeAvailable(.camera))

      PhotosPicker(selection: $selectedPhotoItem, matching: .videos) {
        Label("Photos", systemImage: "photo.on.rectangle")
      }
      .buttonStyle(.bordered)

      Button {
        fileImportRequest = .newVideo
        showingFileImporter = true
      } label: {
        Label("Fichiers", systemImage: "folder")
      }
      .buttonStyle(.bordered)

      if let currentClip {
        Button(role: .destructive) {
          clipPendingDeletion = currentClip
        } label: {
          Label("Retirer la vidéo", systemImage: "trash")
        }
        .buttonStyle(.bordered)
      }
    }
  }

  private var emptyVideoState: some View {
    VStack(spacing: 18) {
      Image(systemName: "video.badge.plus")
        .font(.system(size: 58, weight: .semibold))
        .foregroundStyle(Color.vaultAnalysisAccent)
      Text("Importer une vidéo de saut")
        .font(.title2.weight(.black))
      Text(
        "La vidéo est copiée localement. La grille dynamique compense le panoramique de la caméra dans les 5 derniers mètres."
      )
      .font(.subheadline)
      .foregroundStyle(Color.vaultMuted)
      .multilineTextAlignment(.center)
      .frame(maxWidth: 560)
      importControls
    }
    .frame(maxWidth: .infinity, minHeight: 420)
    .vaultCard()
  }

  private var videoWorkspace: some View {
    VStack(spacing: VaultSpacing.medium) {
      Picker("Espace de travail", selection: $workspaceMode) {
        ForEach(VideoWorkspaceMode.allCases) { mode in Text(mode.rawValue).tag(mode) }
      }
      .pickerStyle(.segmented)
      .accessibilityLabel("Espace de travail vidéo")

      if workspaceMode == .measure || workspaceMode == .biomechanics { toolBar }
      videoSurface

      if workspaceMode == .compare {
        playbackControls
      } else {
        PrecisionVideoTransportView(viewModel: viewModel, saveAction: saveAnalysis)
      }

      if workspaceMode == .measure {
        physicalMeasurementWorkflowPanel
        if let result = viewModel.motionResult {
          motionSpeedSummaryCard(result)
        }
        if viewModel.pelvisValidation != nil { pelvisValidationPanel }
        DisclosureGroup(isExpanded: $showAdvancedBoxMeasurement) {
          VStack(spacing: VaultSpacing.medium) {
            dynamicCalibrationPanel
            motionAnalysisPanel
          }
          .padding(.top, 12)
        } label: {
          Label("Mesure avancée depuis le fond du butoir", systemImage: "ruler.fill")
            .font(.headline.weight(.black))
            .foregroundStyle(Color.vaultText)
        }
        .padding(18)
        .vaultCard(background: Color.vaultCyan.opacity(0.025))
      }

      if workspaceMode == .biomechanics {
        nerdStatsPanel
        ViewThatFits(in: .horizontal) {
          HStack(alignment: .top, spacing: VaultSpacing.large) { vectorInspector; phaseInspector }
          VStack(spacing: VaultSpacing.large) { vectorInspector; phaseInspector }
        }
      }

      videoCommentsPanel
    }
  }

  private var toolBar: some View {
    ScrollView(.horizontal, showsIndicators: false) {
      HStack(spacing: 9) {
        ForEach(VideoLabViewModel.Tool.allCases) { tool in
          Button {
            viewModel.selectTool(tool)
          } label: {
            Label(tool.title, systemImage: tool.symbol)
              .font(.subheadline.weight(.bold))
              .padding(.horizontal, 12)
              .padding(.vertical, 9)
              .foregroundStyle(viewModel.tool == tool ? Color.white : Color.vaultText)
              .background(
                viewModel.tool == tool ? Color.vaultAnalysisAccent : Color.vaultPanelRaised,
                in: Capsule()
              )
          }
          .buttonStyle(.plain)
        }

        if viewModel.tool == .vector {
          Picker("Type de vecteur", selection: $viewModel.selectedVectorKind) {
            ForEach(VectorKind.allCases.filter { $0 != .calibration }) { kind in
              Text(kind.title).tag(kind)
            }
          }
          .pickerStyle(.menu)
          .frame(maxWidth: 180)
        }

        Button(action: performUndo) {
          Label("Retour", systemImage: "arrow.uturn.backward")
        }
        .buttonStyle(.bordered)
        .disabled(!canUndo)

        Button {
          viewModel.deleteSelectedVector()
        } label: {
          Label("Supprimer le vecteur", systemImage: "trash.slash")
        }
        .buttonStyle(.bordered)
        .disabled(viewModel.selectedVectorID == nil)

        Button(role: .destructive) {
          showingClearConfirmation = true
        } label: {
          Label("Poubelle", systemImage: "trash")
        }
        .buttonStyle(.bordered)
        .disabled(!viewModel.hasAnnotations)
      }
      .padding(12)
    }
    .background(
      Color.vaultPanel, in: RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
    )
    .overlay {
      RoundedRectangle(cornerRadius: VaultRadius.medium, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }

  private var canUndo: Bool {
    if viewModel.tool == .freehand || viewModel.tool == .erase {
      return pencilCanvas?.undoManager?.canUndo == true || !viewModel.pencilDrawing.strokes.isEmpty
    }
    return viewModel.hasAnnotations
  }

  private func performUndo() {
    if (viewModel.tool == .freehand || viewModel.tool == .erase),
      let canvas = pencilCanvas,
      canvas.undoManager?.canUndo == true
    {
      canvas.undoManager?.undo()
      viewModel.pencilDrawing = canvas.drawing
      Haptics.impact(.light)
    } else {
      viewModel.undoNonPencilAnnotation()
    }
  }

  private func revealVideoChrome(for duration: TimeInterval = 2.4) {
    if !videoChromeVisible {
      withAnimation(.easeInOut(duration: 0.18)) {
        videoChromeVisible = true
      }
    }
    videoChromeHideWorkItem?.cancel()
    let workItem = DispatchWorkItem {
      withAnimation(.easeInOut(duration: 0.22)) {
        videoChromeVisible = false
      }
    }
    videoChromeHideWorkItem = workItem
    DispatchQueue.main.asyncAfter(deadline: .now() + duration, execute: workItem)
  }

  private func openFullScreenWorkspace() {
    videoChromeHideWorkItem?.cancel()
    withAnimation(.easeInOut(duration: 0.15)) {
      videoChromeVisible = false
    }
    viewModel.pausePlayback()
    showFullScreen = true
  }

  @ViewBuilder
  private var videoSurface: some View {
    if viewModel.comparisonPlayer != nil, viewModel.comparisonMode == .sideBySide {
      ViewThatFits(in: .horizontal) {
        HStack(alignment: .top, spacing: VaultSpacing.medium) {
          primaryVideoSurface
          if let player = viewModel.comparisonPlayer { comparisonVideoSurface(player: player) }
        }
        VStack(spacing: VaultSpacing.medium) {
          primaryVideoSurface
          if let player = viewModel.comparisonPlayer { comparisonVideoSurface(player: player) }
        }
      }
    } else {
      primaryVideoSurface
    }
  }

  private var primaryVideoSurface: some View {
    GeometryReader { geometry in
      let videoRect = aspectFitRect(contentSize: viewModel.videoNaturalSize, in: geometry.size)

      ZStack {
        RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
          .fill(Color.black)

        ZStack {
          if let player = viewModel.player {
            VideoPlayer(player: player)
              .disabled(true)
              .clipShape(RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous))
          }

          if viewModel.comparisonMode == .overlay,
            let comparisonPlayer = viewModel.comparisonPlayer
          {
            VideoPlayer(player: comparisonPlayer)
              .disabled(true)
              .rotationEffect(.degrees(viewModel.overlayTransform.rotationDegrees))
              .scaleEffect(
                x: viewModel.overlayTransform.mirrorHorizontal ? -viewModel.overlayTransform.scale : viewModel.overlayTransform.scale,
                y: viewModel.overlayTransform.mirrorVertical ? -viewModel.overlayTransform.scale : viewModel.overlayTransform.scale
              )
              .offset(
                x: viewModel.overlayTransform.translationX,
                y: viewModel.overlayTransform.translationY
              )
              .opacity(viewModel.overlayOpacity)
              .blendMode(.normal)
              .clipShape(RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous))
          }

          analysisLayers
            .frame(width: videoRect.width, height: videoRect.height)
            .position(x: videoRect.midX, y: videoRect.midY)
        }
        .scaleEffect(viewModel.viewportTransform.scale)
        .rotationEffect(.radians(viewModel.viewportTransform.rotationRadians))
        .offset(viewModel.viewportTransform.translation)

        VideoGestureLayer(
          onPan: { delta in
            if viewModel.comparisonMode == .overlay, overlayDirectManipulation {
              viewModel.overlayTransform.applyPan(delta)
            } else {
              viewModel.viewportTransform.translation.width += delta.width
              viewModel.viewportTransform.translation.height += delta.height
            }
          },
          onScale: { delta in
            if viewModel.comparisonMode == .overlay, overlayDirectManipulation {
              viewModel.overlayTransform.applyScale(delta)
            } else {
              viewModel.viewportTransform.applyScale(delta)
            }
          },
          onRotation: { delta in
            if viewModel.comparisonMode == .overlay, overlayDirectManipulation {
              viewModel.overlayTransform.applyRotation(delta)
            } else {
              viewModel.viewportTransform.rotationRadians += delta
            }
          }
        )

        videoLabels

        if !viewModel.isPelvisValidationActive {
          activeToolCoach
        }

        if viewModel.isPelvisValidationActive, viewModel.currentPelvisCheckpoint != nil {
          pelvisFloatingControls
        }

        if videoChromeVisible && !viewModel.isPelvisValidationActive {
          floatingVideoFullscreenButton
        }
      }
      .contentShape(Rectangle())
      .simultaneousGesture(
        DragGesture(minimumDistance: 0)
          .onChanged { _ in revealVideoChrome() }
      )
    }
    .aspectRatio(max(viewModel.videoNaturalSize.width / max(viewModel.videoNaturalSize.height, 1), 0.75), contentMode: .fit)
    .frame(minHeight: 360)
    .overlay {
      RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
        .stroke(Color.vaultLine, lineWidth: 1)
    }
  }

  private var floatingVideoFullscreenButton: some View {
    VStack {
      Spacer()
      HStack {
        Spacer()
        Button {
          openFullScreenWorkspace()
        } label: {
          Image(systemName: "arrow.up.left.and.arrow.down.right")
            .font(.headline.weight(.black))
            .foregroundStyle(Color.white)
            .frame(width: 46, height: 46)
            .background(Color.black.opacity(0.65), in: Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.22), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Ouvrir la vidéo en plein écran")
      }
      .padding(.trailing, 14)
      .padding(.bottom, 14)
    }
    .transition(.scale(scale: 0.88).combined(with: .opacity))
  }

  private var analysisLayers: some View {
    ZStack {
      VectorOverlayView(
        vectors: $viewModel.vectors,
        selectedVectorID: $viewModel.selectedVectorID,
        currentTime: viewModel.currentTime,
        frameRate: viewModel.frameRate,
        isDrawingEnabled: viewModel.tool == .vector,
        isSelectionEnabled: viewModel.tool == .select,
        selectedKind: viewModel.selectedVectorKind,
        onVectorCreated: viewModel.vectorWasCreated
      )

      CalibrationOverlayView(
        calibration: $viewModel.calibration,
        isActive: viewModel.tool == .scale
      )
      .opacity(viewModel.tool == .scale || viewModel.calibration.distanceMeters > 0 ? 1 : 0)

      BackgroundAnchorOverlayView(
        anchors: $viewModel.backgroundAnchors,
        isActive: viewModel.tool == .background
      )
      .opacity(viewModel.tool == .background || !viewModel.backgroundAnchors.isEmpty ? 1 : 0)

      DynamicRunwayGridOverlayView(
        editableGrid: $viewModel.runwayGrid,
        dynamicTrack: viewModel.dynamicCalibration,
        currentTime: viewModel.currentTime,
        isActive: viewModel.tool == .calibration,
        nearLineIsBoxOrigin: viewModel.physicalCameraMode != .fixedOblique
          || viewModel.fixedRunwayMetricOrigin == .box
      )
      .opacity(
        (viewModel.tool == .scale || viewModel.tool == .background)
          ? 0
          : (((viewModel.tool == .calibration && viewModel.isRunwayGridConfigured)
            || viewModel.dynamicCalibration != nil) ? 1 : 0)
      )

      TakeoffMeasurementOverlayView(
        pointValue: $viewModel.takeoffPoint,
        measurement: viewModel.takeoffMeasurement,
        isActive: viewModel.tool == .takeoff,
        onPointCommitted: viewModel.commitTakeoffPoint
      )

      MotionTrackingOverlayView(
        seed: $viewModel.trackingSeed,
        result: viewModel.motionResult,
        currentTime: viewModel.currentTime,
        isSelectionActive: viewModel.tool == .tracking && !viewModel.isPelvisValidationActive
      )

      PelvisCheckpointOverlayView(
        checkpoint: viewModel.currentPelvisCheckpoint,
        index: viewModel.pelvisCheckpointIndex,
        total: viewModel.pelvisCheckpointCount,
        isActive: viewModel.isPelvisValidationActive,
        onPointChanged: viewModel.setCurrentPelvisPoint
      )
      .opacity(viewModel.pelvisValidation == nil ? 0 : 1)

      PoseSkeletonOverlay(joints: viewModel.poseJoints)
        .allowsHitTesting(false)

      if viewModel.tool == .pose, !viewModel.poseCandidates.isEmpty {
        PoseCandidateSelectionOverlay(
          candidates: viewModel.poseCandidates,
          selectedID: viewModel.selectedAthleteCandidate?.id,
          onSelect: viewModel.selectPoseCandidate
        )
      }

      PencilCanvasView(
        drawing: $viewModel.pencilDrawing,
        canvasReference: $pencilCanvas,
        isActive: viewModel.tool == .freehand || viewModel.tool == .erase,
        isEraser: viewModel.tool == .erase
      )
    }
    .clipped()
  }

  @ViewBuilder
  private var activeToolCoach: some View {
    VStack {
      Spacer()
      HStack(spacing: 10) {
        switch viewModel.tool {
        case .vector:
          Label("Glissez sur l’image pour tracer le vecteur", systemImage: "arrow.up.right")
            .font(.caption.weight(.bold))
        case .takeoff:
          Label("Touchez la pointe du pied au dernier appui", systemImage: "shoeprints.fill")
            .font(.caption.weight(.bold))
        case .pose:
          Label("Posture : détecter le perchiste sur cette image", systemImage: "figure.arms.open")
            .font(.caption.weight(.bold))
          Button {
            Task { await viewModel.analyzePose() }
          } label: {
            Label(viewModel.isAnalyzingPose ? "Analyse…" : "Analyser cette image", systemImage: "viewfinder")
              .font(.caption.weight(.black))
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAnalysisAccent)
          .disabled(viewModel.isAnalyzingPose)
        default:
          EmptyView()
        }
      }
      .padding(.horizontal, 12)
      .padding(.vertical, 9)
      .background(.ultraThinMaterial, in: Capsule())
      .padding(.bottom, 12)
    }
    .padding(.horizontal, 12)
    .allowsHitTesting(viewModel.tool == .pose)
  }

  private var pelvisFloatingControls: some View {
    VStack {
      Spacer()
      HStack(spacing: 10) {
        Button {
          viewModel.movePelvisCheckpoint(by: -1)
        } label: {
          Image(systemName: "chevron.left")
            .font(.headline.weight(.black))
            .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)
        .background(.ultraThinMaterial, in: Circle())
        .disabled(viewModel.pelvisCheckpointIndex == 0)

        if let checkpoint = viewModel.currentPelvisCheckpoint {
          VStack(alignment: .leading, spacing: 2) {
            Text(String(format: "\(viewModel.validationPointTitleUppercased) À %.2f s", checkpoint.timeSeconds))
              .font(.caption2.monospacedDigit().weight(.black))
            Text("Glissez le repère bleu, puis confirmez")
              .font(.caption2)
          }
          .foregroundStyle(Color.vaultText)
        }

        if viewModel.canRefineValidationPointWithVision {
          Button {
            Task { await viewModel.refineCurrentPelvisSuggestion() }
          } label: {
            Label("Vision", systemImage: "figure.arms.open")
              .font(.caption.weight(.bold))
              .padding(.horizontal, 12)
              .frame(height: 38)
          }
          .buttonStyle(.plain)
          .background(.ultraThinMaterial, in: Capsule())
        }

        Button {
          viewModel.confirmCurrentPelvisCheckpoint()
        } label: {
          Label("Confirmer +0,1 s", systemImage: "checkmark.circle.fill")
            .font(.caption.weight(.black))
            .foregroundStyle(Color.white)
            .padding(.horizontal, 14)
            .frame(height: 40)
        }
        .buttonStyle(.plain)
        .background(Color.vaultAnalysisAccent, in: Capsule())

        Button {
          viewModel.movePelvisCheckpoint(by: 1)
        } label: {
          Image(systemName: "chevron.right")
            .font(.headline.weight(.black))
            .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)
        .background(.ultraThinMaterial, in: Circle())
        .disabled(viewModel.pelvisCheckpointIndex >= max(viewModel.pelvisCheckpointCount - 1, 0))
      }
      .padding(10)
      .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
      .shadow(color: Color.black.opacity(0.24), radius: 10, y: 4)
      .padding(14)
    }
  }

  private var videoLabels: some View {
    VStack {
      HStack(alignment: .top) {
        VStack(alignment: .leading, spacing: 4) {
          Text(viewModel.comparisonMode == .overlay && viewModel.comparisonPlayer != nil ? "Superposition" : "Vidéo principale")
            .font(.caption2.weight(.black))
            .textCase(.uppercase)
            .foregroundStyle(Color.vaultAnalysisAccent)
          Label(String(format: "%.3f s", viewModel.currentTime), systemImage: "clock")
            .font(.caption.monospacedDigit().weight(.bold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))

        Spacer()

        Label(viewModel.processingPhase.title, systemImage: viewModel.processingPhase.symbol)
          .font(.caption2.weight(.black))
          .padding(.horizontal, 9)
          .padding(.vertical, 6)
          .background(.ultraThinMaterial, in: Capsule())

        if let result = viewModel.motionResult {
          HStack(spacing: 5) {
            Image(systemName: "speedometer")
            Text(String(format: "%.2f m/s", result.representativeHorizontalSpeed))
              .monospacedDigit()
          }
          .font(.caption.weight(.black))
          .foregroundStyle(Color.white)
          .padding(.horizontal, 10)
          .padding(.vertical, 7)
          .background(Color.black.opacity(0.58), in: Capsule())
          .accessibilityLabel(String(format: "Vitesse moyenne %.2f mètres par seconde", result.representativeHorizontalSpeed))
        }

        if viewModel.comparisonMode == .overlay, viewModel.comparisonPlayer != nil {
          Text(String(format: "Référence %.0f %%", viewModel.overlayOpacity * 100))
            .font(.caption.monospacedDigit().weight(.bold))
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.ultraThinMaterial, in: Capsule())
        }

        if viewModel.isAnalyzingPose || viewModel.isAnalyzingMotion || viewModel.isAnalyzingBoxlessMotion {
          ProgressView()
            .padding(8)
            .background(.ultraThinMaterial, in: Circle())
        }
      }
      Spacer()
      if let message = viewModel.analysisMessage {
        Text(message)
          .font(.caption)
          .padding(8)
          .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
      }
    }
    .padding(12)
    .allowsHitTesting(false)
  }

  private func comparisonVideoSurface(player: AVPlayer) -> some View {
    ZStack {
      RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous).fill(Color.black)
      VideoPlayer(player: player)
        .disabled(true)
        .scaleEffect(viewModel.comparisonViewportTransform.scale)
        .rotationEffect(.radians(viewModel.comparisonViewportTransform.rotationRadians))
        .offset(viewModel.comparisonViewportTransform.translation)
        .clipShape(RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous))

      VideoGestureLayer(
        onPan: { delta in
          viewModel.comparisonViewportTransform.translation.width += delta.width
          viewModel.comparisonViewportTransform.translation.height += delta.height
        },
        onScale: { delta in viewModel.comparisonViewportTransform.applyScale(delta) },
        onRotation: { delta in viewModel.comparisonViewportTransform.rotationRadians += delta }
      )

      VStack {
        HStack {
          VStack(alignment: .leading, spacing: 4) {
            Text("Comparaison")
              .font(.caption2.weight(.black))
              .textCase(.uppercase)
              .foregroundStyle(Color.vaultCyan)
            Text(comparisonClip?.originalFilename ?? "Vidéo de référence")
              .font(.caption.weight(.bold))
              .lineLimit(1)
          }
          .padding(.horizontal, 10)
          .padding(.vertical, 7)
          .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
          Spacer()
          Text(String(format: "%+.3f s", viewModel.comparisonOffset))
            .font(.caption.monospacedDigit().weight(.bold))
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.ultraThinMaterial, in: Capsule())
        }
        Spacer()
      }
      .padding(12)
      .allowsHitTesting(false)
    }
    .aspectRatio(max(viewModel.comparisonNaturalSize.width / max(viewModel.comparisonNaturalSize.height, 1), 0.75), contentMode: .fit)
    .frame(minHeight: 360)
    .overlay(alignment: .bottomTrailing) {
      Button {
        viewModel.resetComparisonViewport()
      } label: {
        Label("Réinitialiser la vue de référence", systemImage: "arrow.counterclockwise")
          .labelStyle(.iconOnly)
          .padding(10)
          .background(.ultraThinMaterial, in: Circle())
      }
      .padding(12)
      .accessibilityLabel("Réinitialiser le zoom de la vidéo de référence")
    }
    .overlay {
      RoundedRectangle(cornerRadius: VaultRadius.large, style: .continuous)
        .stroke(Color.vaultCyan.opacity(0.5), lineWidth: 1)
        .allowsHitTesting(false)
    }
  }

  private var playbackControls: some View {
    VStack(spacing: 14) {
      comparisonControls
        .padding(18)
        .vaultCard(padding: 0)

      PrecisionVideoTransportView(
        viewModel: viewModel,
        saveAction: saveAnalysis
      )
    }
  }

  private var comparisonControls: some View {
    VStack(spacing: 12) {
      HStack(spacing: 12) {
        Picker("Mode de comparaison", selection: $viewModel.comparisonMode) {
          ForEach(VideoComparisonMode.allCases) { mode in
            Label(mode.title, systemImage: mode.symbol).tag(mode)
          }
        }
        .pickerStyle(.segmented)
        .frame(maxWidth: 360)

        Picker(
          "Vidéo à comparer",
          selection: Binding<UUID?>(
            get: { comparisonClipID },
            set: { newValue in
              comparisonClipID = newValue
              if let newValue, let clip = athleteClips.first(where: { $0.id == newValue }) {
                loadComparisonClip(clip)
              } else {
                viewModel.clearComparison()
              }
            }
          )
        ) {
          Text("Aucune").tag(UUID?.none)
          ForEach(athleteClips.filter { $0.id != currentClipID }) { clip in
            Text(clip.originalFilename).tag(Optional(clip.id))
          }
        }
        .pickerStyle(.menu)
        .frame(maxWidth: 280)

        Spacer()

        if viewModel.comparisonPlayer != nil {
          Button {
            comparisonClipID = nil
            viewModel.clearComparison()
          } label: {
            Label("Retirer la comparaison", systemImage: "xmark.circle.fill")
          }
          .labelStyle(.iconOnly)
        }
      }

      if viewModel.comparisonPlayer != nil {
        HStack(spacing: 12) {
          Text("Décalage")
            .font(.caption.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
          Slider(
            value: Binding(
              get: { viewModel.comparisonOffset },
              set: { value in
                viewModel.comparisonOffset = value
                viewModel.synchronizeComparison()
              }
            ),
            in: -15...15,
            step: 0.001
          )
          .tint(.vaultCyan)
          Text(String(format: "%+.3f s", viewModel.comparisonOffset))
            .font(.caption.monospacedDigit().weight(.bold))
            .frame(width: 74, alignment: .trailing)

          HStack(spacing: 6) {
            Button("-1 img") { viewModel.nudgeComparisonByFrames(-1) }
            Button("+1 img") { viewModel.nudgeComparisonByFrames(1) }
            Button("-0,1 s") { viewModel.nudgeComparison(by: -0.1) }
            Button("+0,1 s") { viewModel.nudgeComparison(by: 0.1) }
          }
          .buttonStyle(.bordered)
          .controlSize(.small)

          Button {
            viewModel.markComparisonTakeoffHere()
          } label: {
            Label(viewModel.comparisonTakeoffTime == nil ? "Marquer impulsion réf." : "Re-marquer impulsion réf.", systemImage: "mappin.and.ellipse")
          }
          .buttonStyle(.bordered)
          .controlSize(.small)

          Button {
            viewModel.synchronizeOnTakeoff()
          } label: {
            Label("Sync impulsion", systemImage: "scope")
          }
          .buttonStyle(.bordered)
          .controlSize(.small)
          .disabled(viewModel.comparisonTakeoffTime == nil)

          if !viewModel.comparisonFrameTimestamps.isEmpty {
            Text("PTS réf. ✓")
              .font(.caption2.weight(.black))
              .foregroundStyle(Color.vaultSuccess)
              .accessibilityLabel("Index temporel exact de la vidéo de référence disponible")
          }

          if viewModel.comparisonMode == .overlay {
            Divider().frame(height: 24)
            Toggle("Ajuster la superposition", isOn: $overlayDirectManipulation)
              .toggleStyle(.button)
              .controlSize(.small)
              .help("Quand ce mode est actif, les gestes à deux doigts déplacent, zooment et tournent la référence. Sinon ils agissent sur la vue principale.")
            Text("Transparence")
              .font(.caption.weight(.bold))
              .foregroundStyle(Color.vaultMuted)
            Slider(
              value: Binding(
                get: { 1 - viewModel.overlayOpacity },
                set: { viewModel.overlayOpacity = 1 - min(max($0, 0), 0.95) }
              ),
              in: 0...0.95
            )
              .tint(.vaultAnalysisAccent)
              .frame(maxWidth: 220)
            Text("\(Int(((1 - viewModel.overlayOpacity) * 100).rounded())) %")
              .font(.caption.monospacedDigit().weight(.bold))
              .frame(width: 54, alignment: .trailing)
            Menu("Orientation") {
              ForEach([0.0, 90.0, 180.0, 270.0], id: \.self) { degrees in
                Button("\(Int(degrees))°") {
                  viewModel.overlayTransform.rotationDegrees = degrees
                }
              }
              Divider()
              Button(viewModel.overlayTransform.mirrorHorizontal ? "Retirer miroir horizontal" : "Miroir horizontal") {
                viewModel.overlayTransform.mirrorHorizontal.toggle()
              }
              Button(viewModel.overlayTransform.mirrorVertical ? "Retirer miroir vertical" : "Miroir vertical") {
                viewModel.overlayTransform.mirrorVertical.toggle()
              }
              Button("Réinitialiser") {
                viewModel.resetOverlayTransform()
              }
            }
            .buttonStyle(.bordered)
          }
        }
      }
    }
  }


  private var dynamicCalibrationPanel: some View {
    VStack(alignment: .leading, spacing: 16) {
      HStack(alignment: .top) {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Calibration dynamique · caméra mobile")
          Text("Grille métrique des 5 derniers mètres")
            .font(.title3.weight(.black))
          Text("Le butoir reste l’origine 0,00 m. Quatre ancrages sont suivis image par image pendant le panoramique.")
            .font(.footnote)
            .foregroundStyle(Color.vaultMuted)
        }
        Spacer()
        if viewModel.isAnalyzingCalibration { ProgressView() }
      }

      ViewThatFits(in: .horizontal) {
        HStack(alignment: .top, spacing: 18) {
          calibrationActions
          RectifiedRunwayQualityView(
            track: viewModel.dynamicCalibration,
            currentTime: viewModel.currentTime
          )
          .frame(maxWidth: 420)
        }
        VStack(alignment: .leading, spacing: 16) {
          calibrationActions
          RectifiedRunwayQualityView(
            track: viewModel.dynamicCalibration,
            currentTime: viewModel.currentTime
          )
        }
      }

      if let message = viewModel.calibrationMessage {
        Label(message, systemImage: "viewfinder.circle")
          .font(.footnote.weight(.semibold))
          .foregroundStyle(Color.vaultText)
          .padding(10)
          .frame(maxWidth: .infinity, alignment: .leading)
          .background(Color.vaultCyan.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
      }

      if let track = viewModel.dynamicCalibration {
        CalibrationTimelineStrip(
          track: track,
          currentTime: viewModel.currentTime,
          duration: viewModel.duration,
          onSeek: viewModel.seek
        )
        HStack(spacing: 10) {
          Button { viewModel.jumpToNextCalibrationIssue() } label: {
            Label("Prochaine zone à contrôler", systemImage: "exclamationmark.magnifyingglass")
          }
          .buttonStyle(.bordered)
          Spacer()
          Text("Vert : fiable · Violet : contrôle · Rouge : correction")
            .font(.caption2.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
        }

        HStack(spacing: 12) {
          calibrationStatusPill(
            title: "Score qualité moyen",
            value: String(format: "%.0f %%", track.averageConfidence * 100),
            symbol: "checkmark.shield"
          )
          calibrationStatusPill(
            title: "Images calibrées",
            value: "\(track.samples.count)",
            symbol: "film.stack"
          )
          calibrationStatusPill(
            title: "Corrections",
            value: "\(viewModel.manualCalibrationKeyframes.count)",
            symbol: "hand.draw"
          )
        }
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultCyan.opacity(0.035))
  }

  private var calibrationActions: some View {
    VStack(alignment: .leading, spacing: 12) {
      ViewThatFits(in: .horizontal) {
        HStack(spacing: 10) { calibrationSetupButtons }
        VStack(alignment: .leading, spacing: 10) { calibrationSetupButtons }
      }

      HStack(spacing: 10) {
        VStack(alignment: .leading, spacing: 4) {
          Text("Longueur analysée")
            .font(.caption.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
          TextField(
            "5,00",
            value: $viewModel.runwayGrid.zoneLengthMeters,
            format: .number.precision(.fractionLength(2))
          )
          .keyboardType(.decimalPad)
          .textFieldStyle(.roundedBorder)
          .frame(width: 105)
        }
        VStack(alignment: .leading, spacing: 4) {
          Text("Largeur de piste")
            .font(.caption.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
          TextField(
            "1,22",
            value: $viewModel.runwayGrid.runwayWidthMeters,
            format: .number.precision(.fractionLength(2))
          )
          .keyboardType(.decimalPad)
          .textFieldStyle(.roundedBorder)
          .frame(width: 105)
        }
        Text("m")
          .font(.caption.weight(.bold))
          .foregroundStyle(Color.vaultMuted)
      }

      HStack(spacing: 10) {
        Button("Début zone ici") { viewModel.setTrackingStartHere() }
          .buttonStyle(.bordered)
        Text(String(format: "%.2f s", viewModel.trackingStartTime))
          .font(.caption.monospacedDigit().weight(.bold))
        Button("Fin zone ici") { viewModel.setTrackingEndHere() }
          .buttonStyle(.bordered)
        Text(String(format: "%.2f s", viewModel.trackingEndTime))
          .font(.caption.monospacedDigit().weight(.bold))
      }

      HStack(spacing: 10) {
        Button {
          viewModel.addCalibrationCorrection()
        } label: {
          Label("Ajouter une correction ici", systemImage: "diamond.fill")
        }
        .buttonStyle(.bordered)

        Button {
          Task { await viewModel.analyzeDynamicCalibration() }
        } label: {
          Label(
            viewModel.isAnalyzingCalibration ? "Calcul dynamique…" : "Suivre la grille",
            systemImage: "point.3.connected.trianglepath.dotted"
          )
        }
        .buttonStyle(.borderedProminent)
        .tint(.vaultAnalysisAccent)
        .disabled(
          viewModel.isAnalyzingCalibration
            || !viewModel.isRunwayGridConfigured
            || !viewModel.runwayGrid.isGeometricallyUsable
            || viewModel.trackingEndTime <= viewModel.trackingStartTime
        )
      }

      Label(
        !viewModel.isRunwayGridConfigured
          ? "Initialisez la grille pour faire apparaître les quatre poignées."
          : (viewModel.runwayGrid.isGeometricallyUsable
              ? "Grille valide : vous pouvez ajouter une correction puis lancer le suivi."
              : "Grille invalide : écartez les coins et supprimez tout croisement."),
        systemImage: viewModel.runwayGrid.isGeometricallyUsable && viewModel.isRunwayGridConfigured
          ? "checkmark.circle.fill" : "exclamationmark.triangle.fill"
      )
      .font(.caption.weight(.semibold))
      .foregroundStyle(
        viewModel.runwayGrid.isGeometricallyUsable && viewModel.isRunwayGridConfigured
          ? Color.vaultAnalysisAccent : Color.vaultAnalysisReview
      )

      Text("Si le butoir est masqué, n’utilisez pas une fausse grille : les Mesures avancées peuvent être calculées avec la stabilisation sans butoir. La grille manuelle reste réservée à la marque d’impulsion absolue.")
        .font(.caption)
        .foregroundStyle(Color.vaultAnalysisReview)

      Text("Gestes : glisser une poignée pour corriger un coin (des guides horizontaux/verticaux apparaissent pour le réglage fin), glisser le centre pour déplacer, pincer pour redimensionner et tourner à deux doigts pour aligner la piste.")
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)

      Label(
        "Protocole caméra : éviter l’ultra-grand-angle, garder l’athlète près du centre optique et limiter les panoramiques rapides. La v12 ne corrige pas encore explicitement la distorsion d’objectif ni le rolling shutter.",
        systemImage: "camera.aperture"
      )
      .font(.caption)
      .foregroundStyle(Color.vaultAnalysisReview)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
  }

  @ViewBuilder
  private var calibrationSetupButtons: some View {
    Button {
      viewModel.initializeManualRunwayGrid()
      viewModel.selectTool(.calibration)
    } label: {
      Label(
        viewModel.isRunwayGridConfigured ? "Réinitialiser la grille" : "Initialiser la grille manuelle",
        systemImage: "square.grid.3x3.square"
      )
    }
    .buttonStyle(.borderedProminent)
    .tint(.vaultAnalysisAccent)

    Button {
      viewModel.mirrorRunwayGrid()
      viewModel.selectTool(.calibration)
    } label: {
      Label("Inverser le sens", systemImage: "arrow.left.and.right")
    }
    .buttonStyle(.bordered)
    .disabled(!viewModel.isRunwayGridConfigured)

    Button {
      viewModel.useDynamicGridAtCurrentTimeForCorrection()
    } label: {
      Label("Modifier sur cette image", systemImage: "hand.point.up.left")
    }
    .buttonStyle(.bordered)

    Button {
      Task { await viewModel.proposeAutomaticRunwayGrid() }
    } label: {
      Label("Essayer le détecteur spécialisé", systemImage: "sparkles.rectangle.stack")
    }
    .buttonStyle(.bordered)
  }

  private func calibrationStatusPill(title: String, value: String, symbol: String) -> some View {
    HStack(spacing: 8) {
      Image(systemName: symbol)
        .foregroundStyle(Color.vaultAnalysisAccent)
      VStack(alignment: .leading, spacing: 2) {
        Text(title)
          .font(.caption2.weight(.bold))
          .foregroundStyle(Color.vaultMuted)
        Text(value)
          .font(.subheadline.monospacedDigit().weight(.black))
      }
    }
    .padding(.horizontal, 12)
    .padding(.vertical, 9)
    .background(Color.vaultPanelRaised, in: Capsule())
  }

  private var physicalMeasurementWorkflowPanel: some View {
    let scaleIsValid = viewModel.calibration.distanceMeters > 0
      && viewModel.calibration.pixelLength(in: viewModel.videoNaturalSize) >= 20
    let anchorsAreValid = viewModel.backgroundAnchors.count >= 2
    let fixedGridIsValid = viewModel.isRunwayGridConfigured && viewModel.runwayGrid.isGeometricallyUsable
    let validationIsComplete = viewModel.pelvisValidation?.isComplete == true

    return VStack(alignment: .leading, spacing: 18) {
      HStack(alignment: .top) {
        VStack(alignment: .leading, spacing: 5) {
          SectionEyebrow(text: "Mesure physique guidée")
          Text(viewModel.physicalCameraMode == .fixedOblique
            ? "Vitesse longitudinale · caméra fixe face ou en biais"
            : "Vitesse et accélération · caméra mobile")
            .font(.title2.weight(.black))
          Text(viewModel.physicalCameraMode == .fixedOblique
            ? "Une homographie fixe corrige le plan de la piste, que la caméra soit presque perpendiculaire au mouvement ou placée en biais. Aucun repère de stabilisation du décor n’est suivi."
            : "Temps vidéo + distance réelle + stabilisation du décor + point confirmé toutes les 0,1 s.")
            .font(.subheadline)
            .foregroundStyle(Color.vaultMuted)
        }
        Spacer()
        VStack(alignment: .trailing, spacing: 4) {
          Text(String(format: "%.0f fps", viewModel.frameRate))
            .font(.headline.monospacedDigit().weight(.black))
          Text("PTS réels")
            .font(.caption.monospacedDigit().weight(.bold))
            .foregroundStyle(Color.vaultMuted)
        }
      }

      Picker("Type de caméra", selection: $viewModel.physicalCameraMode) {
        ForEach(PhysicalCameraMode.allCases) { mode in
          Text(mode.title).tag(mode)
        }
      }
      .pickerStyle(.segmented)
      .onChange(of: viewModel.physicalCameraMode) { _, _ in
        viewModel.motionResult = nil
        viewModel.pelvisValidation = nil
        viewModel.analysisMessage = "Mode de mesure changé : reprenez la calibration correspondant à la caméra."
      }

      if viewModel.physicalCameraMode == .mobile {
        HStack(alignment: .top, spacing: 12) {
          Image(systemName: "eye.slash")
            .font(.title3.weight(.bold))
            .foregroundStyle(Color.vaultAnalysisReview)
            .frame(width: 28)
          VStack(alignment: .leading, spacing: 6) {
            Text("Butoir hors champ ?")
              .font(.subheadline.weight(.black))
            Text("Passez directement par le protocole caméra mobile : distance réelle + repères fixes + validation du bassin. N’essayez pas de forcer une grille si le butoir n’est pas visible.")
              .font(.caption)
              .foregroundStyle(Color.vaultMuted)
          }
          Spacer()
          Button {
            viewModel.selectTool(.background)
            viewModel.analysisMessage = "Mode sans butoir : placez 3 ou 4 repères fixes du décor pour stabiliser la caméra."
          } label: {
            Label("Mode sans butoir", systemImage: "camera.metering.matrix")
          }
          .buttonStyle(.bordered)
        }
        .padding(14)
        .background(Color.vaultAnalysisReview.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
      }

      physicalWorkflowStep(
        number: 1,
        title: "Définir la séquence mesurée",
        subtitle: "Choisissez une zone courte et lisible, idéalement les derniers mètres de la course.",
        isComplete: viewModel.trackingEndTime - viewModel.trackingStartTime >= 0.40
      ) {
        HStack(spacing: 10) {
          Button("Début à l’image actuelle") { viewModel.setTrackingStartHere() }
            .buttonStyle(.bordered)
          Text(String(format: "%.3f s", viewModel.trackingStartTime))
            .font(.caption.monospacedDigit().weight(.bold))
          Button("Fin à l’image actuelle") { viewModel.setTrackingEndHere() }
            .buttonStyle(.bordered)
          Text(String(format: "%.3f s", viewModel.trackingEndTime))
            .font(.caption.monospacedDigit().weight(.bold))
        }
      }

      if viewModel.physicalCameraMode == .fixedOblique {
        physicalWorkflowStep(
          number: 2,
          title: "Corriger la perspective de la piste",
          subtitle: viewModel.fixedRunwayMetricOrigin == .box
            ? "Placez quatre points AU SOL : deux sur la ligne du fond du butoir et deux à la distance connue, avec une largeur connue."
            : "Le butoir peut rester hors champ : placez quatre points AU SOL sur un rectangle réel de longueur et largeur connues. L’origine devient relative à la ligne proche.",
          isComplete: fixedGridIsValid
        ) {
          VStack(alignment: .leading, spacing: 10) {
            Picker("Origine métrique", selection: $viewModel.fixedRunwayMetricOrigin) {
              ForEach(FixedRunwayMetricOrigin.allCases) { origin in
                Text(origin.title).tag(origin)
              }
            }
            .pickerStyle(.segmented)
            .onChange(of: viewModel.fixedRunwayMetricOrigin) { _, _ in
              viewModel.motionResult = nil
              viewModel.analysisMessage = viewModel.fixedRunwayMetricOrigin == .box
                ? "Origine butoir : alignez la ligne 0,00 m sur le fond du butoir."
                : "Butoir hors champ : la vitesse reste métrique, mais l’origine X est relative à la ligne proche."
            }

            Text(viewModel.fixedRunwayMetricOrigin.explanation)
              .font(.caption)
              .foregroundStyle(viewModel.fixedRunwayMetricOrigin == .box ? Color.vaultMuted : Color.vaultAnalysisReview)

            HStack(spacing: 10) {
              Button {
                if !viewModel.isRunwayGridConfigured { viewModel.initializeManualRunwayGrid() }
                viewModel.selectTool(.calibration)
              } label: {
                Label("Placer les 4 coins au sol", systemImage: "square.on.square")
              }
              .buttonStyle(.borderedProminent)
              .tint(.vaultAnalysisAccent)

              TextField(
                "Longueur",
                value: $viewModel.runwayGrid.zoneLengthMeters,
                format: .number.precision(.fractionLength(2))
              )
              .keyboardType(.decimalPad)
              .textFieldStyle(.roundedBorder)
              .frame(width: 105)
              Text("m ×")
              TextField(
                "Largeur",
                value: $viewModel.runwayGrid.runwayWidthMeters,
                format: .number.precision(.fractionLength(2))
              )
              .keyboardType(.decimalPad)
              .textFieldStyle(.roundedBorder)
              .frame(width: 95)
              Text("m")
            }

            HStack(spacing: 10) {
              Button("5 m") { viewModel.runwayGrid.zoneLengthMeters = 5 }
                .buttonStyle(.bordered)
              Button("10 m") { viewModel.runwayGrid.zoneLengthMeters = 10 }
                .buttonStyle(.bordered)
              Button("Largeur 1,22 m") { viewModel.runwayGrid.runwayWidthMeters = 1.22 }
                .buttonStyle(.bordered)
            }

            if fixedGridIsValid {
              Label(
                viewModel.fixedRunwayMetricOrigin == .box
                  ? "Homographie fixe prête avec origine au butoir."
                  : "Homographie fixe relative prête. La vitesse est métrique ; la distance absolue au butoir reste indisponible.",
                systemImage: "checkmark.seal.fill"
              )
                .font(.caption.weight(.bold))
                .foregroundStyle(Color.vaultAnalysisAccent)
            } else {
              Label("Les quatre points doivent former un quadrilatère convexe suffisamment large sur le plan du sol.", systemImage: "exclamationmark.triangle")
                .font(.caption)
                .foregroundStyle(Color.vaultAnalysisReview)
            }
          }
        }

        physicalWorkflowStep(
          number: 3,
          title: "Choisir le point biomécanique suivi",
          subtitle: "L’homographie est exacte sur le plan du sol. Pour éviter l’erreur de parallaxe, le point au sol est recommandé.",
          isComplete: true
        ) {
          VStack(alignment: .leading, spacing: 8) {
            Picker("Point suivi", selection: $viewModel.fixedObliqueTrackingPoint) {
              ForEach(FixedObliqueTrackingPoint.allCases) { point in
                Text(point.title).tag(point)
              }
            }
            .pickerStyle(.segmented)
            Text(viewModel.fixedObliqueTrackingPoint.explanation)
              .font(.caption)
              .foregroundStyle(viewModel.fixedObliqueTrackingPoint == .pelvisEstimate ? Color.vaultAnalysisReview : Color.vaultMuted)
          }
        }

        physicalWorkflowStep(
          number: 4,
          title: viewModel.fixedObliqueTrackingPoint == .groundProjection
            ? "Confirmer le point au sol à 10 Hz"
            : "Confirmer le bassin à 10 Hz",
          subtitle: viewModel.fixedObliqueTrackingPoint == .groundProjection
            ? "Toutes les 0,1 s, placez le repère sur le sol sous le bassin ou sur l’appui visible. Le point doit rester dans le plan calibré."
            : "Toutes les 0,1 s, confirmez le bassin. Cette option est une estimation : la parallaxe due à la hauteur du bassin n’est pas éliminée.",
          isComplete: validationIsComplete
        ) {
          HStack(spacing: 10) {
            Button {
              if viewModel.pelvisValidation == nil {
                Task { await viewModel.beginPelvisValidationWorkflow() }
              } else {
                viewModel.resumePelvisValidation()
              }
            } label: {
              Label(
                viewModel.pelvisValidation == nil ? "Commencer la validation 0,1 s" : "Reprendre la validation",
                systemImage: "scope"
              )
            }
            .buttonStyle(.borderedProminent)
            .tint(.vaultAnalysisAccent)

            if let session = viewModel.pelvisValidation {
              Text("\(session.confirmedCount) / \(session.checkpoints.count)")
                .font(.subheadline.monospacedDigit().weight(.black))
            }
          }
        }

        physicalWorkflowStep(
          number: 5,
          title: "Calculer la vitesse longitudinale",
          subtitle: "Chaque point est transformé par l’homographie fixe, projeté sur l’axe longitudinal X de la piste puis dérivé avec les PTS réels. Les ruptures cinématiques majeures provoquent un rejet de la mesure.",
          isComplete: viewModel.motionResult?.measurementMode == .fixedObliqueRunway
        ) {
          HStack(spacing: 12) {
            Button {
              Task { await viewModel.analyzePhysicalMotion() }
            } label: {
              Label(
                viewModel.isAnalyzingCalibratedMotion ? "Calcul en cours…" : "Calculer la vitesse longitudinale",
                systemImage: "arrow.left.and.right"
              )
              .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(.vaultAnalysisAccent)
            .disabled(viewModel.isAnalyzingCalibratedMotion)

            Button(role: .destructive) { viewModel.resetPhysicalCalibration() } label: {
              Label("Réinitialiser", systemImage: "arrow.counterclockwise")
            }
            .buttonStyle(.bordered)
          }
        }

        Label(
          fixedModeSummary,
          systemImage: viewModel.fixedObliqueTrackingPoint == .groundProjection ? "checkmark.shield" : "exclamationmark.triangle"
        )
        .font(.caption)
        .foregroundStyle(viewModel.fixedObliqueTrackingPoint == .groundProjection ? Color.vaultMuted : Color.vaultAnalysisReview)

      } else {
        physicalWorkflowStep(
          number: 2,
          title: "Calibrer le plan de la piste",
          subtitle: "Placez quatre points sur un quadrilatère réel du sol. Une simple échelle pixels/mètre n’est pas utilisée.",
          isComplete: viewModel.isRunwayGridConfigured && viewModel.runwayGrid.isGeometricallyUsable
        ) {
          VStack(alignment: .leading, spacing: 10) {
            HStack {
              Button {
                viewModel.initializeManualRunwayGrid()
                viewModel.selectTool(.calibration)
              } label: { Label("Placer les 4 coins", systemImage: "square.grid.3x3.square") }
                .buttonStyle(.borderedProminent).tint(.vaultAnalysisAccent)
              TextField("Longueur", value: $viewModel.runwayGrid.zoneLengthMeters, format: .number.precision(.fractionLength(2)))
                .keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 110)
              Text("m")
            }
            Text("Choisissez une zone de 5 m ou 10 m dont les dimensions au sol sont réellement connues.")
              .font(.caption).foregroundStyle(Color.vaultMuted)
          }
        }

        physicalWorkflowStep(
          number: 3,
          title: "Suivre la perspective pendant le panoramique",
          subtitle: "Les repères statiques de la piste sont suivis et une homographie image → sol est recalculée au fil des PTS. Les ancrages instables sont rejetés.",
          isComplete: viewModel.dynamicCalibration?.isUsable == true
        ) {
          HStack(spacing: 10) {
            Button("Début ici") { viewModel.setTrackingStartHere() }.buttonStyle(.bordered)
            Button("Fin ici") { viewModel.setTrackingEndHere() }.buttonStyle(.bordered)
            Button { Task { await viewModel.analyzeDynamicCalibration() } } label: {
              Label(viewModel.isAnalyzingCalibration ? "Calcul…" : "Valider la perspective dynamique", systemImage: "point.3.connected.trianglepath.dotted")
            }
            .buttonStyle(.borderedProminent).tint(.vaultAnalysisAccent)
            .disabled(viewModel.isAnalyzingCalibration || !viewModel.runwayGrid.isGeometricallyUsable)
          }
        }

        physicalWorkflowStep(
          number: 4,
          title: "Identifier le perchiste",
          subtitle: "Le suivi d’identité part de l’athlète sélectionné ; la position métrique est ensuite dérivée des chevilles/appuis au sol. Le bassin n’est pas projeté silencieusement sur le sol.",
          isComplete: viewModel.selectedAthleteCandidate != nil || viewModel.trackingSeed != nil
        ) {
          HStack {
            Button { Task { await viewModel.analyzePose() } } label: { Label("Détecter les personnes", systemImage: "figure.arms.open") }
              .buttonStyle(.borderedProminent).tint(.vaultAnalysisAccent)
            if viewModel.trackingSeed != nil { Label("Athlète initialisé", systemImage: "checkmark.circle.fill").foregroundStyle(Color.vaultAnalysisAccent) }
          }
        }

        physicalWorkflowStep(
          number: 5,
          title: "Calculer la vitesse métrique",
          subtitle: "Positions au sol + homographies dynamiques + PTS réels alimentent le même moteur que le mode caméra fixe. Si la perspective est perdue, la mesure est refusée.",
          isComplete: viewModel.motionResult?.measurementMode == .dynamicRunway
        ) {
          Button { Task { await viewModel.analyzePhysicalMotion() } } label: {
            Label(viewModel.isAnalyzingMotion ? "Analyse en cours…" : "Analyser les appuis et la vitesse", systemImage: "waveform.path.ecg")
              .frame(maxWidth: .infinity)
          }
          .buttonStyle(.borderedProminent).tint(.vaultAnalysisAccent)
          .disabled(viewModel.isAnalyzingMotion)
        }

        Text("Mode mobile : aucune vitesse calibrée n’est calculée à partir d’une simple échelle pixels/mètre. Les anciens calculs stabilisés restent décodables pour les analyses enregistrées, mais ne constituent plus la source métrique active.")
          .font(.caption).foregroundStyle(Color.vaultMuted)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultCyan.opacity(0.035))
  }

  private var fixedModeSummary: String {
    let pointText = viewModel.fixedObliqueTrackingPoint == .groundProjection
      ? "point au sol"
      : "bassin estimé avec parallaxe possible"
    let originText = viewModel.fixedRunwayMetricOrigin == .box
      ? "origine absolue au fond du butoir"
      : "origine métrique relative car le butoir est hors champ"
    return "Caméra fixe + quadrilatère réel au sol + homographie fixe + \(pointText) + \(originText). Aucune stabilisation de décor n’est appliquée."
  }

  private func physicalWorkflowStep<Content: View>(
    number: Int,
    title: String,
    subtitle: String,
    isComplete: Bool,
    @ViewBuilder content: () -> Content
  ) -> some View {
    HStack(alignment: .top, spacing: 14) {
      ZStack {
        Circle()
          .fill(isComplete ? Color.vaultAnalysisAccent : Color.vaultPanelRaised)
          .frame(width: 36, height: 36)
        if isComplete {
          Image(systemName: "checkmark")
            .font(.subheadline.weight(.black))
            .foregroundStyle(Color.white)
        } else {
          Text("\(number)")
            .font(.subheadline.monospacedDigit().weight(.black))
            .foregroundStyle(Color.vaultText)
        }
      }

      VStack(alignment: .leading, spacing: 8) {
        Text(title)
          .font(.headline.weight(.black))
        Text(subtitle)
          .font(.footnote)
          .foregroundStyle(Color.vaultMuted)
        content()
      }
      .frame(maxWidth: .infinity, alignment: .leading)
    }
    .padding(14)
    .background(Color.vaultPanelRaised.opacity(0.72), in: RoundedRectangle(cornerRadius: 16))
  }

  private func motionSpeedSummaryCard(_ result: MotionAnalysisResult) -> some View {
    let current = viewModel.currentMotionSample
    return VStack(alignment: .leading, spacing: 14) {
      HStack {
        VStack(alignment: .leading, spacing: 3) {
          SectionEyebrow(text: "Résultat cinématique")
          Text("Vitesse mesurée")
            .font(.title3.weight(.black))
        }
        Spacer()
        Label(
          String(format: "Qualité %.0f %%", result.averageConfidence * 100),
          systemImage: "checkmark.shield"
        )
        .font(.caption.monospacedDigit().weight(.bold))
        .foregroundStyle(Color.vaultMuted)
      }

      HStack(spacing: 12) {
        speedValueTile(
          title: (result.measurementMode == .calibratedManual || result.measurementMode == .fixedObliqueRunway || result.measurementMode == .dynamicRunway)
            ? "Moyenne de zone" : "Représentative",
          value: result.representativeHorizontalSpeed,
          symbol: "figure.run"
        )
        speedValueTile(title: "Pic P95", value: result.peakHorizontalSpeed, symbol: "speedometer")
        if let current {
          speedValueTile(title: "Au curseur", value: abs(current.horizontalVelocity), symbol: "scope")
        }
      }

      Text("Les vitesses sont affichées ici dès qu’un calcul est disponible ; le repère de suivi sur la vidéo affiche également la vitesse longitudinale au curseur.")
        .font(.caption)
        .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultAnalysisAccent.opacity(0.045))
  }

  private func speedValueTile(title: String, value: Double, symbol: String) -> some View {
    HStack(spacing: 10) {
      Image(systemName: symbol)
        .font(.headline.weight(.bold))
        .foregroundStyle(Color.vaultAnalysisAccent)
      VStack(alignment: .leading, spacing: 2) {
        Text(title.uppercased())
          .font(.caption2.weight(.black))
          .tracking(0.7)
          .foregroundStyle(Color.vaultMuted)
        Text(String(format: "%.2f m/s", value))
          .font(.title3.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultText)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding(12)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
  }

  private var nerdStatsPanel: some View {
    let sample = viewModel.currentMotionSample
    return VStack(alignment: .leading, spacing: 16) {
      HStack {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Mesures avancées · temps réel")
          Text("Cinématique au curseur")
            .font(.title3.weight(.black))
        }
        Spacer()
        if let result = viewModel.motionResult {
          Text(String(format: "Score qualité %.0f %% · non probabiliste", result.averageConfidence * 100))
            .font(.caption.monospacedDigit().weight(.bold))
            .foregroundStyle(Color.vaultMuted)
        }
      }

      if let result = viewModel.motionResult {
        Label(
          result.measurementMode?.title ?? "Analyse vidéo",
          systemImage: result.measurementMode == .calibratedManual
            ? "ruler.fill"
            : (result.measurementMode == .athleteScale ? "person.crop.rectangle" : "grid")
        )
        .font(.caption.weight(.bold))
        .foregroundStyle(result.measurementMode == .athleteScale ? Color.vaultAnalysisReview : Color.vaultAnalysisAccent)

        if result.pelvisValidation?.isComplete == true {
          Label(
            result.measurementMode == .fixedObliqueRunway && viewModel.fixedObliqueTrackingPoint == .groundProjection
              ? "Point au sol confirmé à 10 Hz"
              : "Bassin confirmé à 10 Hz",
            systemImage: "checkmark.shield.fill"
          )
          .font(.caption.weight(.black))
          .foregroundStyle(Color.vaultAnalysisAccent)
        }

        if let reference = result.referenceDescription {
          Text(reference)
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        }

        let elapsed = max(result.endTime - result.startTime, 0.001)
        let effectiveAnalysisRate = Double(max(result.samples.count - 1, 0)) / elapsed
        Text(String(format: "Cadence PTS médiane %.2f fps · lecture %.2g× · analyse effective %.2f fps · %d échantillons", viewModel.frameRate, viewModel.playbackRate, effectiveAnalysisRate, result.samples.count))
          .font(.caption.monospacedDigit())
          .foregroundStyle(Color.vaultMuted)
      }

      LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
        nerdMetric("Vitesse longitudinale", value: sample?.horizontalVelocity, unit: "m/s", symbol: "arrow.left.and.right")
        nerdMetric(
          "Accélération longitudinale",
          value: sample?.horizontalAcceleration ?? sample?.acceleration,
          unit: "m/s²",
          symbol: "speedometer"
        )
      }

      if sample?.verticalIsEstimated == true {
        DisclosureGroup("Estimations 2D secondaires") {
          LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            nerdMetric("Projection verticale estimée", value: sample?.verticalVelocity, unit: "m/s", symbol: "arrow.up.and.down")
            nerdMetric("Résultante 2D indicative", value: sample?.resultantVelocity, unit: "m/s", symbol: "arrow.up.right")
          }
          .padding(.top, 10)
          Text("Ces valeurs ne représentent pas une vitesse 3D du centre de masse et ne doivent pas être comparées à une mesure laboratoire.")
            .font(.caption)
            .foregroundStyle(Color.vaultAnalysisReview)
        }
        .font(.caption.weight(.bold))
      }

      if let result = viewModel.motionResult {
        Divider().overlay(Color.vaultLine)
        HStack {
          VStack(alignment: .leading, spacing: 4) {
            Text((result.measurementMode == .calibratedManual || result.measurementMode == .fixedObliqueRunway || result.measurementMode == .dynamicRunway) ? "VITESSE MOYENNE DE ZONE" : "VITESSE REPRÉSENTATIVE")
              .font(.caption2.weight(.black))
              .tracking(1)
              .foregroundStyle(Color.vaultMuted)
            Text(String(format: "%.2f m/s", result.representativeHorizontalSpeed))
              .font(.title2.monospacedDigit().weight(.black))
              .foregroundStyle(Color.vaultAnalysisAccent)
          }
          Spacer()
          VStack(alignment: .trailing, spacing: 4) {
            Text("PIC HORIZONTAL")
              .font(.caption2.weight(.black))
              .tracking(1)
              .foregroundStyle(Color.vaultMuted)
            Text(String(format: "%.2f m/s", result.peakHorizontalSpeed))
              .font(.headline.monospacedDigit().weight(.black))
          }
        }
      } else {
        Text("Sélectionnez le perchiste. Vous pouvez ensuite utiliser la grille de piste ou le mode automatique sans butoir.")
          .font(.footnote)
          .foregroundStyle(Color.vaultMuted)
      }

      if sample?.verticalIsEstimated == true {
        Label(
          viewModel.motionResult?.measurementMode == .calibratedManual
            ? "La vitesse horizontale utilise une distance réelle et des repères fixes suivis dans le décor. La composante verticale reste une projection 2D."
            : (viewModel.motionResult?.measurementMode == .athleteScale
              ? "La composante verticale et l’échelle métrique sont estimées à partir du sujet sélectionné. Le panoramique est compensé par le suivi robuste du décor."
              : "La caméra est compensée par l’homographie dynamique de la piste. Si le point suivi est le bassin/torse, il reste hors du plan du sol : une parallaxe résiduelle est possible."),
          systemImage: "exclamationmark.triangle"
        )
        .font(.caption)
        .foregroundStyle(Color.vaultAnalysisReview)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultCyan.opacity(0.04))
  }

  @ViewBuilder
  private var takeoffActionButtons: some View {
    Button {
      viewModel.selectTool(.takeoff)
    } label: {
      Label("Placer le dernier appui", systemImage: "scope")
    }
    .buttonStyle(.borderedProminent)
    .tint(.vaultAnalysisAccent)

    Button {
      Task { await viewModel.proposeTakeoffFootForSelectedAthlete() }
    } label: {
      Label(
        viewModel.isAnalyzingPose ? "Recherche du pied…" : "Proposer le pied du perchiste",
        systemImage: "figure.walk.motion"
      )
    }
    .buttonStyle(.bordered)
    .disabled(viewModel.isAnalyzingPose)

    Button {
      viewModel.validateTakeoffWithoutMetricOrigin()
    } label: {
      Label("Valider l’impulsion sans distance", systemImage: "checkmark.circle")
    }
    .buttonStyle(.bordered)
    .disabled(viewModel.takeoffPoint == nil)

    Button("Calculer depuis le butoir") {
      viewModel.measureTakeoff()
    }
    .buttonStyle(.borderedProminent)
    .tint(.vaultAnalysisAccent)
    .disabled(viewModel.takeoffPoint == nil || viewModel.dynamicCalibration?.isUsable != true)
  }

  private func nerdMetric(_ title: String, value: Double?, unit: String, symbol: String) -> some View {
    VStack(alignment: .leading, spacing: 8) {
      Label(title, systemImage: symbol)
        .font(.caption.weight(.bold))
        .foregroundStyle(Color.vaultMuted)
      Text(value.map { String(format: "%+.2f %@", $0, unit) } ?? "—")
        .font(.title3.monospacedDigit().weight(.black))
        .foregroundStyle(Color.vaultText)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .padding(14)
    .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 14))
  }

  private var pelvisValidationPanel: some View {
    VStack(alignment: .leading, spacing: 16) {
      HStack(alignment: .top) {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Contrôle qualité · 10 Hz")
          Text(viewModel.physicalCameraMode == .fixedOblique && viewModel.fixedObliqueTrackingPoint == .groundProjection
            ? "Confirmer le point au sol toutes les 0,1 seconde"
            : "Confirmer le bassin toutes les 0,1 seconde")
            .font(.title3.weight(.black))
          Text(viewModel.physicalCameraMode == .fixedOblique && viewModel.fixedObliqueTrackingPoint == .groundProjection
            ? "Le suivi propose le bassin comme repère visuel. Déplacez le point sur le SOL sous le bassin ou sur l’appui visible, confirmez, puis l’application avance de 0,1 s."
            : "Le suivi automatique propose un point. Déplacez-le sur le centre du bassin, confirmez, puis l’application avance automatiquement de 0,1 s.")
            .font(.footnote)
            .foregroundStyle(Color.vaultMuted)
        }
        Spacer()
        if viewModel.isAnalyzingCalibratedMotion || viewModel.isAnalyzingPose { ProgressView() }
      }

      if let session = viewModel.pelvisValidation {
        HStack(spacing: 14) {
          ProgressView(value: session.progress)
            .tint(.vaultAnalysisAccent)
          Text("\(session.confirmedCount) / \(session.checkpoints.count)")
            .font(.subheadline.monospacedDigit().weight(.black))
            .foregroundStyle(session.isComplete ? Color.vaultAnalysisAccent : Color.vaultText)
        }

        if let checkpoint = viewModel.currentPelvisCheckpoint {
          HStack(alignment: .center, spacing: 14) {
            VStack(alignment: .leading, spacing: 4) {
              Text("POINT ACTUEL")
                .font(.caption2.weight(.black))
                .tracking(1)
                .foregroundStyle(Color.vaultMuted)
              Text(String(format: "%.2f s · point %d/%d", checkpoint.timeSeconds, viewModel.pelvisCheckpointIndex + 1, session.checkpoints.count))
                .font(.title3.monospacedDigit().weight(.black))
              Text(checkpoint.state.title)
                .font(.caption.weight(.bold))
                .foregroundStyle(checkpoint.isConfirmed ? Color.vaultAnalysisAccent : Color.vaultAnalysisReview)
            }
            Spacer()
            Button {
              viewModel.movePelvisCheckpoint(by: -1)
            } label: {
              Label("Précédent", systemImage: "chevron.left")
            }
            .buttonStyle(.bordered)
            .disabled(viewModel.pelvisCheckpointIndex == 0)

            if viewModel.canRefineValidationPointWithVision {
              Button {
                Task { await viewModel.refineCurrentPelvisSuggestion() }
              } label: {
                Label("Reproposer avec Vision", systemImage: "figure.arms.open")
              }
              .buttonStyle(.bordered)
              .disabled(viewModel.isAnalyzingPose)
            }

            Button {
              viewModel.confirmCurrentPelvisCheckpoint()
            } label: {
              Label("Confirmer et avancer", systemImage: "checkmark.circle.fill")
            }
            .buttonStyle(.borderedProminent)
            .tint(.vaultAnalysisAccent)

            Button {
              viewModel.movePelvisCheckpoint(by: 1)
            } label: {
              Label("Suivant", systemImage: "chevron.right")
            }
            .buttonStyle(.bordered)
            .disabled(viewModel.pelvisCheckpointIndex >= session.checkpoints.count - 1)
          }
        }

        pelvisCheckpointStrip(session)

        HStack(spacing: 10) {
          Button {
            viewModel.resumePelvisValidation()
          } label: {
            Label("Reprendre la validation", systemImage: "scope")
          }
          .buttonStyle(.bordered)

          Button {
            Task { await viewModel.analyzeCalibratedManualMotion() }
          } label: {
            Label(
              viewModel.isAnalyzingCalibratedMotion ? "Calcul physique…" : "Calculer avec l’échelle réelle",
              systemImage: "waveform.path.ecg"
            )
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAnalysisAccent)
          .disabled(viewModel.isAnalyzingCalibratedMotion || !session.isComplete)

          Spacer()

          Button(role: .destructive) {
            viewModel.clearPelvisValidation()
          } label: {
            Label("Effacer les confirmations", systemImage: "trash")
          }
          .buttonStyle(.bordered)
        }

        if !session.isComplete {
          Label(
            "Les statistiques ne seront remplacées qu’après confirmation des \(session.checkpoints.count) positions. Les points violets restent à vérifier.",
            systemImage: "exclamationmark.triangle"
          )
          .font(.caption)
          .foregroundStyle(Color.vaultAnalysisReview)
        } else {
          Label(
            "Validation complète. Le calcul final utilise la distance réelle, les repères fixes du décor et une régression polynomiale locale pour éviter les accélérations aberrantes.",
            systemImage: "checkmark.shield.fill"
          )
          .font(.caption)
          .foregroundStyle(Color.vaultAnalysisAccent)
        }
      } else {
        HStack(alignment: .center, spacing: 18) {
          Image(systemName: "scope")
            .font(.system(size: 32, weight: .bold))
            .foregroundStyle(Color.vaultAnalysisAccent)
            .frame(width: 58, height: 58)
            .background(Color.vaultCyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 16))
          VStack(alignment: .leading, spacing: 5) {
            Text("Après le calcul automatique sans butoir")
              .font(.headline.weight(.black))
            Text("Créez une image de contrôle tous les 0,1 s. Cette étape corrige les pertes de suivi, les confusions avec la perche et les sauts de squelette.")
              .font(.footnote)
              .foregroundStyle(Color.vaultMuted)
          }
          Spacer()
          Button {
            viewModel.preparePelvisValidation(athleteHeightCM: analysisAthleteHeightCM)
          } label: {
            Label("Créer les points 0,1 s", systemImage: "timeline.selection")
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAnalysisAccent)
          .disabled(viewModel.motionResult == nil || viewModel.isAnalyzingBoxlessMotion)
        }
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard(background: Color.vaultCyan.opacity(0.035))
  }

  private func pelvisCheckpointStrip(_ session: PelvisValidationSession) -> some View {
    ScrollView(.horizontal, showsIndicators: false) {
      HStack(spacing: 7) {
        ForEach(Array(session.checkpoints.enumerated()), id: \.element.id) { index, checkpoint in
          Button {
            viewModel.jumpToPelvisCheckpoint(index)
          } label: {
            VStack(spacing: 4) {
              Circle()
                .fill(pelvisCheckpointColor(checkpoint, index: index))
                .frame(width: index == viewModel.pelvisCheckpointIndex ? 16 : 11, height: index == viewModel.pelvisCheckpointIndex ? 16 : 11)
                .overlay {
                  if index == viewModel.pelvisCheckpointIndex {
                    Circle().stroke(Color.white, lineWidth: 2)
                  }
                }
              Text(String(format: "+%.1f", checkpoint.timeSeconds - session.startTime))
                .font(.caption2.monospacedDigit())
                .foregroundStyle(Color.vaultMuted)
            }
            .padding(.vertical, 4)
          }
          .buttonStyle(.plain)
          .accessibilityLabel(String(format: "Bassin à %.1f seconde", checkpoint.timeSeconds))
        }
      }
      .padding(.horizontal, 2)
    }
  }

  private func pelvisCheckpointColor(_ checkpoint: PelvisCheckpoint, index: Int) -> Color {
    if index == viewModel.pelvisCheckpointIndex { return .vaultAnalysisAccent }
    switch checkpoint.state {
    case .pending: return .vaultAnalysisReview
    case .confirmed: return .vaultCyan
    case .adjusted: return .vaultAnalysisAccent
    }
  }

  private var motionAnalysisPanel: some View {
    VStack(alignment: .leading, spacing: 16) {
      HStack {
        VStack(alignment: .leading, spacing: 4) {
          SectionEyebrow(text: "Mesures biomécaniques")
          Text("Vitesse et marque d’impulsion")
            .font(.title3.weight(.black))
        }
        Spacer()
        if viewModel.isAnalyzingMotion || viewModel.isAnalyzingBoxlessMotion { ProgressView() }
      }

      VStack(alignment: .leading, spacing: 10) {
        Label("1. Définir la zone finale", systemImage: "timeline.selection")
          .font(.subheadline.weight(.bold))
        HStack {
          Button("Début ici") { viewModel.setTrackingStartHere() }
            .buttonStyle(.bordered)
          Text(String(format: "%.3f s", viewModel.trackingStartTime))
            .font(.caption.monospacedDigit().weight(.bold))
          Button("Fin ici") { viewModel.setTrackingEndHere() }
            .buttonStyle(.bordered)
          Text(String(format: "%.3f s", viewModel.trackingEndTime))
            .font(.caption.monospacedDigit().weight(.bold))
        }
      }

      Divider().overlay(Color.vaultLine)

      VStack(alignment: .leading, spacing: 10) {
        Label("2. Sélectionner le perchiste", systemImage: "person.crop.rectangle")
          .font(.subheadline.weight(.bold))
        HStack {
          Button {
            Task { await viewModel.analyzePose() }
          } label: {
            Label(
              viewModel.isAnalyzingPose ? "Détection…" : "Détecter toutes les personnes",
              systemImage: "person.3.sequence"
            )
          }
          .buttonStyle(.borderedProminent)
          .tint(.vaultAnalysisAccent)
          .disabled(viewModel.isAnalyzingPose)

          Button {
            viewModel.useDetectedPelvisForTracking()
          } label: {
            Label("Utiliser son bassin", systemImage: "scope")
          }
          .buttonStyle(.bordered)
          .disabled(viewModel.selectedAthleteCandidate == nil)
        }

        if viewModel.poseCandidates.count > 1, viewModel.selectedAthleteCandidate == nil {
          Label(
            "Touchez directement le cadre numéroté du perchiste sur la vidéo.",
            systemImage: "hand.tap"
          )
          .font(.caption.weight(.semibold))
          .foregroundStyle(Color.vaultAnalysisReview)
        } else if let candidate = viewModel.selectedAthleteCandidate {
          Label(
            String(format: "Perchiste sélectionné · score qualité %.0f %%", candidate.confidence * 100),
            systemImage: "checkmark.circle.fill"
          )
          .font(.caption.weight(.semibold))
          .foregroundStyle(Color.vaultAnalysisAccent)
        }
      }

      VStack(alignment: .leading, spacing: 10) {
        Label("3. Calculer les Mesures avancées", systemImage: "waveform.path.ecg.rectangle")
          .font(.subheadline.weight(.bold))

        HStack(spacing: 10) {
          VStack(alignment: .leading, spacing: 4) {
            Text("TAILLE UTILISÉE POUR L’ÉCHELLE")
              .font(.caption2.weight(.black))
              .tracking(0.8)
              .foregroundStyle(Color.vaultMuted)
            TextField(
              "Ex. 180",
              value: $analysisAthleteHeightCM,
              format: .number.precision(.fractionLength(0))
            )
            .keyboardType(.numberPad)
            .textFieldStyle(.roundedBorder)
            .focused($analysisHeightFieldFocused)
            .frame(width: 150)
          }
          Text("cm")
            .font(.subheadline.weight(.bold))
            .foregroundStyle(Color.vaultMuted)
          if let profileHeight = athlete?.heightCM, profileHeight >= 120 {
            Button("Utiliser le profil (\(Int(profileHeight)) cm)") {
              analysisAthleteHeightCM = profileHeight
            }
            .buttonStyle(.bordered)
          }
          Spacer()
        }

        if analysisAthleteHeightCM < 120 || analysisAthleteHeightCM > 230 {
          Label(
            "Saisissez la taille réelle entre 120 et 230 cm. Le bouton reste accessible et expliquera toute donnée manquante.",
            systemImage: "ruler"
          )
          .font(.caption.weight(.semibold))
          .foregroundStyle(Color.vaultAnalysisReview)
        }

        Button {
          if analysisAthleteHeightCM < 120 || analysisAthleteHeightCM > 230 {
            analysisHeightFieldFocused = true
            viewModel.analysisMessage = "Renseignez la taille réelle de l’athlète pour lancer le calcul sans butoir."
            Haptics.warning()
          } else {
            Task { await viewModel.analyzeMotionWithoutBox(athleteHeightCM: analysisAthleteHeightCM) }
          }
        } label: {
          Label(
            viewModel.isAnalyzingBoxlessMotion
              ? "Stabilisation automatique…"
              : "Calcul automatique sans butoir",
            systemImage: "camera.metering.matrix"
          )
          .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(.vaultAnalysisAccent)
        .disabled(viewModel.isAnalyzingBoxlessMotion)

        Text("Ce mode compense le panoramique avec le décor et utilise la taille renseignée dans le profil comme échelle dynamique. Il calcule la vitesse sans voir le butoir, mais pas la distance absolue d’impulsion.")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)

        Button {
          Task { await viewModel.analyzeMotion() }
        } label: {
          Label(
            viewModel.isAnalyzingMotion ? "Calcul grille…" : "Calcul de précision avec grille de piste",
            systemImage: "grid"
          )
          .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
        .disabled(
          viewModel.isAnalyzingMotion || viewModel.trackingSeed == nil
            || viewModel.dynamicCalibration?.isUsable != true
            || viewModel.trackingEndTime <= viewModel.trackingStartTime
        )
      }

      Divider().overlay(Color.vaultLine)

      VStack(alignment: .leading, spacing: 10) {
        Label("4. Mesurer la marque d’impulsion", systemImage: "shoeprints.fill")
          .font(.subheadline.weight(.bold))
        Picker("Convention", selection: $viewModel.takeoffConvention) {
          ForEach(TakeoffContactConvention.allCases) { convention in
            Text(convention.title).tag(convention)
          }
        }
        .pickerStyle(.segmented)

        ViewThatFits(in: .horizontal) {
          HStack(spacing: 10) { takeoffActionButtons }
          VStack(alignment: .leading, spacing: 10) { takeoffActionButtons }
        }

        if viewModel.dynamicCalibration?.isUsable != true {
          Label(
            "Sans grille, validez l’image d’impulsion pour les phases et les angles. La distance absolue depuis le butoir restera indisponible.",
            systemImage: "info.circle"
          )
          .font(.caption)
          .foregroundStyle(Color.vaultAnalysisReview)
        }

        if let measurement = viewModel.takeoffMeasurement {
          HStack {
            VStack(alignment: .leading, spacing: 3) {
              Text("MARQUE D’IMPULSION")
                .font(.caption2.weight(.black))
                .tracking(1)
                .foregroundStyle(Color.vaultMuted)
              Text(measurement.formattedDistance)
                .font(.title3.monospacedDigit().weight(.black))
                .foregroundStyle(Color.vaultAnalysisAccent)
            }
            Spacer()
            Text(measurement.status.title)
              .font(.caption.weight(.bold))
              .padding(.horizontal, 10)
              .padding(.vertical, 6)
              .background(Color.vaultCyan.opacity(0.12), in: Capsule())
          }
          Button(action: saveTakeoffMeasurementToProfile) {
            Label("Enregistrer dans la progression", systemImage: "ruler.fill")
          }
          .buttonStyle(.bordered)
        }
      }

      if viewModel.motionResult != nil {
        Button(action: saveVideoSpeedToProfile) {
          Label("Enregistrer la vitesse d’élan actuelle", systemImage: "person.crop.circle.badge.checkmark")
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
      }

      Text("La distance d’impulsion est métrique sur le plan de la piste. Les angles aériens restent des angles 2D projetés. La vitesse verticale est signalée comme estimation monoculaire.")
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var vectorInspector: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        SectionEyebrow(text: "Vecteurs")
        Spacer()
        Text("\(viewModel.vectors.count)")
          .font(.headline.monospacedDigit().weight(.black))
          .foregroundStyle(Color.vaultMuted)
      }

      if viewModel.vectors.isEmpty {
        Text("Choisissez Vecteur, mettez la vidéo en pause puis faites glisser sur l’image.")
          .font(.subheadline)
          .foregroundStyle(Color.vaultMuted)
      } else {
        ForEach($viewModel.vectors) { $vector in
          Button {
            viewModel.selectedVectorID = vector.id
            viewModel.seek(to: vector.timeSeconds)
            viewModel.selectTool(.select)
          } label: {
            HStack(spacing: 12) {
              Image(systemName: "arrow.up.right")
                .foregroundStyle(vector.source == "ai" ? Color.vaultCyan : Color.vaultAnalysisAccent)
              VStack(alignment: .leading, spacing: 3) {
                TextField("Nom du vecteur", text: $vector.label)
                  .font(.subheadline.weight(.bold))
                  .textFieldStyle(.plain)
                Text(String(format: "%.3f s · %.0f° · %@", vector.timeSeconds, vector.angleDegrees, vector.kind.title))
                  .font(.caption.monospacedDigit())
                  .foregroundStyle(Color.vaultMuted)
              }
              Spacer()
              if viewModel.selectedVectorID == vector.id {
                Image(systemName: "checkmark.circle.fill")
                  .foregroundStyle(Color.vaultAnalysisAccent)
              }
            }
            .padding(10)
            .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12))
          }
          .buttonStyle(.plain)
        }
      }

      Label(
        "L’étalonnage transforme les déplacements de suivi en mètres. Les vecteurs manuels restent des annotations sauf s’ils sont explicitement reliés à une mesure.",
        systemImage: "ruler"
      )
      .font(.footnote)
      .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var phaseInspector: some View {
    VStack(alignment: .leading, spacing: 14) {
      SectionEyebrow(text: "Phases du saut")
      Picker("Phase", selection: $viewModel.currentPhase) {
        ForEach(VaultPhase.allCases) { phase in
          Text(phase.title).tag(phase)
        }
      }
      .pickerStyle(.segmented)

      Button { viewModel.addPhaseMarker() } label: {
        Label("Marquer \(viewModel.currentPhase.title) sur cette image", systemImage: "mappin.and.ellipse")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.borderedProminent)
      .tint(.vaultAnalysisAccent)

      ForEach(viewModel.phaseMarkers) { marker in
        Button { viewModel.seek(to: marker.timeSeconds) } label: {
          HStack {
            Text(marker.phase.title).font(.subheadline.weight(.bold))
            Spacer()
            Text(String(format: "%.3f s", marker.timeSeconds))
              .font(.subheadline.monospacedDigit())
              .foregroundStyle(Color.vaultMuted)
          }
          .padding(10)
          .background(Color.vaultPanelRaised, in: RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
      }

      Divider().overlay(Color.vaultLine)

      Button {
        Task { await viewModel.analyzePose() }
      } label: {
        Label(
          viewModel.isAnalyzingPose ? "Analyse…" : "Détecter la posture sur cette image",
          systemImage: "figure.arms.open"
        )
        .frame(maxWidth: .infinity)
      }
      .buttonStyle(.bordered)
      .disabled(viewModel.isAnalyzingPose)

      if viewModel.poseCandidates.count > 1 {
        Text("Plusieurs personnes ont été détectées. Sélectionnez le perchiste sur l’image avant de lire les angles.")
          .font(.caption.weight(.semibold))
          .foregroundStyle(Color.vaultAnalysisReview)
      }

      if !viewModel.biomechanicalAngles.isEmpty {
        Divider().overlay(Color.vaultLine)
        Text("ANGLES PROJETÉS 2D")
          .font(.caption2.weight(.black))
          .tracking(1)
          .foregroundStyle(Color.vaultMuted)
        VStack(spacing: 10) {
          AngleAccordion(
            title: "Membres inférieurs",
            angles: angleGroup(keywords: ["Genou", "Hanche", "Cheville"])
          )
          AngleAccordion(
            title: "Haut du corps",
            angles: angleGroup(keywords: ["Coude", "Épaule", "Bras"])
          )
          AngleAccordion(
            title: "Axes techniques",
            angles: viewModel.biomechanicalAngles.filter { angle in
              !["Genou", "Hanche", "Cheville", "Coude", "Épaule", "Bras"]
                .contains(where: { angle.title.localizedCaseInsensitiveContains($0) })
            }
          )
        }
      }

      Text("Les points corporels sont calculés localement avec Apple Vision. Les angles sont des projections 2D, avec incertitude angulaire non calibrée. Ne comparez pas directement deux angles issus de prises de vue différentes sans géométrie caméra équivalente.")
        .font(.footnote)
        .foregroundStyle(Color.vaultMuted)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .vaultCard()
  }

  private var videoCommentsPanel: some View {
    VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Commentaires d’analyse")
      VaultCommentEditor(
        text: Binding(
          get: { currentClip?.analysisNotes ?? "" },
          set: { currentClip?.analysisNotes = $0 }
        ),
        placeholder: "Repères techniques, contexte de la séance, observations sur la présentation, l’impulsion, le renversement et la comparaison…",
        minHeight: 230
      )
      Button {
        currentClip?.updatedAt = .now
        PersistenceIssueCenter.shared.save(modelContext)
        Haptics.success()
      } label: {
        Label("Enregistrer les commentaires", systemImage: "text.bubble.fill")
      }
      .buttonStyle(.bordered)
    }
    .vaultCard()
  }

  private var clipLibrary: some View {
    VStack(alignment: .leading, spacing: 12) {
      SectionEyebrow(text: "Vidéothèque locale")
      ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 12) {
          ForEach(athleteClips) { clip in
            VStack(alignment: .leading, spacing: 8) {
              HStack {
                Image(systemName: "video.fill")
                  .font(.title2)
                  .foregroundStyle(currentClipID == clip.id ? Color.vaultAnalysisAccent : Color.vaultMuted)
                Spacer()
                Button(role: .destructive) {
                  clipPendingDeletion = clip
                } label: {
                  Image(systemName: "trash")
                    .font(.subheadline.weight(.bold))
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Retirer la vidéo")
              }
              Text(clip.originalFilename)
                .font(.subheadline.weight(.bold))
                .lineLimit(1)
              Text(String(format: "%.2f s · %.0f fps", clip.durationSeconds, clip.frameRate))
                .font(.caption.monospacedDigit())
                .foregroundStyle(Color.vaultMuted)
            }
            .frame(width: 210, alignment: .leading)
            .vaultCard(
              background: currentClipID == clip.id ? Color.vaultAnalysisAccent.opacity(0.07) : .vaultPanel
            )
            .contentShape(Rectangle())
            .onTapGesture { loadClip(clip) }
            .contextMenu {
              Button { loadClip(clip) } label: {
                Label("Ouvrir en vidéo principale", systemImage: "play.rectangle")
              }
              if currentClipID != clip.id {
                Button {
                  comparisonClipID = clip.id
                  loadComparisonClip(clip)
                } label: {
                  Label("Utiliser pour comparer", systemImage: "rectangle.split.2x1")
                }
              }
              Button {
                relinkClipID = clip.id
                fileImportRequest = .relink(clip.id)
                showingFileImporter = true
              } label: {
                Label("Relier le fichier source", systemImage: "link")
              }
              Divider()
              Button(role: .destructive) {
                clipPendingDeletion = clip
              } label: {
                Label("Retirer la vidéo", systemImage: "trash")
              }
            }
          }
        }
      }
    }
  }

  private func stopRemoteRecordingAndImport() {
    Task { await remoteCamera.stopRecording() }
  }

  private func importPendingRemoteRecording() {
    Task { await importPendingRemoteRecordingAsync() }
  }

  @MainActor
  private func importPendingRemoteRecordingAsync() async {
    do {
      let existingIDs = successfullyImportedRemoteIDs
      let (asset, manifest, endpoint) = try await remoteCamera.importPending(existingRemoteIDs: existingIDs)
      await registerAndLoadVideo(
        asset: asset,
        originalFilename: manifest.filename,
        remoteManifest: manifest,
        remoteEndpoint: endpoint
      )
    } catch RemoteCameraError.duplicateRecording {
      if let recordingID = remoteCamera.pendingManifest?.recordingID {
        await remoteCamera.confirmImported(recordingID: recordingID)
      }
    } catch {
      importError = error.localizedDescription
      Haptics.error()
    }
  }

  private func handleCameraCapture(_ source: URL) {
    Task {
      do {
        let asset = try await VideoAssetStore.shared.importVideo(from: source)
        await registerAndLoadVideo(
          asset: asset,
          originalFilename: "Vidéo de piste \(Date().formatted(date: .abbreviated, time: .shortened))"
        )
      } catch {
        await MainActor.run {
          importError = error.localizedDescription
          Haptics.error()
        }
      }
    }
  }

  private func importPhotoItem(_ item: PhotosPickerItem) async {
    do {
      guard let movie = try await item.loadTransferable(type: MovieTransferable.self) else {
        throw CocoaError(.fileReadUnknown)
      }
      let asset = try await VideoAssetStore.shared.importVideo(from: movie.url)
      await registerAndLoadVideo(asset: asset, originalFilename: item.itemIdentifier ?? "Vidéo importée")
    } catch {
      importError = error.localizedDescription
      Haptics.error()
    }
  }

  private func handleFileImport(_ result: Result<[URL], Error>) {
    let request = fileImportRequest
    let source: URL

    switch result {
    case .success(let urls):
      guard let first = urls.first else {
        importError = VideoFileImportError.emptySelection.localizedDescription
        Haptics.error()
        return
      }
      source = first
    case .failure(let error):
      let cocoaError = error as NSError
      if cocoaError.domain == NSCocoaErrorDomain && cocoaError.code == NSUserCancelledError {
        return
      }
      importError = error.localizedDescription
      Haptics.error()
      return
    }

    let accessing = source.startAccessingSecurityScopedResource()

    Task { @MainActor in
      defer {
        if accessing { source.stopAccessingSecurityScopedResource() }
      }

      do {
        switch request {
        case .newVideo:
          let asset = try await VideoAssetStore.shared.importVideo(from: source)
          await registerAndLoadVideo(asset: asset, originalFilename: source.lastPathComponent)

        case .relink(let clipID):
          guard let clip = athleteClips.first(where: { $0.id == clipID }) else {
            throw VideoFileImportError.missingRelinkTarget
          }

          if let expected = clip.fileSHA256,
            !(await VideoAssetStore.shared.matchesSHA256(url: source, expected: expected))
          {
            importError = "Ce fichier ne correspond pas à la vidéo source d’origine. Vérifiez votre sélection."
            Haptics.error()
            return
          }

          let asset = try await VideoAssetStore.shared.importVideo(from: source)
          clip.mediaStorageKey = asset.storageKey
          clip.fileSHA256 = asset.sha256
          clip.localURLString = ""
          clip.updatedAt = .now
          do {
            try modelContext.save()
            relinkClipID = nil
            loadClip(clip)
            Haptics.success()
          } catch {
            importError = "Impossible de relier la vidéo : \(error.localizedDescription)"
            Haptics.error()
          }
        }
      } catch {
        importError = error.localizedDescription
        Haptics.error()
      }
    }
  }

  @MainActor
  @discardableResult
  private func registerAndLoadVideo(
    asset: ImportedVideoAsset,
    originalFilename: String,
    remoteManifest: RemoteRecordingManifest? = nil,
    remoteEndpoint: RemoteCameraEndpoint? = nil
  ) async -> Bool {
    guard let athlete else { return false }

    var remoteValidation: VideoMediaValidation?
    if remoteManifest != nil {
      do {
        remoteValidation = try await VideoAssetStore.shared.validatePlayableVideo(at: asset.url)
      } catch {
        importError = "Le transfert est intact, mais la vidéo ne peut pas être ouverte par AVFoundation : \(error.localizedDescription)"
        Haptics.error()
        return false
      }
    }

    await viewModel.load(url: asset.url)

    if let remoteManifest,
       let existing = athleteClips.first(where: { $0.remoteRecordingID == remoteManifest.recordingID })
    {
      let oldStorageKey = existing.mediaStorageKey
      let oldSHA = existing.fileSHA256
      existing.mediaStorageKey = asset.storageKey
      existing.fileSHA256 = asset.sha256
      existing.originalFilename = originalFilename
      existing.sourceDeviceName = remoteEndpoint?.name ?? "Pixel"
      existing.sourceCameraDescription = remoteManifest.lensLabel
      existing.sourceResolution = "\(remoteManifest.width)×\(remoteManifest.height)"
      existing.remoteCreationTime = remoteManifest.createdAt
      existing.remoteOrientation = remoteManifest.orientation
      existing.durationSeconds = remoteValidation?.durationSeconds ?? remoteManifest.durationSeconds
      existing.frameRate = remoteManifest.nominalFPS > 0
        ? remoteManifest.nominalFPS
        : (remoteValidation?.nominalFrameRate ?? existing.frameRate)
      existing.updatedAt = .now

      do {
        try modelContext.save()
      } catch {
        existing.mediaStorageKey = oldStorageKey
        existing.fileSHA256 = oldSHA
        try? await VideoAssetStore.shared.removeVideo(storageKey: asset.storageKey)
        importError = "Impossible de réparer le projet vidéo existant : \(error.localizedDescription)"
        Haptics.error()
        return false
      }

      if !oldStorageKey.isEmpty, oldStorageKey != asset.storageKey {
        try? await VideoAssetStore.shared.removeVideo(storageKey: oldStorageKey)
      }
      await remoteCamera.confirmImported(recordingID: remoteManifest.recordingID)
      currentClipID = existing.id
      loadClip(existing)
      Haptics.success()
      return true
    }

    let linkedAttemptID = appState.pendingVideoAthleteID == athlete.id
      ? appState.pendingVideoAttemptID
      : nil
    let clip = VideoClipRecord(
      athleteID: athlete.id,
      attemptID: linkedAttemptID,
      mediaStorageKey: asset.storageKey,
      fileSHA256: asset.sha256,
      originalFilename: originalFilename,
      durationSeconds: remoteValidation?.durationSeconds ?? viewModel.duration,
      frameRate: remoteManifest?.nominalFPS ?? remoteValidation?.nominalFrameRate ?? viewModel.frameRate
    )
    if let remoteManifest {
      clip.sourceDeviceName = remoteEndpoint?.name ?? "Pixel"
      clip.sourceCameraDescription = remoteManifest.lensLabel
      clip.sourceResolution = "\(remoteManifest.width)×\(remoteManifest.height)"
      clip.remoteRecordingID = remoteManifest.recordingID
      clip.remoteCreationTime = remoteManifest.createdAt
      clip.remoteOrientation = remoteManifest.orientation
      clip.durationSeconds = remoteValidation?.durationSeconds ?? remoteManifest.durationSeconds
    }
    modelContext.insert(clip)
    do {
      try modelContext.save()
      appState.pendingVideoAttemptID = nil
      appState.pendingVideoAthleteID = nil
      performanceStore.didChangePerformanceData()
    } catch {
      modelContext.delete(clip)
      if remoteManifest != nil {
        try? await VideoAssetStore.shared.removeVideo(storageKey: asset.storageKey)
      }
      importError = "Impossible d’enregistrer le projet vidéo : \(error.localizedDescription)"
      Haptics.error()
      return false
    }

    if let remoteManifest {
      await remoteCamera.confirmImported(recordingID: remoteManifest.recordingID)
    }

    comparisonClipID = nil
    viewModel.clearComparison()
    currentClipID = clip.id
    viewModel.restore(
      vectors: [],
      phaseMarkers: [],
      pencilData: nil,
      calibration: nil,
      dynamicCalibration: nil,
      trackingSeed: nil,
      motionResult: nil
    )
    Haptics.success()
    return true
  }

  @MainActor
  private func recoverLegacyRemoteClips() async {
    for clip in athleteClips where !clip.remoteRecordingID.isEmpty && !clip.mediaStorageKey.isEmpty {
      guard URL(fileURLWithPath: clip.mediaStorageKey).pathExtension.lowercased() == "partial" else { continue }
      do {
        _ = try await repairLegacyRemoteClipIfNeeded(clip)
      } catch {
        // Preserve the original .partial and surface one actionable message. Nothing is deleted.
        importError = "Ancienne vidéo Pixel conservée mais non réparée : \(error.localizedDescription)"
      }
    }
  }

  @MainActor
  private func repairLegacyRemoteClipIfNeeded(_ clip: VideoClipRecord) async throws -> URL? {
    guard !clip.remoteRecordingID.isEmpty,
          !clip.mediaStorageKey.isEmpty,
          URL(fileURLWithPath: clip.mediaStorageKey).pathExtension.lowercased() == "partial"
    else { return nil }

    let preferredExtension = try VideoAssetStore.preferredVideoExtension(fromRemoteFilename: clip.originalFilename)
    let oldStorageKey = clip.mediaStorageKey
    let oldSHA = clip.fileSHA256
    let repaired = try await VideoAssetStore.shared.prepareLegacyRemoteRepair(
      storageKey: oldStorageKey,
      preferredFileExtension: preferredExtension,
      expectedSHA256: oldSHA
    )

    clip.mediaStorageKey = repaired.storageKey
    clip.fileSHA256 = repaired.sha256
    clip.updatedAt = .now
    do {
      try modelContext.save()
    } catch {
      clip.mediaStorageKey = oldStorageKey
      clip.fileSHA256 = oldSHA
      try? await VideoAssetStore.shared.removeVideo(storageKey: repaired.storageKey)
      throw error
    }

    // Persistence now points to the validated replacement. Only now remove the legacy copy.
    try? await VideoAssetStore.shared.removeVideo(storageKey: oldStorageKey)
    return repaired.url
  }

  @MainActor
  private func resolveClipMediaURL(_ clip: VideoClipRecord) async throws -> URL {
    if let repaired = try await repairLegacyRemoteClipIfNeeded(clip) {
      return repaired
    }
    if !clip.mediaStorageKey.isEmpty {
      return try await VideoAssetStore.shared.resolve(clip.mediaStorageKey)
    }
    if !clip.localURLString.isEmpty {
      let migrated = try await VideoAssetStore.shared.migrateLegacyAbsolutePath(clip.localURLString)
      clip.mediaStorageKey = migrated.storageKey
      clip.fileSHA256 = migrated.sha256
      clip.localURLString = ""
      clip.updatedAt = .now
      try modelContext.save()
      return migrated.url
    }
    throw VideoStoreError.missingFile
  }

  private func loadClip(_ clip: VideoClipRecord) {
    comparisonClipID = nil
    viewModel.clearComparison()
    currentClipID = clip.id

    let vectors = savedVectors.filter { $0.videoID == clip.id }.map(\.overlayVector)
    let markers = savedPhaseMarkers.filter { $0.videoID == clip.id }.compactMap { record -> PhaseMarker? in
      guard let phase = VaultPhase(rawValue: record.phaseRaw) else { return nil }
      return PhaseMarker(id: record.id, phase: phase, timeSeconds: record.timeSeconds)
    }
    let dynamicCalibration = clip.calibrationData.flatMap {
      try? JSONDecoder().decode(DynamicCalibrationTrack.self, from: $0)
    }
    let calibration = dynamicCalibration == nil
      ? clip.calibrationData.flatMap { try? JSONDecoder().decode(VideoCalibration.self, from: $0) }
      : nil
    let seed: NormalizedPoint? = {
      guard let x = clip.trackingSeedX, let y = clip.trackingSeedY else { return nil }
      return NormalizedPoint(x: x, y: y).clamped()
    }()
    let motionResult = clip.motionAnalysisData.flatMap {
      try? JSONDecoder().decode(MotionAnalysisResult.self, from: $0)
    }

    viewModel.restore(
      vectors: vectors,
      phaseMarkers: markers,
      pencilData: clip.pencilDrawingData,
      calibration: calibration,
      dynamicCalibration: dynamicCalibration,
      trackingSeed: seed,
      motionResult: motionResult
    )
    viewModel.comparisonOffset = clip.comparisonOffsetSeconds
    viewModel.comparisonMode = VideoComparisonMode(rawValue: clip.comparisonModeRaw) ?? .sideBySide
    viewModel.comparisonTakeoffTime = clip.comparisonTakeoffTime
    if let data = clip.overlayTransformData, let transform = try? JSONDecoder().decode(OverlayVideoTransform.self, from: data) {
      viewModel.overlayTransform = transform
    }
    comparisonClipID = clip.comparisonClipID

    Task { @MainActor in
      do {
        let url = try await resolveClipMediaURL(clip)
        if !(await VideoAssetStore.shared.matchesSHA256(url: url, expected: clip.fileSHA256)) {
          importError = "La vidéo retrouvée ne correspond pas au fichier source de ce projet."
          return
        }
        await viewModel.load(url: url)
        if let comparisonID = clip.comparisonClipID,
           let comparison = athleteClips.first(where: { $0.id == comparisonID && $0.id != clip.id })
        {
          loadComparisonClip(comparison, preserveWorkspace: true)
        }
        Haptics.selection()
      } catch {
        importError = "Vidéo introuvable ou illisible. L’analyse est intacte. Utilisez « Relier le fichier source » si nécessaire. \(error.localizedDescription)"
        relinkClipID = clip.id
        Haptics.warning()
      }
    }
  }

  private func loadComparisonClip(_ clip: VideoClipRecord, preserveWorkspace: Bool = false) {
    guard clip.id != currentClipID else { return }
    comparisonClipID = clip.id
    Task { @MainActor in
      do {
        let url = try await resolveClipMediaURL(clip)
        guard await VideoAssetStore.shared.matchesSHA256(url: url, expected: clip.fileSHA256) else {
          importError = "La vidéo de comparaison ne correspond pas au fichier source enregistré."
          comparisonClipID = nil
          return
        }
        let savedTakeoff = savedPhaseMarkers.first(where: { $0.videoID == clip.id && $0.phaseRaw == VaultPhase.takeoff.rawValue })?.timeSeconds
        let takeoff = preserveWorkspace ? viewModel.comparisonTakeoffTime : (savedTakeoff ?? clip.comparisonTakeoffTime)
        viewModel.loadComparison(url: url, takeoffTime: takeoff)
        Haptics.selection()
      } catch {
        importError = "La vidéo de comparaison est introuvable ou illisible."
        comparisonClipID = nil
      }
    }
  }

  private func deleteClip(_ clip: VideoClipRecord) {
    let wasCurrent = currentClipID == clip.id
    let wasComparison = comparisonClipID == clip.id
    let nextClip = athleteClips.first(where: { $0.id != clip.id })
    let storageKey = clip.mediaStorageKey
    let legacyURL = clip.localURLString.isEmpty ? nil : URL(fileURLWithPath: clip.localURLString)

    for record in savedVectors where record.videoID == clip.id { modelContext.delete(record) }
    for record in savedPhaseMarkers where record.videoID == clip.id { modelContext.delete(record) }
    modelContext.delete(clip)
    do {
      try modelContext.save()
    } catch {
      importError = "Impossible de supprimer le projet : \(error.localizedDescription)"
      Haptics.error()
      return
    }

    Task {
      if !storageKey.isEmpty {
        try? await VideoAssetStore.shared.removeVideo(storageKey: storageKey)
      } else if let legacyURL {
        try? await VideoAssetStore.shared.removeVideo(atLegacyURL: legacyURL)
      }
    }

    if wasComparison {
      comparisonClipID = nil
      viewModel.clearComparison()
    }

    if wasCurrent {
      currentClipID = nil
      comparisonClipID = nil
      pencilCanvas?.drawing = PKDrawing()
      viewModel.teardown()
      viewModel.clearAnnotations()
      if let nextClip { loadClip(nextClip) }
    }
    Haptics.warning()
  }

  private func saveAnalysis() {
    guard let athlete, let clip = currentClip else { return }

    for record in savedVectors where record.videoID == clip.id { modelContext.delete(record) }
    for record in savedPhaseMarkers where record.videoID == clip.id { modelContext.delete(record) }

    for vector in viewModel.vectors {
      modelContext.insert(VectorAnnotationRecord(athleteID: athlete.id, videoID: clip.id, vector: vector))
    }
    for marker in viewModel.phaseMarkers {
      modelContext.insert(
        PhaseMarkerRecord(
          id: marker.id,
          athleteID: athlete.id,
          videoID: clip.id,
          phase: marker.phase,
          timeSeconds: marker.timeSeconds
        )
      )
    }

    clip.durationSeconds = viewModel.duration
    clip.frameRate = viewModel.frameRate
    clip.pencilDrawingData = viewModel.pencilDrawing.dataRepresentation()
    clip.calibrationData = viewModel.dynamicCalibration.flatMap { try? JSONEncoder().encode($0) }
      ?? (try? JSONEncoder().encode(viewModel.calibration))
    clip.trackingSeedX = viewModel.trackingSeed?.x
    clip.trackingSeedY = viewModel.trackingSeed?.y
    var compactMotionResult = viewModel.motionResult
    compactMotionResult?.dynamicCalibration = nil
    clip.motionAnalysisData = compactMotionResult.flatMap { try? JSONEncoder().encode($0) }
    clip.comparisonClipID = comparisonClipID
    clip.comparisonOffsetSeconds = viewModel.comparisonOffset
    clip.comparisonModeRaw = viewModel.comparisonMode.rawValue
    clip.comparisonTakeoffTime = viewModel.comparisonTakeoffTime
    clip.overlayTransformData = try? JSONEncoder().encode(viewModel.overlayTransform)
    clip.updatedAt = .now
    do {
      try modelContext.save()
      performanceStore.didChangePerformanceData()
      Haptics.success()
    } catch {
      importError = "Impossible d’enregistrer l’analyse : \(error.localizedDescription)"
      Haptics.error()
    }
  }

  private func saveTakeoffMeasurementToProfile() {
    guard let athlete, let measurement = viewModel.takeoffMeasurement else { return }
    modelContext.insert(
      PhysicalMetricRecord(
        athleteID: athlete.id,
        kind: .takeoffMark,
        value: measurement.distanceFromBoxMeters,
        source: "Vidéo — homographie dynamique",
        protocolName: measurement.convention.title,
        measuredAt: .now,
        note: {
          let uncertainty = measurement.uncertaintyMeters.map { "incertitude estimée ± \(Int(($0 * 100).rounded())) cm" }
            ?? "incertitude non calibrée"
          return "Distance signée depuis le fond du butoir · \(uncertainty) · score qualité \(Int((measurement.confidence * 100).rounded())) % (non probabiliste)."
        }()
      )
    )
    do {
      try modelContext.save()
      performanceStore.didChangePerformanceData()
      Haptics.success()
    } catch {
      importError = "Impossible d’enregistrer la mesure d’impulsion : \(error.localizedDescription)"
      Haptics.error()
    }
  }

  private func saveVideoSpeedToProfile() {
    guard let athlete, let result = viewModel.motionResult else { return }
    let speed = result.representativeHorizontalSpeed

    let isBoxless = result.measurementMode == .athleteScale
    let isCalibratedManual = result.measurementMode == .calibratedManual
    let isFixedOblique = result.measurementMode == .fixedObliqueRunway
    let isDynamicPerspective = result.measurementMode == .dynamicRunway
    let isTrustedGroundMetric = (isFixedOblique && viewModel.fixedObliqueTrackingPoint == .groundProjection) || isDynamicPerspective
    guard isTrustedGroundMetric else {
      importError = "Cette analyse est un mode historique/estimé. Elle reste consultable mais ne peut pas être enregistrée comme vitesse métrique calibrée v15."
      Haptics.warning()
      return
    }
    let source: String
    if isFixedOblique {
      source = viewModel.fixedObliqueTrackingPoint == .groundProjection
        ? "Vidéo — caméra fixe face/biais · point sol"
        : "Vidéo — caméra fixe face/biais · bassin estimé"
    } else if isCalibratedManual {
      source = "Vidéo — distance réelle et bassin validé"
    } else if isBoxless {
      source = "Vidéo — stabilisation sans butoir"
    } else {
      source = "Vidéo — perspective dynamique · appuis au sol"
    }

    let protocolName = result.referenceDescription
      ?? (isFixedOblique
        ? "Homographie fixe du plan de piste · vitesse longitudinale"
        : (isCalibratedManual
        ? "Bassin à 10 Hz · repères fixes · échelle réelle"
        : (isBoxless
          ? "Sujet sélectionné · échelle anthropométrique"
          : String(
              format: "Appuis/chevilles · homographies dynamiques · %.2f m",
              result.dynamicCalibration?.initialGrid.zoneLengthMeters ?? result.calibration.distanceMeters
            ))))

    let precisionNote: String
    if isFixedOblique {
      precisionNote = viewModel.fixedObliqueTrackingPoint == .groundProjection
        ? "Mesure de référence monocaméra : PTS réels, homographie fixe du plan du sol et vitesse uniquement longitudinale."
        : "Estimation monocaméra : PTS réels et homographie fixe du sol appliquée au bassin ; erreur de parallaxe possible."
    } else if isCalibratedManual {
      precisionNote = "Mesure physique : temps issu des PTS réels des images, échelle issue d’une distance réelle, panoramique compensé par les repères fixes et bassin confirmé toutes les 0,1 s."
    } else if isBoxless {
      precisionNote = "Estimation terrain : panoramique compensé par le décor et échelle actualisée avec la taille déclarée de l’athlète."
    } else {
      precisionNote = "Mesure perspective dynamique : position longitudinale issue des appuis/chevilles au sol, homographie recalculée dans le temps et PTS réels. Les intervalles de géométrie non fiable sont rejetés."
    }

    do {
      let analysisRate = result.endTime > result.startTime
        ? Double(max(result.samples.count - 1, 0)) / (result.endTime - result.startTime)
        : nil
      let qualityStatus = result.averageConfidence >= 0.75 ? "automatic" : (result.averageConfidence >= 0.5 ? "review" : "low-quality")
      let verticalIsEstimated = result.samples.contains { $0.verticalIsEstimated == true }
      let isGroundPlaneReference = isFixedOblique && viewModel.fixedObliqueTrackingPoint == .groundProjection
      let estimatedMeasurement = !isTrustedGroundMetric
      let manuallyVerified = result.pelvisValidation?.isComplete == true
      let qualityParameters: [String: Any] = [
        "measurementMode": result.measurementMode?.rawValue ?? "unknown",
        "verticalIsEstimated": verticalIsEstimated,
        "groundPlaneReference": isGroundPlaneReference || isDynamicPerspective,
        "parameterSet": VideoAnalysisConfiguration.parameterSetVersion,
        "timeline": result.timeBasisRaw ?? "presentation-timestamps",
        "groundPointMethod": result.groundPointMethodRaw ?? "unknown",
        "quality": result.speedQualityReport.map { report in
          [
            "calibration": report.components.calibration,
            "anchorStability": report.components.anchorStability,
            "usableAnchorCount": report.components.usableAnchorCount,
            "homographyContinuity": report.components.homographyContinuity,
            "athleteTrackingContinuity": report.components.athleteTrackingContinuity,
            "groundPointConfidence": report.components.groundPointConfidence,
            "metricTrajectoryCoverage": report.components.metricTrajectoryCoverage,
            "outlierControl": report.components.outlierControl,
            "ptsCoverage": report.components.ptsCoverage
          ]
        } ?? [:]
      ]
      let parameters = (try? JSONSerialization.data(withJSONObject: qualityParameters))
        .flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
      _ = try PerformanceRepository(context: modelContext).saveSpeedMeasurement(
        athleteID: athlete.id,
        kind: .videoEstimatedSpeed,
        value: speed,
        source: source,
        protocolName: protocolName,
        note: "\(precisionNote) Indice qualité \(Int((result.averageConfidence * 100).rounded()))/100 (non probabiliste). \(result.speedQualityReport?.diagnostics.joined(separator: " · ") ?? "")",
        algorithmVersion: result.modelVersion,
        captureFrameRate: viewModel.frameRate,
        analysisFrameRate: analysisRate,
        analysisStartTime: result.startTime,
        analysisEndTime: result.endTime,
        sampleCount: result.samples.count,
        qualityStatusRaw: qualityStatus,
        isEstimated: estimatedMeasurement,
        userVerified: manuallyVerified,
        parametersJSON: parameters
      )
      performanceStore.didSaveVideoMeasurement(speed)
      Haptics.success()
    } catch {
      importError = "Impossible d’enregistrer la vitesse : \(error.localizedDescription)"
      Haptics.error()
    }
  }

  private func angleGroup(keywords: [String]) -> [BiomechanicalAngle] {
    viewModel.biomechanicalAngles.filter { angle in
      keywords.contains(where: { angle.title.localizedCaseInsensitiveContains($0) })
    }
  }

}

private struct RemoteCameraPanel: View {
  @ObservedObject var controller: PixelRemoteCameraController
  @ObservedObject var discovery: BonjourCameraDiscovery
  let existingRemoteIDs: Set<String>
  let onStopAndImport: () -> Void
  let onRetryImport: () -> Void

  @State private var pairingCode = ""
  @State private var selectedEndpointID: String?

  private var selectedEndpoint: RemoteCameraEndpoint? {
    discovery.endpoints.first { $0.id == selectedEndpointID }
  }

  var body: some View {
    DisclosureGroup {
      VStack(alignment: .leading, spacing: 12) {
        if discovery.endpoints.isEmpty {
          Label("Aucun compagnon Pixel détecté sur le réseau local.", systemImage: "wifi.exclamationmark")
            .font(.footnote)
            .foregroundStyle(Color.vaultMuted)
          Text("Ouvrez Perche Camera Companion sur le Pixel et vérifiez que les deux appareils sont sur le même réseau Wi‑Fi.")
            .font(.caption)
            .foregroundStyle(Color.vaultMuted)
        } else {
          HStack(spacing: 10) {
            Picker("Pixel", selection: $selectedEndpointID) {
              Text("Choisir un appareil").tag(String?.none)
              ForEach(discovery.endpoints) { endpoint in
                Text(endpoint.name).tag(Optional(endpoint.id))
              }
            }
            .pickerStyle(.menu)

            TextField("Code d’appairage", text: $pairingCode)
              .textContentType(.oneTimeCode)
              .keyboardType(.numberPad)
              .frame(maxWidth: 180)

            Button("Appairer") {
              guard let selectedEndpoint else { return }
              Task { await controller.pair(endpoint: selectedEndpoint, code: pairingCode) }
            }
            .buttonStyle(.borderedProminent)
            .disabled(selectedEndpoint == nil || pairingCode.trimmingCharacters(in: .whitespaces).isEmpty)
          }

          if let selectedEndpoint {
            Text("\(selectedEndpoint.host) · contrôle \(selectedEndpoint.controlPort) · transfert \(selectedEndpoint.transferPort)")
              .font(.caption.monospacedDigit())
              .foregroundStyle(Color.vaultMuted)
              .textSelection(.enabled)
              .accessibilityLabel("Adresse Pixel \(selectedEndpoint.host), port de contrôle \(selectedEndpoint.controlPort), port de transfert \(selectedEndpoint.transferPort)")
          }
        }

        if !controller.configurations.isEmpty {
          HStack(spacing: 12) {
            Picker("Configuration", selection: $controller.selectedConfigurationID) {
              ForEach(controller.configurations) { config in
                Text(config.displayName).tag(Optional(config.id))
              }
            }
            .pickerStyle(.menu)
            .onChange(of: controller.selectedConfigurationID) { _, _ in
              Task { await controller.applySelectedConfiguration() }
            }

            Toggle("Audio", isOn: $controller.audioEnabled)
              .toggleStyle(.switch)
              .onChange(of: controller.audioEnabled) { _, _ in
                Task { await controller.applySelectedConfiguration() }
              }

            Toggle("Stabilisation", isOn: $controller.stabilizationEnabled)
              .toggleStyle(.switch)
              .disabled(controller.configurations.first(where: { $0.id == controller.selectedConfigurationID })?.stabilizationSupported != true)
              .onChange(of: controller.stabilizationEnabled) { _, _ in
                Task { await controller.applySelectedConfiguration() }
              }
          }
        }

        if controller.state != .disconnected && controller.state != .connecting {
          HStack(spacing: 14) {
            Label("Pixel connecté", systemImage: "link")
              .foregroundStyle(Color.vaultMuted)
            Label(
              controller.cameraReady ? "Caméra prête" : "Caméra non prête",
              systemImage: controller.cameraReady ? "video.fill" : "video.slash"
            )
            .foregroundStyle(controller.cameraReady ? Color.vaultSuccess : Color.orange)
            if controller.previewActive {
              Label("Aperçu Pixel actif", systemImage: "eye.fill")
                .foregroundStyle(Color.vaultSuccess)
            }
          }
          .font(.caption.weight(.semibold))
        }

        HStack(spacing: 10) {
          Label(controller.state.title, systemImage: stateSymbol)
            .font(.subheadline.weight(.bold))
            .foregroundStyle(stateColor)

          if controller.state == .recording, let started = controller.recordingStartedAt {
            TimelineView(.periodic(from: .now, by: 1)) { context in
              Text(context.date.timeIntervalSince(started), format: .number.precision(.fractionLength(0)))
                .monospacedDigit()
                .accessibilityLabel("Durée d’enregistrement en secondes")
            }
          }
          Spacer()

          if controller.state == .ready || controller.state == .imported {
            Button {
              Task { await controller.startRecording() }
            } label: {
              Label("Enregistrer", systemImage: "record.circle")
            }
            .buttonStyle(.borderedProminent)
            .disabled(controller.selectedConfigurationID == nil || !controller.cameraReady)
          }

          if controller.state == .recording {
            Button(role: .destructive) { onStopAndImport() } label: {
              Label("Arrêter et importer", systemImage: "stop.circle.fill")
            }
            .buttonStyle(.borderedProminent)
          }

          if let manifest = controller.pendingManifest,
             !existingRemoteIDs.contains(manifest.recordingID),
             controller.state != .recording,
             controller.state != .transferring
          {
            Button("Reprendre le transfert") { onRetryImport() }
              .buttonStyle(.bordered)
          }
        }

        if !controller.statusMessage.isEmpty {
          Text(controller.statusMessage)
            .font(.footnote)
            .foregroundStyle(Color.vaultMuted)
        }

        Text("Le Pixel enregistre d’abord le fichier maître localement. Le transfert vers l’iPad ne commence qu’après finalisation ; la copie Pixel est conservée si le réseau tombe.")
          .font(.caption)
          .foregroundStyle(Color.vaultMuted)
      }
      .padding(.top, 12)
    } label: {
      Label("Caméra Pixel distante", systemImage: "iphone.radiowaves.left.and.right")
        .font(.headline.weight(.bold))
    }
    .vaultCard()
  }

  private var stateSymbol: String {
    switch controller.state {
    case .disconnected: "wifi.slash"
    case .connecting: "antenna.radiowaves.left.and.right"
    case .ready: "checkmark.circle.fill"
    case .recording: "record.circle.fill"
    case .stopping: "hourglass"
    case .transferring: "arrow.down.circle.fill"
    case .imported: "checkmark.seal.fill"
    case .error: "exclamationmark.triangle.fill"
    }
  }

  private var stateColor: Color {
    switch controller.state {
    case .ready, .imported: .vaultSuccess
    case .recording: .red
    case .error, .disconnected: .vaultMuted
    default: .vaultAccent
    }
  }
}
