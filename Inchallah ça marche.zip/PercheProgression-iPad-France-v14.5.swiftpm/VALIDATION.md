# Validation v15.0.4

| Zone | Validation effectuée | Résultat | Limite restante |
|---|---|---|---|
| Test matériel v15.0.2 | Découverte Bonjour/NSD iPad ↔ Pixel | **Confirmé sur matériel réel** | aucune pour la découverte |
| Test matériel v15.0.2 | Appairage/TCP et démarrage CameraX distant | **Confirmé sur matériel réel** | cycle post-enregistrement à revalider en v15.0.3 |
| Test matériel v15.0.2 | Transfert d’une vidéo Pixel | **Transfert reçu mais média illisible** | cause `.partial` corrigée en source v15.0.3 ; retest requis |
| Test matériel v15.0.2 | Stop local Pixel | **Finalisation iPad bloquée** | reconciliation STATUS ajoutée ; retest requis |
| Swift source v15.0.3 | `swiftc -frontend -parse` sur AppModule + Tests | **81/81 fichiers parsés** | ce n’est pas un build Xcode |
| iOS remote media | Import avec extension explicite + validation AVFoundation avant `VideoClipRecord` | **Implémenté en source** | XCTest/Xcode à exécuter sur Apple runtime |
| iOS récupération | Migration non destructive `source.partial` → média suffixé + SHA + AVFoundation | **Implémenté en source** | récupération du clip physique à vérifier sur iPad |
| iOS tests v15.0.3 | `RemoteVideoImportTests` (extension, SHA, échec non destructif, doublon, reprise) | **10 tests ajoutés** | exécution Apple/Xcode en attente |
| Android protocole pur | `ProtocolSelfTest` compilé/exécuté avec `kotlinc` | **PASS** | ne remplace pas CameraX |
| Android machine d’état | Tests JUnit Stop iPad/Pixel, erreur/recovery, record-again, restauration manifeste | **8 tests ajoutés** | exécution Gradle GitHub en attente |
| Android CameraX | Source 15.0.4 sans patch CI de production | **Prête pour GitHub Actions** | build Android **PENDING** |
| GitHub CI | Workflow compile `gradle clean :app:assembleDebug` sans réécriture source | **Workflow mis à jour** | exécution distante **PENDING** |
| Cycle matériel cible | RECORD → STOP iPad/Pixel → FINALIZE → STATUS → TRANSFER → AVFoundation → RECORD AGAIN | **PENDING** | nécessite le nouvel APK + iPad physique |

## Gate matériel v15.0.3

Trois enregistrements consécutifs doivent être validés :

1. Stop depuis l’iPad → finalisation → transfert → lecture/frame-step.
2. Stop depuis le Pixel → STATUS iPad → transfert automatique → lecture.
3. Nouvel enregistrement sans redémarrer les applications → finalisation → transfert → lecture.

Ensuite : Force Stop du compagnon Pixel, réouverture, nouvel appairage, STATUS et récupération d’un manifeste en attente le cas échéant.

## Gate matériel v15.0.4 — aperçu Pixel

À confirmer sur le Pixel réel : `CAMERA` accordée → indicateur caméra Android vert → image `PreviewView` en direct → `cameraReady=true` sur l’iPad → enregistrement/finalisation/transfert/réenregistrement v15.0.3 toujours fonctionnels.
