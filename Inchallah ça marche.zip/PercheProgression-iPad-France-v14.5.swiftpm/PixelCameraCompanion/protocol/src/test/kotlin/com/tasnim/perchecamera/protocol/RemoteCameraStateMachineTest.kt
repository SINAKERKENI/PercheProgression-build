package com.tasnim.perchecamera.protocol

import org.junit.Assert.*
import org.junit.Test

class RemoteCameraStateMachineTest {
    private fun manifest(id: String = "r1") = sampleManifest(id)

    @Test
    fun remoteStopFinalizesToReadyWithPendingManifest() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.IPAD)
        val manifest = manifest()
        state.recordingFinalized(manifest)
        assertEquals(CameraState.READY, state.state)
        assertEquals(manifest, state.finalizedManifest)
        assertEquals(StopOrigin.IPAD, state.lastStopOrigin)
    }

    @Test
    fun localPixelStopUsesSameFinalizationState() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.PIXEL)
        val manifest = manifest()
        state.recordingFinalized(manifest)
        assertEquals(CameraState.READY, state.state)
        assertEquals(manifest, state.finalizedManifest)
        assertEquals(StopOrigin.PIXEL, state.lastStopOrigin)
    }

    @Test
    fun finalizedManifestRemainsDiscoverableAfterMissedResponse() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.IPAD)
        val manifest = manifest()
        state.recordingFinalized(manifest)
        // A control-response loss does not alter authoritative finalized state.
        assertSame(manifest, state.finalizedManifest)
        assertEquals(CameraState.READY, state.state)
    }

    @Test
    fun finalizeDoesNotDependOnControlConnection() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.SYSTEM)
        val manifest = manifest()
        state.recordingFinalized(manifest)
        assertEquals(manifest, state.finalizedManifest)
        assertEquals(CameraState.READY, state.state)
    }

    @Test
    fun transientErrorRecoversOnlyWhenIdle() {
        val state = RemoteCameraStateMachine()
        state.recordingFailed("temporary CameraX error")
        assertEquals(CameraState.ERROR, state.state)
        assertFalse(state.recoverIfIdle(operationActive = true))
        assertEquals(CameraState.ERROR, state.state)
        assertTrue(state.recoverIfIdle(operationActive = false))
        assertEquals(CameraState.READY, state.state)
        assertEquals("temporary CameraX error", state.lastErrorMessage)
    }

    @Test
    fun recordAgainWorksAfterSuccessfulFinalize() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.IPAD)
        state.recordingFinalized(manifest("first"))
        assertEquals(CameraState.READY, state.state)

        state.recordingStarted()
        assertEquals(CameraState.RECORDING, state.state)
        state.stopRequested(StopOrigin.PIXEL)
        state.recordingFinalized(manifest("second"))
        assertEquals(CameraState.READY, state.state)
        assertEquals("second", state.finalizedManifest?.recordingID)
    }

    @Test
    fun transferStateDoesNotDeleteFinalizedRecording() {
        val state = RemoteCameraStateMachine()
        state.recordingStarted()
        state.stopRequested(StopOrigin.IPAD)
        val manifest = manifest()
        state.recordingFinalized(manifest)
        state.transferStarted()
        assertEquals(CameraState.TRANSFERRING, state.state)
        state.transferFinished()
        assertEquals(CameraState.READY, state.state)
        assertEquals(manifest, state.finalizedManifest)
        state.clearFinalizedManifest(manifest.recordingID)
        assertNull(state.finalizedManifest)
    }
    @Test
    fun persistedManifestCanBeRestoredAfterControllerRecreation() {
        val first = RemoteCameraStateMachine()
        first.recordingStarted()
        first.stopRequested(StopOrigin.PIXEL)
        val manifest = manifest("persisted")
        first.recordingFinalized(manifest)

        val recreated = RemoteCameraStateMachine()
        recreated.restoreFinalizedManifest(manifest)
        assertEquals(CameraState.READY, recreated.state)
        assertEquals(manifest, recreated.finalizedManifest)
    }

}
