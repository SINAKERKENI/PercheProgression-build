package com.tasnim.perchecamera.protocol

import java.security.MessageDigest
import java.security.SecureRandom

enum class CameraState { DISCONNECTED, READY, RECORDING, STOPPING, TRANSFERRING, ERROR }
enum class StopOrigin { IPAD, PIXEL, SYSTEM }

data class RecordingManifest(
    val recordingID: String,
    val filename: String,
    val sizeBytes: Long,
    val sha256: String,
    val createdAtISO8601: String,
    val durationSeconds: Double,
    val width: Int,
    val height: Int,
    val nominalFPS: Double,
    val lensLabel: String,
    val orientation: String,
    val transferPath: String,
    val finalizedAtISO8601: String? = null,
    val transferState: String = "pending",
)

data class CameraConfiguration(
    val id: String,
    val lensLabel: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val stabilizationSupported: Boolean,
    val stabilizationEnabled: Boolean = false,
    val audioEnabled: Boolean = false,
)

/**
 * Pure synchronized lifecycle. CameraX callbacks and network commands may originate from
 * different executors, so every transition is serialized here. A recording failure is kept
 * separately from the current state so an idle camera can recover without losing diagnostics.
 */
class RemoteCameraStateMachine {
    @Volatile
    var state: CameraState = CameraState.READY
        private set

    @Volatile
    var finalizedManifest: RecordingManifest? = null
        private set

    @Volatile
    var lastErrorMessage: String? = null
        private set

    @Volatile
    var lastStopOrigin: StopOrigin? = null
        private set

    @Synchronized
    fun recordingStarted() {
        check(state == CameraState.READY) { "recording can only start from READY" }
        state = CameraState.RECORDING
        lastErrorMessage = null
        lastStopOrigin = null
    }

    @Synchronized
    fun stopRequested(origin: StopOrigin) {
        check(state == CameraState.RECORDING || state == CameraState.STOPPING) { "stop requires RECORDING or STOPPING" }
        if (state == CameraState.RECORDING) state = CameraState.STOPPING
        lastStopOrigin = origin
    }

    @Synchronized
    fun recordingFinalized(manifest: RecordingManifest) {
        check(state == CameraState.STOPPING || state == CameraState.RECORDING) { "finalize requires an active recording" }
        finalizedManifest = manifest
        state = CameraState.READY
    }

    @Synchronized
    fun recordingFailed(message: String) {
        lastErrorMessage = message
        state = CameraState.ERROR
    }

    @Synchronized
    fun transferStarted() {
        if (state == CameraState.READY) state = CameraState.TRANSFERRING
    }

    @Synchronized
    fun transferFinished() {
        if (state == CameraState.TRANSFERRING) state = CameraState.READY
    }

    @Synchronized
    fun recoverIfIdle(operationActive: Boolean): Boolean {
        if (operationActive) return false
        if (state == CameraState.ERROR) state = CameraState.READY
        return state == CameraState.READY
    }

    @Synchronized
    fun restoreFinalizedManifest(manifest: RecordingManifest) {
        finalizedManifest = manifest
        if (state != CameraState.RECORDING && state != CameraState.STOPPING) {
            state = CameraState.READY
        }
    }

    @Synchronized
    fun clearFinalizedManifest(recordingID: String) {
        if (finalizedManifest?.recordingID == recordingID) finalizedManifest = null
    }
}

class PairingAuthority(private val clockMillis: () -> Long = System::currentTimeMillis) {
    private val random = SecureRandom()
    private var pairingCode: String = newCode()
    private var codeCreatedAt = clockMillis()
    private val sessions = mutableMapOf<String, Session>()

    data class Session(val clientID: String, val expiresAtMillis: Long)

    fun currentCode(): String {
        if (clockMillis() - codeCreatedAt > 10 * 60_000L) rotateCode()
        return pairingCode
    }

    fun pair(code: String, clientID: String): String? {
        if (code != currentCode() || clientID.isBlank()) return null
        val token = ByteArray(32).also(random::nextBytes).joinToString("") { "%02x".format(it) }
        sessions[token] = Session(clientID, clockMillis() + 12 * 60 * 60_000L)
        rotateCode() // one-time PIN
        return token
    }

    fun isAuthorized(token: String?): Boolean {
        if (token == null) return false
        val session = sessions[token] ?: return false
        if (session.expiresAtMillis <= clockMillis()) {
            sessions.remove(token)
            return false
        }
        return true
    }

    private fun rotateCode() {
        pairingCode = newCode()
        codeCreatedAt = clockMillis()
    }

    private fun newCode() = (100000 + random.nextInt(900000)).toString()
}

object Hashing {
    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
