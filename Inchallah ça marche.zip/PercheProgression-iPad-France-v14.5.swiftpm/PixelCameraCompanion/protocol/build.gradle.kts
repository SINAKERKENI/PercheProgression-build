plugins { id("com.android.library") }

android {
    namespace = "com.tasnim.perchecamera.protocol"
    compileSdk = 37
    defaultConfig { minSdk = 28 }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
