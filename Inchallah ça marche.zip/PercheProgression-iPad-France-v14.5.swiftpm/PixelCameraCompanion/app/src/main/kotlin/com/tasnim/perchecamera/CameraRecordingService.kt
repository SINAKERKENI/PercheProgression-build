package com.tasnim.perchecamera

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Log
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.DynamicRange
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.SessionConfig
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.HighSpeedVideoSessionConfig
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.RecordingManifest
import com.tasnim.perchecamera.protocol.StopOrigin
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.time.Instant
import java.util.Properties
import java.util.UUID
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraRecordingService : LifecycleService() {
    companion object { private const val TAG = "PercheCamera" }
    data class InternalConfig(val public: CameraConfiguration, val cameraId: String, val quality: Quality, val highSpeed: Boolean)

    data class CameraDiagnostics(
        val providerReady: Boolean,
        val cameraBound: Boolean,
        val previewSurfaceAttached: Boolean,
        val previewActive: Boolean,
        val videoCaptureReady: Boolean,
        val bindingInProgress: Boolean,
        val selectedConfiguration: CameraConfiguration?,
        val bindingError: String?,
    )

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val lifecycleLock = Any()
    @Volatile private var provider: ProcessCameraProvider? = null
    @Volatile private var activeRecording: Recording? = null
    @Volatile private var activeFile: File? = null
    @Volatile private var activeConfig: InternalConfig? = null
    @Volatile private var finalizationInProgress: Boolean = false
    @Volatile private var selectedConfig: InternalConfig? = null
    @Volatile private var defaultBackCameraID: String? = null
    @Volatile private var boundConfig: InternalConfig? = null
    @Volatile private var boundPreview: Preview? = null
    @Volatile private var boundVideoCapture: VideoCapture<Recorder>? = null
    @Volatile private var boundRecorder: Recorder? = null
    @Volatile private var cameraBound: Boolean = false
    @Volatile private var cameraBindingInProgress: Boolean = false
    @Volatile private var previewSurfaceAttached: Boolean = false
    @Volatile private var previewStreaming: Boolean = false
    @Volatile private var cameraBindingError: String? = null
    private var previewSurfaceProvider: Preview.SurfaceProvider? = null
    private var recordingStartNanos: Long = 0
    private val stopWaiters = mutableListOf<CompletableFuture<RecordingManifest>>()
    private val configs = ConcurrentHashMap<String, InternalConfig>()
    private val manifests = ConcurrentHashMap<String, RecordingManifest>()
    private lateinit var localServer: LocalCameraServer

    override fun onCreate() {
        super.onCreate()
        CompanionRuntime.service = this
        loadPersistedManifests()
        startForegroundNotification()
        LocalCameraServer(this).also { localServer = it; it.start() }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                rebuildConfigurations()
                val initial = preferredDefaultConfig()
                    ?: throw IllegalStateException("Aucune configuration caméra exploitable.")
                bindCameraUseCases(initial)
                recoverIfIdle()
            } catch (t: Throwable) {
                CompanionRuntime.stateMachine.recordingFailed(t.message ?: "CameraX n’a pas pu initialiser la caméra.")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        if (::localServer.isInitialized) localServer.stop()
        boundPreview?.setSurfaceProvider(null)
        provider?.unbindAll()
        cameraExecutor.shutdown()
        CompanionRuntime.service = null
        super.onDestroy()
    }

    fun configurations(): List<CameraConfiguration> {
        val selected = selectedConfig
        return configs.values
            .map { candidate -> if (candidate.public.id == selected?.public?.id) selected.public else candidate.public }
            .sortedWith(
                compareBy<CameraConfiguration>(
                    { if (it.id == preferredDefaultConfig()?.public?.id) 0 else 1 },
                    { if (it.lensLabel.startsWith("Arrière")) 0 else 1 },
                    { if (it.width == 1280 && it.height == 720) 0 else 1 },
                    { if (it.fps == 30) 0 else 1 },
                    { it.lensLabel },
                    { it.width },
                    { it.fps },
                ),
            )
    }

    fun selectedConfiguration(): CameraConfiguration? = selectedConfig?.public

    fun lastErrorMessage(): String? = CompanionRuntime.stateMachine.lastErrorMessage

    fun isFinalizing(): Boolean = finalizationInProgress

    fun cameraDiagnostics(): CameraDiagnostics = CameraDiagnostics(
        providerReady = provider != null,
        cameraBound = cameraBound,
        previewSurfaceAttached = previewSurfaceAttached,
        previewActive = previewStreaming,
        videoCaptureReady = boundVideoCapture != null && boundRecorder != null,
        bindingInProgress = cameraBindingInProgress,
        selectedConfiguration = selectedConfig?.public,
        bindingError = cameraBindingError,
    )

    fun cameraReady(): Boolean {
        if (provider == null || !cameraBound || boundVideoCapture == null || boundRecorder == null || cameraBindingInProgress) return false
        // While the Pixel UI is visibly asking for a preview, READY means frames are genuinely streaming.
        // When the Activity is backgrounded and the surface is detached, VideoCapture remains valid for remote recording.
        return !previewSurfaceAttached || previewStreaming
    }

    fun previewActive(): Boolean = previewStreaming

    fun recordingElapsedSeconds(): Long? {
        if (activeRecording == null || recordingStartNanos <= 0L) return null
        return ((System.nanoTime() - recordingStartNanos).coerceAtLeast(0L) / 1_000_000_000L)
    }

    fun attachPreviewSurface(surfaceProvider: Preview.SurfaceProvider) {
        ContextCompat.getMainExecutor(this).execute {
            previewSurfaceProvider = surfaceProvider
            previewSurfaceAttached = true
            previewStreaming = false
            boundPreview?.setSurfaceProvider(surfaceProvider)
            if (!cameraBound && !cameraBindingInProgress) {
                val config = selectedConfig ?: preferredDefaultConfig()
                if (config != null) runCatching { bindCameraUseCases(config) }
            }
            Log.i(TAG, "Preview surface attached cameraBound=$cameraBound")
        }
    }

    fun detachPreviewSurface() {
        ContextCompat.getMainExecutor(this).execute {
            previewSurfaceProvider = null
            previewSurfaceAttached = false
            previewStreaming = false
            boundPreview?.setSurfaceProvider(null)
            Log.i(TAG, "Preview surface detached; VideoCapture remains bound=$cameraBound")
        }
    }

    fun setPreviewStreaming(active: Boolean) {
        previewStreaming = active
        if (active) {
            cameraBindingError = null
            recoverIfIdle()
            Log.i(TAG, "Preview stream active")
        } else {
            Log.i(TAG, "Preview stream inactive")
        }
    }

    fun reportPreviewFailure(message: String) {
        ContextCompat.getMainExecutor(this).execute {
            if (!previewSurfaceAttached || previewStreaming || activeRecording != null || finalizationInProgress) return@execute
            cameraBindingError = message
            CompanionRuntime.stateMachine.recordingFailed(message)
            Log.e(TAG, message)
        }
    }

    fun configureCamera(requested: CameraConfiguration): CompletableFuture<CameraConfiguration> {
        val result = CompletableFuture<CameraConfiguration>()
        ContextCompat.getMainExecutor(this).execute {
            try {
                if (activeRecording != null || finalizationInProgress) {
                    throw IllegalStateException("Impossible de changer de caméra pendant un enregistrement ou une finalisation.")
                }
                val effective = effectiveConfig(requested)
                val current = boundConfig
                if (current != null && current.public.id == effective.public.id &&
                    current.public.stabilizationEnabled == effective.public.stabilizationEnabled && cameraBound) {
                    selectedConfig = effective
                    boundConfig = effective
                } else {
                    bindCameraUseCases(effective)
                }
                result.complete(effective.public)
            } catch (t: Throwable) {
                cameraBindingError = t.message ?: "Configuration caméra impossible."
                CompanionRuntime.stateMachine.recordingFailed(cameraBindingError!!)
                result.completeExceptionally(t)
            }
        }
        return result
    }

    fun startRemoteRecording(requested: CameraConfiguration?): CompletableFuture<Long> {
        val result = CompletableFuture<Long>()
        ContextCompat.getMainExecutor(this).execute {
            try {
                if (!recoverIfIdle()) throw IllegalStateException("Caméra Pixel non prête.")
                if (latestPendingManifest() != null) {
                    throw IllegalStateException("Une vidéo finalisée attend encore son transfert vers l’iPad.")
                }
                if (activeRecording != null || finalizationInProgress || cameraBindingInProgress) {
                    throw IllegalStateException("Un enregistrement, une finalisation ou un changement de caméra est déjà en cours.")
                }
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    throw SecurityException("Autorisation caméra refusée.")
                }

                val config = if (requested != null) effectiveConfig(requested)
                else selectedConfig ?: preferredDefaultConfig() ?: throw IllegalStateException("Aucune configuration caméra exploitable.")

                val current = boundConfig
                if (current == null || current.cameraId != config.cameraId || current.public.id != config.public.id ||
                    current.public.stabilizationEnabled != config.public.stabilizationEnabled) {
                    bindCameraUseCases(config)
                } else {
                    selectedConfig = config
                }

                if (!captureBindingReady()) throw IllegalStateException("Caméra Pixel non prête.")
                startBoundRecording(config, result)
            } catch (t: Throwable) {
                CompanionRuntime.stateMachine.recordingFailed(t.message ?: "Impossible de démarrer l’enregistrement.")
                result.completeExceptionally(t)
            }
        }
        return result
    }

    fun stopRemoteRecording(): CompletableFuture<RecordingManifest> = requestStop(StopOrigin.IPAD)

    fun requestStopFromPixel(): CompletableFuture<RecordingManifest> = requestStop(StopOrigin.PIXEL)

    private fun requestStop(origin: StopOrigin): CompletableFuture<RecordingManifest> {
        val future = CompletableFuture<RecordingManifest>()
        ContextCompat.getMainExecutor(this).execute {
            var recordingToStop: Recording? = null
            synchronized(lifecycleLock) {
                val recording = activeRecording
                if (recording == null) {
                    if (finalizationInProgress) {
                        // CameraX has emitted Finalize and the manifest/SHA is still being built.
                        // Join the same finalization waiter instead of reporting a false "no recording" error.
                        stopWaiters += future
                    } else {
                        val pending = latestPendingManifest()
                        if (pending != null) {
                            future.complete(pending)
                        } else {
                            future.completeExceptionally(IllegalStateException("Aucun enregistrement en cours ou finalisé en attente."))
                        }
                    }
                    return@execute
                }

                stopWaiters += future
                try {
                    CompanionRuntime.stateMachine.stopRequested(origin)
                    Log.i(TAG, "Stop requested origin=$origin finalizing=$finalizationInProgress")
                    if (!finalizationInProgress) {
                        finalizationInProgress = true
                        recordingToStop = recording
                    }
                } catch (t: Throwable) {
                    stopWaiters.remove(future)
                    future.completeExceptionally(t)
                    return@execute
                }
            }

            if (recordingToStop != null) {
                try {
                    recordingToStop?.stop()
                } catch (t: Throwable) {
                    synchronized(lifecycleLock) { finalizationInProgress = false }
                    CompanionRuntime.stateMachine.recordingFailed(t.message ?: "Impossible d’arrêter l’enregistrement.")
                    completeStopWaiters(exception = t)
                }
            }
        }
        return future
    }

    private fun startBoundRecording(config: InternalConfig, startFuture: CompletableFuture<Long>) {
        val recorder = requireNotNull(boundRecorder) { "Recorder CameraX indisponible." }
        require(boundVideoCapture != null && cameraBound) { "VideoCapture CameraX n’est pas lié." }

        val recordings = File(filesDir, "recordings").apply { mkdirs() }
        val id = UUID.randomUUID().toString()
        val file = File(recordings, "$id.mp4")
        val createdAt = Instant.now().toString()
        var pending: PendingRecording = recorder.prepareRecording(this, FileOutputOptions.Builder(file).build())
        if (config.public.audioEnabled && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            updateForegroundServiceTypes(includeMicrophone = true)
            pending = pending.withAudioEnabled()
        } else {
            updateForegroundServiceTypes(includeMicrophone = false)
        }

        synchronized(lifecycleLock) {
            activeFile = file
            activeConfig = config
            finalizationInProgress = false
        }

        val recording = pending.start(cameraExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    recordingStartNanos = System.nanoTime()
                    CompanionRuntime.stateMachine.recordingStarted()
                    startFuture.complete(recordingStartNanos)
                    Log.i(TAG, "VideoRecordEvent.Start config=${config.public.id} previewActive=$previewStreaming")
                }
                is VideoRecordEvent.Finalize -> finalizeRecording(event, id, file, config, createdAt, startFuture)
            }
        }
        synchronized(lifecycleLock) { activeRecording = recording }
    }

    private fun finalizeRecording(
        event: VideoRecordEvent.Finalize,
        id: String,
        file: File,
        config: InternalConfig,
        createdAtISO8601: String,
        startFuture: CompletableFuture<Long>,
    ) {
        synchronized(lifecycleLock) {
            finalizationInProgress = true
            activeRecording = null
            activeFile = null
            activeConfig = null
        }
        updateForegroundServiceTypes(includeMicrophone = false)

        if (event.hasError() || !file.isFile || file.length() <= 0) {
            val message = "CameraX Finalize a signalé l’erreur ${event.error}. Le fichier Pixel est conservé s’il existe."
            CompanionRuntime.stateMachine.recordingFailed(message)
            Log.e(TAG, message)
            val error = IllegalStateException(message)
            if (!startFuture.isDone) startFuture.completeExceptionally(error)
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(exception = error)
            return
        }

        try {
            val metadata = readMetadata(file)
            require(metadata.first.isFinite() && metadata.first > 0) { "Durée vidéo invalide après finalisation." }
            require(metadata.second.first > 0 && metadata.second.second > 0) { "Dimensions vidéo invalides après finalisation." }
            val finalizedAt = Instant.now().toString()
            val manifest = RecordingManifest(
                recordingID = id,
                filename = file.name,
                sizeBytes = file.length(),
                sha256 = sha256(file),
                createdAtISO8601 = createdAtISO8601,
                durationSeconds = metadata.first,
                width = metadata.second.first,
                height = metadata.second.second,
                nominalFPS = config.public.fps.toDouble(),
                lensLabel = config.public.lensLabel,
                orientation = if (metadata.second.first >= metadata.second.second) "landscape" else "portrait",
                transferPath = "/recordings/$id",
                finalizedAtISO8601 = finalizedAt,
                transferState = "pending",
            )
            manifests[manifest.recordingID] = manifest
            persistManifest(manifest)
            Log.i(TAG, "Recording finalized id=${manifest.recordingID.take(8)}… bytes=${manifest.sizeBytes} duration=${manifest.durationSeconds}")
            if (CompanionRuntime.stateMachine.state == com.tasnim.perchecamera.protocol.CameraState.RECORDING) {
                CompanionRuntime.stateMachine.stopRequested(StopOrigin.SYSTEM)
            }
            CompanionRuntime.stateMachine.recordingFinalized(manifest)
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(manifest = manifest)
        } catch (t: Throwable) {
            val message = t.message ?: "Impossible de finaliser les métadonnées de la vidéo."
            CompanionRuntime.stateMachine.recordingFailed(message)
            synchronized(lifecycleLock) { finalizationInProgress = false }
            completeStopWaiters(exception = t)
        }
    }

    private fun completeStopWaiters(manifest: RecordingManifest? = null, exception: Throwable? = null) {
        val waiters = synchronized(lifecycleLock) {
            val copy = stopWaiters.toList()
            stopWaiters.clear()
            copy
        }
        for (waiter in waiters) {
            if (manifest != null) waiter.complete(manifest)
            else waiter.completeExceptionally(exception ?: IllegalStateException("Finalisation interrompue."))
        }
    }

    private fun effectiveConfig(requested: CameraConfiguration): InternalConfig {
        val base = configs[requested.id]
            ?: throw IllegalArgumentException("Configuration caméra inconnue : ${requested.id}")
        val stabilization = requested.stabilizationEnabled && base.public.stabilizationSupported
        return base.copy(
            public = base.public.copy(
                stabilizationEnabled = stabilization,
                audioEnabled = requested.audioEnabled,
            ),
        )
    }

    private fun preferredDefaultConfig(): InternalConfig? {
        val values = configs.values.toList()
        val backID = defaultBackCameraID
        return values.firstOrNull { candidate ->
            candidate.cameraId == backID && candidate.quality == Quality.HD && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.cameraId == backID && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.public.lensLabel.startsWith("Arrière") && candidate.quality == Quality.HD && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull { candidate ->
            candidate.public.lensLabel.startsWith("Arrière") && candidate.public.fps == 30 && !candidate.highSpeed
        } ?: values.firstOrNull()
    }

    private fun captureBindingReady(): Boolean =
        provider != null && cameraBound && boundVideoCapture != null && boundRecorder != null && !cameraBindingInProgress

    private fun bindCameraUseCases(config: InternalConfig) {
        val provider = requireNotNull(provider) { "CameraX n’est pas initialisé." }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            throw SecurityException("Autorisation caméra refusée.")
        }

        cameraBindingInProgress = true
        cameraBindingError = null
        previewStreaming = false
        Log.i(TAG, "Binding CameraX config=${config.public.id} camera=${config.cameraId} fps=${config.public.fps}")

        try {
            provider.unbindAll()
            cameraBound = false
            boundPreview = null
            boundVideoCapture = null
            boundRecorder = null

            val selector = CameraSelector.Builder().addCameraFilter { infos ->
                infos.filter { Camera2CameraInfo.from(it).cameraId == config.cameraId }
            }.build()

            val stabilizationEnabled = config.public.stabilizationEnabled && config.public.stabilizationSupported
            val preview = Preview.Builder()
                .setPreviewStabilizationEnabled(stabilizationEnabled)
                .build()
            previewSurfaceProvider?.let(preview::setSurfaceProvider)

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(config.quality))
                .build()
            val videoCapture = VideoCapture.Builder(recorder)
                .setVideoStabilizationEnabled(stabilizationEnabled)
                .build()
            val fpsRange = Range(config.public.fps, config.public.fps)

            if (config.highSpeed) {
                val session = HighSpeedVideoSessionConfig.Builder(videoCapture)
                    .setPreview(preview)
                    .setFrameRateRange(fpsRange)
                    .setSlowMotionEnabled(false)
                    .build()
                provider.bindToLifecycle(this, selector, session)
            } else {
                val session = SessionConfig.Builder(preview, videoCapture)
                    .setFrameRateRange(fpsRange)
                    .build()
                val info = provider.getCameraInfo(selector)
                require(info.getSupportedFrameRateRanges(session).any { it.contains(config.public.fps) }) {
                    "Cadence ${config.public.fps} i/s non prise en charge avec l’aperçu et VideoCapture."
                }
                provider.bindToLifecycle(this, selector, session)
            }

            selectedConfig = config
            boundConfig = config
            boundPreview = preview
            boundVideoCapture = videoCapture
            boundRecorder = recorder
            cameraBound = true
            cameraBindingError = null
            Log.i(TAG, "CameraX bound camera=${config.cameraId} preview=${previewSurfaceProvider != null} videoCapture=true")
        } catch (t: Throwable) {
            cameraBound = false
            boundConfig = null
            boundPreview = null
            boundVideoCapture = null
            boundRecorder = null
            cameraBindingError = t.message ?: "Impossible d’ouvrir la caméra Pixel."
            CompanionRuntime.stateMachine.recordingFailed(cameraBindingError!!)
            Log.e(TAG, "CameraX bind failed", t)
            throw t
        } finally {
            cameraBindingInProgress = false
        }
    }

    fun recoverIfIdle(): Boolean {
        val operationActive = activeRecording != null || finalizationInProgress || cameraBindingInProgress
        val cameraAvailable = cameraReady()
        return CompanionRuntime.stateMachine.recoverIfIdle(operationActive = operationActive || !cameraAvailable)
    }

    fun resetCamera(): CompletableFuture<Boolean> {
        val future = CompletableFuture<Boolean>()
        ContextCompat.getMainExecutor(this).execute {
            if (activeRecording != null || finalizationInProgress) {
                future.complete(false)
                return@execute
            }
            try {
                val previousID = selectedConfig?.public?.id
                provider?.unbindAll()
                cameraBound = false
                boundPreview = null
                boundVideoCapture = null
                boundRecorder = null
                rebuildConfigurations()
                val next = previousID?.let(configs::get) ?: preferredDefaultConfig()
                    ?: throw IllegalStateException("Aucune configuration caméra exploitable après réinitialisation.")
                bindCameraUseCases(next)
                future.complete(recoverIfIdle())
            } catch (t: Throwable) {
                cameraBindingError = t.message ?: "Réinitialisation CameraX impossible."
                CompanionRuntime.stateMachine.recordingFailed(cameraBindingError!!)
                future.complete(false)
            }
        }
        return future
    }

    private fun rebuildConfigurations() {
        val provider = provider ?: return
        val next = mutableMapOf<String, InternalConfig>()
        defaultBackCameraID = runCatching {
            Camera2CameraInfo.from(provider.getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)).cameraId
        }.getOrNull()
        val defaultFrontCameraID = runCatching {
            Camera2CameraInfo.from(provider.getCameraInfo(CameraSelector.DEFAULT_FRONT_CAMERA)).cameraId
        }.getOrNull()

        val infos = provider.availableCameraInfos.sortedBy { Camera2CameraInfo.from(it).cameraId }
        val rearSecondaryIDs = infos.filter { it.lensFacing == CameraSelector.LENS_FACING_BACK }
            .map { Camera2CameraInfo.from(it).cameraId }
            .filter { it != defaultBackCameraID }
        val frontSecondaryIDs = infos.filter { it.lensFacing == CameraSelector.LENS_FACING_FRONT }
            .map { Camera2CameraInfo.from(it).cameraId }
            .filter { it != defaultFrontCameraID }

        for (info in infos) {
            val camera2 = Camera2CameraInfo.from(info)
            val id = camera2.cameraId
            val facing = info.lensFacing
            val label = when {
                facing == CameraSelector.LENS_FACING_BACK && id == defaultBackCameraID -> "Arrière — principale"
                facing == CameraSelector.LENS_FACING_BACK -> {
                    val index = rearSecondaryIDs.indexOf(id).takeIf { it >= 0 }?.plus(1) ?: 1
                    "Arrière — objectif secondaire $index"
                }
                facing == CameraSelector.LENS_FACING_FRONT && id == defaultFrontCameraID -> "Avant — principale"
                facing == CameraSelector.LENS_FACING_FRONT -> {
                    val index = frontSecondaryIDs.indexOf(id).takeIf { it >= 0 }?.plus(1) ?: 1
                    "Avant — objectif secondaire $index"
                }
                else -> "Caméra externe"
            }

            val capabilities = Recorder.getVideoCapabilities(info)
            for (quality in capabilities.getSupportedQualities(DynamicRange.SDR)) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                val preview = Preview.Builder().build()
                val probe = SessionConfig.Builder(preview, capture).build()
                val supportedRanges = info.getSupportedFrameRateRanges(probe)
                for (fps in listOf(30, 60)) if (supportedRanges.any { it.contains(fps) }) {
                    val stabilization = capabilities.isStabilizationSupported() && fps <= 30 && w <= 1920 && h <= 1080
                    val public = CameraConfiguration(
                        id = "$id|${qualityName(quality)}|$fps",
                        lensLabel = label,
                        width = w,
                        height = h,
                        fps = fps,
                        stabilizationSupported = stabilization,
                        stabilizationEnabled = false,
                        audioEnabled = false,
                    )
                    next[public.id] = InternalConfig(public, id, quality, false)
                }
            }

            val highCaps = Recorder.getHighSpeedVideoCapabilities(info)
            for (quality in highCaps?.getSupportedQualities(DynamicRange.SDR).orEmpty()) {
                val (w, h) = qualityResolution(quality) ?: continue
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(quality)).build()
                val capture = VideoCapture.withOutput(recorder)
                val preview = Preview.Builder().build()
                for (fps in listOf(120, 240)) {
                    try {
                        val probe = HighSpeedVideoSessionConfig.Builder(capture)
                            .setPreview(preview)
                            .setFrameRateRange(Range(fps, fps))
                            .setSlowMotionEnabled(false)
                            .build()
                        if (info.getSupportedFrameRateRanges(probe).any { it.contains(fps) }) {
                            val public = CameraConfiguration(
                                id = "$id|${qualityName(quality)}|$fps",
                                lensLabel = label,
                                width = w,
                                height = h,
                                fps = fps,
                                stabilizationSupported = false,
                                stabilizationEnabled = false,
                                audioEnabled = false,
                            )
                            next[public.id] = InternalConfig(public, id, quality, true)
                        }
                    } catch (_: IllegalArgumentException) { /* unsupported combination: do not expose */ }
                }
            }
        }
        configs.clear()
        configs.putAll(next)
        Log.i(TAG, "Camera configurations rebuilt count=${next.size} defaultBack=${defaultBackCameraID ?: "none"}")
    }

    private fun qualityName(q: Quality) = when (q) {
        Quality.UHD -> "UHD"; Quality.FHD -> "FHD"; Quality.HD -> "HD"; Quality.SD -> "SD"; else -> q.toString()
    }

    private fun qualityResolution(q: Quality): Pair<Int, Int>? = when (q) {
        Quality.UHD -> 3840 to 2160; Quality.FHD -> 1920 to 1080; Quality.HD -> 1280 to 720; Quality.SD -> 720 to 480; else -> null
    }

    private fun readMetadata(file: File): Pair<Double, Pair<Int, Int>> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val duration = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
            val width = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            duration to (width to height)
        } finally {
            r.release()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun networkDiagnostics(): LocalCameraServer.Diagnostics? =
        if (::localServer.isInitialized) localServer.diagnostics() else null

    fun latestManifest(): RecordingManifest? = latestPendingManifest()

    fun manifest(recordingID: String): RecordingManifest? = manifests[recordingID]

    fun finalizedFile(recordingID: String): File? {
        val manifest = manifests[recordingID] ?: return null
        val file = File(filesDir, "recordings/${manifest.filename}")
        return file.takeIf(File::isFile)
    }

    fun markTransferStarted(recordingID: String) {
        recoverIfIdle()
        updateTransferState(recordingID, "transferring")
        CompanionRuntime.stateMachine.transferStarted()
    }

    fun markTransferServed(recordingID: String) {
        updateTransferState(recordingID, "served")
        CompanionRuntime.stateMachine.transferFinished()
    }

    fun markTransferInterrupted(recordingID: String) {
        updateTransferState(recordingID, "pending")
        CompanionRuntime.stateMachine.transferFinished()
    }

    fun markImported(recordingID: String): Boolean {
        val manifest = manifests[recordingID] ?: return false
        val updated = manifest.copy(transferState = "imported")
        manifests[recordingID] = updated
        persistManifest(updated)
        CompanionRuntime.stateMachine.clearFinalizedManifest(recordingID)
        CompanionRuntime.stateMachine.transferFinished()
        return true
    }

    private fun updateTransferState(recordingID: String, state: String) {
        val manifest = manifests[recordingID] ?: return
        val updated = manifest.copy(transferState = state)
        manifests[recordingID] = updated
        persistManifest(updated)
    }

    private fun latestPendingManifest(): RecordingManifest? = manifests.values
        .asSequence()
        .filter { it.transferState != "imported" }
        .maxByOrNull { it.finalizedAtISO8601 ?: it.createdAtISO8601 }

    private fun persistManifest(manifest: RecordingManifest) {
        val dir = File(filesDir, "recordings").apply { mkdirs() }
        val props = Properties().apply {
            setProperty("recordingID", manifest.recordingID)
            setProperty("filename", manifest.filename)
            setProperty("sizeBytes", manifest.sizeBytes.toString())
            setProperty("sha256", manifest.sha256)
            setProperty("createdAtISO8601", manifest.createdAtISO8601)
            setProperty("durationSeconds", manifest.durationSeconds.toString())
            setProperty("width", manifest.width.toString())
            setProperty("height", manifest.height.toString())
            setProperty("nominalFPS", manifest.nominalFPS.toString())
            setProperty("lensLabel", manifest.lensLabel)
            setProperty("orientation", manifest.orientation)
            setProperty("transferPath", manifest.transferPath)
            setProperty("finalizedAtISO8601", manifest.finalizedAtISO8601 ?: manifest.createdAtISO8601)
            setProperty("transferState", manifest.transferState)
        }
        File(dir, "${manifest.recordingID}.manifest").outputStream().use {
            props.store(it, "Perche Camera Companion recording")
        }
    }

    private fun loadPersistedManifests() {
        val dir = File(filesDir, "recordings")
        if (!dir.isDirectory) return
        val loaded = dir.listFiles { file -> file.extension == "manifest" }.orEmpty().mapNotNull { file ->
            try {
                val p = Properties().also { props -> file.inputStream().use(props::load) }
                RecordingManifest(
                    recordingID = p.getProperty("recordingID"),
                    filename = p.getProperty("filename"),
                    sizeBytes = p.getProperty("sizeBytes").toLong(),
                    sha256 = p.getProperty("sha256"),
                    createdAtISO8601 = p.getProperty("createdAtISO8601"),
                    durationSeconds = p.getProperty("durationSeconds").toDouble(),
                    width = p.getProperty("width").toInt(),
                    height = p.getProperty("height").toInt(),
                    nominalFPS = p.getProperty("nominalFPS").toDouble(),
                    lensLabel = p.getProperty("lensLabel"),
                    orientation = p.getProperty("orientation"),
                    transferPath = p.getProperty("transferPath"),
                    finalizedAtISO8601 = p.getProperty("finalizedAtISO8601") ?: p.getProperty("createdAtISO8601"),
                    transferState = p.getProperty("transferState") ?: "pending",
                ).takeIf { File(dir, it.filename).isFile }
            } catch (_: Throwable) {
                null
            }
        }
        loaded.forEach { manifests[it.recordingID] = it }
        loaded.filter { it.transferState != "imported" }
            .maxByOrNull { it.finalizedAtISO8601 ?: it.createdAtISO8601 }
            ?.let(CompanionRuntime.stateMachine::restoreFinalizedManifest)
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val channelId = "remote_camera"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Caméra distante", NotificationManager.IMPORTANCE_LOW))
        }
        updateForegroundServiceTypes(includeMicrophone = false)
    }

    private fun updateForegroundServiceTypes(includeMicrophone: Boolean) {
        val channelId = "remote_camera"
        val pending = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Perche Camera Companion")
            .setContentText(if (activeRecording != null) "Enregistrement caméra distant" else "Caméra distante disponible sur le réseau local")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()

        var serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (includeMicrophone && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            serviceTypes = serviceTypes or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        ServiceCompat.startForeground(this, 1500, notification, serviceTypes)
    }
}
