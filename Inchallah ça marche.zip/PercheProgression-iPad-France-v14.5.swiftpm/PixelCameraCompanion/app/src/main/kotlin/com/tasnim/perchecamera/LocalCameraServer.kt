package com.tasnim.perchecamera

import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import com.tasnim.perchecamera.protocol.CameraConfiguration
import com.tasnim.perchecamera.protocol.CameraState
import com.tasnim.perchecamera.protocol.RecordingManifest
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Local-only transport. Discovery advertises reachability; it never authorizes commands.
 * Every command except `pair` carries a cryptographically random session token.
 */
class LocalCameraServer(private val service: CameraRecordingService) {
    data class Diagnostics(
        val ipv4Address: String?,
        val controlPort: Int,
        val transferPort: Int,
        val controlConnections: Int,
    ) {
        val controlConnected: Boolean get() = controlConnections > 0
    }

    companion object {
        private const val TAG = "PercheCamera"
    }

    private val running = AtomicBoolean(false)
    private val controlConnections = AtomicInteger(0)
    private val pool = Executors.newCachedThreadPool()
    private var controlSocket: ServerSocket? = null
    private var transferSocket: ServerSocket? = null
    private var registrationListener: NsdManager.RegistrationListener? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        controlSocket = ServerSocket(0)
        transferSocket = ServerSocket(0)
        val controlPort = controlSocket!!.localPort
        val transferPort = transferSocket!!.localPort
        Log.i(TAG, "LocalCameraServer started ip=${localIPv4Address() ?: "unknown"} control=$controlPort transfer=$transferPort")
        advertise(controlPort, transferPort)
        pool.execute { acceptControl() }
        pool.execute { acceptTransfer() }
    }

    fun diagnostics(): Diagnostics = Diagnostics(
        ipv4Address = localIPv4Address(),
        controlPort = controlSocket?.localPort ?: 0,
        transferPort = transferSocket?.localPort ?: 0,
        controlConnections = controlConnections.get(),
    )

    fun stop() {
        Log.i(TAG, "LocalCameraServer stopping")
        running.set(false)
        runCatching { controlSocket?.close() }
        runCatching { transferSocket?.close() }
        val listener = registrationListener
        if (listener != null) {
            runCatching { service.getSystemService(NsdManager::class.java).unregisterService(listener) }
        }
        pool.shutdownNow()
    }

    private fun acceptControl() {
        while (running.get()) {
            val socket = try {
                controlSocket?.accept() ?: break
            } catch (t: Throwable) {
                if (running.get()) Log.w(TAG, "Control accept failed", t)
                break
            }
            Log.i(TAG, "Control connection accepted from ${socket.inetAddress?.hostAddress ?: "unknown"}:${socket.port}")
            pool.execute { handleControl(socket) }
        }
    }

    private fun handleControl(socket: Socket) {
        controlConnections.incrementAndGet()
        try {
            socket.use { client ->
                client.tcpNoDelay = true
                val reader = client.getInputStream().bufferedReader(StandardCharsets.UTF_8)
                val writer = client.getOutputStream().bufferedWriter(StandardCharsets.UTF_8)
                while (running.get()) {
                    val line = try {
                        reader.readLine()
                    } catch (t: Throwable) {
                        Log.w(TAG, "Control read failed", t)
                        null
                    } ?: break
                    val response = try {
                        handleRequest(JSONObject(line))
                    } catch (t: Throwable) {
                        Log.w(TAG, "Control request failed", t)
                        response(null, "error", false, t.message ?: "Erreur de contrôle.")
                    }
                    writer.write(response.toString())
                    writer.write("\n")
                    writer.flush()
                }
            }
        } finally {
            controlConnections.decrementAndGet()
            Log.i(TAG, "Control connection closed")
        }
    }

    private fun handleRequest(json: JSONObject): JSONObject {
        val id = json.optString("id").takeIf(String::isNotBlank)
        val type = json.optString("type")
        if (type == "pair") {
            Log.i(TAG, "Pair request received clientID=${json.optString("clientID").take(12)}…")
            val token = CompanionRuntime.pairing.pair(json.optString("pairingCode"), json.optString("clientID"))
            if (token == null) {
                Log.w(TAG, "Pair request rejected")
                return response(id, type, false, "Code d’appairage invalide ou expiré.")
            }
            service.recoverIfIdle()
            Log.i(TAG, "Pair request accepted")
            return appendCameraStatus(response(id, type, true).put("token", token).put("state", wireState()))
        }

        val token = json.optString("token").takeIf(String::isNotBlank)
        if (!CompanionRuntime.pairing.isAuthorized(token)) {
            return response(id, type, false, "Session non autorisée.")
        }

        return when (type) {
            "status" -> {
                service.recoverIfIdle()
                appendCameraStatus(
                    response(id, type, true)
                        .put("state", wireState())
                        .put("configs", JSONArray(service.configurations().map(::configurationJSON)))
                        .also { obj -> service.latestManifest()?.let { obj.put("manifest", manifestJSON(it)) } },
                )
            }
            "configure" -> {
                val configObject = json.optJSONObject("config")
                    ?: return response(id, type, false, "Configuration caméra manquante.")
                val applied = service.configureCamera(configurationFromJSON(configObject)).get(15, TimeUnit.SECONDS)
                appendCameraStatus(
                    response(id, type, true)
                        .put("state", wireState())
                        .put("config", configurationJSON(applied)),
                )
            }
            "recordStart" -> {
                val config = json.optJSONObject("config")?.let(::configurationFromJSON)
                val startedNanos = service.startRemoteRecording(config).get(15, TimeUnit.SECONDS)
                appendCameraStatus(
                    response(id, type, true)
                        .put("state", "recording")
                        .put("recordingStartedAtMonotonicNanos", startedNanos),
                )
            }
            "recordStop" -> {
                val manifest = service.stopRemoteRecording().get(30, TimeUnit.SECONDS)
                response(id, type, true)
                    .put("state", wireState())
                    .put("manifest", manifestJSON(manifest))
            }
            "transferComplete" -> {
                val recordingID = json.optString("recordingID")
                if (recordingID.isBlank() || !service.markImported(recordingID)) {
                    response(id, type, false, "Enregistrement inconnu.")
                } else {
                    Log.i(TAG, "iPad confirmed validated import recording=${recordingID.take(8)}…")
                    response(id, type, true).put("state", wireState())
                }
            }
            else -> response(id, type, false, "Commande inconnue.")
        }
    }

    private fun acceptTransfer() {
        while (running.get()) {
            val socket = try {
                transferSocket?.accept() ?: break
            } catch (_: Throwable) {
                break
            }
            pool.execute { handleTransfer(socket) }
        }
    }

    private fun handleTransfer(socket: Socket) {
        var activeRecordingID: String? = null
        try {
            socket.use { client ->
                client.soTimeout = 20_000
                val input = client.getInputStream()
                val reader = BufferedReader(InputStreamReader(input, StandardCharsets.US_ASCII))
                val requestLine = reader.readLine() ?: return
                val headers = mutableMapOf<String, String>()
                while (true) {
                    val line = reader.readLine() ?: return
                    if (line.isEmpty()) break
                    val split = line.indexOf(':')
                    if (split > 0) headers[line.substring(0, split).trim().lowercase()] = line.substring(split + 1).trim()
                }
                val parts = requestLine.split(' ')
                if (parts.size < 2 || parts[0] != "GET") {
                    return sendStatus(client.getOutputStream(), 405, "Method Not Allowed")
                }
                val token = headers["authorization"]?.removePrefix("Bearer ")
                if (!CompanionRuntime.pairing.isAuthorized(token)) {
                    return sendStatus(client.getOutputStream(), 401, "Unauthorized")
                }
                val match = Regex("^/recordings/([A-Za-z0-9-]+)$").matchEntire(parts[1])
                    ?: return sendStatus(client.getOutputStream(), 404, "Not Found")
                val recordingID = match.groupValues[1]
                activeRecordingID = recordingID
                val file = service.finalizedFile(recordingID)
                    ?: return sendStatus(client.getOutputStream(), 404, "Not Found")
                val total = file.length()
                var start = 0L
                val range = headers["range"]
                if (range != null) {
                    val r = Regex("bytes=(\\d+)-").matchEntire(range)
                        ?: return sendStatus(client.getOutputStream(), 416, "Range Not Satisfiable")
                    start = r.groupValues[1].toLong()
                    if (start >= total) return sendStatus(client.getOutputStream(), 416, "Range Not Satisfiable")
                }

                service.markTransferStarted(recordingID)
                Log.i(TAG, "Transfer started recording=${recordingID.take(8)}… offset=$start total=$total")
                val output = client.getOutputStream()
                val remaining = total - start
                val status = if (start > 0) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"
                val header = buildString {
                    append(status).append("\r\n")
                    append("Content-Type: video/mp4\r\n")
                    append("Accept-Ranges: bytes\r\n")
                    append("Content-Length: $remaining\r\n")
                    if (start > 0) append("Content-Range: bytes $start-${total - 1}/$total\r\n")
                    append("Connection: close\r\n\r\n")
                }
                output.write(header.toByteArray(StandardCharsets.US_ASCII))
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(start)
                    val buffer = ByteArray(1024 * 1024)
                    var left = remaining
                    while (left > 0) {
                        val count = raf.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
                        if (count <= 0) break
                        output.write(buffer, 0, count)
                        left -= count
                    }
                    if (left != 0L) throw IllegalStateException("Transfer ended with $left bytes remaining")
                }
                output.flush()
                service.markTransferServed(recordingID)
                Log.i(TAG, "Transfer served recording=${recordingID.take(8)}…")
                activeRecordingID = null
            }
        } catch (t: Throwable) {
            activeRecordingID?.let(service::markTransferInterrupted)
            Log.w(TAG, "Transfer interrupted recording=${activeRecordingID?.take(8) ?: "unknown"}…", t)
        }
    }

    private fun advertise(controlPort: Int, transferPort: Int) {
        val manager = service.getSystemService(NsdManager::class.java)
        val info = NsdServiceInfo().apply {
            serviceName = "Perche Pixel ${android.os.Build.MODEL}"
            serviceType = "_perche-camera._tcp."
            port = controlPort
            setAttribute("transferPort", transferPort.toString())
            setAttribute(
                "deviceID",
                android.provider.Settings.Secure.getString(
                    service.contentResolver,
                    android.provider.Settings.Secure.ANDROID_ID,
                ) ?: UUID.randomUUID().toString(),
            )
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "NSD registered name=${serviceInfo.serviceName} type=${serviceInfo.serviceType} port=${serviceInfo.port}")
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD registration failed code=$errorCode")
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "NSD unregistered")
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "NSD unregister failed code=$errorCode")
            }
        }
        registrationListener = listener
        manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun localIPv4Address(): String? = runCatching {
        val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { it.isUp && !it.isLoopback }
        val addresses = interfaces.flatMap { Collections.list(it.inetAddresses) }
            .filterIsInstance<Inet4Address>()
            .filterNot { it.isLoopbackAddress }
        addresses.firstOrNull { it.isSiteLocalAddress }?.hostAddress
            ?: addresses.firstOrNull()?.hostAddress
    }.getOrNull()

    private fun appendCameraStatus(response: JSONObject): JSONObject {
        val diagnostics = service.cameraDiagnostics()
        response.put("cameraReady", service.cameraReady())
        response.put("previewActive", service.previewActive())
        diagnostics.selectedConfiguration?.let { response.put("selectedConfigurationID", it.id) }
        return response
    }

    private fun wireState(): String = when (CompanionRuntime.stateMachine.state) {
        CameraState.DISCONNECTED -> "disconnected"
        CameraState.READY -> "ready"
        CameraState.RECORDING -> "recording"
        CameraState.STOPPING -> "stopping"
        CameraState.TRANSFERRING -> "transferring"
        CameraState.ERROR -> "error"
    }

    private fun response(id: String?, type: String, ok: Boolean, message: String? = null): JSONObject = JSONObject().apply {
        if (id != null) put("id", id)
        put("type", type)
        put("ok", ok)
        if (message != null) put("message", message)
    }

    private fun configurationJSON(c: CameraConfiguration) = JSONObject().apply {
        put("id", c.id)
        put("lensLabel", c.lensLabel)
        put("width", c.width)
        put("height", c.height)
        put("fps", c.fps)
        put("stabilizationSupported", c.stabilizationSupported)
        put("stabilizationEnabled", c.stabilizationEnabled)
        put("audioEnabled", c.audioEnabled)
    }

    private fun configurationFromJSON(o: JSONObject) = CameraConfiguration(
        o.getString("id"),
        o.optString("lensLabel"),
        o.optInt("width"),
        o.optInt("height"),
        o.optInt("fps"),
        o.optBoolean("stabilizationSupported"),
        o.optBoolean("stabilizationEnabled"),
        o.optBoolean("audioEnabled", false),
    )

    private fun manifestJSON(m: RecordingManifest) = JSONObject().apply {
        put("recordingID", m.recordingID)
        put("filename", m.filename)
        put("sizeBytes", m.sizeBytes)
        put("sha256", m.sha256)
        put("createdAtISO8601", m.createdAtISO8601)
        put("durationSeconds", m.durationSeconds)
        put("width", m.width)
        put("height", m.height)
        put("nominalFPS", m.nominalFPS)
        put("lensLabel", m.lensLabel)
        put("orientation", m.orientation)
        put("transferPath", m.transferPath)
        m.finalizedAtISO8601?.let { put("finalizedAtISO8601", it) }
        put("transferState", m.transferState)
    }

    private fun sendStatus(output: OutputStream, code: Int, text: String) {
        output.write("HTTP/1.1 $code $text\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
        output.flush()
    }
}
