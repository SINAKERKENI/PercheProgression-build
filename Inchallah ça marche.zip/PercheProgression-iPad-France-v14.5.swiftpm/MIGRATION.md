# Migration v14.5 → v15.0.0

## Principes

La version 15 conserve le bundle identifier `com.tasnim.vaultroadmap.ipad` et le store SwiftData persistant `PercheProgressionFranceV4`. Aucun chemin de démarrage ne supprime ni ne recrée automatiquement le store.

## Évolution du schéma

- `OfficialPerformanceRecord` : performances officielles FFA, distinctes des tentatives locales.
- `PoleRecommendationDecisionRecord` : décision acceptée/refusée/ignorée avec version du moteur, direction, préparation et confiance de l’évidence.
- Métadonnées vidéo/mesure : provenance et qualité du pipeline perspective, ainsi que métadonnées de fichiers distants (dont identifiant d’enregistrement distant et SHA-256).
- `AthleteProfile` conserve les champs d’association/synchronisation FFA avec valeurs par défaut compatibles avec les profils non liés.
- `GoalActionRecord` conserve les champs nécessaires au type, à la récurrence, au focus, à l’archivage et au classement.

`PerformanceDimensionRecord` reste dans le schéma uniquement pour permettre l’ouverture des stores qui le contiennent déjà. La version 15 ne crée plus de nouveaux scores radar arbitraires et ne les affiche plus.

## Données préservées

La migration ne supprime pas automatiquement : profils, mesures corporelles, perches, profils d’élan, séances, tentatives, prises, vidéos, annotations, mesures physiques, exercices/bibliothèque vidéo, historique de progression ou personnalisations Harada.

Les performances FFA sont ajoutées de façon non destructive et dédupliquées par clé externe déterministe. Une erreur réseau ne supprime pas l’historique local déjà importé. Le record d’entraînement n’est jamais remplacé par un record officiel.

## Harada

Le nouveau modèle de piliers/actions est utilisé pour les nouveaux profils. `SeedService` ne réensemence pas une feuille de route existante lors d’une mise à jour et ne remplace donc pas les actions personnalisées de l’utilisateur.

## Validation restant à faire sur runtime Apple

L’environnement de construction utilisé pour cette livraison ne contient pas Xcode/les SDK Apple. L’ouverture binaire d’un vrai store SwiftData v14.5 avec l’application v15 doit donc encore être validée sur un runtime Apple/Xcode, idéalement après sauvegarde du conteneur de données réel.

## Correctif non destructif des vidéos Pixel v15.0–15.0.2

Certaines vidéos distantes pouvaient avoir été copiées dans le store média durable avec le suffixe de staging `source.partial`. v15.0.3 détecte uniquement les `VideoClipRecord` possédant une provenance Pixel (`remoteRecordingID`) et une clé média `.partial`.

La réparation :

1. conserve l’ancienne copie ;
2. vérifie son SHA-256 lorsqu’il est connu ;
3. dérive l’extension vidéo depuis `originalFilename` (MP4/MOV/M4V uniquement) ;
4. crée une nouvelle copie byte-identique avec le bon suffixe ;
5. valide cette copie avec AVFoundation ;
6. vérifie que le SHA-256 n’a pas changé ;
7. enregistre la nouvelle `mediaStorageKey` dans SwiftData ;
8. supprime l’ancienne copie `.partial` seulement après sauvegarde réussie.

En cas d’échec à n’importe quelle étape, l’ancienne copie reste intacte. Aucun reset de store SwiftData n’est effectué.
